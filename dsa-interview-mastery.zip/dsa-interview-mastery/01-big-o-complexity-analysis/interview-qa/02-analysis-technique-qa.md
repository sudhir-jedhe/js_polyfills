# Interview Q&A — Analysis Technique

**Q: How do you approach finding the time complexity of an unfamiliar piece of code?**
Identify the loops and recursive calls first. For loops: are they sequential (add complexities) or nested (multiply them)? Does an inner loop's bound depend on the outer variable (often still results in a polynomial, via a triangular-number sum)? For recursion: how many recursive calls does each invocation make, and how much does the input shrink each time — one call with input shrinking by a constant amount is usually linear, two-plus calls with the input merely decremented is usually exponential, and one or more calls with the input divided by a constant factor is usually logarithmic or linearithmic. Then combine loop-level and recursion-level costs and simplify to the dominant term.

**Q: When is Big-O analysis misleading, and what would you check instead?**
When constants, input size, or memory-access patterns dominate actual performance — e.g. for small, bounded `n`, or when comparing an algorithm with excellent asymptotic complexity but poor cache locality (frequent random-access jumps around memory) against a "worse" one that's cache-friendly (like scanning a contiguous array). In those cases, actual benchmarking on representative data and input sizes matters more than the asymptotic class alone.

**Q: What's the difference between analyzing a single call's cost and analyzing amortized cost across a sequence of calls?**
A single call's worst-case cost describes the most expensive that one invocation can ever be — e.g. a dynamic array's `push` can cost `O(n)` on the specific call that triggers a resize. Amortized analysis instead spreads the *total* cost of a sequence of `n` operations across all `n` of them, and asks what the average cost per operation is over that whole sequence — for `push`, that comes out to `O(1)` amortized, because resizes happen rarely enough (geometrically less often) that their cost, spread out, doesn't dominate.

**Q: How would you verify your theoretical Big-O analysis is actually correct?**
Empirically: run the function against a few increasing input sizes (e.g. doubling `n` each time) and observe how the runtime scales — `O(n)` should roughly double alongside `n`, `O(n²)` should roughly quadruple when `n` doubles, `O(log n)` should barely change. This isn't a substitute for correct theoretical analysis, but it's a fast sanity check that catches an accidentally-quadratic implementation of what was intended to be linear. See `../snippets/07-empirical-growth-rate-timer.js`.
