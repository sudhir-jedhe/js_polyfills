# Interview Q&A — Notation Fundamentals

**Q: What's the difference between Big O, Big Omega, and Big Theta?**
Big O is an upper bound — "grows no faster than." Big Omega is a lower bound — "grows no slower than." Big Theta is a tight bound — both an upper and lower bound simultaneously, meaning the algorithm's growth rate *is* that function, not just capped by it. In everyday interview usage, "Big O" is often used loosely to mean Big Theta (worst-case growth rate, exactly), even though formally Big O alone only promises an upper bound.

**Q: Why do we drop constants and lower-order terms in Big-O notation?**
Because asymptotic notation describes behavior as `n` approaches infinity, and at that scale, constant factors and additive lower-order terms become irrelevant to the growth *trend* — `O(3n + 100)` and `O(n)` describe the same underlying rate of growth, they only differ by constants that don't change how the function scales as `n` grows without bound. This is also why hardware speed differences don't affect Big-O classification — a faster machine changes the constant factor, not the growth rate.

**Q: Is O(n) always faster than O(n²)?**
Not for every specific `n` — only in the limit as `n` grows large. An `O(n²)` algorithm with tiny constants can outperform an `O(n)` algorithm with large constants or overhead for small or moderate `n`. Big-O describes asymptotic *trend*, not a guarantee at any particular input size; see `../scenarios/01-choosing-between-two-solutions-under-a-time-budget.md` for a concrete case where this matters.

**Q: What does it mean for an algorithm to be "O(1) space"?**
It means the *extra* memory the algorithm allocates, beyond the input itself, does not grow with input size — e.g. a fixed number of scalar variables, regardless of whether the input has 10 or 10 million elements. It does not mean "the algorithm uses zero memory" — it means that extra usage is bounded by a constant.

**Q: Can an algorithm's time complexity differ from its space complexity?**
Yes, and it's common — for example, an in-place array reversal is `O(n)` time (must visit every element) but `O(1)` space (swaps happen within the input array, no proportional extra allocation), while merge sort is `O(n log n)` time and (in typical implementations) `O(n)` space. The two are independent axes and should always be analyzed and reported separately.
