# Problem: Analyze and Optimize a Duplicate Finder

## Problem Statement

You're given a naive `containsDuplicate(arr)` function. State its exact time and space complexity, then rewrite it to be more efficient, stating the new complexity.

```js
function containsDuplicate(arr) {
  for (let i = 0; i < arr.length; i++) {
    for (let j = 0; j < arr.length; j++) {
      if (i !== j && arr[i] === arr[j]) return true;
    }
  }
  return false;
}
```

## Constraints

- `0 <= arr.length <= 10^5`
- Array elements can be any comparable primitive.

## Examples

```
containsDuplicate([1, 2, 3, 1]) → true
containsDuplicate([1, 2, 3, 4]) → false
containsDuplicate([]) → false
```

## Approach

The given version is `O(n²)` time (nested loop, both bounds `= arr.length`) and `O(1)` extra space. A hash-set-based single pass reduces this to `O(n)` time by trading in `O(n)` extra space — checking "have I seen this before?" via `Set.has` is `O(1)` average case, versus re-scanning the whole array for each element.

## Solution

```js
function containsDuplicateOptimized(arr) {
  const seen = new Set();
  for (const x of arr) {
    if (seen.has(x)) return true;
    seen.add(x);
  }
  return false;
}
```

## Complexity Analysis

| Version | Time | Space |
|---|---|---|
| Original nested loop | O(n²) | O(1) |
| Set-based single pass | O(n) | O(n) |

**Time:** `O(n)` — one pass over the array, with `O(1)` average-case `Set.has`/`Set.add` per element.
**Space:** `O(n)` — worst case, the `Set` holds up to `n` distinct elements before a duplicate is found (or if none exists at all).
