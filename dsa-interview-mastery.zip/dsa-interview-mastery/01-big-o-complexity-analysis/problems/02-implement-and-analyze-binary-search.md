# Problem: Implement Binary Search and Prove Its Complexity

## Problem Statement

Implement iterative binary search over a sorted array, and explain precisely why it's `O(log n)` rather than assuming it.

## Constraints

- Input array is sorted ascending, may contain up to `10^6` elements.
- Return the index of `target` if present, else `-1`.
- Must not use recursion (to also demonstrate O(1) space).

## Examples

```
binarySearch([1,3,5,7,9,11], 7)  → 3
binarySearch([1,3,5,7,9,11], 4)  → -1
binarySearch([], 5)              → -1
```

## Approach

Maintain a shrinking `[lo, hi]` window. Each iteration checks the midpoint and discards *half* of the remaining window based on the comparison — this halving is exactly what produces logarithmic growth: the window size after `k` iterations is `n / 2^k`, and the loop terminates once that reaches `< 1`, i.e. after `k = log2(n)` iterations.

## Solution

```js
function binarySearch(sortedArr, target) {
  let lo = 0;
  let hi = sortedArr.length - 1;

  while (lo <= hi) {
    const mid = lo + Math.floor((hi - lo) / 2); // avoids overflow in other languages; safe habit in JS too
    if (sortedArr[mid] === target) return mid;
    if (sortedArr[mid] < target) lo = mid + 1;
    else hi = mid - 1;
  }
  return -1;
}
```

## Complexity Analysis

**Time: O(log n).** Formally: let `T(n)` be the number of iterations for a window of size `n`. Each iteration does `O(1)` work and reduces the window to at most `n/2`. So `T(n) = T(n/2) + O(1)`. By the Master Theorem (`a=1, b=2, d=0`, and `a = b^d`), this resolves to `T(n) = O(log n)`.

**Space: O(1).** Only a fixed number of scalar variables (`lo`, `hi`, `mid`) are used, regardless of `n` — no recursion, so no call-stack growth either. (A recursive implementation of the same algorithm would still be `O(log n)` time but `O(log n)` space, from the recursion depth — worth mentioning as a follow-up point.)
