# Problem: Compute the Big-O of a Mystery Function (No Running Allowed)

## Problem Statement

Without executing any code, determine the exact time and space complexity of each function below, in terms of `n = arr.length`. Justify each answer.

```js
// (a)
function a(arr) {
  let n = arr.length;
  while (n > 1) {
    n = Math.floor(n / 2);
  }
}

// (b)
function b(arr) {
  for (let i = 0; i < arr.length; i++) {
    for (let j = 0; j < 100; j++) {
      console.log(arr[i]);
    }
  }
}

// (c)
function c(arr, n) {
  if (n <= 0) return;
  console.log(arr);
  c(arr.slice(1), n - 1);
}
```

## Constraints

None — this is a pure analysis exercise, not a coding one.

## Approach

For each snippet, identify: does the "size" being reduced shrink additively or multiplicatively? Is a bound a genuine variable proportional to `n`, or a fixed constant that happens to look like a loop? Does a recursive call allocate new memory each step?

## Solution / Complexity Analysis

**(a): O(log n) time, O(1) space.** `n` is halved (integer division by 2) each iteration, so the loop runs `log2(n)` times before `n` drops to 1. No extra data structures are allocated — just one scalar variable.

**(b): O(n) time, O(1) space.** The outer loop runs `n` times, but the inner loop runs exactly `100` times regardless of `n` — `100` is a **constant**, not a variable tied to input size, so it contributes a constant factor, not a second `n`. Total: `O(n · 100) = O(n)`. No proportional extra memory is allocated.

**(c): O(n) time, O(n²) space.** Time: this makes `n` recursive calls, each doing `O(1)` work outside the recursive call itself (the `console.log`), so `O(n)` time — the `.slice(1)` operation itself is `O(current length)`, but summed across all `n` calls (`n + (n-1) + ... + 1`), that additional cost is actually `O(n²)`, so time is really **O(n²)**, not O(n) — a common trap: it's easy to miss that `.slice()` isn't free. **Space:** each `.slice(1)` call allocates a brand new, slightly-shorter array (`O(current length)` each), and there are `n` such calls alive concurrently on the call stack until the base case — summing the sizes of all these live, simultaneously-allocated arrays across the recursion depth gives `O(n²)` space, on top of `O(n)` stack frames (which is dominated by the O(n²) array space). This snippet is a good example of how an innocent-looking one-liner (`arr.slice(1)`) hides real cost that changes the whole complexity picture.
