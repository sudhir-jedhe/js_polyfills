# Problem: Rotate an Array In Place — Reduce Space From O(n) to O(1)

## Problem Statement

Given an array `nums` and an integer `k`, rotate the array to the right by `k` steps. First write an `O(n)`-space solution, then optimize it to `O(1)` extra space while keeping `O(n)` time.

## Constraints

- `1 <= nums.length <= 10^5`
- `0 <= k <= 10^5` (k may exceed array length — must handle via modulo)

## Examples

```
rotate([1,2,3,4,5,6,7], 3) → [5,6,7,1,2,3,4]
rotate([-1,-100,3,99], 2)  → [3,99,-1,-100]
```

## Approach

**O(n) space:** build a new array by concatenating the last `k` elements with the first `n - k`.

**O(1) space:** use the "reverse three times" trick — reversing the whole array, then reversing each of the two resulting segments independently, produces the same result as a rotation, entirely in place with only pointer swaps.

## Solution

```js
// O(n) time, O(n) space
function rotateExtraSpace(nums, k) {
  const n = nums.length;
  k %= n;
  const rotated = [...nums.slice(n - k), ...nums.slice(0, n - k)];
  for (let i = 0; i < n; i++) nums[i] = rotated[i];
}

// O(n) time, O(1) extra space
function rotateInPlace(nums, k) {
  const n = nums.length;
  k %= n;

  const reverse = (arr, start, end) => {
    while (start < end) {
      [arr[start], arr[end]] = [arr[end], arr[start]];
      start++;
      end--;
    }
  };

  reverse(nums, 0, n - 1);       // reverse whole array
  reverse(nums, 0, k - 1);       // reverse first k (now the rotated-in tail)
  reverse(nums, k, n - 1);       // reverse the rest
}
```

## Complexity Analysis

| Version | Time | Space |
|---|---|---|
| Extra array | O(n) | O(n) |
| Three reversals | O(n) | O(1) |

**Time (both): O(n)** — each version touches every element a constant number of times (once for the copy version; three total passes, each O(n) but summing to O(n), for the reversal version — three passes over a total of n elements is still O(3n) = O(n)).
**Space (in-place version): O(1)** — only swaps values within the existing array using a constant number of extra scalar variables (`start`, `end`), no new array proportional to `n`.
