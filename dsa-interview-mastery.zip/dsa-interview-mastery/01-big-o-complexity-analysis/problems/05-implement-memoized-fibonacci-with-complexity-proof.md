# Problem: Implement Memoized Fibonacci and Prove the Complexity Improvement

## Problem Statement

Implement `fib(n)` two ways — naive recursion and memoized recursion — and formally justify why memoization changes the time complexity from exponential to linear.

## Constraints

- `0 <= n <= 40` for the naive version (larger will not finish in reasonable time)
- `0 <= n <= 10000` for the memoized version (limited only by stack depth / a `BigInt` overflow concern, not runtime)

## Examples

```
fib(0)  → 0
fib(1)  → 1
fib(10) → 55
```

## Approach

Naive recursion recomputes every subproblem from scratch across every path that reaches it — `fib(5)` and `fib(4)` both independently recompute `fib(3)`, `fib(2)`, etc. Memoization caches each subproblem's result the first time it's computed, so every distinct subproblem `fib(k)` for `k` from `0` to `n` is computed exactly once.

## Solution

```js
// Naive — O(2^n) time, O(n) space
function fibNaive(n) {
  if (n <= 1) return n;
  return fibNaive(n - 1) + fibNaive(n - 2);
}

// Memoized — O(n) time, O(n) space
function fibMemo(n, cache = new Map()) {
  if (n <= 1) return n;
  if (cache.has(n)) return cache.get(n);
  const result = fibMemo(n - 1, cache) + fibMemo(n - 2, cache);
  cache.set(n, result);
  return result;
}
```

## Complexity Analysis

**Naive: O(2ⁿ) time, O(n) space.** Recurrence `T(n) = T(n-1) + T(n-2) + O(1)`; this branches into two calls per invocation with the input decremented by a constant (not divided), producing a call tree with `O(2ⁿ)` nodes. Space is `O(n)` — only the single deepest active path down the tree is alive on the stack at any one time, since finished branches pop off before siblings execute.

**Memoized: O(n) time, O(n) space.** There are exactly `n + 1` distinct subproblems, `fib(0)` through `fib(n)`. Each is computed once (`O(1)` work per subproblem, ignoring the recursive calls themselves, which are covered by the cache after the first visit) and then served from `cache` on every subsequent request — total work is `O(n)`. Space is `O(n)` for the cache (`n + 1` entries) plus `O(n)` recursion depth, both linear, so `O(n)` overall.

**Why this generalizes:** any recursive algorithm with **overlapping subproblems** (the same subproblem reachable via multiple different call paths) is a memoization candidate — the technique converts "recompute every path" (often exponential) into "compute every distinct subproblem once" (often polynomial), at the cost of `O(number of distinct subproblems)` extra space.
