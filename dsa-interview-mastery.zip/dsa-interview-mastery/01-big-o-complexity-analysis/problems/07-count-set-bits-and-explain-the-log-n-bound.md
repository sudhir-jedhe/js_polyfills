# Problem: Count Set Bits in an Integer — Explain Why It's O(log n)

## Problem Statement

Implement a function that counts the number of `1` bits in the binary representation of a non-negative integer `n`, and explain precisely why the complexity is expressed in terms of `log n` rather than `n`.

## Constraints

- `0 <= n <= 2^31 - 1`

## Examples

```
countSetBits(11) → 3   (1011 in binary)
countSetBits(128) → 1  (10000000 in binary)
countSetBits(0) → 0
```

## Approach

Repeatedly strip the lowest set bit using `n & (n - 1)`, which clears the lowest `1` bit in one operation, and count how many times this can be done before `n` reaches 0. The number of iterations equals the number of set bits, which is bounded by the number of *bits* in `n`, not the *value* of `n` — and the number of bits needed to represent a value `n` is `⌈log2(n + 1)⌉`.

## Solution

```js
function countSetBits(n) {
  let count = 0;
  while (n !== 0) {
    n &= (n - 1); // clears the lowest set bit each iteration
    count++;
  }
  return count;
}
```

## Complexity Analysis

**Time: O(log n).** The loop runs once per set bit, and the maximum number of set bits an integer `n` can have is the number of bits needed to represent it in binary, which is `⌊log2(n)⌋ + 1`. This is the key distinction: the complexity is a function of the number of **bits** in the input (`log n` of it), not the numeric value of `n` itself directly — this is the same reasoning behind why numeric-input algorithms (like this one, or trial-division primality checks) are conventionally described in terms of `log n`, since the "size" of a number, in the information-theoretic sense relevant to computation, is its bit length, not its magnitude.

**Space: O(1).** Only the `count` and mutated `n` variables — no data structures proportional to input size.
