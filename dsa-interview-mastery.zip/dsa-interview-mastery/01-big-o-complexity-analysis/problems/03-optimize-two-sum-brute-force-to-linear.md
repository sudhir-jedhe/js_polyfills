# Problem: Optimize Two Sum from Brute Force to Linear

## Problem Statement

Given an array of integers `nums` and a target integer, return the indices of the two numbers that add up to `target`. Start from the brute-force solution, then optimize it, stating the complexity of each.

## Constraints

- Exactly one valid answer exists.
- You may not use the same element twice.
- `2 <= nums.length <= 10^4`

## Examples

```
twoSum([2, 7, 11, 15], 9) → [0, 1]   (2 + 7 = 9)
twoSum([3, 2, 4], 6)      → [1, 2]   (2 + 4 = 6)
```

## Approach

**Brute force:** check every pair — `O(n²)` time, `O(1)` space.

**Optimized:** for each element `x`, the only thing that matters is whether `target - x` has already been seen. A hash map from value → index, built incrementally in a single pass, answers that in `O(1)` average time per element, giving `O(n)` overall — this is the standard "complement lookup" pattern.

## Solution

```js
// Brute force — O(n^2) time, O(1) space
function twoSumBruteForce(nums, target) {
  for (let i = 0; i < nums.length; i++) {
    for (let j = i + 1; j < nums.length; j++) {
      if (nums[i] + nums[j] === target) return [i, j];
    }
  }
  return [];
}

// Optimized — O(n) time, O(n) space
function twoSum(nums, target) {
  const seen = new Map(); // value -> index
  for (let i = 0; i < nums.length; i++) {
    const complement = target - nums[i];
    if (seen.has(complement)) {
      return [seen.get(complement), i];
    }
    seen.set(nums[i], i);
  }
  return [];
}
```

## Complexity Analysis

| Version | Time | Space |
|---|---|---|
| Brute force | O(n²) | O(1) |
| Hash map | O(n) | O(n) |

**Time (optimized): O(n)** — single pass, `O(1)` average-case `Map.has`/`Map.get`/`Map.set` per element.
**Space (optimized): O(n)** — worst case, the map holds up to `n - 1` entries before the match is found.
