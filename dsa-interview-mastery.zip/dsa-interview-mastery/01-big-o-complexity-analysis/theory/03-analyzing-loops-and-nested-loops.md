# Analyzing Loops and Nested Loops

Most interview-level complexity analysis comes down to counting loop iterations. A handful of patterns cover the vast majority of cases.

## Single loop over n → O(n)

```js
for (let i = 0; i < n; i++) { /* O(1) work */ }
// O(n)
```

## Sequential (non-nested) loops → add them

```js
for (let i = 0; i < n; i++) { /* ... */ }   // O(n)
for (let j = 0; j < m; j++) { /* ... */ }   // O(m)
// O(n + m) — NOT O(n * m). These run one after another, not inside each other.
// If n and m are the same variable, O(n + n) = O(2n) = O(n).
```

A very common mistake is multiplying complexities of loops that are actually sequential rather than nested. Only nesting multiplies; sequencing adds.

## Nested loops over the same input → multiply

```js
for (let i = 0; i < n; i++) {
  for (let j = 0; j < n; j++) { /* O(1) work */ }
}
// O(n * n) = O(n^2)
```

## Nested loop where the inner bound depends on the outer variable

```js
for (let i = 0; i < n; i++) {
  for (let j = i; j < n; j++) { /* O(1) work */ }
}
// Inner loop runs n, n-1, n-2, ..., 1 times as i goes 0..n-1.
// Total iterations = n + (n-1) + ... + 1 = n(n+1)/2
// Still O(n^2) — the leading term dominates; constants and lower-order terms drop.
```

This "triangular" iteration count shows up constantly (e.g. comparing every pair once, like a naive duplicate-pair check) and it's still quadratic, not linear, even though the inner loop shrinks each time.

## Loop with a multiplicative step → logarithmic

```js
for (let i = 1; i < n; i *= 2) { /* O(1) work */ }
// i takes values 1, 2, 4, 8, ..., up to n → runs log2(n) times
// O(log n)
```

Whenever the loop variable is multiplied or divided each iteration (rather than incremented/decremented by a constant), suspect `O(log n)`.

## Loop that depends on two separate inputs

```js
function printAllPairs(arrA, arrB) {
  for (const a of arrA)       // n iterations
    for (const b of arrB)     // m iterations
      console.log(a, b);
}
// O(n * m) — NOT O(n^2), because n and m are genuinely different, independent sizes.
// Only write O(n^2) when both loops truly iterate over the same n.
```

## Nested loops doing different amounts of work per pass

```js
function example(arr) {
  for (const x of arr) {           // O(n)
    for (const y of arr) {         // O(n)
      process(x, y);               // O(1)
    }
  }
  for (const x of arr) process(x); // O(n), sequential — not nested with the above
}
// O(n^2) + O(n) = O(n^2) — lower-order term drops
```

## Quick reference

| Loop pattern | Complexity |
|---|---|
| Single pass | O(n) |
| Two sequential passes | O(n) (terms add, then simplify) |
| Nested, both over n | O(n²) |
| Nested, inner shrinks with outer (triangular) | O(n²) |
| Nested, over two different inputs n and m | O(n · m) |
| Loop variable multiplies/divides each step | O(log n) |
| Nested: outer O(n), inner O(log n) | O(n log n) |
