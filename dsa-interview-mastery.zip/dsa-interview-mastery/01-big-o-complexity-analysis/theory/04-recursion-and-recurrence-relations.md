# Analyzing Recursion: Recurrence Relations and the Master Theorem

Recursive functions can't be analyzed by "counting loop iterations" directly — instead you express the runtime as a **recurrence relation**: the cost of a call in terms of the cost of its recursive sub-calls, then solve (or approximate) that recurrence.

## Linear recursion

```js
function sum(arr, i = 0) {
  if (i >= arr.length) return 0;
  return arr[i] + sum(arr, i + 1);
}
```

Recurrence: `T(n) = T(n-1) + O(1)`. Each call does O(1) work and makes one recursive call on a problem one smaller. Unrolling: `T(n) = T(n-1) + 1 = T(n-2) + 2 = ... = T(0) + n`. **T(n) = O(n)** time. Space is also O(n), from n stacked call frames.

## Divide-and-conquer recursion (two sub-calls, each on half the input)

```js
function mergeSort(arr) {
  if (arr.length <= 1) return arr;
  const mid = Math.floor(arr.length / 2);
  const left = mergeSort(arr.slice(0, mid));   // T(n/2)
  const right = mergeSort(arr.slice(mid));      // T(n/2)
  return merge(left, right);                    // O(n) to merge
}
```

Recurrence: `T(n) = 2T(n/2) + O(n)`. This is the single most common recurrence shape in interviews (merge sort, most divide-and-conquer algorithms).

## The Master Theorem (lightweight version)

For recurrences of the form `T(n) = a·T(n/b) + O(n^d)`, where `a` = number of sub-calls, `b` = factor the input shrinks by, and `d` = exponent of the work done outside the recursive calls:

- If `a < b^d` → **T(n) = O(n^d)** (work outside dominates)
- If `a = b^d` → **T(n) = O(n^d · log n)** (work is balanced across all levels)
- If `a > b^d` → **T(n) = O(n^(log_b a))** (the recursive branching dominates)

Applying this to merge sort: `a = 2`, `b = 2`, `d = 1`. Since `2 = 2^1`, we're in the middle case: **T(n) = O(n log n)**.

Applying it to binary search — `T(n) = T(n/2) + O(1)`, so `a = 1`, `b = 2`, `d = 0`. Since `1 = 2^0`, again the middle case: **T(n) = O(log n)**.

Applying it to naive recursive Fibonacci — `T(n) = T(n-1) + T(n-2) + O(1)` doesn't fit the Master Theorem's shape at all (the sub-problems aren't `n/b`, they're `n-1` and `n-2`), which is a strong signal you're looking at exponential growth rather than divide-and-conquer — see below.

## Exponential recursion (tree branches faster than input shrinks)

```js
function fib(n) {
  if (n <= 1) return n;
  return fib(n - 1) + fib(n - 2); // two calls, each only slightly smaller
}
```

Each call spawns two more calls, and the input barely shrinks (by 1, not by half) — the recursion tree has roughly `2^n` nodes. **T(n) = O(2^n)** time, O(n) space (the deepest single path down the tree, since stack frames from already-returned branches are freed). This is why naive recursive Fibonacci is a canonical example of "correct but exponential" — see `05-common-complexity-classes.md` for how memoization fixes it.

## Practical shortcut for interviews

You rarely need to formally solve a recurrence live. Instead:
1. Count how many recursive calls each invocation makes (`a`).
2. Note how much smaller the input gets each time (`/b`, or `-1`).
3. Note the non-recursive work per call (`O(n^d)`).
4. If it's "one call, input shrinks by a constant factor or amount" → linear or logarithmic.
5. If it's "two-plus calls, input shrinks by a constant factor" → apply Master Theorem intuition (usually `O(n log n)`).
6. If it's "two-plus calls, input shrinks by a constant amount (not factor)" → exponential.
