# Amortized Analysis, and Best/Average/Worst Case

Two related but distinct ideas that interviewers often conflate on purpose to see if you'll untangle them: **case analysis** (does the input matter?) and **amortized analysis** (does averaging over a *sequence* of operations matter?).

## Best, average, and worst case

These describe how an algorithm's cost varies depending on **which input** of size `n` you feed it.

```js
function linearSearch(arr, target) {
  for (let i = 0; i < arr.length; i++) {
    if (arr[i] === target) return i;
  }
  return -1;
}
```

- **Best case — Ω(1):** target is `arr[0]`, loop exits on the first comparison.
- **Worst case — O(n):** target is `arr[n-1]` or absent entirely, every element is checked.
- **Average case — Θ(n):** assuming a uniformly random position (or absence), expected comparisons are proportional to `n/2`, which is still `Θ(n)` after dropping the constant.

Interviews default to **worst case** unless stated otherwise, because it's the guarantee that holds regardless of input — you can't rely on getting lucky in production. Quicksort is the sharpest example of why this distinction matters:

| Case | Quicksort complexity | When it happens |
|---|---|---|
| Best/average | O(n log n) | Pivot roughly splits the array in half each time |
| Worst | O(n²) | Pivot is always the min/max (e.g. already-sorted input with a naive "always pick first element" pivot) |

This is exactly why interviewers expect you to know quicksort's worst case is quadratic, even though "quicksort is O(n log n)" is the common shorthand.

## Amortized analysis

Amortized analysis answers a different question: given a **sequence of operations**, what's the *average cost per operation over the whole sequence*, even if individual operations occasionally spike in cost? This is not the same as "average case" above — amortized analysis holds for *any* input, it's about spreading out occasional expensive operations across many cheap ones.

### Classic example: dynamic array (JS `Array.push`) resizing

JS arrays grow dynamically. When a backing array is full, `push` triggers a reallocation: a new, larger array is allocated (typically double the size) and every existing element is copied over.

```js
const arr = [];
for (let i = 0; i < n; i++) {
  arr.push(i); // usually O(1), but occasionally O(k) when a resize is triggered
}
```

If capacity doubles every time it fills (1, 2, 4, 8, 16, ...), then across `n` pushes, the total cost of *all* the resize-copies combined is `1 + 2 + 4 + ... + n ≈ 2n` — still `O(n)` total copy work over `n` pushes. Spread evenly, that's `O(n) / n = O(1)` **amortized** per push, even though any individual push might occasionally cost `O(n)` in the worst case (right when a resize fires).

| Push # | Capacity before | Action | Actual cost |
|---|---|---|---|
| 1 | 0 | allocate cap=1 | O(1) |
| 2 | 1 | resize to cap=2, copy 1 | O(1) |
| 3 | 2 | resize to cap=4, copy 2 | O(2) |
| 5 | 4 | resize to cap=8, copy 4 | O(4) |
| 9 | 8 | resize to cap=16, copy 8 | O(8) |

Total cost through push 9: roughly `9 + (1+2+4+8) = 24`, which is `O(n)` for `n=9` pushes — i.e. **O(1) amortized** per push, not O(n). The key insight: doubling (geometric growth) is what makes this work — if the array grew by a *fixed* amount (e.g. +1 slot) instead of doubling, you'd trigger a resize on nearly every push, and the amortized cost would degrade to O(n) per push.

## Amortized vs worst-case vs average-case — don't conflate them

| Concept | Question it answers | Example |
|---|---|---|
| Worst case | Slowest possible single call, over all inputs | `push` can cost O(n) on a resizing call |
| Average case | Expected cost for a "typical" random input | Randomized quicksort pivot selection |
| Amortized | Average cost per op, summed over a *sequence*, valid for every input | `push` is O(1) amortized, even though worst-case single call is O(n) |

Amortized analysis is not about probability or "typical" inputs at all — it's a guarantee that holds for *every* sequence of operations, which is what makes `array.push` reliably described as "O(1) amortized" in every JS reference, not just on average.
