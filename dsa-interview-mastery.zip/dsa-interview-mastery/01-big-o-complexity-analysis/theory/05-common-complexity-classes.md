# Common Complexity Classes, with Real Examples

Ranked from fastest-growing to slowest-growing, here are the complexity classes you'll actually use in interviews.

## O(1) — Constant

Work is independent of input size.

```js
function firstElement(arr) {
  return arr[0]; // always exactly one operation, regardless of arr.length
}
```
Array index access, push/pop at the end of an array, hash map get/set (average case) are all O(1).

## O(log n) — Logarithmic

Work halves (or is divided by a constant factor) each step.

```js
function binarySearch(sortedArr, target) {
  let lo = 0, hi = sortedArr.length - 1;
  while (lo <= hi) {
    const mid = (lo + hi) >> 1;
    if (sortedArr[mid] === target) return mid;
    if (sortedArr[mid] < target) lo = mid + 1;
    else hi = mid - 1;
  }
  return -1;
}
// Each iteration eliminates half the remaining search space → log2(n) iterations
```
Balanced binary search tree operations and binary search itself are the classic examples. Doubling `n` only adds *one* more step — this is why O(log n) is considered extremely fast.

## O(n) — Linear

Work scales directly with input size — a single pass.

```js
function findMax(arr) {
  let max = -Infinity;
  for (const x of arr) if (x > max) max = x; // must look at every element
  return max;
}
```

## O(n log n) — Linearithmic

Typical of efficient comparison-based sorting: `n` levels of work, each doing O(log n)-related splitting, or `log n` levels each doing O(n) work.

```js
function mergeSortLength(arr) {
  return arr.slice().sort((a, b) => a - b); // built-in sort: O(n log n)
}
```
`Array.prototype.sort` in modern JS engines (TimSort in V8) is O(n log n). Merge sort and quicksort (average case) are the textbook algorithms in this class.

## O(n²) — Quadratic

Nested loops over the same input — comparing every element to every other element.

```js
function hasDuplicatePair(arr) {
  for (let i = 0; i < arr.length; i++)
    for (let j = i + 1; j < arr.length; j++)
      if (arr[i] === arr[j]) return true;
  return false;
}
```
Bubble sort, insertion sort, selection sort, and any brute-force "compare all pairs" approach land here. Fine for small `n` (dozens to low hundreds), painful beyond that.

## O(2^n) — Exponential

Each additional input element doubles the work — typically from branching recursion that tries all subsets or all combinations.

```js
function powerSet(arr) {
  if (arr.length === 0) return [[]];
  const [first, ...rest] = arr;
  const withoutFirst = powerSet(rest);
  const withFirst = withoutFirst.map(subset => [first, ...subset]);
  return [...withoutFirst, ...withFirst];
}
// 2^n subsets exist, so this must be at least O(2^n)
```
Generating all subsets, naive recursive Fibonacci, and brute-force traveling-salesman are canonical O(2^n) problems. Only tractable for small `n` (roughly n < 25-30).

## O(n!) — Factorial

Generating all permutations of `n` items — even worse than exponential, only tractable for tiny `n` (roughly n < 10-11).

```js
function permutations(arr) {
  if (arr.length <= 1) return [arr];
  const result = [];
  for (let i = 0; i < arr.length; i++) {
    const rest = [...arr.slice(0, i), ...arr.slice(i + 1)];
    for (const perm of permutations(rest)) result.push([arr[i], ...perm]);
  }
  return result;
}
```

## Growth comparison at a glance

| n | O(log n) | O(n) | O(n log n) | O(n²) | O(2ⁿ) |
|---|---|---|---|---|---|
| 10 | ~3 | 10 | ~33 | 100 | 1,024 |
| 20 | ~4 | 20 | ~86 | 400 | 1,048,576 |
| 50 | ~6 | 50 | ~282 | 2,500 | ~10^15 |

The gap between O(n log n) and O(n²) — and especially between polynomial and exponential — is why the jump from a brute-force to an optimized solution matters far more than micro-optimizing constants.
