# Asymptotic Notation: Big O, Big Omega, Big Theta

Asymptotic notation describes how an algorithm's resource usage (time or space) grows as the input size `n` grows towards infinity, ignoring constant factors and lower-order terms. It answers "how does this scale?" rather than "how many milliseconds does this take on my laptop?" — machine speed, language, and constant-time overhead vary, but growth *rate* is a property of the algorithm itself.

## Big O — upper bound (worst case growth)

`f(n) = O(g(n))` means `f(n)` grows **no faster than** `g(n)`, up to a constant factor, for sufficiently large `n`. Formally, there exist constants `c > 0` and `n0` such that `f(n) <= c * g(n)` for all `n >= n0`. This is the notation used almost universally in interviews because it caps how bad things can get.

```js
function containsValue(arr, target) {
  for (let i = 0; i < arr.length; i++) {   // runs up to n times
    if (arr[i] === target) return true;
  }
  return false;
}
// O(n): in the worst case (target absent, or last element), we touch every element.
```

## Big Omega — lower bound (best case growth)

`f(n) = Ω(g(n))` means `f(n)` grows **at least as fast as** `g(n)` — a floor on the work required. For `containsValue` above, the best case is `Ω(1)` (target is the first element, loop exits immediately). Omega is used far less often in interviews than Big O, but it's useful for describing algorithms that *must* touch all input, e.g. summing an array is `Ω(n)` because you cannot sum n numbers without reading all of them.

## Big Theta — tight bound (exact growth rate)

`f(n) = Θ(g(n))` means `f(n)` is bounded both above and below by `g(n)` (up to constants) — the algorithm's growth rate *is* `g(n)`, not just capped by it. Summing every element of an array is `Θ(n)`: it is both `O(n)` (never worse) and `Ω(n)` (never better, must read every element). When people casually say "Big O" in interviews, they usually mean this tighter, both-bounds sense, even though technically Big O alone only promises an upper bound.

## Why the distinction matters in practice

| Notation | Bound type | Interview usage |
|---|---|---|
| `O(g(n))` | Upper bound ("at most") | Default choice — describes worst-case guarantee |
| `Ω(g(n))` | Lower bound ("at least") | Rare — used to prove an algorithm *can't* be faster |
| `Θ(g(n))` | Tight bound ("exactly") | Used when best and worst case coincide |

A search through an unsorted array is `O(n)` worst case but `Ω(1)` best case — these bounds differ, so no single `Θ` applies to the algorithm's *worst-case behavior* alone; you'd say the worst case is `Θ(n)` and the best case is `Θ(1)` separately. Interviewers rarely quiz the Greek-letter distinctions directly, but using "Big O" to mean "worst case, ignoring constants" and being able to explain best/worst/average case separately (see `06-best-average-worst-case.md`) is what actually gets evaluated.

## Dropping constants and lower-order terms

`O(2n + 100)` simplifies to `O(n)` — constants and additive lower-order terms vanish because they're irrelevant at scale:

```js
function example(arr) {
  console.log(arr[0]);              // O(1)
  console.log(arr[1]);               // O(1)
  for (const x of arr) console.log(x); // O(n)
}
// Total: O(1) + O(1) + O(n) = O(n + 2) → simplified to O(n)
```

This is why `O(n)` and `O(n/2)` are considered the *same* complexity class — the constant factor `1/2` doesn't change how the runtime scales as `n → ∞`.
