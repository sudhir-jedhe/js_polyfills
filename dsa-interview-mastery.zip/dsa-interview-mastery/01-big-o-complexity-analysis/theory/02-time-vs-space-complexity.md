# Time Complexity vs Space Complexity

Every algorithm has two costs worth analyzing independently: **time complexity** (how the number of operations grows with input size) and **space complexity** (how the amount of extra memory grows with input size). Interviewers expect both, and expect you to recognize the classic time/space tradeoff — using more memory to go faster, or vice versa.

## Time complexity

Counts the number of "basic operations" (comparisons, arithmetic, assignments) as a function of `n`, not wall-clock seconds.

```js
function sum(arr) {
  let total = 0;
  for (const n of arr) total += n; // n additions
  return total;
}
// Time: O(n) — one pass, one operation per element
```

## Space complexity

Counts extra memory used **beyond the input itself** as a function of `n` — this is the critical, commonly-missed detail. Input storage doesn't count toward space complexity; only *additional* structures your algorithm allocates do.

```js
function double(arr) {
  const result = [];
  for (const n of arr) result.push(n * 2);
  return result;
}
// Space: O(n) — result grows linearly with the input
```

```js
function doubleInPlace(arr) {
  for (let i = 0; i < arr.length; i++) arr[i] *= 2;
  return arr;
}
// Space: O(1) — no new structure proportional to n; mutates the input in place
```

Both functions are `O(n)` time (one pass), but they differ in space: `O(n)` extra vs `O(1)` extra. This is exactly the kind of distinction interviewers probe for — "can you do this in-place?"

## Call stack space counts too

Recursive solutions consume space on the call stack, and that counts toward space complexity even though no explicit array or object was allocated:

```js
function factorial(n) {
  if (n <= 1) return 1;
  return n * factorial(n - 1); // n stacked calls before any returns
}
// Time: O(n) — n multiplications
// Space: O(n) — n stack frames alive simultaneously at the deepest point of recursion
```

An iterative version of the same computation is `O(1)` space, since it uses a single loop variable rather than a growing call stack — a common recursion-to-iteration tradeoff.

## The time/space tradeoff

Using extra memory can often buy a faster runtime. Classic example: checking for duplicates.

```js
// O(n^2) time, O(1) extra space — nested loop, no extra memory
function hasDuplicateSlow(arr) {
  for (let i = 0; i < arr.length; i++)
    for (let j = i + 1; j < arr.length; j++)
      if (arr[i] === arr[j]) return true;
  return false;
}

// O(n) time, O(n) extra space — trade memory for speed
function hasDuplicateFast(arr) {
  const seen = new Set();
  for (const n of arr) {
    if (seen.has(n)) return true;
    seen.add(n);
  }
  return false;
}
```

| Approach | Time | Space | When to prefer |
|---|---|---|---|
| Nested loop | O(n²) | O(1) | Memory-constrained, `n` is small |
| Hash set | O(n) | O(n) | Memory is available, `n` is large — almost always the right call |

In interviews, stating both complexities and explicitly naming the tradeoff you're making (and why) is often worth more than silently picking the "optimal" solution.
