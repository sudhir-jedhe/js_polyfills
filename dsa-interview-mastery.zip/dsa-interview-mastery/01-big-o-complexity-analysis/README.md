# Big O & Complexity Analysis

Complexity analysis is the language interviewers use to evaluate every other DSA topic — before discussing arrays, trees, or dynamic programming, you need a precise, defensible way to describe how an algorithm's time and memory usage scale with input size. This topic covers Big O/Omega/Theta notation, how to analyze loops and recursion (including recurrence relations and a lightweight Master Theorem), the standard complexity classes from O(1) to O(n!), amortized analysis (why `array.push` is "O(1) amortized" rather than plain O(1)), and best/average/worst case reasoning. Getting this right matters because every later topic's solutions are judged against it — a "correct" answer with the wrong stated Big-O is usually treated as an incomplete answer in interviews.

## Folder structure

- **`theory/`** — asymptotic notation (O/Ω/Θ), time vs space complexity, analyzing loops & nested loops, recursion & recurrence relations (with a lightweight Master Theorem), the standard complexity classes with real code examples, and amortized analysis alongside best/average/worst case.
- **`snippets/`** — 7 runnable examples: constant vs linear lookup, binary search, nested-loop vs hash-set tradeoff, recursive vs iterative space, memoized Fibonacci, simulated dynamic-array doubling, and an empirical growth-rate timer.
- **`output-based/`** — 6 "what's the time/space complexity of this?" questions covering sequential loops, multi-input nested loops, string concatenation, recursion-plus-merge, hash-map frequency counting, and branching recursion.
- **`scenarios/`** — 4 real-world engineering scenarios: choosing between two correct solutions under a latency/memory budget, diagnosing a production slowdown that scales nonlinearly, explaining a tradeoff to a non-technical stakeholder, and picking a caching strategy for overlapping subproblems.
- **`interview-qa/`** — 3 themed Q&A files: notation fundamentals, analysis technique, and amortized/case analysis.
- **`problems/`** — 7 hands-on coding challenges, each optimizing a brute-force solution and formally justifying the resulting complexity: duplicate finder, binary search, two sum, a mystery-function analysis exercise, memoized Fibonacci, in-place array rotation, and bit counting.
- **`assets/`** — placeholder for diagrams (see `assets/README.md`).

## What's covered

- Big O, Big Omega, Big Theta — precise definitions and when each is used
- Time complexity vs space complexity, analyzed independently, including call-stack space
- Analyzing loops: sequential vs nested, triangular iteration counts, multiplicative-step loops
- Recursion and recurrence relations, with a practical (non-formal-proof) walkthrough of the Master Theorem
- The standard complexity classes — O(1), O(log n), O(n), O(n log n), O(n²), O(2ⁿ), O(n!) — each with a concrete code example
- Amortized analysis, using dynamic-array resizing (`Array.push`) as the canonical example
- Best/average/worst case, and why interviews default to worst case
- Hands-on: optimizing brute-force solutions (duplicate detection, two sum, array rotation) while proving the resulting complexity, not just asserting it
