Placeholder for diagrams (growth-rate charts, recursion trees, etc.) related to this topic. Nothing here yet.
