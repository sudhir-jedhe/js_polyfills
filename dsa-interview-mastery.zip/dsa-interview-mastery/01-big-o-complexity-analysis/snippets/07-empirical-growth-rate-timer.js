// A small harness to empirically observe growth rate — useful for sanity-checking
// your Big-O analysis by watching how runtime scales as n increases.

function timeIt(fn, n) {
  const arr = Array.from({ length: n }, () => Math.floor(Math.random() * n));
  const start = performance.now();
  fn(arr);
  return performance.now() - start;
}

function linearScan(arr) {
  let sum = 0;
  for (const x of arr) sum += x;
  return sum;
}

function quadraticScan(arr) {
  let count = 0;
  for (let i = 0; i < arr.length; i++)
    for (let j = 0; j < arr.length; j++)
      if (arr[i] === arr[j]) count++;
  return count;
}

for (const n of [1_000, 2_000, 4_000, 8_000]) {
  console.log(`n=${n}  linear=${timeIt(linearScan, n).toFixed(2)}ms  quadratic=${timeIt(quadraticScan, n).toFixed(2)}ms`);
}
// Expect: linear time roughly doubles alongside n (as expected for O(n)),
// while quadratic time roughly quadruples each time n doubles (as expected for O(n^2)) —
// a quick empirical gut-check against the theoretical Big-O analysis.
