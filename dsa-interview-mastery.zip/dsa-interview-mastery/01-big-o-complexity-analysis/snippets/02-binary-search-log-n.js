// O(log n): binary search on a sorted array — halves the search space each iteration

function binarySearch(sortedArr, target) {
  let lo = 0;
  let hi = sortedArr.length - 1;
  let steps = 0;

  while (lo <= hi) {
    steps++;
    const mid = (lo + hi) >> 1; // integer midpoint
    if (sortedArr[mid] === target) {
      console.log(`found at index ${mid} in ${steps} step(s)`);
      return mid;
    }
    if (sortedArr[mid] < target) lo = mid + 1;
    else hi = mid - 1;
  }
  console.log(`not found, checked ${steps} step(s)`);
  return -1;
}

const sorted = Array.from({ length: 1_000_000 }, (_, i) => i);
binarySearch(sorted, 999999); // ~20 steps, not 1,000,000 — log2(1,000,000) ≈ 20
binarySearch(sorted, 0);      // ~20 steps as well — worst case is bounded by depth, not position
