// O(n^2) nested-loop pair check vs O(n) hash-set version — the classic time/space tradeoff

// O(n^2) time, O(1) extra space
function hasPairWithSumSlow(arr, target) {
  for (let i = 0; i < arr.length; i++) {
    for (let j = i + 1; j < arr.length; j++) {
      if (arr[i] + arr[j] === target) return true;
    }
  }
  return false;
}

// O(n) time, O(n) extra space
function hasPairWithSumFast(arr, target) {
  const seen = new Set();
  for (const n of arr) {
    if (seen.has(target - n)) return true;
    seen.add(n);
  }
  return false;
}

const data = [2, 7, 11, 15, 3, 6, 9];
console.log(hasPairWithSumSlow(data, 26)); // true (11 + 15), O(n^2) work
console.log(hasPairWithSumFast(data, 26)); // true (11 + 15), O(n) work
