// Simulating dynamic-array doubling to visualize amortized O(1) push

class DynamicArray {
  constructor() {
    this._store = new Array(1);
    this._length = 0;
    this.totalCopies = 0; // tracks total element-copy work across all pushes
  }

  push(value) {
    if (this._length === this._store.length) {
      const bigger = new Array(this._store.length * 2); // double capacity
      for (let i = 0; i < this._length; i++) {
        bigger[i] = this._store[i];
        this.totalCopies++; // O(current size) copy cost on a resize
      }
      this._store = bigger;
    }
    this._store[this._length++] = value;
  }
}

const da = new DynamicArray();
const n = 1000;
for (let i = 0; i < n; i++) da.push(i);

console.log(`pushes: ${n}`);
console.log(`total copy operations across all resizes: ${da.totalCopies}`);
console.log(`amortized copies per push: ${(da.totalCopies / n).toFixed(2)}`);
// totalCopies stays roughly proportional to n (never exceeds ~2n), so the
// amortized cost per push stays O(1) even though individual resizing
// pushes are O(current length) in that single call.
