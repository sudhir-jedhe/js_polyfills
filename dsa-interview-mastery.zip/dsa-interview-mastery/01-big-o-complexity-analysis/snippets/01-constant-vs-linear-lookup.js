// O(1) vs O(n) lookup, side by side

// O(1): array index access — direct memory offset calculation, independent of array length
function getFirst(arr) {
  return arr[0];
}

// O(n): linear search — must potentially inspect every element
function indexOfValue(arr, target) {
  for (let i = 0; i < arr.length; i++) {
    if (arr[i] === target) return i;
  }
  return -1;
}

const big = Array.from({ length: 1_000_000 }, (_, i) => i);
console.log(getFirst(big));           // instant, regardless of array size
console.log(indexOfValue(big, 999999)); // slowest possible case: last element
