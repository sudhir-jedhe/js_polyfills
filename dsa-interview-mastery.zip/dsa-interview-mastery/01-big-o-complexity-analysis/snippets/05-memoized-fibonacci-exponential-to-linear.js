// O(2^n) naive recursion vs O(n) memoized version — same result, wildly different growth

function fibNaive(n) {
  if (n <= 1) return n;
  return fibNaive(n - 1) + fibNaive(n - 2);
}
// Time: O(2^n) — the call tree roughly doubles in size with each increment of n
// Space: O(n) — deepest single path down the recursion tree

function fibMemoized(n, cache = new Map()) {
  if (n <= 1) return n;
  if (cache.has(n)) return cache.get(n);
  const result = fibMemoized(n - 1, cache) + fibMemoized(n - 2, cache);
  cache.set(n, result);
  return result;
}
// Time: O(n) — each subproblem 0..n is computed exactly once, then cached
// Space: O(n) — cache holds n entries, plus O(n) recursion depth

console.time('naive');
console.log(fibNaive(28)); // already noticeably slow at n=28
console.timeEnd('naive');

console.time('memoized');
console.log(fibMemoized(50)); // instant even at n=50, where naive would never finish
console.timeEnd('memoized');
