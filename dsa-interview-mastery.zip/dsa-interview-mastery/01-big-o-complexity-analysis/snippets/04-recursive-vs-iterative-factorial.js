// Same O(n) time, different O(n) vs O(1) space — recursion costs call-stack frames

function factorialRecursive(n) {
  if (n <= 1) return 1;
  return n * factorialRecursive(n - 1);
}
// Time: O(n) — n multiplications
// Space: O(n) — n stack frames alive at the deepest point before any return

function factorialIterative(n) {
  let result = 1;
  for (let i = 2; i <= n; i++) result *= i;
  return result;
}
// Time: O(n) — same n multiplications
// Space: O(1) — a single loop variable, no growing call stack

console.log(factorialRecursive(10)); // 3628800
console.log(factorialIterative(10)); // 3628800
