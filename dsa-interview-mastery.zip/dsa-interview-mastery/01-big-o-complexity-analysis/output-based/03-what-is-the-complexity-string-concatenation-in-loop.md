# What's the Time Complexity? — String Building in a Loop

```js
function buildString(n) {
  let result = '';
  for (let i = 0; i < n; i++) {
    result += 'x'; // string concatenation
  }
  return result;
}
```

**Question:** Is this `O(n)`?

**Answer:** `O(n²)` in the worst case for engines that treat strings as immutable fixed-size buffers — though modern JS engines optimize this specific pattern well in practice. The theoretically-correct, engine-agnostic answer is `O(n²)`.

**Why:** Strings in JavaScript are immutable. Conceptually, `result += 'x'` doesn't mutate `result` in place — it must allocate an entirely new string of length `i + 1` and copy all `i` existing characters into it, then append the new one. Across `n` iterations, that's `1 + 2 + 3 + ... + n = n(n+1)/2` character copies in total, which is `O(n²)`.

**Important caveat:** V8 (Node.js/Chrome) and most modern engines internally use "rope" or "cons string" representations that defer actual concatenation, making repeated `+=` in a tight loop perform close to `O(n)` amortized in practice. This nuance is worth mentioning in an interview (it shows depth), but the theoretically correct, portable answer — the one that holds regardless of engine internals, and the one true for languages without this optimization — is `O(n²)`, and the safe, portable fix is to push segments into an array and `join('')` once at the end:

```js
function buildStringFast(n) {
  const parts = [];
  for (let i = 0; i < n; i++) parts.push('x');
  return parts.join(''); // O(n) — array push is O(1) amortized, one O(n) join at the end
}
```
