# What's the Time Complexity? — Recursion With a Loop Inside

```js
function mystery(arr) {
  if (arr.length <= 1) return arr;
  const mid = Math.floor(arr.length / 2);
  const left = mystery(arr.slice(0, mid));
  const right = mystery(arr.slice(mid));

  const merged = [];
  let i = 0, j = 0;
  while (i < left.length && j < right.length) { // O(n) merge step
    merged.push(left[i] <= right[j] ? left[i++] : right[j++]);
  }
  return [...merged, ...left.slice(i), ...right.slice(j)];
}
```

**Answer:** `O(n log n)` time, `O(n log n)` space (see below).

**Why:** This is merge sort. The recurrence is `T(n) = 2T(n/2) + O(n)` — two recursive calls on half the input each, plus `O(n)` work to merge (and `O(n)` work for the two `.slice()` calls that split the array, which also count toward that same linear term). By the Master Theorem (`a=2, b=2, d=1`, and `a = b^d`), this resolves to `T(n) = O(n log n)`.

**Space is the sneaky part:** `arr.slice()` allocates new arrays at every level of recursion rather than working on the original array in place, and the `merged` array plus the spread at the end allocate more new arrays too. Each of the `log n` levels of recursion allocates `O(n)` total space (across all calls at that level combined), giving `O(n log n)` auxiliary space here — worse than the `O(n)` space a more careful, buffer-reusing merge sort implementation could achieve. This is a common follow-up interviewers ask: "can you reduce the space?" — the answer is to merge into a single reused auxiliary buffer instead of slicing new arrays at every recursive call.
