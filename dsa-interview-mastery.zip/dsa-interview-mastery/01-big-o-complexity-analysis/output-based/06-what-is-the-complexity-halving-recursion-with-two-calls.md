# What's the Time Complexity? — Binary Tree of Recursive Calls

```js
function countPaths(n) {
  if (n <= 0) return 1;
  return countPaths(n - 1) + countPaths(n - 1); // two calls, SAME reduced size
}
```

**Question:** Is this `O(n)` because the input only decreases by 1 each call, like linear recursion?

**Answer:** `O(2ⁿ)` — exponential, not linear.

**Why:** It's a common trap to assume "input shrinks by 1 → linear," but that reasoning only holds for a *single* recursive call per invocation. Here, every call to `countPaths(n)` spawns **two** calls to `countPaths(n - 1)`, forming a full binary recursion tree of depth `n`. The number of leaf calls at depth `n` is `2ⁿ`, and the total number of calls across the whole tree is also `O(2ⁿ)` (a geometric series dominated by its last level). Contrast this directly with `04-recursion-and-recurrence-relations.md`'s linear-recursion example (`sum(arr, i+1)`), which makes exactly **one** recursive call per invocation and is `O(n)` — the number of recursive calls made per invocation (the branching factor) matters just as much as how fast the input shrinks. Space, notably, is still only `O(n)` here — the deepest single path down the tree before the first `return` — since sibling branches don't coexist in memory once they've returned.
