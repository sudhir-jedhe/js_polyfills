# What's the Time Complexity? — Two Different-Sized Inputs

```js
function hasCommonElement(arrA, arrB) {
  for (const a of arrA) {
    for (const b of arrB) {
      if (a === b) return true;
    }
  }
  return false;
}
```

**Question:** If `arrA` has length `n` and `arrB` has length `m`, what's the time complexity? Is it `O(n²)`?

**Answer:** `O(n · m)` — **not** `O(n²)`.

**Why:** It's tempting to see a nested loop and immediately write `O(n²)`, but that shorthand only applies when *both* loops iterate over the same-sized collection. Here, the outer loop runs `n` times and the inner loop runs `m` times *independently* — `n` and `m` are two genuinely different variables that could be wildly different sizes (e.g. `arrA` has 5 elements, `arrB` has 5,000,000). Writing `O(n²)` would incorrectly imply both arrays share one size variable. The precise answer, `O(n · m)`, only collapses to `O(n²)` in the special case where `n === m` by coincidence — and even then, it should be described as `O(n²)` only after establishing that `n` and `m` refer to the same underlying quantity.
