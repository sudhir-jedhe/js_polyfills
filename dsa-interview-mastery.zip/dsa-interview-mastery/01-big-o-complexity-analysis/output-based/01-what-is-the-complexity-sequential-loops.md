# What's the Time Complexity? — Sequential Loops

```js
function process(arr) {
  let a = 0;
  for (let i = 0; i < arr.length; i++) a += arr[i];

  let b = 0;
  for (let j = 0; j < arr.length; j++) {
    for (let k = 0; k < arr.length; k++) b += arr[j] * arr[k];
  }

  return a + b;
}
```

**Answer:** `O(n²)`

**Why:** The first loop is `O(n)`. The second is a nested loop over the same array, both bounds equal to `arr.length`, giving `O(n²)`. Since these two blocks run sequentially (one after the other, not nested inside each other), their costs **add**: `O(n) + O(n²)`. When simplifying a sum of complexity terms, only the dominant (fastest-growing) term survives, so `O(n) + O(n²)` simplifies to `O(n²)` — the linear loop's cost is completely dwarfed by the quadratic one as `n` grows, so it drops out of the final answer entirely.
