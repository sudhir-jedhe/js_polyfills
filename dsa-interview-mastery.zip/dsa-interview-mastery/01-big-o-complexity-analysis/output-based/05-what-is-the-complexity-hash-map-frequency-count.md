# What's the Time Complexity? — Frequency Counting With a Map

```js
function mostFrequent(arr) {
  const counts = new Map();
  for (const x of arr) {
    counts.set(x, (counts.get(x) || 0) + 1); // Map get/set
  }

  let best = null, bestCount = 0;
  for (const [value, count] of counts) {
    if (count > bestCount) { best = value; bestCount = count; }
  }
  return best;
}
```

**Answer:** Time: `O(n)`. Space: `O(k)`, where `k` is the number of distinct values in `arr` (which is `O(n)` in the worst case, when all elements are unique).

**Why:** `Map.get` and `Map.set` are `O(1)` average case (amortized, hash-based lookup — same guarantee as JS objects/Sets under the hood). The first loop runs `n` times doing `O(1)` work each = `O(n)`. The second loop iterates over the `Map`'s entries, which number at most `k` (distinct values) — and since `k <= n` always, this second loop is `O(k)`, which is bounded above by `O(n)`. Total: `O(n) + O(k) = O(n)`. Space is proportional to the number of distinct keys stored in the `Map`, i.e. `O(k)`; in the worst case (every element distinct) that's `O(n)`, but if the value domain is small and bounded (e.g. only 26 possible letters), space would be `O(1)` regardless of `n` — always express space in terms of what actually varies, not just blindly write `O(n)`.
