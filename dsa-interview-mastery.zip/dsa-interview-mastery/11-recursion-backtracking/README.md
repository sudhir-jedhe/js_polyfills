# Recursion & Backtracking

Recursion is a function solving a problem by calling itself on a smaller version of the same problem, until it reaches a base case simple enough to answer directly. Backtracking is recursion's most interview-heavy application: systematically exploring a tree of choices — choose, recurse, then undo the choice before trying the next option — to generate or search combinatorial possibilities (subsets, permutations, board configurations) without brute-forcing every option up front. This topic is one of the most consistently tested in coding interviews because a huge share of "hard" problems (N-Queens, Sudoku, word search, generate parentheses) all reduce to the exact same choose/explore/un-choose template once you recognize the pattern — and because understanding the call stack precisely (frame lifetime, stack depth vs. total calls, why JS doesn't optimize tail calls) is what separates candidates who can debug a `RangeError` from those who can't.

## Folder structure

- **`theory/`** — recursion fundamentals (base case & call stack), call stack visualization & stack overflow, tail recursion and why JS engines mostly don't optimize it, the backtracking choose/explore/un-choose template, recursion vs. iteration tradeoffs, and time/space complexity analysis of recursive algorithms.
- **`snippets/`** — 7 focused, runnable code examples: factorial/Fibonacci, recursive array sum, subsets, permutations, combinations, memoized Fibonacci, and generate parentheses.
- **`output-based/`** — 7 "trace through this recursion" questions covering call stack order, exponential call counts, mutual recursion, backtracking result ordering, swap-based permutations, the classic shared-mutable-array bug, and tail-position calls still overflowing in V8.
- **`scenarios/`** — 5 real-world engineering scenarios: flattening a nested comment tree, generating valid feature-flag combinations, maze pathfinding, deep-cloning nested objects (with the circular-reference trap), and a decision framework for backtracking vs. brute-force loops.
- **`interview-qa/`** — 12 Q&A pairs across 3 themed files: recursion fundamentals, backtracking patterns, and complexity/optimization.
- **`problems/`** — 7 hands-on coding challenges: subsets, permutations, combinations, N-Queens, Sudoku solver, generate parentheses, and word search — each with a full JavaScript solution and Big-O analysis.
- **`assets/`** — placeholder for diagrams (call stack frames, recursion trees, backtracking decision trees).

## What's covered

- Precise definition of base case vs. recursive case, and why a missing/unreachable base case throws `RangeError` rather than hanging
- Visualizing the call stack frame-by-frame, and the distinction between total calls made and maximum simultaneous stack depth
- Tail recursion in the ES2015 spec, and why V8/Node and SpiderMonkey don't implement proper tail calls (only Safari's JavaScriptCore does)
- The universal backtracking template — choose, explore, un-choose — and the single most common bug (pushing a reference instead of a snapshot)
- When to reach for recursion vs. plain iteration, including converting recursion to an explicit-stack iterative form for unbounded/untrusted input depth
- Time and space complexity analysis for linear recursion, tree recursion, and backtracking search trees (O(2^n), O(n!), O(C(n,k)))
- Hands-on: subsets, permutations, combinations, N-Queens, Sudoku solver, generate parentheses, and word search
