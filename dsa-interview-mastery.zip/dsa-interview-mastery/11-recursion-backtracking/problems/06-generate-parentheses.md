# Problem: Generate Parentheses

## Problem Statement

Given `n` pairs of parentheses, write a function to generate all combinations of well-formed (balanced and correctly nested) parentheses.

## Constraints

- `1 <= n <= 8`

## Examples

```
Input: n = 3
Output: ["((()))","(()())","(())()","()(())","()()()"]

Input: n = 1
Output: ["()"]
```

## Approach

Build the string character by character, tracking how many `(` and `)` have been used so far. An open paren can be added any time fewer than `n` have been used; a close paren can only be added if fewer close parens have been used than open ones so far (otherwise the string would go "unbalanced," e.g. `")"` with no matching `(`). Enforcing this constraint *while building* — rather than generating every 2n-length string of parens and filtering afterward — is what makes this backtracking with pruning rather than brute force.

## Solution

```js
function generateParenthesis(n) {
  const result = [];

  function backtrack(current, openCount, closeCount) {
    if (current.length === n * 2) {
      result.push(current);
      return;
    }
    if (openCount < n) {
      backtrack(current + '(', openCount + 1, closeCount);   // choose '(' and explore
    }
    if (closeCount < openCount) {
      backtrack(current + ')', openCount, closeCount + 1);   // choose ')' and explore
    }
    // no explicit "un-choose" needed — `current` is passed by value (a new string each call),
    // so there's no shared mutable state to revert here, unlike an array-based `path`.
  }

  backtrack('', 0, 0);
  return result;
}

module.exports = { generateParenthesis };

// --- verification ---
console.log(generateParenthesis(3));
// ["((()))","(()())","(())()","()(())","()()()"]
console.log(generateParenthesis(3).length); // 5 — matches the 3rd Catalan number
```

## Complexity

- **Time:** O(4^n / √n) — bounded by the nth Catalan number, which counts the number of valid parenthesizations; each valid string also costs O(n) to build, but the dominant term is the Catalan-number count of valid strings itself.
- **Space:** O(n) for recursion depth (each call adds one character), excluding the output.
