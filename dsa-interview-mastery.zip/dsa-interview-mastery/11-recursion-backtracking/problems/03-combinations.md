# Problem: Combinations

## Problem Statement

Given two integers `n` and `k`, return all possible combinations of `k` numbers chosen from the range `[1, n]`, in any order. Each combination should contain unique numbers, and combinations should not repeat (order within a combination doesn't distinguish it from another with the same elements).

## Constraints

- `1 <= n <= 20`
- `1 <= k <= n`

## Examples

```
Input: n = 4, k = 2
Output: [[1,2],[1,3],[1,4],[2,3],[2,4],[3,4]]

Input: n = 1, k = 1
Output: [[1]]
```

## Approach

Same `start`-index technique as subsets (only ever look forward, so `[1,2]` and `[2,1]` are never both generated), but with a fixed target length `k` instead of recording every prefix. Add a pruning bound: if fewer than `k - path.length` numbers remain between the current candidate and `n`, no valid combination can possibly be completed from here, so that branch can be skipped without recursing into it at all.

## Solution

```js
function combine(n, k) {
  const result = [];
  const path = [];

  function backtrack(start) {
    if (path.length === k) {
      result.push([...path]);
      return;
    }
    const remainingNeeded = k - path.length;
    for (let i = start; i <= n - remainingNeeded + 1; i++) { // pruned loop bound
      path.push(i);
      backtrack(i + 1);
      path.pop();
    }
  }

  backtrack(1);
  return result;
}

module.exports = { combine };

// --- verification ---
console.log(combine(4, 2));
// [[1,2],[1,3],[1,4],[2,3],[2,4],[3,4]]
console.log(combine(4, 2).length); // 6 — matches C(4, 2)
```

## Complexity

- **Time:** O(k · C(n, k)) — C(n, k) total combinations, each costing O(k) to build and copy.
- **Space:** O(k) for recursion depth and `path`, excluding the output.
