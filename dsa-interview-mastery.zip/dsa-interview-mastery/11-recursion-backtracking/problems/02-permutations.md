# Problem: Permutations

## Problem Statement

Given an array `nums` of distinct integers, return all possible permutations, in any order.

## Constraints

- `1 <= nums.length <= 6`
- `-10 <= nums[i] <= 10`
- All elements of `nums` are unique.

## Examples

```
Input: nums = [1,2,3]
Output: [[1,2,3],[1,3,2],[2,1,3],[2,3,1],[3,1,2],[3,2,1]]

Input: nums = [0,1]
Output: [[0,1],[1,0]]
```

## Approach

Unlike subsets, permutations use every element exactly once, but order matters — so instead of a `start` index (which only looks forward), every recursive call considers *every* not-yet-used element, tracked with a `used` boolean array. Base case: the path has grown to the full length of `nums`, meaning a complete permutation has been assembled.

## Solution

```js
function permute(nums) {
  const result = [];
  const path = [];
  const used = new Array(nums.length).fill(false);

  function backtrack() {
    if (path.length === nums.length) {
      result.push([...path]);
      return;
    }
    for (let i = 0; i < nums.length; i++) {
      if (used[i]) continue;       // this element is already in the current path

      used[i] = true;               // choose
      path.push(nums[i]);
      backtrack();                  // explore
      path.pop();                   // un-choose
      used[i] = false;
    }
  }

  backtrack();
  return result;
}

module.exports = { permute };

// --- verification ---
console.log(permute([1, 2, 3]));
// [[1,2,3],[1,3,2],[2,1,3],[2,3,1],[3,1,2],[3,2,1]]
console.log(permute([1, 2, 3]).length); // 6 === 3!
```

## Complexity

- **Time:** O(n · n!) — there are n! permutations, and building/copying each one costs O(n).
- **Space:** O(n) for the recursion depth, `path`, and `used` array, excluding the O(n · n!) output.
