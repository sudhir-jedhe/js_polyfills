# Problem: N-Queens

## Problem Statement

The n-queens puzzle is placing `n` chess queens on an `n x n` chessboard so that no two queens attack each other (no shared row, column, or diagonal). Given `n`, return the number of distinct solutions (a simpler, common interview variant of "return all board configurations").

## Constraints

- `1 <= n <= 9`

## Examples

```
Input: n = 4
Output: 2
(Two distinct arrangements of 4 non-attacking queens on a 4x4 board.)

Input: n = 1
Output: 1
```

## Approach

Since no two queens can share a row, place exactly one queen per row and recurse row by row — this alone eliminates the row-conflict check entirely and cuts the branching factor from "any of n² cells" down to "any of n columns per row." Track occupied columns and both diagonal directions in `Set`s for O(1) conflict checks (a cell's "diagonal identity" is `row - col` for one diagonal direction and `row + col` for the other — both are constant along any diagonal).

## Solution

```js
function totalNQueens(n) {
  const cols = new Set();
  const diag1 = new Set(); // row - col is constant along a "/" diagonal
  const diag2 = new Set(); // row + col is constant along a "\" diagonal
  let count = 0;

  function backtrack(row) {
    if (row === n) {
      count++;               // placed a queen in every row without conflicts
      return;
    }
    for (let col = 0; col < n; col++) {
      if (cols.has(col) || diag1.has(row - col) || diag2.has(row + col)) {
        continue;             // pruned — this column/diagonal is already under attack
      }
      cols.add(col);          // choose
      diag1.add(row - col);
      diag2.add(row + col);

      backtrack(row + 1);     // explore

      cols.delete(col);       // un-choose
      diag1.delete(row - col);
      diag2.delete(row + col);
    }
  }

  backtrack(0);
  return count;
}

module.exports = { totalNQueens };

// --- verification ---
console.log(totalNQueens(4)); // 2
console.log(totalNQueens(8)); // 92 — the classic 8-queens solution count
```

## Complexity

- **Time:** O(n!) worst case — the branching factor shrinks by roughly one per row (n choices in row 0, at most n-1 viable in row 1, etc.), similar in shape to permutation generation; the `Set`-based conflict checks (O(1) each) keep pruning cheap.
- **Space:** O(n) for the three `Set`s and the recursion depth.
