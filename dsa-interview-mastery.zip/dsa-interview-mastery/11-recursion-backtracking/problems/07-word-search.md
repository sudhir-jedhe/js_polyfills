# Problem: Word Search

## Problem Statement

Given an `m x n` grid of characters `board` and a string `word`, return `true` if `word` exists in the grid. The word must be constructed from letters of sequentially adjacent cells (horizontally or vertically neighboring), and the same cell may not be used more than once within one word.

## Constraints

- `1 <= board.length, board[i].length <= 6`
- `1 <= word.length <= 15`
- `board` and `word` consist of lowercase and uppercase English letters.

## Examples

```
Input: board = [["A","B","C","E"],["S","F","C","S"],["A","D","E","E"]], word = "ABCCED"
Output: true

Input: board = [["A","B","C","E"],["S","F","C","S"],["A","D","E","E"]], word = "SEE"
Output: true

Input: board = [["A","B","C","E"],["S","F","C","S"],["A","D","E","E"]], word = "ABCB"
Output: false
```

## Approach

Try every cell as a potential starting point for `word[0]`. From a matching cell, backtrack in the 4 directions looking for `word[1]`, then `word[2]`, and so on. Mark a cell as "in use" while it's part of the current path (so the search can't reuse it later in the same attempt), and un-mark it on backtrack so it's available again for a *different* path that doesn't go through it.

## Solution

```js
function exist(board, word) {
  const rows = board.length, cols = board[0].length;

  function backtrack(r, c, i) {
    if (i === word.length) return true; // matched every character — found it

    if (
      r < 0 || c < 0 || r >= rows || c >= cols ||   // out of bounds
      board[r][c] !== word[i]                        // character mismatch
    ) {
      return false;
    }

    const temp = board[r][c];
    board[r][c] = '#';         // choose — mark this cell as "in use" for the current path

    const found =
      backtrack(r + 1, c, i + 1) ||
      backtrack(r - 1, c, i + 1) ||
      backtrack(r, c + 1, i + 1) ||
      backtrack(r, c - 1, i + 1);   // explore all 4 directions

    board[r][c] = temp;          // un-choose — restore the cell regardless of outcome

    return found;
  }

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      if (backtrack(r, c, 0)) return true; // try every cell as a starting point
    }
  }
  return false;
}

module.exports = { exist };

// --- verification ---
const board = [
  ['A', 'B', 'C', 'E'],
  ['S', 'F', 'C', 'S'],
  ['A', 'D', 'E', 'E'],
];
console.log(exist(board, 'ABCCED')); // true
console.log(exist(board, 'SEE'));    // true
console.log(exist(board, 'ABCB'));   // false — no path revisits a cell to reuse the 2nd "B"
```

## Complexity

- **Time:** O(m · n · 4^L) — `m · n` possible starting cells, and from each, up to 4 directions explored per character of `word` (length `L`); in practice the mismatch check (`board[r][c] !== word[i]`) prunes almost every branch immediately.
- **Space:** O(L) for the recursion depth, matching the length of `word`; the board is mutated in place (O(1) extra storage) rather than using a separate `visited` set.
