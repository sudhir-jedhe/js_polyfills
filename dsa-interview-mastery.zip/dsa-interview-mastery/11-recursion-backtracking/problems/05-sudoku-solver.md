# Problem: Sudoku Solver

## Problem Statement

Write a program to solve a 9x9 Sudoku puzzle by filling the empty cells (represented as `'.'`) in place, following the standard Sudoku rules: each row, each column, and each of the nine 3x3 sub-boxes must contain the digits `1`–`9` exactly once. The puzzle is guaranteed to have exactly one solution.

## Constraints

- `board.length === 9`, `board[i].length === 9`
- `board[i][j]` is a digit `'1'`–`'9'` or `'.'`
- The given board is a valid, solvable puzzle with a unique solution.

## Example

```
Input:
[["5","3",".",".","7",".",".",".","."],
 ["6",".",".","1","9","5",".",".","."],
 [".","9","8",".",".",".",".","6","."],
 ["8",".",".",".","6",".",".",".","3"],
 ["4",".",".","8",".","3",".",".","1"],
 ["7",".",".",".","2",".",".",".","6"],
 [".","6",".",".",".",".","2","8","."],
 [".",".",".","4","1","9",".",".","5"],
 [".",".",".",".","8",".",".","7","9"]]

Output: the board filled in with a valid complete solution (mutated in place).
```

## Approach

Scan for the next empty cell; try digits `1`–`9` in it; for each digit that doesn't conflict with its row, column, or 3x3 box, place it and recurse into the *next* empty cell. If the recursive call succeeds (returns `true`, meaning the rest of the board was solvable from here), propagate success back up immediately. If no digit works for the current cell, backtrack: undo the last placement and let the caller try its next candidate digit. Solving is signaled with a boolean return value rather than collecting results, because the puzzle has exactly one solution and we can stop as soon as we find it.

## Solution

```js
function solveSudoku(board) {
  function isValid(row, col, digit) {
    for (let i = 0; i < 9; i++) {
      if (board[row][i] === digit) return false;                          // row conflict
      if (board[i][col] === digit) return false;                          // column conflict
      const boxRow = 3 * Math.floor(row / 3) + Math.floor(i / 3);
      const boxCol = 3 * Math.floor(col / 3) + (i % 3);
      if (board[boxRow][boxCol] === digit) return false;                  // 3x3 box conflict
    }
    return true;
  }

  function backtrack() {
    for (let row = 0; row < 9; row++) {
      for (let col = 0; col < 9; col++) {
        if (board[row][col] !== '.') continue; // already filled, skip

        for (let d = 1; d <= 9; d++) {
          const digit = String(d);
          if (!isValid(row, col, digit)) continue;

          board[row][col] = digit;   // choose
          if (backtrack()) return true; // explore — propagate success immediately
          board[row][col] = '.';     // un-choose — this digit didn't lead to a solution
        }
        return false; // no digit 1-9 works for this cell — trigger backtrack in the caller
      }
    }
    return true; // no empty cells left — solved
  }

  backtrack();
  return board;
}

module.exports = { solveSudoku };
```

## Complexity

- **Time:** O(9^m) worst case, where `m` is the number of empty cells — each empty cell tries up to 9 digits. In practice, the row/column/box validity checks prune the vast majority of branches almost immediately, so real puzzles solve far faster than the worst-case bound suggests.
- **Space:** O(m) for the recursion depth (one frame per empty cell along the deepest branch being explored); the board itself is mutated in place with O(1) extra storage for the solution.
