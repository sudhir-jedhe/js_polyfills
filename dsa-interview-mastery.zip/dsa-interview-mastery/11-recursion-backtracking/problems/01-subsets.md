# Problem: Subsets

## Problem Statement

Given an array `nums` of unique integers, return all possible subsets (the power set). The solution set must not contain duplicate subsets; subsets may be returned in any order.

## Constraints

- `1 <= nums.length <= 10`
- `-10 <= nums[i] <= 10`
- All elements of `nums` are unique.

## Examples

```
Input: nums = [1,2,3]
Output: [[],[1],[1,2],[1,2,3],[1,3],[2],[2,3],[3]]

Input: nums = [0]
Output: [[],[0]]
```

## Approach

Every element is independently either included or excluded from a given subset, so the decision tree has depth `n` (one decision per element) and `2^n` leaves (one per subset). Using the backtracking template with a `start` index (rather than a per-element in/out boolean) naturally avoids generating the same subset twice: at each recursive call, only elements *after* the current index are considered for inclusion, so no ordering of the same elements is ever revisited.

## Solution

```js
function subsets(nums) {
  const result = [];
  const path = [];

  function backtrack(start) {
    result.push([...path]); // record every partial path — each is itself a valid subset

    for (let i = start; i < nums.length; i++) {
      path.push(nums[i]);     // choose
      backtrack(i + 1);        // explore — only look forward from i + 1
      path.pop();               // un-choose
    }
  }

  backtrack(0);
  return result;
}

module.exports = { subsets };

// --- verification ---
console.log(subsets([1, 2, 3]));
// [[],[1],[1,2],[1,2,3],[1,3],[2],[2,3],[3]]
console.log(subsets([1, 2, 3]).length); // 8 === 2^3
```

## Complexity

- **Time:** O(n · 2^n) — there are 2^n subsets, and copying each one into `result` via `[...path]` costs O(n) in the worst case.
- **Space:** O(n) for the recursion depth and `path` array, excluding the output itself (which is O(n · 2^n) to store all subsets).
