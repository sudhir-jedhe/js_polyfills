# What Does This Output? — Swap-Based Permutations

```js
function permute(arr, start = 0, result = []) {
  if (start === arr.length) {
    result.push([...arr]);
    return result;
  }
  for (let i = start; i < arr.length; i++) {
    [arr[start], arr[i]] = [arr[i], arr[start]]; // swap
    permute(arr, start + 1, result);
    [arr[start], arr[i]] = [arr[i], arr[start]]; // swap back
  }
  return result;
}
console.log(permute([1, 2, 3]));
```

**Answer:** `[[1,2,3],[1,3,2],[2,1,3],[2,3,1],[3,2,1],[3,1,2]]`

**Why:** this variant generates permutations by swapping elements *in place* rather than tracking a separate `path` array and a `used` set — `start` marks the boundary between the "fixed prefix" and the "still being permuted" suffix. At each level, every element from `start` onward takes a turn being swapped into the `start` position (fixing it), then the rest is permuted recursively, then the swap is undone (the "un-choose" step) before the next candidate is swapped in. Note the output order differs from the `used`-array version in `../snippets/04-permutations-backtracking.md` — both produce all 6 permutations, but swap-based generation visits them in a different sequence, since which element gets fixed first depends on swap positions rather than a fixed left-to-right scan. This is a good example of "correct but different traversal order" — both are valid, and interviewers generally accept either as long as all permutations are produced exactly once.
