# What Does This Output? — Order of Backtracking Results

```js
function subsets(nums) {
  const result = [];
  const path = [];
  function backtrack(start) {
    result.push([...path]);
    for (let i = start; i < nums.length; i++) {
      path.push(nums[i]);
      backtrack(i + 1);
      path.pop();
    }
  }
  backtrack(0);
  return result;
}
console.log(subsets([1, 2]));
```

**Answer:** `[[], [1], [1, 2], [2]]`

**Why:** the result is pushed at the *top* of `backtrack`, before the loop — so every recursive call records its current `path` immediately upon entry, in the order calls are entered (which is depth-first, always going as deep as possible before backtracking to try a sibling). Tracing it: `backtrack(0)` records `[]`, then chooses `1` and calls `backtrack(1)`, which records `[1]`, then chooses `2` and calls `backtrack(2)`, which records `[1, 2]` (loop doesn't execute, `i` starts at 2 which is out of bounds) and returns. Back in `backtrack(1)`, `2` is popped, loop ends, returns. Back in `backtrack(0)`, `1` is popped, loop continues to `i = 1`: chooses `2`, calls `backtrack(2)`, which records `[2]`. This depth-first, "record on entry" pattern is why the output is ordered by nesting depth (shortest prefixes interleaved with their extensions), not sorted by subset length.
