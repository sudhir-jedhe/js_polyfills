# What Does This Output? — Mutual Recursion

```js
function isEven(n) {
  if (n === 0) return true;
  return isOdd(n - 1);
}
function isOdd(n) {
  if (n === 0) return false;
  return isEven(n - 1);
}
console.log(isEven(4), isOdd(4), isEven(7));
```

**Answer:** `true false false`

**Why:** this is **mutual recursion** — two functions calling each other rather than a function calling itself. `isEven(4)` calls `isOdd(3)`, which calls `isEven(2)`, which calls `isOdd(1)`, which calls `isEven(0)`, which hits the base case and returns `true` — the chain unwinds returning `true` all the way up. Each call decrements `n` by 1 and flips which function is asking, so after `n` total calls the parity of the original `n` determines which base case (`isEven(0) === true` or `isOdd(0) === false`) is hit. `isEven(7)` makes an odd number of hand-offs starting from "is this even," lands on `isOdd(0)`, which returns `false`. Mutual recursion still uses one shared call stack — there's nothing special about the mechanics, just two named functions taking turns pushing frames.
