# What Does This Output? — Tail-Position Call Still Overflows in V8

```js
'use strict';
function countUp(n, max) {
  if (n === max) return n; // tail position: nothing happens after this call returns
  return countUp(n + 1, max);
}
try {
  console.log(countUp(0, 1000000));
} catch (e) {
  console.log(e instanceof RangeError, e.message);
}
```

**Answer (in Node.js / V8):** `true "Maximum call stack size exceeded"`

**Why:** `countUp`'s recursive call is syntactically in tail position — its return value is returned directly, with no pending multiplication or other work left for the outer call to do — which is exactly the shape the ES2015 spec allows an engine to optimize into O(1) stack space via proper tail calls (PTC). But V8 (which powers both Node.js and Chrome) never shipped PTC in its default configuration, so this still pushes one real stack frame per call, and a million-deep recursion overflows the stack well before it finishes, just as it would if the call weren't in tail position at all. Running the identical code in Safari (JavaScriptCore, which *does* implement PTC) would print `1000000` with no error. This gap between "spec-legal optimization" and "what your actual runtime does" is the practical takeaway — see `../theory/03-tail-recursion-and-why-js-doesnt-optimize-it.md`.
