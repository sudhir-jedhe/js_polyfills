# What Does This Output? — The Shared-Reference Backtracking Bug

```js
function subsetsBuggy(nums) {
  const result = [];
  const path = [];
  function backtrack(start) {
    result.push(path); // BUG: pushing the reference, not a copy
    for (let i = start; i < nums.length; i++) {
      path.push(nums[i]);
      backtrack(i + 1);
      path.pop();
    }
  }
  backtrack(0);
  return result;
}
console.log(subsetsBuggy([1, 2]));
```

**Answer:** `[[], [], [], []]`

**Why:** `result.push(path)` stores a *reference* to the same `path` array on every call, not a snapshot of its contents at that moment. By the time `backtrack(0)` finally returns, every `push`/`pop` pair has fully unwound and `path` is empty again — and since all four entries in `result` point at that *same* array object, every one of them now displays as `[]`, regardless of what `path` contained when each entry was recorded. This is the single most common backtracking bug: the fix is `result.push([...path])` or `result.push(path.slice())`, which copies the array's current contents into a brand-new array rather than storing a pointer to the one array that keeps getting mutated. See `../theory/04-backtracking-template-choose-explore-unchoose.md` for the corrected template.
