# What Does This Output? — Counting Naive Fibonacci Calls

```js
let calls = 0;
function fib(n) {
  calls++;
  if (n <= 1) return n;
  return fib(n - 1) + fib(n - 2);
}
fib(5);
console.log(calls);
```

**Answer:** `15`

**Why:** draw the call tree for `fib(5)` — it branches into `fib(4)` and `fib(3)`, each of which branches again, and so on down to the base cases. Counting every node in that tree (every time `fib` is *entered*, regardless of what it returns) gives 15 total calls for `fib(5)`, even though there are only 6 distinct values of `n` involved (`0` through `5`). Several of those values get recomputed many times independently — `fib(2)` alone is computed 3 separate times within this one call to `fib(5)` — which is exactly the "overlapping subproblems" property that makes this a textbook case for memoization (see `06-memoized-recursion-fibonacci.md` in `../snippets/`). The call count roughly doubles as `n` increases by 1, confirming the O(2^n) time complexity.
