# What Does This Output? — Factorial Call Stack

```js
function factorial(n) {
  console.log('enter', n);
  if (n <= 1) {
    console.log('base case', n);
    return 1;
  }
  const result = n * factorial(n - 1);
  console.log('exit', n, '->', result);
  return result;
}
factorial(3);
```

**Answer:**
```
enter 3
enter 2
enter 1
base case 1
exit 2 -> 2
exit 3 -> 6
```

**Why:** every `enter` log fires on the way *down* the call stack, in the order calls are made (3, then 2, then 1). Execution only reaches `base case` once it hits `n <= 1`. The `exit` logs then fire on the way *back up*, in reverse order — `factorial(2)`'s multiplication can't complete until `factorial(1)` has returned, and `factorial(3)`'s can't complete until `factorial(2)` has. This down-then-up pattern is the clearest way to observe that recursion is stack-based: the "exit" order is exactly the reverse of the "enter" order.
