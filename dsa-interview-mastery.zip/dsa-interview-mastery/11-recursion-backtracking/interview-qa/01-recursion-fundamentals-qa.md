# Interview Q&A — Recursion Fundamentals

**Q: What are the two required parts of any correct recursive function?**
A base case that returns a value directly without recursing further, and a recursive case that reduces the problem toward that base case. Every recursive path through the function must eventually reach a base case, or the recursion never terminates and eventually throws `RangeError: Maximum call stack size exceeded` once it exhausts the call stack.

**Q: What actually happens on the call stack when a function calls itself?**
Each call pushes a new stack frame containing that call's own parameters and local variables — it does not overwrite or share the previous call's frame. The function only starts "returning" once a base case is hit; frames are then popped one at a time, in reverse order of how they were pushed (LIFO), with each resuming its pending work using the value the call below it returned.

**Q: Why does `RangeError: Maximum call stack size exceeded` happen, and how is it different from an infinite loop?**
Every stack frame consumes memory, and the call stack has a finite size. Unbounded recursion (missing or unreachable base case) keeps pushing frames until that limit is hit, at which point the engine throws. This is different from `while (true) {}`, which uses constant memory and just hangs forever without ever throwing — the failure mode for infinite recursion is a crash, not a hang.

**Q: What is the difference in space complexity between linear recursion and tree recursion?**
Linear recursion (one recursive call per frame, like array-sum or factorial) uses O(n) stack space for n levels of recursion. Tree recursion (multiple recursive calls per frame, like naive Fibonacci) also uses only O(depth) stack space at any instant, because only one root-to-leaf path of frames is ever alive simultaneously — siblings are fully resolved and popped before the next sibling is pushed. It's the *time* complexity that differs dramatically between the two, not necessarily the space.

**Q: Can every recursive algorithm be rewritten iteratively?**
Yes — any recursion can be converted to iteration by managing your own explicit stack (or queue) in place of the implicit call stack. Whether that's worth doing is a tradeoff: iterative code avoids stack-depth limits and function-call overhead, but can be less readable than recursion for problems (trees, graphs, backtracking, divide-and-conquer) whose structure is naturally recursive to begin with.
