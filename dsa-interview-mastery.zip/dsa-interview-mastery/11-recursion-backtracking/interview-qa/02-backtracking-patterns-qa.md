# Interview Q&A — Backtracking Patterns

**Q: What is backtracking, in one sentence?**
Backtracking is depth-first exploration of a decision tree where each choice is tentatively made, explored via recursion, and then explicitly undone before the next sibling choice is tried — allowing every branch to be explored using one shared, reused piece of state instead of copying state per branch.

**Q: What are the three steps of the backtracking template?**
Choose (mutate shared state to reflect a tentative decision, e.g. `path.push(x)`), explore (recurse one level deeper with that state), and un-choose (revert the mutation, e.g. `path.pop()`, so the next sibling iteration starts from a clean slate). Skipping "un-choose" is the most common backtracking bug — it leaks stale state into sibling branches.

**Q: Why is `result.push([...path])` used instead of `result.push(path)` when recording a completed candidate?**
`path` is a single array that gets mutated (pushed/popped) throughout the entire search. Pushing `path` itself stores a reference to that one array, not a snapshot — every entry in `result` ends up pointing at the same array, which shows whatever `path` happens to contain by the time the whole search finishes (usually empty, once fully unwound). `[...path]` (or `path.slice()`) copies the current contents into a new array, decoupling each recorded entry from later mutations.

**Q: How does backtracking differ from plain brute-force enumeration?**
Brute force typically generates every full candidate first and validates each one afterward. Backtracking validates partial candidates *as they're built* and abandons (prunes) invalid branches immediately, without extending them further — this pruning is what makes backtracking tractable for problems like N-Queens or Sudoku, where the space of all possible full boards is astronomically larger than the space actually explored once invalid partial boards are cut early.

**Q: What's the time complexity of generating all subsets vs. all permutations of n elements, and why the difference?**
Subsets: O(2^n), since each of the n elements independently is either included or excluded. Permutations: O(n!), since the *number* of elements chosen is fixed at n but their *order* matters, and each position has fewer remaining choices than the last (n choices for the first position, n-1 for the second, and so on). n! grows dramatically faster than 2^n once n is more than a handful — this is a very testable "sanity check" number to know off the top of your head.

**Q: In N-Queens or Sudoku, why is checking validity *before* recursing (rather than at the end) so important?**
Without early pruning, the algorithm would place queens or fill cells all the way to a complete (possibly invalid) board before checking any constraint — exploring huge swaths of the search space that were doomed from an early, easily-detectable conflict. Checking validity at each step (e.g. `isSafe(row, col, ...)` before placing a queen) prunes an entire invalid subtree the moment it becomes invalid, which is the difference between a solution that finishes instantly and one that times out.
