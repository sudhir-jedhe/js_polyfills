# Interview Q&A — Complexity and Optimization

**Q: Why is naive recursive Fibonacci O(2^n) in time but only O(n) in space?**
Time counts *total* calls made across the whole run — the call tree for `fib(n)` has roughly `2^n` nodes because of massive repeated recomputation of the same subproblems (`fib(k)` for a given `k` is recomputed independently many times). Space counts the *maximum simultaneous* stack depth, which is bounded by the longest single root-to-leaf path through that tree — that's just `n`, since siblings are fully resolved and their frames popped before the next sibling is even pushed.

**Q: What does memoization change about naive recursive Fibonacci's complexity?**
Memoization caches each `fib(k)` result the first time it's computed, so every subsequent call with that same `k` becomes an O(1) cache lookup instead of a full re-expansion of the subtree. This drops time complexity from O(2^n) to O(n), at the cost of O(n) extra space for the cache (in addition to the O(n) call-stack space already being used) — an O(n) time, O(n) space solution instead of O(2^n) time, O(n) space.

**Q: Does tail-call optimization (TCO) reduce a recursive function's time complexity?**
No — TCO (when available) only affects *space*, by letting the engine reuse a single stack frame for a chain of tail calls instead of pushing a new one per call, bringing stack space down to O(1) regardless of recursion depth. It doesn't reduce the number of operations performed, so time complexity is unchanged. And in most JS engines (V8/Node, SpiderMonkey/Firefox), TCO isn't implemented at all, so this benefit isn't available in practice outside Safari's JavaScriptCore — see `../theory/03-tail-recursion-and-why-js-doesnt-optimize-it.md`.

**Q: How do you compute the time complexity of a backtracking solution?**
Bound it by the size of the full decision tree explored before any pruning takes effect — subsets of n items: O(2^n); permutations of n items: O(n!); combinations choosing k of n: O(C(n, k)). Real-world pruning (early validity checks that cut off invalid branches) reduces the *actual* number of nodes visited, often dramatically, but the standard way to state complexity in an interview is the worst-case bound before pruning, with a note that effective pruning typically makes the practical runtime far better on real inputs.

**Q: If two functions each make O(n) recursive calls, are they necessarily equally efficient?**
Not necessarily — the constant work done *per call* matters too. A function that makes O(n) calls but does O(n) work in each call (e.g. copying an array at every level) is actually O(n²) overall, not O(n). Always multiply "number of calls" by "work done per call," not just count the calls in isolation — this is a common trap when a recursive helper does something like `arr.slice()` or spreads an array on every call.
