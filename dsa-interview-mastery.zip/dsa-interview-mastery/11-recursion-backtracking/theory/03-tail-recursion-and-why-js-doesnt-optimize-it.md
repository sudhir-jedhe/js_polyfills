# Tail Recursion, and Why JS Engines Mostly Don't Optimize It

A recursive call is in **tail position** when it's the very last thing the function does — its return value is returned directly, with no pending work left to do afterward (no multiplication, addition, or any other operation applied to the result of the recursive call).

```js
// NOT tail recursive — multiplication happens AFTER factorial(n - 1) returns
function factorial(n) {
  if (n <= 1) return 1;
  return n * factorial(n - 1); // pending work: "multiply by n" after the call returns
}

// Tail recursive — the recursive call's return value IS the function's return value
function factorialTail(n, acc = 1) {
  if (n <= 1) return acc;
  return factorialTail(n - 1, n * acc); // nothing left to do after this call returns
}
```

The trick to writing tail-recursive functions is passing an **accumulator** parameter that carries the "work so far," so each call can hand off a complete answer to the next call instead of waiting for it to come back.

## Proper tail calls (PTC) in the spec

ECMAScript 2015 (ES6) formally specifies **proper tail calls**: when a call is in tail position, the engine is *permitted* to reuse the current stack frame instead of pushing a new one, since the current frame has no remaining work and nothing to return to except "pass this value up." Done correctly, this makes tail-recursive functions run in O(1) stack space, regardless of recursion depth — turning what looks like recursion into what is, under the hood, a loop.

## Why most JS engines don't do this

| Engine | PTC support | Status |
|---|---|---|
| Safari / JavaScriptCore | Yes | Implemented, has shipped it for years |
| V8 (Chrome, Node.js, Edge) | No | Implemented experimentally once, then removed |
| SpiderMonkey (Firefox) | No | Never shipped |

V8 briefly implemented PTC and then pulled it, publicly, for practical reasons that keep coming up in interviews:

- **Debuggability** — if frames are silently reused, stack traces lose the call history, which makes debugging and `Error.stack` far less useful; V8's maintainers prioritized keeping full stack traces over the optimization.
- **It only covers `'use strict'`, syntactically-tail-position calls** — a narrow slice of real-world recursive code, since most recursion (accumulate-then-combine style, like the naive `factorial`) isn't written in tail form to begin with, and rewriting it as tail-recursive is itself unfamiliar to most JS developers.
- **No engine consensus** — with only one major engine implementing it, relying on PTC is not web-compatible in practice; code that "works" in Safari can crash with a stack overflow in Chrome or Node, which is arguably worse than no optimization existing at all, since it creates a false sense of safety.

## Practical consequence

Because you cannot rely on tail-call optimization in JavaScript (except in Safari), writing "tail recursive" code in JS does **not** protect against stack overflow on deep recursion the way it would in Scheme, Erlang, or Elixir. For deep or unbounded recursion in JS, the safe options are:

- Convert to an explicit iterative loop with your own stack/queue data structure.
- Cap recursion depth and fall back to an iterative or chunked approach for larger inputs.
- Accept the stack depth if the input is bounded and small (e.g. recursing over a UI tree that's realistically never more than a few dozen levels deep).

```js
// Iterative equivalent — O(1) stack frames, safe for any n
function factorialIterative(n) {
  let acc = 1;
  for (let i = 2; i <= n; i++) acc *= i;
  return acc;
}
```

**Interview takeaway:** know that PTC exists in the spec, know that V8/Node do *not* implement it, and be ready to say that writing tail-recursive JS is a style choice for clarity, not a performance guarantee — unlike in languages/runtimes that do guarantee it.
