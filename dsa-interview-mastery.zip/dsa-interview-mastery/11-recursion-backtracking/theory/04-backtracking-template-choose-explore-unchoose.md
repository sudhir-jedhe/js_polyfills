# The Backtracking Template: Choose, Explore, Un-choose

Backtracking is depth-first search over a tree of decisions: at each step you tentatively make a choice, recurse into the consequences of that choice, and then **undo** the choice before trying the next one — so every branch of the decision tree is explored with a clean, shared state instead of allocating new state per branch. This "choose → explore → un-choose" cycle is the single template that solves subsets, permutations, combinations, N-Queens, Sudoku, and word search.

## The template

```js
function backtrack(path, choices, result) {
  if (isComplete(path)) {       // base case: a full/valid candidate is built
    result.push([...path]);      // copy — `path` will keep mutating after this
    return;
  }

  for (const choice of choices) {
    if (!isValid(choice, path)) continue; // prune invalid branches early

    path.push(choice);           // 1. CHOOSE — tentatively commit to this option
    backtrack(path, remaining(choices, choice), result); // 2. EXPLORE — recurse deeper
    path.pop();                  // 3. UN-CHOOSE — undo, so the next loop iteration starts clean
  }
}
```

The critical line most people get wrong is `result.push([...path])` — pushing `path` itself (rather than a copy) stores a *reference* to the same array that keeps getting mutated by later `push`/`pop` calls, so every entry in `result` ends up pointing at the same, final, empty-again array. Always snapshot with `[...path]` or `path.slice()` at the moment a candidate is complete.

## Worked example: subsets

```js
function subsets(nums) {
  const result = [];
  const path = [];

  function backtrack(start) {
    result.push([...path]); // every path so far (including empty) is a valid subset

    for (let i = start; i < nums.length; i++) {
      path.push(nums[i]);        // choose
      backtrack(i + 1);           // explore (only look forward, avoids duplicate subsets)
      path.pop();                 // un-choose
    }
  }

  backtrack(0);
  return result;
}

console.log(subsets([1, 2, 3]));
// [[],[1],[1,2],[1,2,3],[1,3],[2],[2,3],[3]]
```

## Why "un-choose" matters: shared mutable state

Backtracking's efficiency comes from reusing one `path` array across the entire search instead of copying it at every node — but that only works because every choice is explicitly undone before the loop moves to the next sibling. Skipping the `pop()` (or forgetting it) leaves stale choices in `path` that leak into sibling branches, silently producing wrong or duplicated results without throwing any error — a subtle bug that's easy to introduce and easy to miss in review.

## Pruning: the difference between backtracking and brute force

Plain brute force generates every possible full candidate and checks validity at the end. Backtracking checks validity **as choices are made**, so an invalid partial candidate is abandoned immediately instead of being extended further — this pruning is what makes backtracking practical for problems like N-Queens or Sudoku, where the full search space is astronomically large but the valid space, reached via early pruning, is small.

```js
// N-Queens pruning example: only try a column if it doesn't conflict with
// any queen already placed, BEFORE recursing into the next row.
if (isSafe(row, col, placedQueens)) {
  placedQueens.push(col);
  backtrack(row + 1, placedQueens);
  placedQueens.pop();
}
```

## General shape recap

| Step | Purpose |
|---|---|
| Base case (`isComplete`) | Recognizes a fully-built, valid candidate and records it |
| Loop over choices | Enumerates every option available at the current decision point |
| Validity check / pruning | Skips choices that can't possibly lead to a valid result, before recursing |
| Choose | Mutates shared state to reflect the tentative choice |
| Explore | Recurses one level deeper with the updated state |
| Un-choose | Reverts the mutation so the next sibling choice starts from a clean slate |
