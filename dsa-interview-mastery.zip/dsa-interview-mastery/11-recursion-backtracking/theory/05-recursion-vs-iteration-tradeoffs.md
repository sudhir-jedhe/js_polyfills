# Recursion vs Iteration: Tradeoffs

Any recursive algorithm can be rewritten iteratively (typically using an explicit stack or queue to replace the implicit call stack), and any bounded iterative algorithm can be written recursively. The choice between them in an interview is about clarity, safety, and what the problem's structure naturally suggests — not about one being universally "better."

## Comparison

| Aspect | Recursion | Iteration |
|---|---|---|
| Memory | O(depth) stack frames — can overflow on deep/unbounded input | O(1) extra memory (unless you add your own explicit stack) |
| Code clarity for self-similar problems | Often mirrors the problem definition directly (tree traversal, divide-and-conquer, backtracking) | Can require manually managing state that recursion gives you for free (the call stack) |
| Performance | Function call overhead per level; naive tree recursion can be exponential without memoization | Generally faster in JS — no call overhead, no risk of stack overflow |
| Best fit | Problems with a naturally recursive structure: trees, graphs (DFS), divide-and-conquer, backtracking | Problems with a simple linear/counted structure: array scans, fixed-count loops |

## When recursion is the natural fit

Tree and graph traversal, divide-and-conquer (merge sort, quicksort), and backtracking all have a recursive *structure* baked into the problem itself — "the answer for this node depends on the answer for its children," or "explore this decision, then all decisions that follow from it." Forcing these into pure iteration usually means manually building the exact call stack the language would have given you for free, which tends to produce harder-to-read code for no real benefit unless stack depth is a genuine concern.

```js
// Recursive tree traversal — mirrors the tree's own recursive definition
function inorder(node, result = []) {
  if (!node) return result;
  inorder(node.left, result);
  result.push(node.value);
  inorder(node.right, result);
  return result;
}
```

## When iteration is the safer choice

Linear scans, counted loops, and any recursion over input whose size isn't bounded by something small (e.g. processing an array of arbitrary/attacker-controlled length) are better as loops — there's no risk of `RangeError: Maximum call stack size exceeded`, and the code usually runs faster since there's no function-call overhead per element.

```js
// Iterative sum — O(1) memory, no stack depth concern regardless of array size
function sum(arr) {
  let total = 0;
  for (const n of arr) total += n;
  return total;
}
```

## Converting recursion to iteration with an explicit stack

When a problem's structure is best expressed recursively but the recursion depth is a real risk (e.g. traversing a deeply nested, possibly attacker-supplied JSON structure), you can keep the same traversal *logic* while replacing the call stack with your own array-based stack, trading implicit stack frames for explicit heap-allocated ones (which don't have the same fixed size limit):

```js
function inorderIterative(root) {
  const result = [];
  const stack = [];
  let node = root;
  while (node || stack.length) {
    while (node) {
      stack.push(node);
      node = node.left;
    }
    node = stack.pop();
    result.push(node.value);
    node = node.right;
  }
  return result;
}
```

## Interview framing

A strong interview answer doesn't just pick one — it names the tradeoff: "I'll write this recursively since it mirrors the problem cleanly, but note that for very deep/unbounded input, an iterative version with an explicit stack would avoid the call-stack limit." That single sentence signals awareness of exactly the kind of production bug (uncaught `RangeError` on unexpectedly large input) that pure-recursion code is prone to.
