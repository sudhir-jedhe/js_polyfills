# Recursion Fundamentals: Base Case and Call Stack

A recursive function is a function that calls itself to solve a smaller instance of the same problem, until it reaches a case simple enough to answer directly. Every correct recursive function needs two parts:

- **Base case** — the condition that stops the recursion and returns a value without making another recursive call. Without it (or if it's unreachable), the function recurses forever until it exhausts the call stack.
- **Recursive case** — the part that breaks the problem into a smaller version of itself and calls the function again, then combines that result into the current step's answer.

```js
function factorial(n) {
  if (n <= 1) return 1;       // base case — stops the recursion
  return n * factorial(n - 1); // recursive case — smaller subproblem
}

console.log(factorial(5)); // 120
```

## The call stack

Each call to `factorial` doesn't execute and vanish immediately — it gets pushed onto the **call stack** as a new stack frame, and stays there, paused, waiting for its recursive call to return a value it can use. Only when the base case is hit does the stack start unwinding, with each frame resuming exactly where it left off and multiplying its own `n` into the returned result.

```
factorial(5)
  -> factorial(4)
    -> factorial(3)
      -> factorial(2)
        -> factorial(1) returns 1               (base case hit, stack starts unwinding)
      returns 2 * 1 = 2
    returns 3 * 2 = 6
  returns 4 * 6 = 24
returns 5 * 24 = 120
```

Five frames exist simultaneously at the deepest point, each holding its own local `n` — this is the key mental model interviewers are checking for. Recursion isn't "the function running multiple times"; it's multiple independent stack frames, each with their own copy of the local variables, stacked on top of each other, unwinding in reverse order (LIFO — last frame pushed is the first to return).

## Why a missing or wrong base case breaks things

```js
function badFactorial(n) {
  return n * badFactorial(n - 1); // no base case — never stops
}
badFactorial(5); // RangeError: Maximum call stack size exceeded
```

Every call stack has a finite size (browser/Node limits vary, but it's on the order of ten-to-twenty thousand frames for simple functions). A missing base case, or a base case that the recursive calls never actually reach (e.g. decrementing by 2 from an odd starting number toward an even-only base case), exhausts the stack and throws a `RangeError`, not an infinite loop that hangs silently the way `while (true) {}` would.

## Multiple base cases

Problems like Fibonacci need more than one base case, because a single recursive step depends on two prior results:

```js
function fib(n) {
  if (n === 0) return 0; // base case 1
  if (n === 1) return 1; // base case 2
  return fib(n - 1) + fib(n - 2); // two recursive calls per step
}
```

Getting every base case right — and confirming every recursive path eventually reaches one — is the single most common source of recursion bugs in interviews, more so than the recursive logic itself.
