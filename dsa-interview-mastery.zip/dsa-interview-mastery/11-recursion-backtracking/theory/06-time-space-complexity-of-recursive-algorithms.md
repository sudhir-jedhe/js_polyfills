# Time and Space Complexity of Recursive Algorithms

Analyzing recursive algorithms means separately accounting for **time** (total work across every call) and **space** (peak memory across simultaneously-alive stack frames) — they don't always scale the same way, and interviewers routinely ask for both.

## Time complexity: count total calls and work per call

For simple linear recursion (one recursive call per frame), time complexity is the number of calls times the work done per call:

```js
function sum(arr, i = 0) {
  if (i === arr.length) return 0;
  return arr[i] + sum(arr, i + 1); // n calls, O(1) work each
}
// Time: O(n) — n calls, constant work per call
// Space: O(n) — n stack frames alive at the deepest point
```

For **tree recursion** (multiple recursive calls per frame), the total number of calls grows with the branching factor raised to the depth:

```js
function fib(n) {
  if (n <= 1) return n;
  return fib(n - 1) + fib(n - 2); // 2 recursive calls per frame
}
// Time: O(2^n) — the call tree roughly doubles in size per level of depth
// Space: O(n) — only ONE root-to-leaf path is alive on the stack at any instant
```

This is the single most-missed distinction in interviews: naive Fibonacci's *time* is exponential because of massively repeated overlapping subproblems (`fib(3)` gets recomputed independently many times), but its *space* is only linear, because tree recursion never has more than one full root-to-leaf path of frames alive simultaneously — siblings are resolved and popped before the next sibling is even pushed.

## Recursion tree method

Drawing the recursion tree is the standard way to derive complexity by hand:

```
fib(4)
├── fib(3)
│   ├── fib(2)
│   │   ├── fib(1)
│   │   └── fib(0)
│   └── fib(1)
└── fib(2)
    ├── fib(1)
    └── fib(0)
```

Count nodes (≈ time complexity) and count the longest root-to-leaf path (≈ space complexity, since that's the max simultaneous stack depth). For `fib(n)`, the tree has roughly `2^n` nodes but only depth `n` — hence O(2^n) time, O(n) space.

## Backtracking complexity

Backtracking's time complexity is bounded by the size of the full decision tree it explores, before pruning: for permutations of `n` items it's O(n!), for subsets of `n` items it's O(2^n) (each item is either in or out), and for combinations choosing `k` from `n` it's O(C(n, k)). Space is the recursion depth (O(n) for the call stack) plus the space used to build and copy each candidate into the result.

| Problem | Time complexity | Space complexity (excl. output) |
|---|---|---|
| Linear recursion (array sum, factorial) | O(n) | O(n) — call stack depth |
| Naive Fibonacci (tree recursion, no memo) | O(2^n) | O(n) — call stack depth |
| Memoized Fibonacci | O(n) | O(n) — cache + call stack |
| Subsets (backtracking) | O(2^n) | O(n) — recursion depth |
| Permutations (backtracking) | O(n!) | O(n) — recursion depth |
| Combinations, choose k of n (backtracking) | O(C(n, k)) | O(k) — recursion depth |

## Common mistake: conflating "number of calls" with "stack depth"

A recursive function can make an enormous *number* of calls over its lifetime while only ever holding a small *number of frames* on the stack at once (tree recursion is the classic example). When asked for space complexity, always answer with "maximum simultaneous stack depth," not "total number of calls made" — the two are frequently different, and interviewers use exactly this question to check the distinction is understood.
