# Call Stack Visualization and Stack Overflow

Visualizing recursion as a stack of frames (rather than "a function calling itself") is what makes tracing recursive code tractable in an interview. Each recursive call pushes a new frame containing that call's own parameters and local variables; the frame is popped only when that specific call returns.

## Tracing with a stack diagram

```js
function sumTo(n) {
  if (n === 0) return 0;
  return n + sumTo(n - 1);
}
sumTo(4);
```

| Step | Stack (top to bottom) | Action |
|---|---|---|
| 1 | `sumTo(4)` | pushed, waits on `sumTo(3)` |
| 2 | `sumTo(3)`, `sumTo(4)` | pushed, waits on `sumTo(2)` |
| 3 | `sumTo(2)`, `sumTo(3)`, `sumTo(4)` | pushed, waits on `sumTo(1)` |
| 4 | `sumTo(1)`, `sumTo(2)`, `sumTo(3)`, `sumTo(4)` | pushed, waits on `sumTo(0)` |
| 5 | `sumTo(0)`, ... | base case hit, returns `0`, frame popped |
| 6 | `sumTo(1)`, ... | resumes: `1 + 0 = 1`, returned, frame popped |
| 7 | `sumTo(2)`, ... | resumes: `2 + 1 = 3`, returned, frame popped |
| 8 | `sumTo(3)` | resumes: `3 + 3 = 6`, returned, frame popped |
| 9 | (empty) | `sumTo(4)` resumes: `4 + 6 = 10`, returned |

Growth phase (pushing frames) mirrors shrinkage phase (popping frames) exactly — the depth reached is the depth unwound. This symmetry is why recursion depth directly determines both memory use (one frame per pending call) and the number of "steps" visible when single-stepping through a debugger.

## Stack overflow

```js
function countDown(n) {
  console.log(n);
  countDown(n - 1); // no base case
}
countDown(100000); // RangeError: Maximum call stack size exceeded
```

Every pending call holds a frame in memory until it returns, so unbounded recursion depth is an unbounded memory cost, distinct from an unbounded *loop*, which uses constant memory per iteration. This is the core practical tradeoff: recursion trades stack memory for code that mirrors a problem's natural self-similar structure. In interviews, when input size is unbounded (e.g. "flatten an arbitrarily deep object" on untrusted data), it's worth explicitly naming this risk and mentioning an iterative-with-explicit-stack alternative even if you go on to implement the recursive version.

## Recursion depth vs input size

| Recursion style | Frames alive at peak | Example |
|---|---|---|
| Linear recursion (one recursive call per frame) | O(n) — proportional to input size | `factorial`, `sumTo`, linked list traversal |
| Tree recursion (multiple recursive calls per frame) | O(depth of the tree), but O(branches^depth) total calls | naive `fib`, subset/permutation generation |
| Tail recursion | O(n) frames in JS today (see the tail-call theory file) — same as linear recursion in practice | accumulator-style factorial |

Tree recursion's frame count at any instant is bounded by the deepest single path (not the total number of calls made), because siblings are resolved and popped before the next sibling is pushed — this is why `fib(30)` doesn't overflow the stack even though it makes over a million calls in total.
