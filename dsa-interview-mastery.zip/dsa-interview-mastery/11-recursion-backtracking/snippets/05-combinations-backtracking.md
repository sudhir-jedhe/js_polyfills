# Combinations — Choosing k of n

```js
function combinations(n, k) {
  const result = [];
  const path = [];

  function backtrack(start) {
    if (path.length === k) {
      result.push([...path]);
      return;
    }
    // prune: stop early if there aren't enough remaining numbers to reach length k
    for (let i = start; i <= n - (k - path.length) + 1; i++) {
      path.push(i);
      backtrack(i + 1);
      path.pop();
    }
  }

  backtrack(1);
  return result;
}

console.log(combinations(4, 2));
// [[1,2],[1,3],[1,4],[2,3],[2,4],[3,4]] — C(4,2) = 6 combinations
```

The loop bound `n - (k - path.length) + 1` is a pruning optimization: if fewer than `k - path.length` numbers remain between `i` and `n`, no valid combination can be completed from here, so those branches are skipped entirely instead of being explored and rejected later.
