# Permutations — Backtracking with a "Used" Tracker

```js
function permutations(nums) {
  const result = [];
  const path = [];
  const used = new Array(nums.length).fill(false);

  function backtrack() {
    if (path.length === nums.length) {
      result.push([...path]);
      return;
    }
    for (let i = 0; i < nums.length; i++) {
      if (used[i]) continue;      // skip elements already placed in this path
      used[i] = true;              // choose
      path.push(nums[i]);
      backtrack();                 // explore
      path.pop();                  // un-choose
      used[i] = false;
    }
  }

  backtrack();
  return result;
}

console.log(permutations([1, 2, 3]));
// [[1,2,3],[1,3,2],[2,1,3],[2,3,1],[3,1,2],[3,2,1]] — 3! = 6 permutations
```

Unlike subsets (which only ever look forward from a `start` index), permutations must consider every unused element at every position, so a `used` array replaces the `start` index as the mechanism that prevents reusing an element within the same path.
