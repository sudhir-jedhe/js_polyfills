# Summing an Array Recursively (Linear Recursion)

```js
function sumArray(arr, i = 0) {
  if (i === arr.length) return 0;         // base case: past the end, nothing left to add
  return arr[i] + sumArray(arr, i + 1);    // recursive case: this element + the rest
}

console.log(sumArray([1, 2, 3, 4, 5])); // 15
console.log(sumArray([]));              // 0 — base case hit immediately
```

One recursive call per frame (linear recursion) means O(n) time and O(n) stack depth — n frames alive at the deepest point, one per array index. Passing `i` as a default parameter avoids needing a separate wrapper function to kick off the recursion at index 0.
