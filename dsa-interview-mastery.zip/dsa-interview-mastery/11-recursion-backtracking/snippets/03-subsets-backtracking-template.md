# Subsets — the Core Backtracking Template

```js
function subsets(nums) {
  const result = [];
  const path = [];

  function backtrack(start) {
    result.push([...path]); // snapshot — every path node is itself a valid subset

    for (let i = start; i < nums.length; i++) {
      path.push(nums[i]);   // choose
      backtrack(i + 1);      // explore
      path.pop();            // un-choose
    }
  }

  backtrack(0);
  return result;
}

console.log(subsets([1, 2, 3]));
// [[],[1],[1,2],[1,2,3],[1,3],[2],[2,3],[3]]
```

This is the template referenced throughout the rest of the topic — see `../theory/04-backtracking-template-choose-explore-unchoose.md` for the general shape it's built from.
