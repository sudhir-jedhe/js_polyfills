# Memoized Fibonacci — Fixing Exponential Recursion

```js
function fibMemo(n, cache = new Map()) {
  if (n <= 1) return n;
  if (cache.has(n)) return cache.get(n);       // cache hit — skip recomputation

  const result = fibMemo(n - 1, cache) + fibMemo(n - 2, cache);
  cache.set(n, result);                         // cache miss — store before returning
  return result;
}

console.log(fibMemo(40)); // 102334155 — instant; naive fib(40) would take seconds
```

Passing the same `cache` `Map` through every recursive call turns the O(2^n) naive tree recursion into O(n): each `fibMemo(k)` is computed exactly once, and every subsequent call with that same `k` is an O(1) map lookup. This is the top-down (memoized) half of the memoization-vs-tabulation pairing covered in depth in `13-dynamic-programming/theory/02-memoization-vs-tabulation-same-problem-both-ways.md`.
