# Generate Valid Parentheses Combinations

```js
function generateParenthesis(n) {
  const result = [];

  function backtrack(current, open, close) {
    if (current.length === n * 2) {
      result.push(current);
      return;
    }
    if (open < n) {                      // can still open a new pair
      backtrack(current + '(', open + 1, close);
    }
    if (close < open) {                  // can only close if it matches an unclosed open
      backtrack(current + ')', open, close + 1);
    }
  }

  backtrack('', 0, 0);
  return result;
}

console.log(generateParenthesis(3));
// ["((()))","(()())","(())()","()(())","()()()"]
```

The validity constraint (`close < open`) is enforced *while building*, not checked afterward — this is backtracking's pruning in action: an invalid partial string like `")"` is never even constructed, since the `close < open` branch simply isn't taken when `open` is `0`.
