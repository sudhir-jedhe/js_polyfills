# Factorial and Fibonacci — Basic Recursion

```js
function factorial(n) {
  if (n <= 1) return 1;
  return n * factorial(n - 1);
}
console.log(factorial(6)); // 720

function fib(n) {
  if (n <= 1) return n;
  return fib(n - 1) + fib(n - 2);
}
console.log(fib(10)); // 55
```

Both follow the same shape: one or more base cases that return directly, and a recursive case that reduces `n` toward the base case. `fib` recurses twice per call, which makes it exponential time — see `../theory/06-time-space-complexity-of-recursive-algorithms.md` and the memoized version in `06-memoized-recursion-fibonacci.md`.
