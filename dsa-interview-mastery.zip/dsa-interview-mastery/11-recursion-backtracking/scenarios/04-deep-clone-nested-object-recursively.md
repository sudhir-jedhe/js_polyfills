# Scenario: Deep-Cloning an Arbitrarily Nested Object

**Scenario:** You need a `deepClone(obj)` utility that copies a nested object/array structure so mutating the copy never affects the original, at any depth. Why is this naturally recursive, and what's the one edge case that breaks a naive version?

**Approach:**

```js
function deepClone(value) {
  if (value === null || typeof value !== 'object') return value; // base case: primitive
  if (Array.isArray(value)) return value.map(deepClone);          // recurse into each element
  const result = {};
  for (const key in value) {
    result[key] = deepClone(value[key]);                          // recurse into each property
  }
  return result;
}
```

Objects/arrays are recursively defined data (a value is either a primitive, or a container of more values), so cloning them is naturally recursive too — the base case is "this is a primitive, return it as-is," and the recursive case is "clone every nested value and rebuild the container around the clones."

**Edge case — circular references:** if the object contains a cycle (`obj.self = obj`), this naive version recurses forever and throws `RangeError: Maximum call stack size exceeded`, since there's no way to reach the base case along that path. The fix is tracking already-visited objects (typically with a `Map` from original object → clone) and returning the existing clone instead of recursing again when a reference is seen a second time:

```js
function deepCloneSafe(value, seen = new Map()) {
  if (value === null || typeof value !== 'object') return value;
  if (seen.has(value)) return seen.get(value); // break the cycle
  const result = Array.isArray(value) ? [] : {};
  seen.set(value, result);
  for (const key in value) {
    result[key] = deepCloneSafe(value[key], seen);
  }
  return result;
}
```

In an interview, proactively raising the circular-reference case (before being asked) is a strong signal — it shows you're thinking about recursion's failure modes on real-world, not just well-behaved, input.
