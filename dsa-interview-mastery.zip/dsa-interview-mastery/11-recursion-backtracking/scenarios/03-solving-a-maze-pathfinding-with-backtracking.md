# Scenario: Finding a Path Through a Maze

**Scenario:** Given a 2D grid maze (`0` = open cell, `1` = wall), find *a* path from the top-left to the bottom-right, moving up/down/left/right, never revisiting a cell. How would you solve it?

**Approach:** this is backtracking applied to grid traversal — at each cell, try each of the 4 directions; if a direction leads somewhere useful, keep going; if it's a dead end, un-mark the cell and try the next direction:

```js
function findPath(maze) {
  const rows = maze.length, cols = maze[0].length;
  const path = [];
  const visited = new Set();

  function backtrack(r, c) {
    if (r < 0 || c < 0 || r >= rows || c >= cols) return false; // out of bounds
    if (maze[r][c] === 1) return false;                          // wall
    if (visited.has(`${r},${c}`)) return false;                   // already tried this cell

    visited.add(`${r},${c}`);
    path.push([r, c]);                                            // choose

    if (r === rows - 1 && c === cols - 1) return true;            // reached the goal

    const directions = [[1, 0], [-1, 0], [0, 1], [0, -1]];
    for (const [dr, dc] of directions) {
      if (backtrack(r + dr, c + dc)) return true;                 // explore
    }

    path.pop();                                                    // un-choose — dead end
    return false;
  }

  return backtrack(0, 0) ? path : null;
}
```

The `visited` set prevents infinite loops between adjacent open cells, and `path.pop()` on a dead end is the backtracking step — the cell is removed from the *current candidate path* (though it stays in `visited` to avoid re-trying it from a different direction, since we've already proven it doesn't lead anywhere useful along this route). This same 4-directions-per-cell backtracking shape is exactly what `problems/07-word-search.md` builds on, with the added constraint of matching a target string character by character.
