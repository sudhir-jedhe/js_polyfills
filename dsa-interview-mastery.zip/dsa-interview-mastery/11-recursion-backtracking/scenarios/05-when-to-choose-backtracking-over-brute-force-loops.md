# Scenario: Deciding Between Backtracking and Plain Nested Loops

**Scenario:** An interviewer gives you a problem — "find all ways to assign 4 tasks to 4 people, one task each, minimizing total cost" — and asks how you'd approach it before writing any code. How do you decide whether this needs backtracking, or whether nested loops / brute force is enough?

**Decision framework:**

- **Is the number of "slots" to fill fixed and small, with a fixed set of choices per slot, where choices interact (using one option affects what's available next)?** That's the signature of a backtracking problem — here, "assign a person to a task" removes that person from consideration for the remaining tasks, so choices aren't independent. Plain nested loops work when choices *are* independent (e.g. "for every pair (i, j), independently check something") — no need for backtracking's choose/un-choose machinery if nothing needs to be undone between choices.
- **Does the search space need pruning to be tractable?** With 4 people and 4 tasks, brute force (4! = 24 total assignments) is small enough to fully enumerate either way. But the *pattern* is backtracking regardless of scale — the moment the problem said "assign," "arrange," or "one task each" (implying a choice that removes an option from later consideration), that's the tell, independent of whether N happens to be small enough for brute force to also work.
- **Is a full result set needed, or just the single best one?** If only the minimum-cost assignment is needed (not every possible assignment), backtracking with pruning (abandon a partial assignment as soon as its cost already exceeds the best solution found so far — a technique called branch and bound) is significantly faster than generating everything and comparing afterward.

**Approach (backtracking with branch-and-bound pruning):**

```js
function minCostAssignment(costMatrix) {
  const n = costMatrix.length;
  const usedTasks = new Array(n).fill(false);
  let best = Infinity;

  function backtrack(person, currentCost) {
    if (currentCost >= best) return;          // prune: already worse than the best found
    if (person === n) {
      best = Math.min(best, currentCost);
      return;
    }
    for (let task = 0; task < n; task++) {
      if (usedTasks[task]) continue;
      usedTasks[task] = true;                  // choose
      backtrack(person + 1, currentCost + costMatrix[person][task]); // explore
      usedTasks[task] = false;                 // un-choose
    }
  }

  backtrack(0, 0);
  return best;
}
```

**Takeaway:** the keywords "all ways to," "every arrangement of," "assign," with a constraint that later choices depend on earlier ones, are the practical trigger for reaching for backtracking over plain loops — and adding a pruning condition (like `if (currentCost >= best) return;`) is what separates a working-but-slow backtracking solution from an efficient one.
