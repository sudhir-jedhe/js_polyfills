# Scenario: Flattening a Nested Comments Tree

**Scenario:** Your app renders threaded comments (each comment has a `replies` array of child comments, arbitrarily deep). You need a flat, ordered list of every comment (for search indexing or a "load more" flattened view), preserving depth-first order. How would you approach it, and what's the risk?

**Approach:**

```js
function flattenComments(comments, depth = 0, result = []) {
  for (const comment of comments) {
    result.push({ ...comment, depth, replies: undefined });
    if (comment.replies?.length) {
      flattenComments(comment.replies, depth + 1, result); // recurse into children
    }
  }
  return result;
}
```

Recursion is the natural fit here because the data itself is recursively defined (a comment tree is a comment, plus a list of comment trees) — the traversal code mirrors the data structure almost line for line. Each call handles one level of `replies`, appending flattened entries in depth-first order and tagging each with its `depth` for indentation.

**Risk to flag:** comment threads are usually shallow in practice, but if the data is user-generated and unbounded (e.g. a malicious client crafts a reply chain thousands of levels deep before submitting), this recursive approach can throw `RangeError: Maximum call stack size exceeded`. In an interview, naming this tradeoff explicitly is the signal: either cap the depth defensively before recursing, or convert to an iterative traversal with an explicit stack (see `../theory/05-recursion-vs-iteration-tradeoffs.md`) if the input can't be trusted to stay shallow.
