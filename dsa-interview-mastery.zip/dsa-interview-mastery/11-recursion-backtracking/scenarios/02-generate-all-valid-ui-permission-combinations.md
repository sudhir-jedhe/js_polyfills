# Scenario: Generating All Valid Feature-Flag Combinations for QA

**Scenario:** QA wants to test every possible combination of 5 independent feature flags (each on/off) to catch interaction bugs, but only combinations that satisfy a business rule (e.g. "flag C requires flag A") should be tested — invalid combinations should be skipped, not generated and then filtered out. How would you generate them?

**Approach:** this is a subset-generation problem (each flag is either included/"on" or excluded/"off") with a validity constraint applied *during* generation — a direct fit for the backtracking template with pruning:

```js
function validCombinations(flags, rules) {
  const result = [];
  const chosen = [];

  function backtrack(i) {
    if (i === flags.length) {
      if (rules.every((rule) => rule(chosen))) {
        result.push([...chosen]);
      }
      return;
    }
    chosen.push(true);  // flag i = on
    backtrack(i + 1);
    chosen.pop();

    chosen.push(false); // flag i = off
    backtrack(i + 1);
    chosen.pop();
  }

  backtrack(0);
  return result;
}
```

For a stronger answer: instead of validating only at the leaf (`i === flags.length`), push validity checks earlier wherever a rule can be evaluated on a partial `chosen` array — e.g. if flag C is already decided "on" and flag A is already decided "off," you can prune that whole branch immediately rather than walking all the way to a full combination first. This is the same "prune early, not late" principle used in N-Queens and Sudoku: the earlier an invalid branch is cut off, the more of the exponential search tree is avoided.
