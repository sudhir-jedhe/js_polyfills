Diagrams (call stack frames, recursion trees, backtracking decision trees) for this topic will be added here.
