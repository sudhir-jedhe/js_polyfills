# Source Map — js_polyfills/Algorithm + Data Structure → this repo

Note: device staging is still blocked this pass (`untrusted_device` — sign in again in the Claude desktop app
to fix). Nothing was physically copied into `from-your-notes/`/`assets/` this time; the mapping below is
accurate and ready to execute once you're signed back in.

## Mapped from `js_polyfills/Data Structure/`

| New topic | Source file(s)/folder(s) |
|---|---|
| `01-big-o-complexity-analysis` | `dsa-with-javascript-course-master/#1 - Big O Notation/` (time-complexity.md, space-complexity.md) |
| `02-arrays-strings` | `dsa-with-javascript-course-master/#2 - Arrays/`, `#6 - Strings/`, `containerWithMaxWater.md` |
| `03-linked-lists` | `linkedList/` (20+ files — a very deep folder you already have, worth a full read alongside this topic), `dsa-with-javascript-course-master/#9 - Linked List/` |
| `04-stacks-queues` | `stack/` (13 files), `Queue/` (4 files), `dsa-with-javascript-course-master/#4 - Stacks/`, `#5 - Queue/` |
| `05-trees-bst` | `BinaryTree/`, `BinarySearchTree/`, `Tree/Tree.md` |
| `06-graphs` | `graph/` (dfs.md, Graph.md), `breadth-first-search/`, `depth-first-search/` |
| `07-heaps-priority-queues` | `Queue/priority-queue-in-JavaScript.md`, `sorting/heap-sort/` |
| `08-hashing-hashmaps-sets` | `Set/index.md` |
| `09-sorting-algorithms` | `sorting/` (bubbleSort, insertionSort, selectionSort, merge-sort/, quick-sort/, heap-sort/, Bucket sort/, TopologicalSort/), `dsa-with-javascript-course-master/#8 - Sorting Algorithms/` |
| `10-searching-algorithms` | `searching/` (binarySearch/, linear-search.md, aho-corasick-algorithm.md), `dsa-with-javascript-course-master/#7 - Search Algorithms/` |
| `11-recursion-backtracking` | `recursive/` (fibonaci.md, towerOfHanoi.md), `backTracking/` (n-queen-problem, solveSudoku), `dsa-with-javascript-course-master/#3 - Recursion/` |
| `12-two-pointers-sliding-window-prefix-sum` | `containerWithMaxWater.md` (shared with 02), `dsa-with-javascript-course-master/#5 - Queue/4-sliding-window-maximum.md` |
| `13-dynamic-programming` | *(no dedicated DP folder found in your notes — this is a gap your existing material doesn't cover; the new content here is the primary resource)* |
| *(general reference)* | `DSA quiz in js.md`, `flood-fill-algorithm.md`, `k-means.md`, `leetcode.md` — worth a skim, cut across topics |

## Mapped from `js_polyfills/Algorithm/` (flat folder, tree/array-heavy)

| New topic | Source file(s) |
|---|---|
| `05-trees-bst` | `Binary Search Tree.md`, `Binary Tree Diameter.md`, `BST Traversal.md`, `Find Successor.md`, `Height Balanced Binary Tree.md`, `Invert binary tree.md`, `Branch Sums.md` |
| `06-graphs` | `Depth First Search.md` |
| `02-arrays-strings` | `isMonotonicArrayIncreasing.md`, `moveElementToEnd.md`, `runLengthEncoding.md`, `sortedSquaredArray.md`, `threeNumberSum.md` |
| `03-linked-lists` | `removeDuplicatesFromLinkedList.js'` (note: filename has a trailing stray quote character) |
| `13-dynamic-programming` | `minimumNumberOfCoinsToMakeChange.md`, `numberOfWaysToMakeChange.md`, `productSum.md` |
| `10-searching-algorithms` | `binarySearch.md` |

## Real reference material worth a manual skim (not auto-processed)

- `Data Structure/SDLC Vibe codding.pdf` (9.8MB) and `Data Structure/Top50.pdf` (4.9MB) — too large for automatic
  extraction, worth opening directly.
- `Data Structure/dsa-with-javascript-course-master/` is a full structured mini-course you already have (9
  numbered modules) — most of it is now cross-referenced above, but the folder itself is worth browsing end to
  end as a second-pass review.

## What wasn't touched

Nothing else — the two source folders were fully inventoried above.
