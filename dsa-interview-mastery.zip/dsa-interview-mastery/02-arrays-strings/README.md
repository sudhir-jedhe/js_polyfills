# Arrays & Strings

Arrays and strings are the substrate almost every other DSA topic builds on — most interview problems start by reasoning about a linear sequence of data before layering on trees, graphs, or dynamic programming. This topic covers the real complexity of every core array operation (why `push` is cheap and `unshift` is expensive), in-place vs extra-space tradeoffs, the standard string-manipulation patterns (frequency counting, anagrams, palindromes), a light introduction to two pointers (the full topic lives at `12-two-pointers-sliding-window-prefix-sum`), JS's mutable-array/immutable-string semantics and the bugs that come from getting that wrong, and a brief look at typed arrays.

## Folder structure

- **`theory/`** — array operation complexities, in-place vs extra-space techniques, common string manipulation patterns, two-pointer basics, mutability/reference semantics in JS, and a brief typed-arrays overview.
- **`snippets/`** — 7 runnable examples: push/unshift cost comparison, in-place reversal, two anagram-check approaches, two-pointer sorted-pair-sum, in-place duplicate removal, efficient string building, and shallow-vs-deep copy.
- **`output-based/`** — 6 "what's the output / complexity?" questions covering reference mutation, default `sort()` behavior, string immutability, `splice` vs `slice`, a hidden `O(n²)` from `.includes()` in a loop, and array-length manipulation/holes.
- **`scenarios/`** — 4 real-world engineering scenarios: an activity feed with expensive prepends, de-duplicating a multi-million-row import, a shared-state mutation bug from `sort()`, and choosing `Set` over `Array` for hot-path membership checks.
- **`interview-qa/`** — 3 themed Q&A files: array fundamentals, strings and mutability, and optimization patterns.
- **`problems/`** — 7 hands-on coding challenges: two sum, valid anagram, maximum subarray (Kadane's), longest substring without repeating characters, product of array except self, group anagrams, and valid palindrome.
- **`assets/`** — placeholder for diagrams (see `assets/README.md`).

## What's covered

- The real time complexity of every core array operation (index access, push/pop, shift/unshift, splice, slice, sort, search)
- In-place (O(1) extra space) vs extra-space (O(n)) techniques, and the read/write-pointer pattern for in-place compaction
- Common string patterns: frequency counting, anagram checks, palindrome checks, and efficient string building
- Two-pointer basics: opposite-ends (converging) and same-direction pointer patterns
- JS mutability rules: which array methods mutate vs return new arrays, string immutability, and shallow vs deep copying
- A brief look at typed arrays and when they matter
- Hands-on: two sum, valid anagram, maximum subarray, longest substring without repeats, product of array except self, group anagrams, and valid palindrome — each with full complexity analysis
