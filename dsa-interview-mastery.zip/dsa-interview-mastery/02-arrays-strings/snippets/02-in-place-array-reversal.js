// In-place array reversal with two pointers — O(n) time, O(1) space

function reverseInPlace(arr) {
  let left = 0;
  let right = arr.length - 1;
  while (left < right) {
    [arr[left], arr[right]] = [arr[right], arr[left]];
    left++;
    right--;
  }
  return arr;
}

const nums = [1, 2, 3, 4, 5];
console.log(reverseInPlace(nums)); // [5, 4, 3, 2, 1]
console.log(nums);                  // same array reference, mutated directly
