// Building a string efficiently: array-join pattern vs naive += concatenation

function buildNaive(n) {
  let result = '';
  for (let i = 0; i < n; i++) result += `item-${i},`;
  return result;
}
// Theoretically O(n^2) worst case across engines without rope-string optimization

function buildWithJoin(n) {
  const parts = [];
  for (let i = 0; i < n; i++) parts.push(`item-${i},`);
  return parts.join('');
}
// O(n) — array push is O(1) amortized per element, one O(n) join at the end

console.log(buildNaive(5));      // item-0,item-1,item-2,item-3,item-4,
console.log(buildWithJoin(5));   // item-0,item-1,item-2,item-3,item-4,
// Prefer buildWithJoin for large n or when portability across engines matters.
