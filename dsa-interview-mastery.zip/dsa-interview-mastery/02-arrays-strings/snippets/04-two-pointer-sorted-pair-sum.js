// Two-pointer sorted pair sum — O(n) vs the O(n^2) brute force

function twoSumBruteForce(sortedArr, target) {
  for (let i = 0; i < sortedArr.length; i++) {
    for (let j = i + 1; j < sortedArr.length; j++) {
      if (sortedArr[i] + sortedArr[j] === target) return [i, j];
    }
  }
  return [-1, -1];
}
// O(n^2) time, O(1) space

function twoSumTwoPointer(sortedArr, target) {
  let left = 0;
  let right = sortedArr.length - 1;
  while (left < right) {
    const sum = sortedArr[left] + sortedArr[right];
    if (sum === target) return [left, right];
    if (sum < target) left++;
    else right--;
  }
  return [-1, -1];
}
// O(n) time, O(1) space -- only works because the input is sorted

const sorted = [-4, -1, 0, 3, 10, 15];
console.log(twoSumBruteForce(sorted, 9));  // [1, 4]  (-1 + 10 = 9)
console.log(twoSumTwoPointer(sorted, 9));  // [1, 4]  same result, O(n) instead of O(n^2)
