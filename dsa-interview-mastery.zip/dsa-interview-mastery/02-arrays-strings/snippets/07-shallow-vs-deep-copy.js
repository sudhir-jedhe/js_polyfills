// Shallow copy vs deep copy pitfalls with nested arrays

const matrix = [[1, 2], [3, 4]];

const shallowCopy = [...matrix];       // copies the OUTER array only
shallowCopy[0].push(99);
console.log('original after shallow mutation:', matrix[0]); // [1, 2, 99] -- leaked!

const resetMatrix = [[1, 2], [3, 4]];
const deepCopy = resetMatrix.map(row => [...row]); // copies each inner array too
deepCopy[0].push(100);
console.log('original after deep-copy mutation:', resetMatrix[0]); // [1, 2] -- protected

// For deeper nesting, structuredClone() performs a true deep copy natively:
const deeplyNested = { grid: [[1, [2, 3]], [4, 5]] };
const trueClone = structuredClone(deeplyNested);
trueClone.grid[0][1].push(999);
console.log('original untouched:', deeplyNested.grid[0][1]); // [2, 3]
