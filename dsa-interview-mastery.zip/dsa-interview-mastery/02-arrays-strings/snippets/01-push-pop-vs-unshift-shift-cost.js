// push/pop (O(1) amortized) vs unshift/shift (O(n)) — measuring the real-world difference

function timeOperation(fn) {
  const start = performance.now();
  fn();
  return (performance.now() - start).toFixed(2);
}

const n = 50_000;

const arrEnd = [];
const endTime = timeOperation(() => {
  for (let i = 0; i < n; i++) arrEnd.push(i); // O(1) amortized each
});

const arrFront = [];
const frontTime = timeOperation(() => {
  for (let i = 0; i < n; i++) arrFront.unshift(i); // O(n) each -> O(n^2) total
});

console.log(`push x${n}:    ${endTime}ms`);
console.log(`unshift x${n}: ${frontTime}ms`); // dramatically slower — O(n^2) vs O(n) total work
