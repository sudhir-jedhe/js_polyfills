// Remove duplicates from a SORTED array in place — read/write pointer pattern

function removeDuplicatesSorted(sortedArr) {
  if (sortedArr.length === 0) return 0;
  let writeIdx = 0;
  for (let readIdx = 1; readIdx < sortedArr.length; readIdx++) {
    if (sortedArr[readIdx] !== sortedArr[writeIdx]) {
      writeIdx++;
      sortedArr[writeIdx] = sortedArr[readIdx];
    }
  }
  return writeIdx + 1; // new logical length; elements beyond this index are stale
}
// O(n) time, O(1) extra space

const arr = [1, 1, 2, 2, 2, 3, 4, 4, 5];
const newLength = removeDuplicatesSorted(arr);
console.log(newLength);                 // 5
console.log(arr.slice(0, newLength));   // [1, 2, 3, 4, 5]
