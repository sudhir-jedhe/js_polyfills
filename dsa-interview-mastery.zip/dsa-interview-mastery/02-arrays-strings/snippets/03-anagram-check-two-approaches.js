// Anagram check: O(n log n) sort-based vs O(n) frequency-map based

function isAnagramSort(a, b) {
  if (a.length !== b.length) return false;
  return [...a].sort().join('') === [...b].sort().join('');
}
// O(n log n) time, O(n) space (arrays created for sorting)

function isAnagramFreq(a, b) {
  if (a.length !== b.length) return false;
  const counts = new Map();
  for (const ch of a) counts.set(ch, (counts.get(ch) || 0) + 1);
  for (const ch of b) {
    const remaining = counts.get(ch);
    if (!remaining) return false;
    counts.set(ch, remaining - 1);
  }
  return true;
}
// O(n) time, O(k) space where k = number of distinct characters

console.log(isAnagramSort('listen', 'silent')); // true
console.log(isAnagramFreq('listen', 'silent')); // true
console.log(isAnagramFreq('rat', 'car'));         // false
