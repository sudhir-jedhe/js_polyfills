# Interview Q&A — Array Fundamentals

**Q: Why are `push`/`pop` fast but `shift`/`unshift` slow on JS arrays?**
JS arrays are backed by contiguous, index-addressed storage. `push`/`pop` operate at the end, so no other elements need to move — that's O(1) (amortized for push, due to occasional resizing). `shift`/`unshift` operate at the start, which requires re-indexing every other element by one position — that's O(n) regardless of where in the array you're inserting/removing, since all subsequent elements must shift.

**Q: What's the time complexity of `Array.prototype.sort()` in V8, and what's its worst case?**
O(n log n) — V8 uses TimSort (a hybrid of merge sort and insertion sort), which has a guaranteed O(n log n) worst case, unlike quicksort's O(n²) worst case. It's also worth knowing that `.sort()` mutates the array in place and returns the same reference.

**Q: Are JS arrays and typed arrays interchangeable?**
No. Regular arrays are dynamic, can hold mixed types, and support methods like `push`/`splice` that change length. Typed arrays (`Int32Array`, `Float64Array`, etc.) are fixed-length, single-numeric-type views over a raw binary buffer — they're more memory-efficient for large numeric datasets but lack length-changing methods entirely.

**Q: What's the difference between `slice` and `splice`?**
`slice(start, end)` is non-mutating and returns a new array containing a shallow copy of the specified range. `splice(start, deleteCount, ...itemsToInsert)` is mutating — it removes elements directly from the original array (and optionally inserts new ones), returning the removed elements as a new array.

**Q: Why does `[10, 1, 2].sort()` not sort numerically?**
Because `sort()` without a comparator converts elements to strings and compares them lexicographically by default, so `'10' < '2'` as strings even though `10 > 2` numerically. Always pass an explicit comparator (`(a, b) => a - b`) when sorting numbers.
