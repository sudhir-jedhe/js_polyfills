# Interview Q&A — Optimization Patterns

**Q: You have a nested loop where the inner loop calls `.includes()` on another array. What's the actual complexity, and how would you fix it?**
If both collections have size n, the outer loop runs n times and each `.includes()` call is itself O(n), giving O(n²) total, even though there's only one visible `for` loop in the code — a hidden linear scan inside a loop is a common way quadratic complexity sneaks in unnoticed. The fix is to convert the inner collection to a `Set` once, upfront (O(n)), and replace `.includes()` calls with `Set.has()` (O(1) average), bringing the total down to O(n).

**Q: When would you choose a two-pointer approach over a hash-map approach for a "find a pair" style problem, given both can be O(n)?**
Two pointers requires the input to be sorted (or sortable, factoring in the O(n log n) sort cost if it isn't already) but needs only O(1) extra space; a hash-map approach works on unsorted input directly and is O(n) time but requires O(n) extra space. If the input is already sorted and memory is a concern, prefer two pointers. If the input is unsorted and you don't want to pay an O(n log n) sort just to enable two pointers, the hash-map approach is usually the better default.

**Q: What's the general strategy for reducing an O(n²) array/string solution to O(n)?**
Ask what information the nested loop is repeatedly re-deriving, and whether it can be precomputed or looked up in O(1). Almost always the fix is one of: (1) a hash map/set to replace repeated linear scans with O(1) lookups, (2) a single pass with a running aggregate (sum, max, frequency count) instead of recomputing it from scratch each iteration, or (3) sorting once upfront to enable a two-pointer or greedy single pass afterward.

**Q: Why is "in-place" not really achievable for string algorithms the way it is for arrays?**
Because strings are immutable in JS — there's no operation that mutates a string's existing memory the way `arr[i] = x` mutates an array. Any "in-place" string algorithm actually means "O(1) *extra* space beyond a fixed-size result," typically achieved by converting to a mutable array of characters, performing in-place swaps/edits on that array, and calling `.join('')` once at the end to produce the unavoidable new string.
