# Interview Q&A — Strings and Mutability

**Q: Why are strings immutable in JavaScript, and what's the practical consequence for algorithm design?**
Strings are a primitive type in JS; every operation that appears to "modify" a string (concatenation, `slice`, `replace`, `toUpperCase`, etc.) actually creates and returns a brand-new string, leaving the original untouched. The practical consequence: any algorithm that "builds" a string incrementally should generally accumulate pieces in a mutable array and call `.join('')` once at the end, rather than repeatedly concatenating with `+=` in a loop, to avoid a theoretical O(n²) blowup on engines without rope-string optimization.

**Q: How would you check if two strings are anagrams of each other, and what's the complexity of your approach?**
Two viable approaches: sort both strings and compare for equality (O(n log n), dominated by the sort), or build a character-frequency map from one string and decrement counts while scanning the other, failing if any count goes negative or a character is unseen (O(n) time, O(k) space for k distinct characters). The frequency-map approach is strictly better asymptotically and is the preferred answer when optimality is asked for.

**Q: What's the difference between a shallow copy and a deep copy, and when does the distinction matter for arrays of strings vs arrays of arrays/objects?**
A shallow copy (`[...arr]`, `.slice()`) copies only the top-level container — if the elements themselves are primitives (like strings or numbers), a shallow copy is sufficient since primitives are copied by value. If elements are reference types (nested arrays/objects), a shallow copy still shares those nested references with the original, so mutating a nested element affects both the "copy" and the original — a deep copy (recursively copying every nested level, or using `structuredClone()`) is required to fully isolate them.

**Q: Given a mutable array method like `sort()` or `reverse()`, how do you use it without mutating the caller's original array?**
Copy first, then call the mutating method on the copy: `const sorted = [...arr].sort(...)`. As of ES2023, non-mutating counterparts exist for the most common mutating methods — `toSorted()`, `toReversed()`, `toSpliced()`, and `with()` — which return a new array without touching the original, avoiding the copy-then-mutate boilerplate.
