# Problem: Maximum Subarray (Kadane's Algorithm)

## Problem Statement

Given an integer array `nums`, find the contiguous subarray with the largest sum, and return that sum.

## Constraints

- `1 <= nums.length <= 10^5`
- `-10^4 <= nums[i] <= 10^4`
- Array may contain negative numbers; at least one element exists.

## Examples

```
maxSubArray([-2,1,-3,4,-1,2,1,-5,4]) → 6   (subarray [4,-1,2,1])
maxSubArray([1])                       → 1
maxSubArray([-1,-2,-3])                → -1  (best is the single least-negative element)
```

## Approach

Kadane's algorithm: track the best sum ending exactly at the current index (`currentSum`), and the best sum seen anywhere so far (`maxSum`). At each element, decide whether to extend the previous subarray or start fresh at the current element — extending is only worth it if the running sum so far is positive; otherwise, starting fresh is at least as good. This is a single linear pass with O(1) state, no nested loops needed despite this being a "subarray" problem (which often tempts an O(n²) brute-force scan of all subarrays).

## Solution

```js
function maxSubArray(nums) {
  let currentSum = nums[0];
  let maxSum = nums[0];

  for (let i = 1; i < nums.length; i++) {
    currentSum = Math.max(nums[i], currentSum + nums[i]); // extend or restart
    maxSum = Math.max(maxSum, currentSum);
  }

  return maxSum;
}
```

## Complexity Analysis

**Time: O(n)** — single pass, O(1) work per element. This beats the naive brute-force approach of checking every subarray's sum, which is O(n²) (or O(n³) without a running-sum optimization).
**Space: O(1)** — only two scalar variables, no auxiliary structure.
