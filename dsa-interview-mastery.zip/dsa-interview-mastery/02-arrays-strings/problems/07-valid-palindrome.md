# Problem: Valid Palindrome (Alphanumeric Only, Case-Insensitive)

## Problem Statement

Given a string `s`, determine if it is a palindrome after converting all uppercase letters to lowercase and removing all non-alphanumeric characters.

## Constraints

- `1 <= s.length <= 2 * 10^5`
- `s` consists only of printable ASCII characters.

## Examples

```
isPalindrome('A man, a plan, a canal: Panama') → true
isPalindrome('race a car')                       → false
isPalindrome(' ')                                 → true  (empty after filtering)
```

## Approach

Rather than building a cleaned copy of the string first (which would cost O(n) extra space for the filtered string), use two pointers converging from both ends of the *original* string, skipping non-alphanumeric characters on the fly and comparing lowercase versions directly — avoiding any intermediate string allocation.

## Solution

```js
function isPalindrome(s) {
  const isAlphanumeric = ch => /[a-z0-9]/i.test(ch);

  let left = 0;
  let right = s.length - 1;

  while (left < right) {
    while (left < right && !isAlphanumeric(s[left])) left++;
    while (left < right && !isAlphanumeric(s[right])) right--;

    if (s[left].toLowerCase() !== s[right].toLowerCase()) return false;

    left++;
    right--;
  }

  return true;
}
```

## Complexity Analysis

**Time: O(n)** — each of `left` and `right` moves strictly toward the center and each index is visited a constant number of times total across both the skip-loops and the comparison, so total work is bounded by O(n) despite the nested `while` loops.
**Space: O(1)** — no new string or array is built; only two index pointers and constant per-character work (the regex test and `toLowerCase()` calls are O(1) per single character).
