# Problem: Valid Anagram

## Problem Statement

Given two strings `s` and `t`, return `true` if `t` is an anagram of `s` (uses exactly the same characters, same multiplicity, in any order).

## Constraints

- `1 <= s.length, t.length <= 5 * 10^4`
- Lowercase English letters only (for the O(1)-space variant).

## Examples

```
isAnagram('anagram', 'nagaram') → true
isAnagram('rat', 'car')          → false
isAnagram('a', 'ab')             → false
```

## Approach

Different lengths can never be anagrams — check that first as an O(1) short-circuit. Otherwise, build a frequency count of characters in `s`, then decrement for each character in `t`; if any count goes negative or a character is unseen, they're not anagrams.

## Solution

```js
function isAnagram(s, t) {
  if (s.length !== t.length) return false;

  const counts = new Array(26).fill(0); // fixed alphabet -> O(1) space
  const base = 'a'.charCodeAt(0);

  for (let i = 0; i < s.length; i++) {
    counts[s.charCodeAt(i) - base]++;
    counts[t.charCodeAt(i) - base]--;
  }

  return counts.every(c => c === 0);
}
```

## Complexity Analysis

**Time: O(n)** — two single passes over strings of length n (the counting loop, then the O(26) = O(1) `.every` check).
**Space: O(1)** — the counts array is fixed at 26 entries regardless of input size (assuming a fixed lowercase-English alphabet; a general Unicode version would need a hash map instead, giving O(k) space for k distinct characters).
