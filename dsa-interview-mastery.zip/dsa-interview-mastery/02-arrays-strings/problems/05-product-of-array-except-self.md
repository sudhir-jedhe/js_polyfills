# Problem: Product of Array Except Self

## Problem Statement

Given an integer array `nums`, return an array `answer` such that `answer[i]` is the product of all elements of `nums` except `nums[i]`, **without using division**, in O(n) time.

## Constraints

- `2 <= nums.length <= 10^5`
- The product of any prefix or suffix fits in a 32-bit integer.
- Division is explicitly disallowed (otherwise the trivial solution is: total product / nums[i]).
- The output array does not count toward the O(1)-extra-space follow-up.

## Examples

```
productExceptSelf([1,2,3,4]) → [24,12,8,6]
productExceptSelf([-1,1,0,-3,3]) → [0,0,9,0,0]
```

## Approach

For each index `i`, the answer is (product of everything to its left) × (product of everything to its right). Compute left-running-products in one pass, then fold in right-running-products in a second pass, reusing the output array itself as the "left products" storage to keep extra space at O(1) (beyond the required output array).

## Solution

```js
function productExceptSelf(nums) {
  const n = nums.length;
  const answer = new Array(n).fill(1);

  // Pass 1: answer[i] = product of all elements to the LEFT of i
  let leftProduct = 1;
  for (let i = 0; i < n; i++) {
    answer[i] = leftProduct;
    leftProduct *= nums[i];
  }

  // Pass 2: multiply in the product of all elements to the RIGHT of i
  let rightProduct = 1;
  for (let i = n - 1; i >= 0; i--) {
    answer[i] *= rightProduct;
    rightProduct *= nums[i];
  }

  return answer;
}
```

## Complexity Analysis

**Time: O(n)** — two linear passes over the array, no nested loops, no division.
**Space: O(1)** extra — only two scalar accumulator variables (`leftProduct`, `rightProduct`); the `answer` array is the required output and conventionally not counted as "extra" space.
