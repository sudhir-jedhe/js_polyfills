# Problem: Group Anagrams

## Problem Statement

Given an array of strings `strs`, group the anagrams together. Return the groups in any order.

## Constraints

- `1 <= strs.length <= 10^4`
- `0 <= strs[i].length <= 100`
- Lowercase English letters only.

## Examples

```
groupAnagrams(['eat','tea','tan','ate','nat','bat'])
→ [['eat','tea','ate'], ['tan','nat'], ['bat']]   (order of groups/elements may vary)
```

## Approach

Two strings are anagrams if and only if they produce the same sorted-character key (or the same fixed-length character-count signature). Use a `Map` from that canonical key to the list of original strings sharing it — one pass to compute keys and bucket strings, then return the map's values.

## Solution

```js
function groupAnagrams(strs) {
  const groups = new Map(); // sorted-key -> array of original strings

  for (const str of strs) {
    const key = [...str].sort().join(''); // canonical form: O(k log k) for string length k
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(str);
  }

  return [...groups.values()];
}
```

## Complexity Analysis

**Time: O(n · k log k)** — where n is the number of strings and k is the maximum string length; each of the n strings requires an O(k log k) sort to compute its canonical key, plus O(1) amortized map insert.
**Space: O(n · k)** — storing all n original strings (total characters across all strings is bounded by n·k) inside the map's buckets, plus O(k) for each temporary sorted key during processing.

**Optimization note:** the sort-based key can be replaced with an O(k) character-count signature (e.g. a 26-length count array joined into a string) for a fixed alphabet, reducing the per-string cost from O(k log k) to O(k) and the total time to O(n · k) — worth mentioning as a follow-up optimization.
