# Problem: Two Sum

## Problem Statement

Given an array of integers `nums` and an integer `target`, return the indices of the two numbers that add up to `target`.

## Constraints

- `2 <= nums.length <= 10^4`
- Exactly one valid answer exists.
- You may not use the same element twice.

## Examples

```
twoSum([2, 7, 11, 15], 9) → [0, 1]
twoSum([3, 3], 6)         → [0, 1]
```

## Approach

Single pass with a hash map from value seen so far → its index. For each element, check whether its complement (`target - element`) has already been seen; if so, we've found the pair. This avoids the brute-force nested loop entirely.

## Solution

```js
function twoSum(nums, target) {
  const seen = new Map(); // value -> index
  for (let i = 0; i < nums.length; i++) {
    const complement = target - nums[i];
    if (seen.has(complement)) {
      return [seen.get(complement), i];
    }
    seen.set(nums[i], i);
  }
  return [];
}
```

## Complexity Analysis

**Time: O(n)** — single pass, O(1) average-case map operations per element.
**Space: O(n)** — worst case, the map holds n-1 entries before the match is found.
