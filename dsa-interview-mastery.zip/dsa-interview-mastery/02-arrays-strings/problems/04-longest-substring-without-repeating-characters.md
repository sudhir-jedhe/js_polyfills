# Problem: Longest Substring Without Repeating Characters

## Problem Statement

Given a string `s`, find the length of the longest substring without repeating characters.

## Constraints

- `0 <= s.length <= 5 * 10^4`
- `s` consists of English letters, digits, symbols, and spaces.

## Examples

```
lengthOfLongestSubstring('abcabcbb') → 3   ("abc")
lengthOfLongestSubstring('bbbbb')     → 1   ("b")
lengthOfLongestSubstring('pwwkew')    → 3   ("wke")
```

## Approach

Sliding window with two pointers and a `Map` tracking each character's most recent index within the current window. Expand the right pointer each step; if the character has been seen *within* the current window, jump the left pointer to just past its previous occurrence instead of incrementing one at a time. Each character is added to and removed from consideration at most a constant number of times, keeping the whole scan linear despite the two nested-looking pointer movements.

## Solution

```js
function lengthOfLongestSubstring(s) {
  const lastSeenIndex = new Map(); // char -> most recent index
  let windowStart = 0;
  let maxLength = 0;

  for (let windowEnd = 0; windowEnd < s.length; windowEnd++) {
    const ch = s[windowEnd];
    if (lastSeenIndex.has(ch) && lastSeenIndex.get(ch) >= windowStart) {
      windowStart = lastSeenIndex.get(ch) + 1; // jump past the previous occurrence
    }
    lastSeenIndex.set(ch, windowEnd);
    maxLength = Math.max(maxLength, windowEnd - windowStart + 1);
  }

  return maxLength;
}
```

## Complexity Analysis

**Time: O(n)** — `windowEnd` advances exactly n times, and `windowStart` only ever moves forward (never backward), so total pointer movement across the whole run is bounded by O(n), not O(n²) despite the "two pointers inside one loop" structure.
**Space: O(min(n, k))** — where k is the size of the character set; the map holds at most one entry per distinct character encountered in the current window.
