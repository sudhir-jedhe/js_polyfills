# What's the Output? — `splice` vs `slice`

```js
const arr = [10, 20, 30, 40, 50];
const a = arr.slice(1, 3);
const b = arr.splice(1, 3);

console.log(a);
console.log(b);
console.log(arr);
```

**Answer:**
```
[20, 30]
[20, 30, 40]
[10, 50]
```

**Why:** `slice(start, end)` is **non-mutating** — it returns a shallow copy of elements from index `start` up to (not including) `end`, leaving `arr` untouched; `arr.slice(1, 3)` returns `[20, 30]` (indices 1 and 2) without changing `arr`. `splice(start, deleteCount)` is **mutating** — it removes `deleteCount` elements starting at `start` directly from `arr` and returns those *removed* elements as a new array; `arr.splice(1, 3)` removes 3 elements starting at index 1 (`20, 30, 40`) from the now-still-original `arr` (which was `[10, 20, 30, 40, 50]` at the time `splice` ran, unaffected by the earlier `slice` call) and returns them, leaving `arr` as `[10, 50]`. Confusing these two — both similarly named, one mutating and one not — is one of the most common array-method mistakes in real code, not just interviews.
