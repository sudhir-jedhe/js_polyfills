# What's the Output? — Attempting to Mutate a String by Index

```js
let str = 'cat';
str[0] = 'b';
console.log(str);
console.log(str.length);
```

**Answer:**
```
cat
3
```

**Why:** Strings in JavaScript are immutable primitives. `str[0] = 'b'` looks like array-style mutation, but it's a no-op — in non-strict-mode sloppy code it silently fails without throwing (it does throw a `TypeError` in strict mode / modules, since string index properties are non-writable). `str` still refers to the original, unchanged `'cat'`. The only way to "change" a string is to build an entirely new one and reassign the variable:

```js
str = 'b' + str.slice(1);
console.log(str); // 'bat' -- a genuinely new string, assigned back to str
```

This is why any string transformation is inherently at least `O(n)` extra space — there's no such thing as an in-place string mutation in JS, unlike arrays.
