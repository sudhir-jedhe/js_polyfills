# What's the Output? — Manually Setting `.length`

```js
const arr = [1, 2, 3, 4, 5];
arr.length = 3;
console.log(arr);

arr.length = 5;
console.log(arr);
console.log(arr[4]);
```

**Answer:**
```
[1, 2, 3]
[ 1, 2, 3, <2 empty items> ]
undefined
```

**Why:** `.length` is a writable property on JS arrays, not just a derived read-only count. Setting `arr.length = 3` truncates the array in place, permanently discarding elements at index 3 and beyond (`O(1)` conceptually for the truncation itself, though releasing references is up to the GC). Setting `arr.length = 5` afterward *grows* the array back to length 5, but the newly added slots are **empty slots** (holes), not `undefined`-valued elements — they show as `<2 empty items>` in Node's console output, a distinct concept from actually storing `undefined` at those indices. Reading `arr[4]` returns `undefined` either way (empty slots and explicit `undefined` both read back as `undefined`), but they behave differently for methods that skip holes — e.g. `arr.forEach()` and `arr.map()` silently skip empty slots, while they do NOT skip indices explicitly holding `undefined`. This distinction (holes vs actual `undefined` values) is a frequently-missed detail even among experienced JS developers.
