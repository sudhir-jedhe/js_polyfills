# What's the Output? — Array Passed by Reference

```js
function addItem(list, item) {
  list.push(item);
  return list;
}

const original = [1, 2, 3];
const result = addItem(original, 4);

console.log(original === result);
console.log(original);
```

**Answer:**
```
true
[1, 2, 3, 4]
```

**Why:** Arrays are reference types in JS. `list` inside `addItem` isn't a copy of `original` — it's a reference to the *same* array object in memory. `list.push(item)` mutates that shared array directly, so `original` reflects the change even though `addItem` never explicitly reassigns `original`. Returning `list` at the end simply returns the same reference back out, which is why `original === result` is `true` — they're the identical object, not two equal-but-distinct arrays. This is a very common source of bugs when a function is assumed to be "pure" (non-mutating) but actually mutates its input as a side effect.
