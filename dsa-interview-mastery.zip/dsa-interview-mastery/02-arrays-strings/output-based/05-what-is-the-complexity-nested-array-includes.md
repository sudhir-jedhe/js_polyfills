# What's the Time Complexity? — `includes` Inside a Loop

```js
function intersection(arrA, arrB) {
  const result = [];
  for (const x of arrA) {
    if (arrB.includes(x)) result.push(x);
  }
  return result;
}
```

**Question:** If both arrays have length `n`, what's the time complexity?

**Answer:** `O(n²)` — not `O(n)`.

**Why:** `arrB.includes(x)` is itself an `O(n)` linear scan (unsorted array, no shortcuts). Calling it once per element of `arrA` (also `n` iterations) means the total work is `n` calls × `O(n)` per call = `O(n²)`. It's easy to miss this because the code only has *one* explicit `for` loop — but a built-in array method called inside that loop can silently hide a second, nested linear scan. The fix: convert `arrB` to a `Set` once upfront (`O(n)`), so each membership check becomes `O(1)` average case, bringing the total down to `O(n)`:

```js
function intersectionFast(arrA, arrB) {
  const setB = new Set(arrB);       // O(n) to build
  const result = [];
  for (const x of arrA) {           // O(n)
    if (setB.has(x)) result.push(x); // O(1) average
  }
  return result;
}
// O(n) time, O(n) space
```

**Key takeaway:** always check whether a built-in method called inside a loop is itself `O(n)` — `includes`, `indexOf`, `find`, and `filter` on arrays are common offenders that turn an innocent-looking single loop into a hidden `O(n²)`.
