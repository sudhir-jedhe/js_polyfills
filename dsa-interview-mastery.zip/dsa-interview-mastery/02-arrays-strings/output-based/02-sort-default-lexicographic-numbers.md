# What's the Output? — Default `Array.sort()` on Numbers

```js
const nums = [10, 1, 21, 2];
console.log(nums.sort());
```

**Answer:**
```
[1, 10, 2, 21]
```

**Why:** `Array.prototype.sort()` without a comparator converts every element to a **string** and sorts **lexicographically (UTF-16 code-unit order)** by default — it does not sort numbers numerically. String comparison means `"10"` sorts before `"2"`, because `'1' < '2'` as characters, regardless of the fact that `10 > 2` numerically. This is one of the highest-frequency "gotcha" questions in array interviews. The fix is always to supply an explicit numeric comparator:

```js
console.log(nums.sort((a, b) => a - b)); // [1, 2, 10, 21] -- correct numeric ascending order
```

Also worth knowing: `sort()` mutates the array in place and returns the same reference (it does not return a new array) — so `nums` itself is reordered as a side effect of this call, not just the logged output.
