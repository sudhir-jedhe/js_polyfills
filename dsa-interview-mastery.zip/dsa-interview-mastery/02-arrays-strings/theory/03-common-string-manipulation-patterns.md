# Common String Manipulation Patterns

Strings in JS are immutable UTF-16 sequences. A handful of manipulation patterns cover the large majority of string interview questions.

## Character frequency counting

```js
function charFrequency(str) {
  const freq = {};
  for (const ch of str) {
    freq[ch] = (freq[ch] || 0) + 1;
  }
  return freq;
}
// O(n) time, O(k) space where k = number of distinct characters (O(1) for a fixed alphabet like ASCII)
```
Underlies anagram checks, first-unique-character problems, and character-count comparisons.

## Anagram check via sorted comparison vs frequency map

```js
function isAnagramSort(a, b) {
  if (a.length !== b.length) return false;
  return [...a].sort().join('') === [...b].sort().join('');
}
// O(n log n) — dominated by the sort

function isAnagramFreq(a, b) {
  if (a.length !== b.length) return false;
  const counts = {};
  for (const ch of a) counts[ch] = (counts[ch] || 0) + 1;
  for (const ch of b) {
    if (!counts[ch]) return false;
    counts[ch]--;
  }
  return true;
}
// O(n) — a strictly better approach than sorting for this specific check
```

## Palindrome check (two pointers)

```js
function isPalindrome(str) {
  let left = 0, right = str.length - 1;
  while (left < right) {
    if (str[left] !== str[right]) return false;
    left++; right--;
  }
  return true;
}
// O(n) time, O(1) extra space
```

## Reversing a string (via array, since strings are immutable)

```js
function reverseString(str) {
  return [...str].reverse().join('');
}
// O(n) time, O(n) space — a new array and new string are unavoidable, strings can't be mutated
```

## String-to-array-of-chars round trip

Because strings can't be mutated, "in-place" string algorithms in JS almost always mean: convert to an array of characters, mutate the array, `join('')` once at the end.

```js
function capitalizeWords(str) {
  const chars = [...str];
  let atWordStart = true;
  for (let i = 0; i < chars.length; i++) {
    if (chars[i] === ' ') { atWordStart = true; continue; }
    if (atWordStart) { chars[i] = chars[i].toUpperCase(); atWordStart = false; }
  }
  return chars.join('');
}
// O(n) time, O(n) space (unavoidable — a new string must be produced)
```

## Sliding substring patterns (brief — full topic at 12)

Many "longest substring with property X" problems use a sliding window over the string with a `Map`/`Set` tracking window contents, achieving `O(n)` instead of the naive `O(n²)` or `O(n³)` of checking every substring. This is covered in depth in `12-two-pointers-sliding-window-prefix-sum`; the core idea worth knowing here is: expand a right pointer, shrink a left pointer when a constraint is violated, and each character is added/removed from the window at most once, bounding total work at `O(n)` despite the nested-looking loop structure.

## Quick reference

| Pattern | Typical complexity | Use case |
|---|---|---|
| Frequency map | O(n) time, O(k) space | Anagrams, first unique char, char counts |
| Two-pointer scan | O(n) time, O(1) space | Palindrome checks, reversal |
| Sort-then-compare | O(n log n) | Anagram check (simpler code, worse complexity) |
| Sliding window | O(n) time, O(k) space | Longest/shortest substring with a constraint |
