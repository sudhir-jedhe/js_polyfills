# In-Place vs Extra-Space Techniques

A large share of array/string interview problems hinge on whether you can solve them **in-place** (O(1) extra space, mutating the input) versus needing an **auxiliary structure** (O(n) extra space). Recognizing which is appropriate — and being able to produce both — is a core skill.

## In-place: reversing an array

```js
function reverseInPlace(arr) {
  let left = 0, right = arr.length - 1;
  while (left < right) {
    [arr[left], arr[right]] = [arr[right], arr[left]];
    left++;
    right--;
  }
  return arr; // same array, mutated
}
// Time: O(n) — n/2 swaps
// Space: O(1) — only two index variables, no new array
```

## Extra-space equivalent

```js
function reverseCopy(arr) {
  const result = [];
  for (let i = arr.length - 1; i >= 0; i--) result.push(arr[i]);
  return result; // new array, original untouched
}
// Time: O(n)
// Space: O(n) — a full second array
```

## Why the distinction matters

| Consideration | In-place | Extra-space |
|---|---|---|
| Memory | O(1) — nothing to spare needed | O(n) — needs proportional extra memory |
| Mutates input | Yes — caller's data is changed | No — original preserved |
| Safety | Risky if caller still needs the original | Safe — no side effects |
| Typical interview signal | "optimize the space" follow-up | Default first-pass solution |

Mutating shared/caller-owned data is a real bug risk outside interviews — in production code, be explicit (naming, docs) about whether a function mutates its input, and prefer non-mutating by default unless performance specifically demands otherwise.

## Removing elements in-place (the "write pointer" pattern)

A very common in-place technique: use a slow "write" pointer and a fast "read" pointer to compact an array without allocating a new one.

```js
function removeValueInPlace(arr, val) {
  let writeIdx = 0;
  for (let readIdx = 0; readIdx < arr.length; readIdx++) {
    if (arr[readIdx] !== val) {
      arr[writeIdx] = arr[readIdx];
      writeIdx++;
    }
  }
  arr.length = writeIdx; // truncate trailing leftover elements
  return arr;
}
// Time: O(n), Space: O(1)
console.log(removeValueInPlace([3, 2, 3, 3, 4], 3)); // [2, 4]
```

## Strings are immutable in JS — "in-place" doesn't apply the same way

Unlike arrays, JS strings cannot be mutated at all — every string "modification" produces a new string. So for strings, the in-place/extra-space distinction shifts to: build the result with an array (mutable) and `join` once at the end (`O(n)` total), versus repeated string concatenation in a loop, which risks accidental `O(n²)` behavior on engines without rope-string optimizations (see `../../01-big-o-complexity-analysis/output-based/03-what-is-the-complexity-string-concatenation-in-loop.md`). "In-place" for a string problem in an interview usually means "using O(1) *extra* space beyond a fixed-size output," e.g. building the result by converting to a char array and swapping.

## When to reach for which

- **In-place** when: the problem explicitly asks for it, memory is constrained, or you're processing very large arrays where doubling memory usage is meaningful.
- **Extra-space** when: you need to preserve the original, the transformation isn't naturally reversible in place (e.g. merging two different-length arrays), or the in-place version would meaningfully hurt code clarity for a negligible memory win.
