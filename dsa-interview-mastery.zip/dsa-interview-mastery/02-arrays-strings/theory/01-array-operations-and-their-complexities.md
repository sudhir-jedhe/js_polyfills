# Array Operations and Their Complexities

JavaScript arrays are dynamic, resizable arrays under the hood (not fixed-size C-style arrays), but they still expose the same core operation set interviewers expect you to know cold — and to know the complexity of.

## Read/write by index — O(1)

```js
const arr = [10, 20, 30, 40];
arr[2];       // O(1) — direct offset calculation into contiguous memory
arr[2] = 99;  // O(1) — same reasoning
```

## Push/pop at the end — O(1) amortized / O(1)

```js
arr.push(50); // O(1) amortized — occasionally O(n) when a backing-store resize is triggered
arr.pop();    // O(1) — always, no resize needed to shrink from the end
```
See `../../01-big-o-complexity-analysis/theory/06-amortized-analysis-and-best-average-worst-case.md` for why `push` is amortized rather than strictly O(1).

## Shift/unshift at the start — O(n)

```js
arr.unshift(5); // O(n) — every existing element must shift one position to the right
arr.shift();    // O(n) — every remaining element must shift one position to the left
```
This is the single most common array-complexity trap: `push`/`pop` (end operations) are cheap, `shift`/`unshift` (start operations) are expensive, because JS arrays are contiguous — inserting/removing at the front requires re-indexing everything after it.

## Search (indexOf, includes, find) — O(n)

```js
arr.indexOf(30);           // O(n) — linear scan, no shortcuts for an unsorted array
arr.includes(30);          // O(n) — same
arr.find(x => x > 25);     // O(n) — same
```

## Splice (insert/remove in the middle) — O(n)

```js
arr.splice(1, 0, 15); // insert at index 1 — O(n), shifts every element after index 1
arr.splice(1, 1);      // remove at index 1 — O(n), same reasoning
```

## Slice — O(k), where k is the size of the resulting slice

```js
arr.slice(1, 3); // O(k) — copies k = 2 elements into a new array; O(n) in the worst case (whole array)
```

## Sort — O(n log n)

```js
arr.sort((a, b) => a - b); // O(n log n) — V8 uses TimSort; also mutates in place
```

## Complexity cheat sheet

| Operation | Complexity | Why |
|---|---|---|
| Access by index (`arr[i]`) | O(1) | Direct memory offset |
| `push` / `pop` | O(1) amortized / O(1) | End of array, no shifting; push occasionally resizes |
| `unshift` / `shift` | O(n) | Every other element must shift index |
| `indexOf` / `includes` / `find` | O(n) | No structure to skip elements (unsorted) |
| `splice` (middle insert/remove) | O(n) | Elements after the splice point must shift |
| `slice` | O(k) | Copies k elements into a new array |
| `sort` | O(n log n) | Comparison-based sort (TimSort in V8) |
| `map` / `filter` / `forEach` / `reduce` | O(n) | Single pass, O(1) work per element (assuming callback is O(1)) |

**Interview takeaway:** if you're repeatedly calling `unshift`/`shift` in a loop, that's an `O(n²)` red flag — prefer appending at the end and reversing once, or use a different data structure (e.g. a proper queue, see topic 4) if front operations are frequent.
