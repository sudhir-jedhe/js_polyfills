# Mutable vs Immutable Considerations in JS

Understanding what's mutable, what's a reference, and what gets copied is essential for both correctness and for reasoning about space complexity in array/string problems.

## Arrays are mutable, passed by reference

```js
function mutate(arr) {
  arr.push(999); // mutates the caller's array directly
}
const original = [1, 2, 3];
mutate(original);
console.log(original); // [1, 2, 3, 999] — the caller's array changed
```
Arrays (and objects) are reference types in JS — a function parameter holding an array holds a *reference* to the same underlying array the caller has, not a copy. Methods like `push`, `pop`, `splice`, `sort`, `reverse`, and index assignment (`arr[i] = x`) all mutate in place; methods like `map`, `filter`, `slice`, `concat`, and the spread operator (`[...arr]`) return new arrays without touching the original.

## Mutating vs non-mutating array methods

| Mutates original | Does NOT mutate (returns new) |
|---|---|
| `push`, `pop`, `shift`, `unshift` | `map`, `filter`, `reduce` |
| `splice` | `slice`, `concat` |
| `sort`, `reverse` | `[...arr]` (spread), `Array.from(arr)` |
| `arr[i] = x` (index assignment) | `toSorted`, `toReversed`, `toSpliced` (ES2023+, non-mutating counterparts) |

Calling `.sort()` on an array you don't own (e.g. a shared reference, a prop passed into a UI component) is a classic source of subtle bugs — the caller's array silently reorders. When in doubt, or when the function is meant to be "pure," copy first: `[...arr].sort(...)`.

## Strings are immutable — always

```js
let s = 'hello';
s[0] = 'H'; // silently does nothing (no error in non-strict evaluation contexts here)
console.log(s); // 'hello' — unchanged

s = 'H' + s.slice(1); // the only way to "change" a string: build a new one
console.log(s); // 'Hello'
```
Every string operation (`toUpperCase`, `slice`, `replace`, concatenation) produces a **new** string; the original is never modified. This has a direct space-complexity consequence: any string transformation is inherently at least `O(n)` space for the new result, and chaining multiple transformations can create intermediate throwaway strings unless you route through a mutable array first and `join` once.

## Shallow copy vs deep copy

```js
const nested = [[1, 2], [3, 4]];
const shallow = [...nested]; // copies the OUTER array only
shallow[0].push(99);
console.log(nested[0]); // [1, 2, 99] — inner array is SHARED, both see the mutation

const deep = nested.map(inner => [...inner]); // copies each inner array too
deep[0].push(100);
console.log(nested[0]); // [1, 2, 99] — unaffected this time, inner array was actually copied
```
`[...arr]` and `Array.prototype.slice()` are **shallow** copies — nested arrays/objects inside are still shared references. For problems involving 2D arrays/matrices, this is a frequent bug source: "copying" a matrix with `[...matrix]` does not protect the original from in-place row mutations.

## Interview-relevant takeaway

When a problem says "do not modify the input," check every method you call against the mutates/doesn't-mutate table above — accidentally calling `.sort()` or `.reverse()` on the original array is one of the most common ways candidates unintentionally violate that constraint. And when analyzing space complexity, remember that immutable strings mean **any** string-returning transformation is at minimum `O(n)` space, unlike arrays, where in-place mutation can genuinely achieve `O(1)`.
