# Two-Pointer Technique — Basics

The two-pointer technique uses two index variables that move through a data structure (usually an array or string) according to some rule, instead of nested loops, to solve problems in `O(n)` instead of `O(n²)`. This is a light introduction — the full topic, including sliding windows and prefix sums, lives in `12-two-pointers-sliding-window-prefix-sum`.

## Opposite-ends pointers (converging)

Start one pointer at each end, move them toward each other based on a comparison.

```js
function twoSumSorted(sortedArr, target) {
  let left = 0, right = sortedArr.length - 1;
  while (left < right) {
    const sum = sortedArr[left] + sortedArr[right];
    if (sum === target) return [left, right];
    if (sum < target) left++;   // need a bigger sum — move left pointer up
    else right--;                // need a smaller sum — move right pointer down
  }
  return [-1, -1];
}
// O(n) time, O(1) space — vs O(n^2) brute force, O(n) + O(log n) hash-map approach
```
This only works because the input is **sorted** — the ordering is what lets each pointer move monotonically without missing a valid pair.

## Same-direction pointers (fast/slow, one-pass filtering)

Both pointers move forward, but at different rates or for different purposes — one "reads," one "writes" (as seen in `02-in-place-vs-extra-space-techniques.md`'s `removeValueInPlace`), or one detects a condition the other reacts to.

```js
function removeDuplicatesSorted(sortedArr) {
  if (sortedArr.length === 0) return 0;
  let slow = 0;
  for (let fast = 1; fast < sortedArr.length; fast++) {
    if (sortedArr[fast] !== sortedArr[slow]) {
      slow++;
      sortedArr[slow] = sortedArr[fast];
    }
  }
  return slow + 1; // new logical length
}
// O(n) time, O(1) space
```

## Why two pointers beats the nested-loop default

The brute-force instinct for "find a pair matching some condition" is a nested loop (`O(n²)`) checking every pair. Two pointers works instead because, given a *sorted* input and a monotonic condition (increasing one pointer strictly increases the sum, decreasing the other strictly decreases it), each pointer only ever needs to move forward — never backward, never re-checked. That guarantees each pointer traverses the array at most once, bounding total pointer movement (and thus total work) at `O(n)`, not `O(n²)`.

## When two pointers applies

| Signal in the problem | Likely two-pointer fit |
|---|---|
| Sorted array/string, "find a pair/triplet summing to X" | Opposite-ends pointers |
| "Remove/filter in place," "compact an array" | Same-direction (read/write) pointers |
| Palindrome check | Opposite-ends pointers |
| Merging two sorted sequences | Same-direction pointers, one per sequence |

**Precondition to check:** opposite-ends two-pointer approaches almost always require sorted input (or an input where a similar monotonic property holds) — attempting it on unsorted data silently produces wrong answers, not just a runtime error, so always verify (or explicitly sort first, factoring the `O(n log n)` sort cost into your final complexity).
