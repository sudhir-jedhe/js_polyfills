# Typed Arrays — Brief Overview

Typed arrays are fixed-length, fixed-type array-like views over raw binary data buffers. They're a niche-but-occasionally-asked topic — worth knowing at a conceptual level, not deep implementation detail.

## What they are

```js
const buffer = new ArrayBuffer(16);           // 16 bytes of raw memory
const view = new Int32Array(buffer);           // view: 4 elements, each a 32-bit signed int

const nums = new Int32Array([1, 2, 3, 4]);     // convenience constructor
nums[0] = 100;
console.log(nums);       // Int32Array(4) [100, 2, 3, 4]
console.log(nums.length); // 4 — fixed, cannot grow or shrink
```

## How they differ from regular arrays

| Aspect | Regular `Array` | Typed array (e.g. `Int32Array`) |
|---|---|---|
| Length | Dynamic (grows/shrinks) | Fixed at creation |
| Element type | Any value (mixed types allowed) | Single fixed numeric type |
| Memory layout | Not guaranteed contiguous for all engines/cases | Guaranteed contiguous, fixed-size binary buffer |
| Memory overhead | Higher (boxed values, metadata per element) | Lower (packed raw bytes, no boxing) |
| Methods | Full array method set including `push`/`splice` | Most iteration methods (`map`, `forEach`, etc.), but **no** `push`/`splice`/`shift`/`unshift` (fixed length) |

## Why they matter (briefly)

Typed arrays give predictable, compact memory layout and faster numeric computation — relevant for performance-sensitive numeric code (WebGL, audio/image processing, WebAssembly interop, large numeric datasets). They avoid the overhead of JS's normal "array of boxed values" representation, since every element is a raw fixed-width number packed contiguously, closer to a C array.

```js
const regular = [1, 2, 3];          // each element is a boxed Number, engine may optimize but isn't guaranteed
const typed = new Float64Array([1, 2, 3]); // guaranteed 8 bytes per element, packed, no boxing
```

## When they'd come up in an interview

Rarely as the primary topic, but sometimes as a follow-up: "how would you handle a huge array of numbers more memory-efficiently?" — the answer is a typed array, since it avoids per-element object overhead and guarantees a predictable, minimal memory footprint (`n * bytesPerElement` exactly, vs the larger and less predictable footprint of a regular array of boxed numbers). Not a substitute for a regular array in general-purpose code — reach for one specifically when working with large, fixed-type, fixed-length numeric data (binary protocols, pixel buffers, audio samples).
