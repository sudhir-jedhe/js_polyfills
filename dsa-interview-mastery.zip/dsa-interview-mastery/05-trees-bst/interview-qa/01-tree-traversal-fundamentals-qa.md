# Interview Q&A — Tree Traversal Fundamentals

**Q: What are the four standard tree traversal orders, and what's the rule for each?**
Preorder (node, left, right), inorder (left, node, right), postorder (left, right, node) — all three are depth-first and typically implemented recursively — plus level-order (breadth-first, level by level, left to right), implemented with a queue rather than recursion/a stack.

**Q: Why does inorder traversal of a BST always produce sorted output, but preorder and postorder don't?**
Inorder's left-node-right rule means it fully exhausts everything smaller than the current node (its left subtree) before visiting the node, and everything larger (its right subtree) after — which, applied recursively at every level of a valid BST, unwinds into strictly ascending order. Preorder and postorder don't have "smaller stuff first" baked into their visit order — preorder visits the node before either subtree, and postorder visits the node after both, neither of which lines up with the BST's sorted-order guarantee.

**Q: How would you convert a recursive traversal into an iterative one, in general?**
Replace the implicit call stack with an explicit stack (or queue for BFS) that you manage yourself. Whatever state the recursive call would have needed on each recursive step, you push onto the stack instead of passing as function arguments, and you pop it back off when you'd otherwise "return" from that recursive call. Inorder is the trickiest to convert because the "visit" step happens in the middle of processing a node (after going left, before going right), which is why its iterative version needs an inner `while (curr)` loop to walk left before anything gets popped and recorded.

**Q: Why is level-order traversal implemented with a queue instead of a stack?**
Because level-order needs FIFO (first-in-first-out) ordering — nodes should be processed in the order they were *discovered*, so that all of one level finishes before the next level starts. A stack is LIFO (last-in-first-out), which would process the most recently discovered node next, producing a depth-first order instead — the entire reason DFS's iterative versions use a stack and BFS uses a queue is this same FIFO-vs-LIFO distinction.

**Q: What's the time and space complexity of each traversal, and what determines the space bound?**
All four traversals are `O(n)` time, since every node is visited exactly once regardless of order or recursive/iterative style. Space differs by shape of what's being explored: the three DFS orders are `O(h)` (tree height) because the stack (explicit or call stack) only ever holds one root-to-current-node path at a time; BFS is `O(w)` (tree's maximum width), because the queue can hold an entire level's worth of nodes at once — on a wide, shallow tree, BFS can use meaningfully more memory than DFS, and vice versa on a narrow, deep one.
