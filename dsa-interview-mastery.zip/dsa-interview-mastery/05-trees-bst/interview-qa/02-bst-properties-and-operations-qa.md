# Interview Q&A — BST Properties and Operations

**Q: What is the BST invariant, precisely — and what's a common mistake in checking it?**
For every node, its entire left subtree must be less than it, and its entire right subtree must be greater — not just its immediate children. A common bug is checking only `node.left.val < node.val < node.right.val` locally at each node; that misses cases like a right child whose *own* left grandchild is smaller than the original node but still larger than its immediate parent, which locally looks fine but violates the BST property overall. The correct check propagates a valid `(min, max)` bound down through the recursion so every node is checked against the bounds imposed by *all* of its ancestors, not just its direct parent.

**Q: Walk through deleting a node with two children from a BST.**
You can't simply remove a two-children node without breaking the ordering invariant for its subtrees. Instead, find its inorder successor — the smallest value in its right subtree, found by walking left from `node.right` until there's no more left child — copy that successor's value into the node being deleted, then recursively delete the successor's original position from the right subtree. The successor is guaranteed to have at most one child (specifically no left child, since it was found by walking left as far as possible), so that recursive delete always reduces to the simpler 0-or-1-child case.

**Q: Why is BST search `O(log n)` on a balanced tree but `O(n)` in the worst case?**
Each comparison during search eliminates one entire subtree from consideration, so on a balanced tree the search space roughly halves at each step, exactly like binary search on a sorted array — `O(log n)` steps to reach a leaf. But a plain BST has no mechanism to enforce balance: if data is inserted in sorted (or nearly sorted) order, every new node attaches as a single chain rather than splitting the search space, degrading the tree into a linked list where search must potentially check every node — `O(n)`.

**Q: Given a BST, how would you find the kth smallest element efficiently?**
An inorder traversal visits nodes in ascending order, so the kth smallest is simply the kth value produced by an inorder traversal — walk (iteratively, so you can stop early) and return the value the moment you've visited `k` nodes, rather than materializing the whole traversal first. This runs in `O(h + k)` time using the iterative inorder pattern (walk left, pop, count, go right), rather than `O(n)` for a full traversal followed by indexing.

**Q: Can a BST have duplicate values? How does implementation typically handle that?**
It depends on convention, since strict `left < node < right` doesn't define where equal values go. Common approaches: disallow duplicates outright (insert becomes a no-op if the value already exists, as shown in the standard `insert` implementation here), consistently route equal values to one side (e.g., `<=` goes left), or store a count/list at each node instead of a single value. Whichever convention is chosen, it must be applied consistently across insert, search, and delete, or the tree's invariant silently breaks.
