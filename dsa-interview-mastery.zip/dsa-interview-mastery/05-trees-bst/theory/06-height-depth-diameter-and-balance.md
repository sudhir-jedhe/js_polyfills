# Height, Depth, Diameter, and Checking Balance

These four measurements come up constantly, both as standalone interview questions and as building blocks inside bigger problems (e.g., "is this tree balanced" is a helper inside many validation problems).

## Height

Height of a node = number of edges on the longest path from that node down to a leaf. A single leaf node has height `0`; an empty tree (`null`) is conventionally defined as height `-1`.

```js
function height(node) {
  if (!node) return -1;
  return 1 + Math.max(height(node.left), height(node.right));
}
```

This is `O(n)` — it must visit every node once, since the height of any subtree potentially depends on all of its descendants.

## Depth

Depth of a node = number of edges from the **root** down to that specific node. Depth is measured top-down from a fixed root; height is measured bottom-up from a given node to its deepest leaf. The root's depth is always `0`; the root's height equals the tree's overall height.

```js
function depth(root, target, current = 0) {
  if (!root) return -1;
  if (root === target) return current;
  const left = depth(root.left, target, current + 1);
  if (left !== -1) return left;
  return depth(root.right, target, current + 1);
}
```

## Diameter

The diameter of a binary tree is the length (in edges) of the **longest path between any two nodes**, and that path does not need to pass through the root. The naive approach recomputes height at every node (`O(n)` work per node) for `O(n²)` overall. The efficient approach computes height and updates a running max diameter **in the same postorder pass**, since a node's own height calculation already requires knowing both subtrees' heights — the diameter *through* that node is just `leftHeight + rightHeight + 2` (edges) at that point, essentially free to check.

```js
function diameterOfBinaryTree(root) {
  let maxDiameter = 0;

  function heightAndUpdate(node) {
    if (!node) return -1;
    const leftHeight = heightAndUpdate(node.left);
    const rightHeight = heightAndUpdate(node.right);
    // longest path passing through `node` = left subtree height + right subtree height + 2 edges
    maxDiameter = Math.max(maxDiameter, leftHeight + rightHeight + 2);
    return 1 + Math.max(leftHeight, rightHeight);
  }

  heightAndUpdate(root);
  return maxDiameter;
}
```

This runs in `O(n)` time with a single traversal, versus the naive `O(n²)` of recomputing height per node — a very common "optimize this" interview follow-up.

## Checking if a tree is height-balanced

"Balanced" here (in the LeetCode / common-interview sense, distinct from AVL's strict balance factor) means: for every node, the height difference between its left and right subtrees is at most 1. The naive version recomputes height repeatedly (`O(n²)`); the efficient version again folds the check into a single postorder pass, short-circuiting (bubbling up `-2` as a sentinel) the moment imbalance is found anywhere:

```js
function isBalanced(root) {
  function check(node) {
    if (!node) return -1; // height of empty subtree
    const left = check(node.left);
    if (left === -2) return -2; // imbalance already found below — propagate up
    const right = check(node.right);
    if (right === -2) return -2;
    if (Math.abs(left - right) > 1) return -2; // sentinel: "imbalanced"
    return 1 + Math.max(left, right);
  }
  return check(root) !== -2;
}
```

## Complexity summary

| Operation | Naive | Optimized (single-pass) |
|---|---|---|
| Height | `O(n)` | — (already optimal) |
| Diameter | `O(n²)` (height recomputed per node) | `O(n)` (folded into one postorder pass) |
| Is-balanced check | `O(n²)` | `O(n)` (folded into one postorder pass, with early exit) |

The recurring pattern: whenever a problem needs "height of every subtree" as an ingredient, compute it **bottom-up in a single postorder traversal** and combine it with whatever else is needed (diameter, balance check) at each node during that same pass, rather than calling a separate `height()` function repeatedly from an outer traversal.
