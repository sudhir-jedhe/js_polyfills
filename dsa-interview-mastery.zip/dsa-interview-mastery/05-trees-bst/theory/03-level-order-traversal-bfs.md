# Level-Order Traversal (BFS)

Unlike the three DFS orders, **level-order traversal** (breadth-first search) visits nodes level by level, left to right, before descending to the next level. It uses a **queue** (FIFO) instead of a stack, because the goal is to process nodes in the order they were *discovered*, not the order they were most recently pushed.

```
        1
       / \
      2   3
     / \
    4   5
```

Level order: `1, 2, 3, 4, 5`

## Basic implementation

```js
function levelOrder(root) {
  if (!root) return [];
  const out = [];
  const queue = [root];
  while (queue.length) {
    const node = queue.shift(); // dequeue from the front
    out.push(node.val);
    if (node.left) queue.push(node.left);
    if (node.right) queue.push(node.right);
  }
  return out;
}
```

> **Interview note on `Array.shift()`:** `shift()` is `O(n)` on a plain JS array because every remaining element has to shift down an index. For interview-sized inputs this is fine and keeps the code readable, but for a performance-sensitive real implementation, use an index pointer or a proper queue (e.g. two-stack queue or a circular buffer) to keep dequeue `O(1)`.

## Grouped by level

The far more common interview variant asks for output grouped into a list of levels — `[[1], [2,3], [4,5]]` — which requires snapshotting the queue's size at the start of each level:

```js
function levelOrderGrouped(root) {
  if (!root) return [];
  const result = [];
  const queue = [root];
  while (queue.length) {
    const levelSize = queue.length; // freeze "how many nodes are in this level"
    const level = [];
    for (let i = 0; i < levelSize; i++) {
      const node = queue.shift();
      level.push(node.val);
      if (node.left) queue.push(node.left);
      if (node.right) queue.push(node.right);
    }
    result.push(level);
  }
  return result;
}
```

The key trick: capture `queue.length` **before** the inner loop starts. Since children get pushed into the same queue during the loop, without freezing the size upfront the loop would incorrectly extend into the next level.

## Why BFS instead of DFS here

BFS naturally answers "level" and "shortest path in an unweighted structure" questions because it explores in expanding rings from the source — the first time it reaches a node is guaranteed to be via the shortest (fewest-edges) path. DFS has no such guarantee; it might plunge deep down one branch long before visiting a much shallower node reachable another way.

## Complexity

| | Time | Space |
|---|---|---|
| Level-order (BFS) | `O(n)` — every node visited once | `O(w)` where `w` is the tree's max width, up to `O(n)` for a perfect tree's last level |

Space is bounded by the widest level rather than height, which is the opposite of DFS's `O(h)` — on a wide, shallow tree BFS can use much more memory than DFS, and vice versa on a narrow, deep one.
