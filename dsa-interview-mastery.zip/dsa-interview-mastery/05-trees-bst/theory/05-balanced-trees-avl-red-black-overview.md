# Balanced Trees: AVL and Red-Black Trees (Conceptual Overview)

A plain BST offers no guarantee about its own shape — inserting already-sorted data produces a fully degenerate, linked-list-shaped tree with `O(n)` operations. **Self-balancing binary search trees** solve this by performing extra bookkeeping on every insert/delete to keep the tree's height close to `O(log n)`, no matter what order data arrives in. This topic is almost always asked **conceptually** in interviews ("what is an AVL tree, why does it exist, how does it differ from Red-Black") rather than "implement full rotation logic from scratch" — so the mental model matters more than memorizing rotation code.

## AVL Trees

An AVL tree adds a **balance factor** to every node: `height(left subtree) - height(right subtree)`, which must always be `-1`, `0`, or `1`. After every insert or delete, the tree walks back up from the modified node toward the root, and the moment a node's balance factor goes outside `[-1, 1]`, a **rotation** (single or double: left, right, left-right, right-left) is performed to restore balance.

- **Strictly balanced** — height is always within a tight `O(log n)` bound (proven: height ≤ ~1.44 log₂(n+2)).
- **More rotations on insert/delete** than Red-Black trees, since the balance condition is stricter.
- **Faster lookups** as a result of the tighter balance — good fit for **read-heavy** workloads (e.g., in-memory databases doing many more searches than inserts).

## Red-Black Trees

A Red-Black tree colors every node red or black and enforces a looser set of invariants (root is black, red nodes can't have red children, every root-to-null path has the same number of black nodes), which together still bound height to `O(log n)` — specifically at most `2 log₂(n+1)` — but allow more "slack" than AVL's strict balance factor.

- **Looser balance** than AVL → **fewer rotations** on insert/delete, at the cost of somewhat deeper trees / marginally slower lookups.
- Better fit for **write-heavy** workloads. This is why Red-Black trees (or close variants) back many general-purpose ordered structures: C++'s `std::map`/`std::set`, Java's `TreeMap`/`TreeSet`, and the Linux kernel's scheduler and virtual memory management.

## AVL vs. Red-Black — comparison

| | AVL Tree | Red-Black Tree |
|---|---|---|
| Balance guarantee | Stricter (balance factor ∈ {-1,0,1}) | Looser (color invariants) |
| Height bound | ~`1.44 log n` (tighter) | ~`2 log n` (looser) |
| Lookup speed | Faster (shorter trees) | Slightly slower |
| Insert/delete speed | Slower (more rotations) | Faster (fewer rotations) |
| Typical use case | Read-heavy (databases, lookup tables) | Write-heavy (general-purpose maps/sets, OS internals) |

## Why this matters even without implementing rotations

The interview-relevant takeaway isn't the rotation mechanics — it's recognizing **when a plain BST is insufficient** and being able to name the tradeoff between the two standard fixes. If you're asked "how would you keep BST operations at `O(log n)` no matter the insertion order," the expected answer is "use a self-balancing tree like AVL or Red-Black," followed by being able to explain *why* that guarantee holds (bounded height via rotations) and *which* one you'd reach for depending on read/write ratio.

## Other related structures worth naming

- **B-Trees / B+ Trees** — generalize the balance idea to multi-way (not just binary) nodes, minimizing disk reads; this is what most real databases and filesystems actually use for on-disk indexes, precisely because it minimizes tree height even further by fanning out widely per node.
- **Treaps, Splay Trees** — other self-balancing strategies (randomized priorities, or move-recently-accessed-nodes-to-root) worth knowing exist, though rarely required in-depth for a general interview.
