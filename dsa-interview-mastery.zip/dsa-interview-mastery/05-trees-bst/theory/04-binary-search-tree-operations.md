# Binary Search Tree Properties and Operations

A **binary search tree (BST)** is a binary tree with one additional invariant applied to *every* node: everything in its left subtree is strictly less than the node's value, and everything in its right subtree is strictly greater (assuming no duplicates). Critically, this must hold for **every** subtree, not just a node's immediate children — a node's left child being smaller isn't enough; the entire left subtree must be smaller.

```
        8
       / \
      3    10
     / \      \
    1   6      14
       / \     /
      4   7   13
```

This invariant is what makes inorder traversal of a BST always yield values in **sorted ascending order** — a fact frequently exploited in "validate BST" and "kth smallest" problems.

## Search — `O(h)`

At each node, compare the target to the current value and go left or right, exactly like binary search on a sorted array:

```js
function search(node, target) {
  if (!node || node.val === target) return node;
  return target < node.val ? search(node.left, target) : search(node.right, target);
}
```

## Insert — `O(h)`

Walk down using the same left/right comparison until an empty spot is found, then attach a new node there. New nodes are always inserted as leaves.

```js
function insert(node, val) {
  if (!node) return new TreeNode(val);
  if (val < node.val) node.left = insert(node.left, val);
  else if (val > node.val) node.right = insert(node.right, val);
  return node; // duplicates: no-op, left as-is
}
```

## Delete — `O(h)`, three cases

Deletion is the trickiest BST operation because removing a node must preserve the invariant for the rest of the tree.

1. **Leaf node (no children):** simply remove it (return `null` to the parent).
2. **One child:** splice the node out — replace it with its single child.
3. **Two children:** cannot simply remove the node without breaking the invariant. Instead, find its **inorder successor** (the smallest value in the right subtree — i.e., leftmost node of the right subtree), copy that value into the node being "deleted," then recursively delete the successor from the right subtree (where it's guaranteed to have at most one child, reducing back to case 1 or 2).

```js
function deleteNode(node, val) {
  if (!node) return null;
  if (val < node.val) { node.left = deleteNode(node.left, val); return node; }
  if (val > node.val) { node.right = deleteNode(node.right, val); return node; }

  // val === node.val: this is the node to delete
  if (!node.left) return node.right;   // 0 or 1 child (right)
  if (!node.right) return node.left;   // 1 child (left)

  // two children: find inorder successor (min of right subtree)
  let successor = node.right;
  while (successor.left) successor = successor.left;
  node.val = successor.val;                          // copy value up
  node.right = deleteNode(node.right, successor.val); // remove the duplicate from the subtree
  return node;
}
```

(Using the inorder **predecessor** — the max of the left subtree — instead of the successor is equally valid; either restores the invariant.)

## Complexity summary

| Operation | Balanced BST | Skewed BST (worst case) |
|---|---|---|
| Search | `O(log n)` | `O(n)` |
| Insert | `O(log n)` | `O(n)` |
| Delete | `O(log n)` | `O(n)` |

The entire value proposition of a BST over a sorted array is `O(log n)` insert/delete (vs. `O(n)` to shift elements in a sorted array) while keeping `O(log n)` search — but that only holds when the tree stays roughly balanced, which plain BST insert/delete does **not** guarantee on its own. That's the motivation for self-balancing variants (see the AVL/Red-Black theory file).
