# Binary Tree Basics and Terminology

A **tree** is a hierarchical data structure: a set of nodes connected by edges such that there is exactly one path between any two nodes (no cycles), with one designated **root** node and every other node reachable from it. A **binary tree** further restricts every node to at most two children, conventionally called `left` and `right`.

```js
class TreeNode {
  constructor(val, left = null, right = null) {
    this.val = val;
    this.left = left;
    this.right = right;
  }
}

//        1
//       / \
//      2   3
//     / \
//    4   5
const root = new TreeNode(1,
  new TreeNode(2, new TreeNode(4), new TreeNode(5)),
  new TreeNode(3)
);
```

## Core terminology

| Term | Meaning |
|---|---|
| **Root** | The single top-most node with no parent (`1` above). |
| **Leaf** | A node with no children (`4`, `5`, `3` above). |
| **Parent / Child** | `2` is the parent of `4` and `5`; they are its children. |
| **Edge** | The connection between a parent and a child. |
| **Depth of a node** | Number of edges from the root to that node (root has depth 0). |
| **Height of a node** | Number of edges on the longest downward path from that node to a leaf. |
| **Height of the tree** | Height of the root. |
| **Subtree** | Any node plus all of its descendants, treated as a tree in its own right. |
| **Ancestor / Descendant** | `1` and `2` are ancestors of `4`; `4` and `5` are descendants of `2`. |

## Shapes of binary trees

- **Full binary tree** — every node has either 0 or 2 children (never exactly 1).
- **Complete binary tree** — every level is fully filled except possibly the last, which fills left to right with no gaps. This is the shape a binary heap's array representation relies on.
- **Perfect binary tree** — every internal node has exactly 2 children **and** every leaf is at the same depth. A perfect tree of height `h` has exactly `2^(h+1) - 1` nodes.
- **Degenerate (skewed) tree** — every node has only one child, effectively becoming a linked list. This is the worst case for a BST built from already-sorted input, since it collapses height from `O(log n)` to `O(n)`.

## Why shape matters for Big-O

Almost every tree algorithm's time complexity is expressed in terms of height `h`, and `h` depends entirely on shape:

| Shape | Height for `n` nodes |
|---|---|
| Perfectly balanced | `O(log n)` |
| Degenerate (skewed) | `O(n)` |

This is why "is this tree balanced?" is such a recurring interview concern — an algorithm that's `O(log n)` on a balanced BST silently becomes `O(n)` on a skewed one, even though the code doesn't change at all.
