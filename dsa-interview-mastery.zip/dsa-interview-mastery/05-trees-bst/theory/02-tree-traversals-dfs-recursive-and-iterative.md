# Tree Traversals: DFS (Preorder, Inorder, Postorder) — Recursive and Iterative

Depth-first traversals visit as far down one branch as possible before backtracking. The three DFS orders differ only in **when** the current node's value is processed relative to its two subtrees.

Given this tree:

```
        1
       / \
      2   3
     / \
    4   5
```

| Order | Rule | Result for tree above |
|---|---|---|
| **Preorder** | node → left → right | `1, 2, 4, 5, 3` |
| **Inorder** | left → node → right | `4, 2, 5, 1, 3` |
| **Postorder** | left → right → node | `4, 5, 2, 3, 1` |

## Recursive implementations

Recursion is the natural fit because the call stack itself tracks "where to backtrack to" — that's exactly what an explicit stack would otherwise need to simulate.

```js
function preorder(node, out = []) {
  if (!node) return out;
  out.push(node.val);      // node first
  preorder(node.left, out);
  preorder(node.right, out);
  return out;
}

function inorder(node, out = []) {
  if (!node) return out;
  inorder(node.left, out);
  out.push(node.val);      // node in the middle
  inorder(node.right, out);
  return out;
}

function postorder(node, out = []) {
  if (!node) return out;
  postorder(node.left, out);
  postorder(node.right, out);
  out.push(node.val);      // node last
  return out;
}
```

Each is `O(n)` time (every node visited once) and `O(h)` auxiliary space for the call stack, where `h` is tree height (`O(log n)` balanced, `O(n)` worst case).

## Iterative implementations (explicit stack)

Any recursive DFS can be rewritten iteratively using an explicit stack to hold "work still to do" — useful when recursion depth risks a stack overflow on very deep/skewed trees, or when an interviewer explicitly asks for the non-recursive version.

**Preorder (straightforward — push right before left so left pops first):**

```js
function preorderIterative(root) {
  if (!root) return [];
  const out = [];
  const stack = [root];
  while (stack.length) {
    const node = stack.pop();
    out.push(node.val);
    if (node.right) stack.push(node.right); // pushed first...
    if (node.left) stack.push(node.left);   // ...so left is popped first
  }
  return out;
}
```

**Inorder (the trickiest — walk left as far as possible, then process, then go right):**

```js
function inorderIterative(root) {
  const out = [];
  const stack = [];
  let curr = root;
  while (curr || stack.length) {
    while (curr) {            // go as far left as possible, remembering the path
      stack.push(curr);
      curr = curr.left;
    }
    curr = stack.pop();       // backtrack to the most recent unvisited node
    out.push(curr.val);
    curr = curr.right;        // then explore its right subtree
  }
  return out;
}
```

**Postorder (two common approaches):**

```js
// Approach: reverse of a modified preorder (node -> right -> left), then reverse the output
function postorderIterative(root) {
  if (!root) return [];
  const out = [];
  const stack = [root];
  while (stack.length) {
    const node = stack.pop();
    out.unshift(node.val);              // insert at front instead of push
    if (node.left) stack.push(node.left);
    if (node.right) stack.push(node.right);
  }
  return out;
}
```

This works because postorder (left, right, node) is the exact reverse of (node, right, left) — which is just preorder with the push order of children swapped.

## Complexity summary

| Traversal | Time | Space (recursive, call stack) | Space (iterative, explicit stack) |
|---|---|---|---|
| Preorder / Inorder / Postorder | `O(n)` | `O(h)` | `O(h)` |

All three visit every node exactly once regardless of implementation style — the recursive/iterative choice affects *where* the backtracking bookkeeping lives, not the asymptotic complexity.
