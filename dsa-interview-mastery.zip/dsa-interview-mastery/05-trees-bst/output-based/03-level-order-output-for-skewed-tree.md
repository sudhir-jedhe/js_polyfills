# Output: Level-Order Traversal of a Skewed (Left-Only) Tree

```js
//     4
//    /
//   3
//  /
// 2
///
//1
const root = buildTree([4, 3, null, 2, null, null, null, 1]);
console.log(levelOrderGrouped(root));
```

**Question:** What does `levelOrderGrouped` print for this fully left-skewed tree?

**Answer:** `[[4], [3], [2], [1]]`

**Why:** Every node in this tree has exactly one child (its left child), so each "level" contains exactly one node — the tree is effectively a linked list wearing tree clothing. `levelOrderGrouped` freezes the queue size at the start of each iteration of the outer loop, so it correctly produces one single-element array per level even though the queue only ever holds one node at a time. Note this also means the tree's height (3) equals `n - 1` (4 nodes), the worst case discussed in the BST-shape file — a fully skewed tree gets zero benefit from BFS's usual "wide levels" behavior.
