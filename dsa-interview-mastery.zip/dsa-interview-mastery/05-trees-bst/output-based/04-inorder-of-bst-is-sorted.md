# Output: Inorder Traversal of Any Valid BST Is Always Sorted

```js
let bst = null;
for (const v of [15, 6, 18, 3, 7, 17, 20, 2, 4, 13]) bst = insert(bst, v);
console.log(inorder(bst));
```

**Question:** What does this print, and why can you predict it without drawing the tree?

**Answer:** `[2, 3, 4, 6, 7, 13, 15, 17, 18, 20]`

**Why:** Inorder traversal visits left subtree, then node, then right subtree — and because a BST guarantees every node's left subtree holds smaller values and its right subtree holds larger values *at every level*, that recursive left-node-right pattern necessarily unwinds the tree into ascending sorted order, regardless of the specific shape produced by this particular insertion order. This is precisely why "is a binary tree a valid BST" can be checked by running an inorder traversal and confirming the output is strictly increasing — a single `O(n)` pass with no need to track per-node min/max bounds explicitly (though the bounds-passing approach is the more common way to implement the check, since it avoids materializing the full output array).
