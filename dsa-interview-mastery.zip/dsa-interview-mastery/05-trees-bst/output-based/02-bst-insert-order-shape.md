# Output: BST Shape Depends on Insertion Order

```js
let bstA = null;
for (const v of [5, 3, 8, 1, 4, 7, 9]) bstA = insert(bstA, v);

let bstB = null;
for (const v of [1, 3, 4, 5, 7, 8, 9]) bstB = insert(bstB, v);

console.log(height(bstA));
console.log(height(bstB));
```

**Question:** What does each `height()` call print, given `height(null) = -1` and `height(leaf) = 0`?

**Answer:** `height(bstA)` prints `2`, `height(bstB)` prints `6`.

**Why:** `bstA` inserts `5` first as the root, and the remaining values split roughly evenly into "less than 5" and "greater than 5" on each subsequent insert, producing a roughly balanced tree of height 2 for 7 nodes. `bstB` inserts already-**sorted** ascending values — each new value is greater than everything inserted so far, so every insert attaches as the right child of the previous node, producing a fully degenerate, linked-list-shaped tree (a "right chain") with height `n - 1 = 6`. Same data, same insert logic, wildly different height purely due to input order — this is exactly the scenario self-balancing trees (AVL/Red-Black) are designed to prevent.
