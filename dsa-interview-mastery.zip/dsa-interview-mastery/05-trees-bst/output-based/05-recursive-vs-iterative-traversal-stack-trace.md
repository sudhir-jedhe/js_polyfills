# Output: What the Explicit Stack Holds Mid-Traversal (Iterative Inorder)

```js
//     2
//    / \
//   1   3
const root = buildTree([2, 1, 3]);

const stack = [];
let curr = root;
const log = [];
while (curr || stack.length) {
  while (curr) {
    stack.push(curr.val);
    curr = curr.left;
  }
  log.push(`stack before pop: [${stack.join(', ')}]`);
  const popped = stack.pop();
  curr = /* right child lookup omitted for brevity */ null;
}
console.log(log);
```

**Question:** For the tree `2` with left child `1` and right child `3`, in what order does the stack fill and drain during iterative inorder traversal, and what's the final output array?

**Answer:** Stack progression: push `2` (walking left) → push `1` (walking left, `1.left` is `null` so the inner loop stops) → pop `1`, record it, move to `1.right` (`null`, so nothing pushed) → pop `2`, record it, move to `2.right` (`3`) → push `3` (its left is `null`) → pop `3`, record it. Final output: `[1, 2, 3]`.

**Why:** The inner `while (curr)` loop always drives the stack all the way down the left spine before anything gets popped — that's what guarantees the *smallest* unvisited value is always the one on top of the stack, mirroring exactly what recursive inorder does implicitly via the call stack. Every node gets pushed once and popped once, which is why iterative inorder is `O(n)` time and `O(h)` space, identical to the recursive version — the explicit stack is just standing in for the call stack.
