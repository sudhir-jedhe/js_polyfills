# Output: Preorder, Inorder, Postorder for the Same Tree

```js
//         5
//        / \
//       3   8
//      / \   \
//     1   4   9
console.log(preorder(root));
console.log(inorder(root));
console.log(postorder(root));
```

**Question:** What do the three calls print?

**Answer:**
```
preorder:  [5, 3, 1, 4, 8, 9]
inorder:   [1, 3, 4, 5, 8, 9]
postorder: [1, 4, 3, 9, 8, 5]
```

**Why:** Preorder visits node-left-right, so it starts at the root and always records a node before descending into either subtree: `5`, then all of the left subtree (`3, 1, 4`), then all of the right subtree (`8, 9`). Inorder (left-node-right) fully explores the left subtree before recording the node, so it records `1, 3, 4` (left subtree, itself in sorted order since this happens to be a BST), then `5`, then `8, 9`. Postorder (left-right-node) records a node only after both of its subtrees are fully done, so `1` and `4` come before `3`, and `9` comes before `8`, with the root `5` recorded dead last.
