# Output: Inverting a Binary Tree Mutates in Place

```js
function invertTree(node) {
  if (!node) return null;
  [node.left, node.right] = [node.right, node.left];
  invertTree(node.left);
  invertTree(node.right);
  return node;
}

//       4
//      / \
//     2   7
//    / \ / \
//   1  3 6  9
const root = buildTree([4, 2, 7, 1, 3, 6, 9]);
const original = root; // same reference, not a copy
invertTree(root);
console.log(preorder(root));
console.log(root === original);
```

**Question:** What does `preorder(root)` print after inversion, and what does `root === original` print?

**Answer:** `preorder(root)` prints `[4, 7, 9, 6, 2, 3, 1]`, and `root === original` prints `true`.

**Why:** `invertTree` swaps `node.left` and `node.right` **in place** on the existing node objects rather than building a new tree, so `original` still points at the same (now-mutated) root node — hence the reference equality. After inversion, the tree looks like `4` with left child `7` (children `9, 6`, itself swapped from `6, 9`) and right child `2` (children `3, 1`, swapped from `1, 3`). Preorder on the new shape visits `4`, then the entire new-left subtree (`7, 9, 6`), then the entire new-right subtree (`2, 3, 1`) — note this is exactly the original preorder output (`4, 2, 1, 3, 7, 6, 9`) with every subtree's left/right recursively flipped, not simply the original array reversed.
