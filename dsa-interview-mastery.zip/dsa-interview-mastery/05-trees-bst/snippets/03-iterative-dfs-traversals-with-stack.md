# Iterative DFS Traversals with an Explicit Stack

```js
function preorderIterative(root) {
  if (!root) return [];
  const out = [];
  const stack = [root];
  while (stack.length) {
    const node = stack.pop();
    out.push(node.val);
    if (node.right) stack.push(node.right); // push right first...
    if (node.left) stack.push(node.left);   // ...so left pops first
  }
  return out;
}

function inorderIterative(root) {
  const out = [];
  const stack = [];
  let curr = root;
  while (curr || stack.length) {
    while (curr) {
      stack.push(curr);
      curr = curr.left; // walk all the way left first
    }
    curr = stack.pop();
    out.push(curr.val);
    curr = curr.right;
  }
  return out;
}

const root = buildTree([1, 2, 3, 4, 5]);
console.log(preorderIterative(root)); // [1, 2, 4, 5, 3]
console.log(inorderIterative(root));  // [4, 2, 5, 1, 3]
```
