# BST Insert and Search

```js
function insert(node, val) {
  if (!node) return new TreeNode(val);
  if (val < node.val) node.left = insert(node.left, val);
  else if (val > node.val) node.right = insert(node.right, val);
  return node;
}

function search(node, target) {
  if (!node || node.val === target) return node;
  return target < node.val ? search(node.left, target) : search(node.right, target);
}

let bst = null;
for (const val of [8, 3, 10, 1, 6, 14, 4, 7, 13]) {
  bst = insert(bst, val);
}

console.log(inorder(bst)); // [1, 3, 4, 6, 7, 8, 10, 13, 14] — always sorted for a valid BST
console.log(search(bst, 7)?.val); // 7
console.log(search(bst, 99));     // null
```
