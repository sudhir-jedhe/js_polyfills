# Tree Node Definition and Helper Builder

```js
class TreeNode {
  constructor(val, left = null, right = null) {
    this.val = val;
    this.left = left;
    this.right = right;
  }
}

// Convenience: build a tree from a level-order array with `null` gaps,
// e.g. [1,2,3,null,4] mirrors LeetCode's input format.
function buildTree(arr) {
  if (!arr.length || arr[0] === null) return null;
  const root = new TreeNode(arr[0]);
  const queue = [root];
  let i = 1;
  while (queue.length && i < arr.length) {
    const node = queue.shift();
    if (arr[i] !== undefined && arr[i] !== null) {
      node.left = new TreeNode(arr[i]);
      queue.push(node.left);
    }
    i++;
    if (arr[i] !== undefined && arr[i] !== null) {
      node.right = new TreeNode(arr[i]);
      queue.push(node.right);
    }
    i++;
  }
  return root;
}

const root = buildTree([1, 2, 3, 4, 5]);
console.log(root.left.left.val); // 4
```
