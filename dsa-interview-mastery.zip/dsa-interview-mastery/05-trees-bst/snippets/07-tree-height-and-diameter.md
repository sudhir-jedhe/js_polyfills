# Tree Height and Diameter in a Single Pass

```js
function diameterOfBinaryTree(root) {
  let maxDiameter = 0;

  function heightAndUpdate(node) {
    if (!node) return -1;
    const leftHeight = heightAndUpdate(node.left);
    const rightHeight = heightAndUpdate(node.right);
    maxDiameter = Math.max(maxDiameter, leftHeight + rightHeight + 2);
    return 1 + Math.max(leftHeight, rightHeight);
  }

  heightAndUpdate(root);
  return maxDiameter;
}

//        1
//       / \
//      2   3
//     / \
//    4   5
const root = buildTree([1, 2, 3, 4, 5]);
console.log(diameterOfBinaryTree(root)); // 3 — path 4-2-1-3 or 5-2-1-3 (3 edges)
```
