# BST Delete (All Three Cases)

```js
function deleteNode(node, val) {
  if (!node) return null;
  if (val < node.val) { node.left = deleteNode(node.left, val); return node; }
  if (val > node.val) { node.right = deleteNode(node.right, val); return node; }

  // found the node to delete
  if (!node.left) return node.right;   // 0 or 1 child (right only)
  if (!node.right) return node.left;   // 1 child (left only)

  // two children: replace with inorder successor (min of right subtree)
  let successor = node.right;
  while (successor.left) successor = successor.left;
  node.val = successor.val;
  node.right = deleteNode(node.right, successor.val);
  return node;
}

let bst = null;
for (const val of [8, 3, 10, 1, 6, 14, 4, 7, 13]) bst = insert(bst, val);

bst = deleteNode(bst, 3); // two-child case: 3 replaced by inorder successor 4
console.log(inorder(bst)); // [1, 4, 6, 7, 8, 10, 13, 14]
```
