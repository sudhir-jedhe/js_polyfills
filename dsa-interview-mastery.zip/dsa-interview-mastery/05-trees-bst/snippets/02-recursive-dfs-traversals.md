# Recursive DFS Traversals (Preorder / Inorder / Postorder)

```js
function preorder(node, out = []) {
  if (!node) return out;
  out.push(node.val);
  preorder(node.left, out);
  preorder(node.right, out);
  return out;
}

function inorder(node, out = []) {
  if (!node) return out;
  inorder(node.left, out);
  out.push(node.val);
  inorder(node.right, out);
  return out;
}

function postorder(node, out = []) {
  if (!node) return out;
  postorder(node.left, out);
  postorder(node.right, out);
  out.push(node.val);
  return out;
}

const root = buildTree([1, 2, 3, 4, 5]); // see 01-tree-node-definition.md
console.log(preorder(root));  // [1, 2, 4, 5, 3]
console.log(inorder(root));   // [4, 2, 5, 1, 3]
console.log(postorder(root)); // [4, 5, 2, 3, 1]
```
