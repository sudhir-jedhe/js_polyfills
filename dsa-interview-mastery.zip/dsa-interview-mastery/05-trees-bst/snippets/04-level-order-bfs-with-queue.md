# Level-Order Traversal (BFS) with a Queue, Grouped by Level

```js
function levelOrderGrouped(root) {
  if (!root) return [];
  const result = [];
  const queue = [root];
  while (queue.length) {
    const levelSize = queue.length; // freeze the count before this level's children get pushed
    const level = [];
    for (let i = 0; i < levelSize; i++) {
      const node = queue.shift();
      level.push(node.val);
      if (node.left) queue.push(node.left);
      if (node.right) queue.push(node.right);
    }
    result.push(level);
  }
  return result;
}

const root = buildTree([1, 2, 3, 4, 5]);
console.log(levelOrderGrouped(root)); // [[1], [2, 3], [4, 5]]
```
