Diagrams and images for this topic (tree shapes, traversal walkthroughs, rotation illustrations) go here.
