# Problem: Validate Binary Search Tree

## Problem Statement

Given the root of a binary tree, determine if it is a valid binary search tree: for every node, all values in its left subtree must be strictly less than the node's value, and all values in its right subtree must be strictly greater — for **every** node, not just direct children.

## Examples

```
Input:    5            Input:      5
         / \                      / \
        1   6                    3   6
           / \                      / \
          3   7                    1   4    <- 4 is in 5's right subtree
                                              but is less than 5 — INVALID
Output: false                     (locally 3 < 6 looks fine, but 4 < 5 breaks the global invariant)
```

## Constraints

- Number of nodes: `1 <= n <= 10^4`
- `-2^31 <= Node.val <= 2^31 - 1`

## Approach

The common bug is checking only the immediate parent-child relationship at each node — that misses violations from a deeper descendant that satisfies its *local* parent but violates an *ancestor's* bound. The correct approach threads a valid `(min, max)` range down through the recursion: each node must fall strictly within the range established by all of its ancestors so far, and each recursive call narrows that range for its subtree (left child's max becomes the current node's value; right child's min becomes the current node's value).

## Solution

```js
function isValidBST(root, min = -Infinity, max = Infinity) {
  if (!root) return true;
  if (root.val <= min || root.val >= max) return false;
  return (
    isValidBST(root.left, min, root.val) &&
    isValidBST(root.right, root.val, max)
  );
}

module.exports = { isValidBST };

// --- verification ---
const valid = buildTree([5, 1, 6, null, null, 3, 7]);
console.log(isValidBST(valid)); // true

const invalid = buildTree([5, 3, 6, 1, 4]); // 4 is in 5's right... wait, 4 is left child of 3
// (constructed directly to make the violation explicit)
const brokenRoot = new TreeNode(5,
  new TreeNode(3, new TreeNode(1), new TreeNode(4)), // 4 < 5, fine locally under 3, but must be < 3 too
  new TreeNode(6)
);
console.log(isValidBST(brokenRoot)); // false — 4 violates the (min=3-side) bound
```

**Alternative approach — inorder traversal must be strictly increasing:**

```js
function isValidBSTInorder(root) {
  let prev = -Infinity;
  let valid = true;
  function inorder(node) {
    if (!node || !valid) return;
    inorder(node.left);
    if (node.val <= prev) { valid = false; return; }
    prev = node.val;
    inorder(node.right);
  }
  inorder(root);
  return valid;
}
```

## Complexity

- **Time:** `O(n)` — both approaches visit each node once.
- **Space:** `O(h)` for the recursion stack.
