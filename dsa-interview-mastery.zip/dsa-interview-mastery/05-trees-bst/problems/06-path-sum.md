# Problem: Path Sum

## Problem Statement

Given the root of a binary tree and an integer `targetSum`, return `true` if the tree has a **root-to-leaf** path such that the values along that path add up exactly to `targetSum`.

## Examples

```
Input:      5                    targetSum = 22
           / \
          4   8
         /   / \
        11  13  4
       /  \       \
      7    2        1

Path 5 -> 4 -> 11 -> 2 = 22   -> Output: true
```

```
Input: root = [1, 2, 3], targetSum = 5
Output: false   (paths are 1->2 = 3 and 1->3 = 4; neither is 5)
```

## Constraints

- Number of nodes: `0 <= n <= 5000`
- `-1000 <= Node.val <= 1000`, `-1000 <= targetSum <= 1000`
- Must be a **root-to-leaf** path specifically (not any path, and not stopping at an internal node).

## Approach

DFS while subtracting the current node's value from the remaining target as you descend. The base case must check `!node.left && !node.right` (a true leaf) before comparing the remaining sum to zero — it's a common bug to return `true` as soon as the running sum hits zero at *any* node, even an internal one with children, which the problem explicitly disallows.

## Solution

```js
function hasPathSum(root, targetSum) {
  if (!root) return false;
  const remaining = targetSum - root.val;
  if (!root.left && !root.right) return remaining === 0; // must be a leaf
  return hasPathSum(root.left, remaining) || hasPathSum(root.right, remaining);
}

module.exports = { hasPathSum };

// --- verification ---
const root = buildTree([5, 4, 8, 11, null, 13, 4, 7, 2, null, null, null, 1]);
console.log(hasPathSum(root, 22)); // true  (5-4-11-2)
console.log(hasPathSum(root, 26)); // false
console.log(hasPathSum(null, 0));  // false — an empty tree has no root-to-leaf path at all
```

**Common follow-up — return the actual path(s), not just a boolean:**

```js
function pathSumAll(root, targetSum) {
  const result = [];
  function dfs(node, remaining, path) {
    if (!node) return;
    path.push(node.val);
    remaining -= node.val;
    if (!node.left && !node.right && remaining === 0) {
      result.push([...path]); // copy — `path` keeps mutating as recursion continues
    } else {
      dfs(node.left, remaining, path);
      dfs(node.right, remaining, path);
    }
    path.pop(); // backtrack before returning to the caller
  }
  dfs(root, targetSum, []);
  return result;
}
```

## Complexity

- **Time:** `O(n)` — worst case visits every node once.
- **Space:** `O(h)` for the recursion stack (plus `O(h)` for the `path` array in the all-paths variant).
