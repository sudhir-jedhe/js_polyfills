# Problem: Binary Tree Level Order Traversal

## Problem Statement

Given the root of a binary tree, return the values of its nodes grouped level by level, left to right (an array of arrays, one inner array per depth).

## Examples

```
Input:      3
           / \
          9  20
             /  \
            15   7

Output: [[3], [9, 20], [15, 7]]
```

## Constraints

- Number of nodes: `0 <= n <= 2000`
- `-1000 <= Node.val <= 1000`

## Approach

Standard BFS with a queue. The key trick for grouping by level: snapshot `queue.length` at the **start** of each outer-loop iteration, before any children get enqueued during that iteration — that snapshot is exactly "how many nodes belong to the current level," so the inner loop processes precisely that many nodes even as it pushes the *next* level's nodes onto the same queue.

## Solution

```js
function levelOrder(root) {
  if (!root) return [];
  const result = [];
  const queue = [root];

  while (queue.length) {
    const levelSize = queue.length;
    const level = [];
    for (let i = 0; i < levelSize; i++) {
      const node = queue.shift();
      level.push(node.val);
      if (node.left) queue.push(node.left);
      if (node.right) queue.push(node.right);
    }
    result.push(level);
  }

  return result;
}

module.exports = { levelOrder };

// --- verification ---
const root = buildTree([3, 9, 20, null, null, 15, 7]);
console.log(levelOrder(root)); // [[3], [9, 20], [15, 7]]
console.log(levelOrder(null)); // []
```

## Complexity

- **Time:** `O(n)` — every node enqueued and dequeued exactly once.
- **Space:** `O(w)` where `w` is the maximum width of the tree (largest number of nodes at any single level), which is `O(n)` in the worst case (a perfect tree's bottom level holds roughly half the total nodes).
