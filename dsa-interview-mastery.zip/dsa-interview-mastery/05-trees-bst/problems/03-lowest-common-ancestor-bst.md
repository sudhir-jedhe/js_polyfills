# Problem: Lowest Common Ancestor of a Binary Search Tree

## Problem Statement

Given a BST and two nodes `p` and `q` that both exist in the tree, find their lowest common ancestor (LCA) — the deepest node that has both `p` and `q` as descendants (a node can be a descendant of itself).

## Examples

```
        6
       / \
      2   8
     / \ / \
    0  4 7  9
      / \
     3   5

LCA(2, 8) = 6
LCA(2, 4) = 2   (2 is an ancestor of 4, and a node counts as its own ancestor)
LCA(3, 5) = 4
```

## Constraints

- Number of nodes: `2 <= n <= 10^5`
- All `Node.val` are unique.
- `p` and `q` both exist in the tree and are different nodes.

## Approach

Because this is specifically a **BST** (not just any binary tree), the ordering property lets us skip the "search both subtrees" approach used for a general binary tree and instead navigate directly using value comparisons, the same way BST search does. At each node: if both `p.val` and `q.val` are less than the node's value, the LCA must be in the left subtree (recurse left); if both are greater, recurse right; the moment they're not both on the same side (one is `<=`, the other `>=`, i.e. the search paths diverge, or the current node equals `p` or `q`), the current node is the split point and therefore the LCA.

## Solution

```js
function lowestCommonAncestorBST(root, p, q) {
  let node = root;
  while (node) {
    if (p.val < node.val && q.val < node.val) {
      node = node.left;
    } else if (p.val > node.val && q.val > node.val) {
      node = node.right;
    } else {
      return node; // paths diverge here (or node is p or q) — this is the LCA
    }
  }
  return null;
}

module.exports = { lowestCommonAncestorBST };

// --- verification ---
let bst = null;
for (const v of [6, 2, 8, 0, 4, 7, 9, 3, 5]) bst = insert(bst, v);
const two = search(bst, 2);
const eight = search(bst, 8);
const three = search(bst, 3);
const five = search(bst, 5);
console.log(lowestCommonAncestorBST(bst, two, eight).val); // 6
console.log(lowestCommonAncestorBST(bst, three, five).val); // 4
```

**General binary tree version (no ordering to exploit — must search both subtrees):**

```js
function lowestCommonAncestor(root, p, q) {
  if (!root || root === p || root === q) return root;
  const left = lowestCommonAncestor(root.left, p, q);
  const right = lowestCommonAncestor(root.right, p, q);
  if (left && right) return root;
  return left ?? right;
}
```

## Complexity

- **BST version:** Time `O(h)`, Space `O(1)` (iterative, no recursion stack) — since each step eliminates one subtree entirely, just like BST search.
- **General binary tree version:** Time `O(n)` (worst case must visit every node), Space `O(h)` for the recursion stack.
