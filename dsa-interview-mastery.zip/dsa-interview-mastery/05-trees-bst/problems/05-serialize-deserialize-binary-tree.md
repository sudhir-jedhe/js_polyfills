# Problem: Serialize and Deserialize a Binary Tree

## Problem Statement

Design an algorithm to serialize a binary tree to a string, and deserialize that string back into an identical tree structure (not necessarily a BST — any binary tree, so no ordering property can be relied on).

## Examples

```
Input:      1
           / \
          2   3
             / \
            4   5

serialize(root)   -> e.g. "1,2,#,#,3,4,#,#,5,#,#"
deserialize(data) -> reconstructs the exact same tree shape
```

## Constraints

- Number of nodes: `0 <= n <= 10^4`
- Node values may be any integer (including negative) — must be distinguishable from the "null marker" in the string format chosen.

## Approach

Use **preorder** traversal with explicit null markers (`#`) for missing children. Preorder is the right choice because it records a node *before* its children, which means during deserialization we can rebuild the tree in the exact same top-down order we read it — reading one value at a time from the front of the queue and recursively attaching left/right, mirroring how it was written. Inorder wouldn't work for this alone (it can't disambiguate tree shape without additional information), but preorder (or postorder) with explicit null markers uniquely determines the tree.

## Solution

```js
function serialize(root) {
  const out = [];
  function preorder(node) {
    if (!node) { out.push('#'); return; }
    out.push(String(node.val));
    preorder(node.left);
    preorder(node.right);
  }
  preorder(root);
  return out.join(',');
}

function deserialize(data) {
  const values = data.split(',');
  let i = 0;
  function build() {
    const val = values[i++];
    if (val === '#') return null;
    const node = new TreeNode(Number(val));
    node.left = build();
    node.right = build();
    return node;
  }
  return build();
}

module.exports = { serialize, deserialize };

// --- verification ---
const root = buildTree([1, 2, 3, null, null, 4, 5]);
const data = serialize(root);
console.log(data); // "1,2,#,#,3,4,#,#,5,#,#"
const rebuilt = deserialize(data);
console.log(preorder(rebuilt)); // [1, 2, 3, 4, 5] — same shape as original
```

**Why null markers are required:** without them, `"1,2,3"` could describe multiple different tree shapes (e.g., `2` and `3` both children of `1`, or `2` as `1`'s only left child with `3` as `2`'s child) — the null markers make every leaf's "no more children here" boundary explicit, so preorder + markers is a lossless, unambiguous encoding.

## Complexity

- **Time:** `O(n)` for both serialize and deserialize — each visits every node (or null marker) exactly once.
- **Space:** `O(n)` for the output string/array, plus `O(h)` recursion stack for both directions.
