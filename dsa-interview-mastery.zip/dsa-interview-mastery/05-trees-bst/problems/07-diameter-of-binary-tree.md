# Problem: Diameter of Binary Tree

## Problem Statement

Given the root of a binary tree, return the length (number of **edges**) of the longest path between any two nodes in the tree. This path may or may not pass through the root.

## Examples

```
Input:      1
           / \
          2   3
         / \
        4   5

Output: 3   (path 4 -> 2 -> 1 -> 3, or 5 -> 2 -> 1 -> 3 — either has 3 edges)
```

## Constraints

- Number of nodes: `1 <= n <= 10^4`
- `-100 <= Node.val <= 100`

## Approach

The naive approach computes `height(node.left) + height(node.right) + 2` at every node, but calling a separate `height()` function on the whole subtree at every single node re-walks large portions of the tree repeatedly — `O(n)` work per node, `O(n²)` overall in the worst case. The key insight: computing height is *already* a bottom-up (postorder) process that visits every node once — so fold the diameter check into that same pass. At each node, once you know its left and right subtree heights (which you need anyway to compute *this* node's own height), you also know the longest path *through* this node for free: `leftHeight + rightHeight + 2` edges.

## Solution

```js
function diameterOfBinaryTree(root) {
  let maxDiameter = 0;

  function height(node) {
    if (!node) return -1; // height of an empty subtree
    const leftHeight = height(node.left);
    const rightHeight = height(node.right);
    maxDiameter = Math.max(maxDiameter, leftHeight + rightHeight + 2);
    return 1 + Math.max(leftHeight, rightHeight);
  }

  height(root);
  return maxDiameter;
}

module.exports = { diameterOfBinaryTree };

// --- verification ---
const root = buildTree([1, 2, 3, 4, 5]);
console.log(diameterOfBinaryTree(root)); // 3

const single = buildTree([1]);
console.log(diameterOfBinaryTree(single)); // 0 — a single node has no path at all
```

**Note on the "+2":** `leftHeight` and `rightHeight` are the number of *edges* from this node down to the deepest leaf on each side. The path through this node connecting the deepest leaf on the left to the deepest leaf on the right crosses `leftHeight` edges down the left side, plus `rightHeight` edges down the right side, plus the current node contributes no additional edge by itself — but since both heights are measured as "edges to deepest leaf," and the node itself sits between them, the total path length is `leftHeight + rightHeight + 2` when both subtrees exist (accounting for the edge from the node to each child) — always sanity-check this formula against a small hand-drawn example rather than memorizing it blindly, since off-by-one errors here are the most common bug in this problem.

## Complexity

- **Time:** `O(n)` — a single postorder pass, each node visited once.
- **Space:** `O(h)` for the recursion stack.
