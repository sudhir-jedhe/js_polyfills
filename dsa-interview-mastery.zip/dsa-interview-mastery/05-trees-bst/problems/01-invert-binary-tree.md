# Problem: Invert a Binary Tree

## Problem Statement

Given the root of a binary tree, invert it — mirror every subtree so that left and right children are swapped at every level — and return the new root.

## Examples

```
Input:        4                Output:       4
             / \                            / \
            2   7                          7   2
           / \ / \                        / \ / \
          1  3 6  9                      9  6 3  1
```

## Constraints

- Number of nodes: `0 <= n <= 100`
- `-100 <= Node.val <= 100`

## Approach

At every node, swap its `left` and `right` pointers, then recurse into both (now-swapped) children so the same swap happens at every depth. Base case: `null` inverts to `null`. Order of "swap then recurse" vs. "recurse then swap" doesn't matter for correctness here since both children get fully inverted either way.

## Solution

```js
function invertTree(root) {
  if (!root) return null;
  [root.left, root.right] = [root.right, root.left];
  invertTree(root.left);
  invertTree(root.right);
  return root;
}

module.exports = { invertTree };

// --- verification ---
const root = buildTree([4, 2, 7, 1, 3, 6, 9]);
invertTree(root);
console.log(preorder(root)); // [4, 7, 9, 6, 2, 3, 1]
```

**Iterative alternative (BFS with a queue):**

```js
function invertTreeIterative(root) {
  if (!root) return null;
  const queue = [root];
  while (queue.length) {
    const node = queue.shift();
    [node.left, node.right] = [node.right, node.left];
    if (node.left) queue.push(node.left);
    if (node.right) queue.push(node.right);
  }
  return root;
}
```

## Complexity

- **Time:** `O(n)` — every node is visited and swapped exactly once.
- **Space:** `O(h)` for the recursive call stack (`O(log n)` balanced, `O(n)` worst case skewed), or `O(w)` for the iterative queue version (max tree width).
