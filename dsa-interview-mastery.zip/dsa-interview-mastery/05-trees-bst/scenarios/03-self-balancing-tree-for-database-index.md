# Scenario: Why Database Indexes Don't Use a Plain BST

**Scenario:** A junior engineer asks why a database index (e.g., on a `users.email` column) isn't just implemented as a plain binary search tree, since a BST gives `O(log n)` lookup, insert, and range queries, and email lookups need exactly that. What's the answer?

**Diagnosis:** Two separate problems with a plain (or even self-balancing binary) tree for this use case:

1. **No balance guarantee on a plain BST.** Emails inserted in roughly sorted order (which happens more often than you'd think — sequential IDs, alphabetically-seeded test data, bulk imports) would degrade a plain BST toward `O(n)` height, killing the whole point of indexing. This alone pushes toward a self-balancing tree (AVL/Red-Black) at minimum.
2. **Binary trees are the wrong *shape* for disk-backed storage**, even when balanced. Every level of a binary tree is one more disk read in the worst case (data doesn't fit in memory for large tables), and disk I/O is orders of magnitude slower than in-memory pointer-chasing — so minimizing **tree height**, not just keeping it `O(log n)` with a small binary constant, is the actual goal. A binary tree with `n` keys has height `~log₂(n)`; a **B-Tree** (or B+ Tree) with a branching factor of, say, 200 has height `~log₂₀₀(n)` — for a billion rows that's roughly 30 levels for a binary tree vs. roughly 4 levels for a B-Tree, i.e. roughly 4 disk reads instead of 30 to find a row.

**The actual answer:** real database indexes (MySQL InnoDB, PostgreSQL's default) use **B+ Trees** — a generalization of the balanced-BST idea to wide, multi-way nodes, specifically optimized to minimize height (and therefore disk seeks) rather than to minimize per-node comparison work, plus B+ Trees additionally chain all leaf nodes together in a linked list, making range scans (`WHERE email BETWEEN 'a' AND 'm'`) a single sequential leaf-to-leaf walk instead of repeated tree descents.

**Takeaway:** "Self-balancing BST" is the right first instinct for "keep `O(log n)` regardless of insertion order," but for anything disk-backed or otherwise where each node access has real-world latency, the follow-up instinct should be "minimize the *height*, not just keep it logarithmic" — which is exactly what wide, multi-way B-Trees are built for.
