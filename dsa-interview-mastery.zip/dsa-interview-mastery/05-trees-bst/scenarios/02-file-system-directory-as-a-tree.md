# Scenario: Modeling a File System as a Tree

**Scenario:** You're designing an in-memory representation of a file system for a code editor's file explorer: folders can contain files and other folders, arbitrarily nested, and you need to support "compute total size of a folder (including all nested contents)," "find a file by path," and "render the expandable tree UI." What data structure fits, and which traversal(s) do you reach for?

**Approach:** A file system is a textbook **general tree** (not strictly binary — a folder can have any number of children, not just two), where each node is either a file (leaf, holds a size) or a folder (internal node, holds a list of child nodes). The node shape:

```js
class FSNode {
  constructor(name, isFile, size = 0) {
    this.name = name;
    this.isFile = isFile;
    this.size = size;       // only meaningful for files
    this.children = [];      // only meaningful for folders
  }
}
```

- **Total size of a folder** — this is a **postorder-style** problem: you can't know a folder's total size until you know the total size of every child (files and subfolders) first. Recursively sum: `size = isFile ? size : children.reduce((sum, child) => sum + totalSize(child), 0)`. This naturally visits leaves before the folders that contain them, exactly like postorder DFS.
- **Find a file by path** (`/src/components/Button.js`) — walk down matching each path segment to a child by name, which is really just a guided DFS where you don't backtrack once you've found the matching child at each level — effectively `O(depth)` rather than a full traversal.
- **Render the expandable tree UI** — this is naturally a **preorder** DFS (or BFS if you want breadth-first rendering like "show top-level folders first, then expand"): visit a folder, render it, then recursively render its children — which is exactly why most tree-view UI components implement expand/collapse via a preorder-style recursive render function.

**Why this framing helps in an interview:** naming which traversal matches which requirement (postorder for "aggregate from the bottom up," preorder for "process parent before children," BFS for "level-by-level / shortest-path-like" needs) is the actual skill being tested — the file system is just a believable wrapper around "pick the right traversal for the dependency direction of the computation."
