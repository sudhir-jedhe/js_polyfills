# Scenario: Representing and Evaluating a Math Expression as a Tree

**Scenario:** You need to build a small calculator that parses an expression like `(3 + 5) * (2 - 1)` and evaluates it, and later needs to support pretty-printing the expression back out in different notations (infix, postfix). How would trees help here?

**Approach:** Represent the expression as an **expression tree**: every internal node is an operator, and its children are its operands (which may themselves be sub-expressions or leaf numbers).

```
        *
       / \
      +   -
     / \ / \
    3  5 2  1
```

```js
class ExprNode {
  constructor(val, left = null, right = null) {
    this.val = val;   // operator ('+','-','*','/') or a number
    this.left = left;
    this.right = right;
  }
}

function evaluate(node) {
  if (typeof node.val === 'number') return node.val; // leaf
  const left = evaluate(node.left);
  const right = evaluate(node.right);
  switch (node.val) {
    case '+': return left + right;
    case '-': return left - right;
    case '*': return left * right;
    case '/': return left / right;
  }
}

const tree = new ExprNode('*',
  new ExprNode('+', new ExprNode(3), new ExprNode(5)),
  new ExprNode('-', new ExprNode(2), new ExprNode(1))
);
console.log(evaluate(tree)); // 8  →  (3+5) * (2-1) = 8 * 1 = 8
```

**Why traversal choice matters here:** `evaluate` is a **postorder**-shaped recursion — you must fully evaluate both children before you can apply the operator at a node, exactly like postorder DFS (left, right, node). This connects directly to why expression trees are how compilers/calculators convert between notations: an **inorder** traversal (with parentheses added around each operator's subtree) reproduces the original **infix** expression `((3 + 5) * (2 - 1))`, while a plain **postorder** traversal produces **postfix / Reverse Polish Notation** `3 5 + 2 1 - *` — which is exactly the form a stack-based evaluator consumes directly without needing to worry about operator precedence or parentheses at all.

**Takeaway:** whenever a problem involves nested, precedence-sensitive structure (math expressions, boolean logic, even nested UI component trees), modeling it as a tree turns "parsing/precedence rules" into "which traversal order do I need," which is a much easier problem to reason about and implement correctly.
