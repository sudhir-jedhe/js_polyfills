# Scenario: Using Lowest Common Ancestor for an Org-Chart Permission System

**Scenario:** Your app models a company's org chart as a tree (CEO at the root, each employee's manager is their parent). A feature needs to answer "who is the lowest-level manager that has both employee A and employee B somewhere in their reporting chain" — used to determine the minimum approval authority that can sign off on something involving both of them. How do you solve this efficiently, and why does it matter that this is a tree, not an arbitrary graph?

**Approach:** This is exactly the **Lowest Common Ancestor (LCA)** problem. Because it's a tree — not a general graph — there's a guarantee that's crucial to the efficient solution: there is exactly **one** path from the root down to any node, so "the lowest common ancestor of A and B" is a well-defined, unique node, and it's guaranteed to lie on the unique root-to-A path and the unique root-to-B path simultaneously.

```js
function lowestCommonAncestor(root, p, q) {
  if (!root || root === p || root === q) return root;
  const left = lowestCommonAncestor(root.left, p, q);
  const right = lowestCommonAncestor(root.right, p, q);
  if (left && right) return root; // p and q found in different subtrees — root is the split point
  return left ?? right;           // both found on the same side, or only one found so far
}
```

The recursion bottoms out the moment it finds `p` or `q` and bubbles that fact back up; the first node where "found on both sides" becomes true is, by construction, the deepest node that is an ancestor of both — which is exactly the LCA. This runs in `O(n)` time (worst case, visiting every node once) and `O(h)` space for the recursion stack.

**If the org chart happens to also be a BST** (e.g., nodes ordered by employee ID rather than an arbitrary tree), the same problem becomes solvable in `O(h)` instead of `O(n)` by using the ordering: at each node, if both `p.val` and `q.val` are less than the current node, recurse left; if both are greater, recurse right; the moment they "split" (one less, one greater, or one equals the current node), that node is the LCA — no need to explore both subtrees blindly.

**Why the tree structure matters:** if this were a general graph instead (e.g., a matrix org with dotted-line reporting to multiple managers), "lowest common ancestor" wouldn't even be well-defined the same way — there could be multiple minimal common ancestors, and finding them would require a fundamentally different graph-based approach (see the graphs topic). The clean `O(n)`/`O(h)` LCA algorithm specifically relies on the tree guarantee of "exactly one path from the root to any node."
