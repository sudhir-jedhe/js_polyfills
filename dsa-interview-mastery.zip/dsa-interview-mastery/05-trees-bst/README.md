# Trees & Binary Search Trees

A tree is a hierarchical, non-linear data structure built from nodes connected by parent-child relationships, with no cycles and exactly one path between any two nodes. Binary trees (at most two children per node) and binary search trees (a binary tree with an ordering invariant) are the backbone of an enormous share of interview questions — traversals, recursion practice, and "search-like" structures all funnel through this topic. It's also where recursion, recursion-to-iteration conversion (explicit stacks/queues), and Big-O reasoning about balanced vs. degenerate shapes all come together, which is exactly why it's tested so heavily.

## Folder structure

- **`theory/`** — binary tree basics & terminology, DFS traversals (recursive and iterative), level-order/BFS traversal, BST properties & operations, balanced trees (AVL/Red-Black conceptual overview), and height/depth/diameter calculations.
- **`snippets/`** — 7 focused, runnable code examples: node definition, recursive DFS, iterative DFS with an explicit stack, BFS with a queue, BST insert/search, BST delete, and height/diameter.
- **`output-based/`** — 6 "what's the traversal order / what does this print" questions with the answer worked out step by step.
- **`scenarios/`** — 5 real-world situations where tree/BST choices matter: ordered data structures, file systems, database indexes, expression parsing, and permission hierarchies.
- **`interview-qa/`** — 9 Q&A pairs grouped into 3 themed files: traversal fundamentals, BST properties/operations, and balanced trees/complexity.
- **`problems/`** — 7 hands-on coding challenges: invert a binary tree, validate a BST, lowest common ancestor, level order traversal, serialize/deserialize a tree, path sum, and diameter of a binary tree.
- **`assets/`** — placeholder for diagrams/images (see `assets/README.md`).

## What's covered

- Binary tree terminology: root, leaf, height, depth, subtree, full/complete/perfect/degenerate trees
- All four traversal orders — preorder, inorder, postorder, level-order — recursive **and** iterative, with explicit visited/stack/queue mechanics
- BST invariant (`left < node < right`) and how it enables O(log n) search/insert/delete on a balanced tree, degrading to O(n) on a skewed one
- BST insert, search, and delete (including the three delete cases: leaf, one child, two children via inorder successor)
- Why self-balancing trees (AVL, Red-Black) exist, how they differ, and where each is used in real systems (conceptual — not full rotation implementations)
- Height, depth, and diameter calculations, and how a single post-order pass can compute diameter in O(n) instead of O(n log n) or O(n²)
- Classic problems: invert, validate BST, LCA, level order, serialize/deserialize, path sum, diameter
