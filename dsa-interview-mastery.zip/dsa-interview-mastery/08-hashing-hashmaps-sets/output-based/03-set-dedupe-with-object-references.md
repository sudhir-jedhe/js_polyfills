# Output: `Set` Deduplication with Object References

```js
const set = new Set();
set.add({ id: 1 });
set.add({ id: 1 }); // structurally identical, but a different object
console.log(set.size);

const shared = { id: 2 };
set.add(shared);
set.add(shared); // same reference this time
console.log(set.size);
```

**Answer:** `2`, then `3`.

**Why:** `Set` compares values by identity (SameValueZero) for objects, not by structural/deep equality. `{ id: 1 }` and `{ id: 1 }` are two distinct objects in memory even though they look identical, so both get added — the set has no way to know they're "the same data" without a custom comparison, which `Set` doesn't support natively. `shared` added twice, however, is the exact same reference both times, so the second `add` is a no-op and size only grows by one (to 3 total). This is the same reason `array.includes(obj)` and `.indexOf` also only match by reference for objects — if you need value-based dedupe of objects, you must key by a derived primitive (e.g. `JSON.stringify(obj)` or a specific field) instead.
