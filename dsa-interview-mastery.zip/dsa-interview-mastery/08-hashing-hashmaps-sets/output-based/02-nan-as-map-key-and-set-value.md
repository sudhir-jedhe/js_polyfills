# Output: `NaN` as a `Map` Key / `Set` Value

```js
console.log(NaN === NaN); // ?

const map = new Map();
map.set(NaN, 'not a number');
console.log(map.get(NaN)); // ?

const set = new Set();
set.add(NaN);
set.add(NaN);
console.log(set.size); // ?
```

**Answer:** `false`, then `'not a number'`, then `1`.

**Why:** `===` (strict equality) considers `NaN !== NaN` — famously, `NaN` is the one value that isn't equal to itself under strict equality. But `Map` and `Set` don't use `===` for key/value comparison — they use an algorithm called **SameValueZero**, which is identical to `===` except it treats `NaN` as equal to `NaN` (and, unlike `Object.is`, still treats `+0` and `-0` as equal). This means `NaN` behaves as a single, well-defined, reusable key/value in both `Map` and `Set` — the second `set.add(NaN)` is recognized as a duplicate of the first, so the set's size stays `1`.
