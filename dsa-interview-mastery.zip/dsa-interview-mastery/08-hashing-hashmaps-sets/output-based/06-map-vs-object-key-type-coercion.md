# Output: Key Type Coercion — Object vs `Map`

```js
const obj = {};
obj[1] = 'number key';
obj['1'] = 'string key'; // does this create a second entry?
console.log(Object.keys(obj).length);

const map = new Map();
map.set(1, 'number key');
map.set('1', 'string key'); // does THIS create a second entry?
console.log(map.size);
```

**Answer:** `1`, then `2`.

**Why:** Plain object property keys are always coerced to strings (or symbols). `obj[1] = ...` is really `obj['1'] = ...` under the hood, so the second assignment overwrites the first — they were always the same key. `Map`, however, preserves the key's original type with no coercion: the number `1` and the string `'1'` are distinct keys compared via SameValueZero (which does NOT consider `1 === '1'`, unlike `==`), so both entries coexist. This is one of the most concrete, practical reasons to prefer `Map` over a plain object whenever keys might legitimately be non-string values (numeric IDs mixed with string IDs, for example) — using an object silently merges keys that a `Map` correctly keeps separate.
