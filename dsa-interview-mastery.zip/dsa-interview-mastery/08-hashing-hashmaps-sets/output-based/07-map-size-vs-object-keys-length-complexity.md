# What's the Complexity? — `map.size` vs `Object.keys(obj).length`

```js
const map = new Map();
for (let i = 0; i < 100000; i++) map.set(i, i);

const obj = {};
for (let i = 0; i < 100000; i++) obj[i] = i;

console.log(map.size);               // how expensive is this line?
console.log(Object.keys(obj).length); // how expensive is THIS line?
```

**Answer:** Both print `100000`, but their costs differ: `map.size` is **O(1)** — a maintained counter read directly. `Object.keys(obj).length` is **O(n)** — `Object.keys` must first allocate and populate a brand-new array containing every one of the object's own enumerable keys before `.length` can even be read.

**Why:** `Map` maintains its `size` as an internal counter, updated incrementally on every `set`/`delete`, so reading it is a constant-time property access with no traversal involved. Plain objects have no equivalent built-in counter — there's no `Object.prototype.size`. Getting a count requires materializing the *entire* key list via `Object.keys`/`Object.values`/`Object.entries` (all O(n), since they walk and copy every property) and only then taking `.length`. If you only need a *count*, calling `Object.keys(obj).length` inside a hot loop is a classic performance foot-gun — you rebuild the whole array every single time just to throw it away and read one number.
