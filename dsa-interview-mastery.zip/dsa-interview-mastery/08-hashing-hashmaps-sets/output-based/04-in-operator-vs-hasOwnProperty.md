# Output: `in` Operator vs `hasOwnProperty` on a Plain Object Hash Map

```js
const table = {};
table['apple'] = 3;

console.log('apple' in table);          // ?
console.log('toString' in table);       // ?
console.log(table.hasOwnProperty('toString')); // ?
console.log(table['banana']);           // ?
```

**Answer:** `true`, `true`, `false`, `undefined`.

**Why:** `in` checks the **entire prototype chain**, not just an object's own properties — `toString` was never set on `table`, but it's inherited from `Object.prototype`, so `'toString' in table` is `true`. `hasOwnProperty`, by contrast, only checks properties actually defined directly on the object itself, correctly reporting `false`. `table['banana']` returns `undefined` simply because that key was never set — there's no error, just a missing-property lookup that bottoms out at `undefined`. This is exactly why using a plain object as a hash map is riskier than it looks: naive `key in obj` membership checks can produce false positives for any key that happens to collide with something on `Object.prototype` (`toString`, `constructor`, `hasOwnProperty` itself, `__proto__`, etc.) — `Map.prototype.has()` has no such issue, since a `Map` carries no inherited "data" keys at all.
