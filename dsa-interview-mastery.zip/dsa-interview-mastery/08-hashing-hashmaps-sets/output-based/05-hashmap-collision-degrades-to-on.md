# Output: What's the Complexity Here? — All Keys Colliding

```js
class TerribleHashMap {
  constructor() {
    this.buckets = [[]]; // exactly ONE bucket, always
  }
  set(key, value) {
    const existing = this.buckets[0].find((p) => p[0] === key);
    if (existing) existing[1] = value;
    else this.buckets[0].push([key, value]);
  }
  get(key) {
    const found = this.buckets[0].find((p) => p[0] === key);
    return found ? found[1] : undefined;
  }
}

const map = new TerribleHashMap();
for (let i = 0; i < 10000; i++) map.set(`key${i}`, i);
console.log(map.get('key9999')); // what's the time complexity of this single call?
```

**Answer:** `9999` is the printed value, but the question that matters is the complexity: this single `get` call is **O(n)**, i.e. O(10000) in this case — not O(1).

**Why:** There's only ever one bucket, so every `set` and `get` degenerates into a linear scan of an array holding all `n` entries (`.find` walks the array from the front). This is a hash map in name only — structurally it's just a single linked list/array wrapped in hash-map-shaped method names. It illustrates the theory point directly: O(1) average-case hashing depends entirely on the hash function actually spreading keys across many buckets. A constant/degenerate hash function (or, in a real system, an attacker deliberately crafting keys that all collide — "hash flooding") produces exactly this worst case, turning every operation into O(n).
