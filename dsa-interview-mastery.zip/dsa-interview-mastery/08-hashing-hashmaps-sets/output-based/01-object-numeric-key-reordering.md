# Output: Numeric-Looking Keys Reorder in Plain Objects

```js
const obj = { z: 1, 2: 'two', a: 3, 1: 'one', b: 4 };
console.log(Object.keys(obj));
```

**Answer:** `['1', '2', 'z', 'a', 'b']`

**Why:** Plain object key iteration order is NOT purely insertion order. The spec mandates: (1) integer-index-like keys first, in ascending numeric order, regardless of where they were written; (2) then string keys in insertion order; (3) then symbol keys in insertion order. `'1'` and `'2'` are integer-like (their string form round-trips to a valid array index), so they jump to the front sorted numerically, even though `2` was written before `z` but `1` was written after `a`. This is a frequent surprise for anyone assuming object key order always matches insertion order — it does, but only for the non-numeric keys. `Map` has no such special case: it always preserves exact insertion order for every key type.
