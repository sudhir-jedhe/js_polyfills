# Scenario: Designing an LRU Cache

**Scenario:** You need an in-memory cache with a fixed capacity that evicts the **least recently used** entry (not the oldest-inserted one — access should count as "used") whenever it's full and a new key is added. `get` and `put` both need to run in O(1). What structure gives you this, and why does plain insertion order (like a naive `Map`) not immediately solve it?

**Approach:**

A naive `Map` alone gives you insertion order, but LRU needs *access-recency* order — a `get` on an existing key must move it to the "most recently used" end, not leave it where it was inserted. The trick: `Map` lets you **re-insert** a key (delete then set) to move it to the end of iteration order, which is exactly the operation LRU needs, and both `delete` and `set`/`get` remain O(1) average.

```js
class LRUCache {
  #capacity;
  #map = new Map(); // relies on Map's guaranteed insertion order to track recency

  constructor(capacity) { this.#capacity = capacity; }

  get(key) {
    if (!this.#map.has(key)) return -1;
    const value = this.#map.get(key);
    this.#map.delete(key);
    this.#map.set(key, value); // re-insert -> now "most recently used", moves to end of iteration order
    return value;
  }

  put(key, value) {
    if (this.#map.has(key)) this.#map.delete(key); // remove old position first
    else if (this.#map.size >= this.#capacity) {
      const lruKey = this.#map.keys().next().value; // first key in iteration order = least recently used
      this.#map.delete(lruKey);
    }
    this.#map.set(key, value); // inserted at the "most recent" end
  }
}

const cache = new LRUCache(2);
cache.put(1, 'a'); cache.put(2, 'b');
cache.get(1);           // touches 1 -> now more recent than 2
cache.put(3, 'c');       // evicts 2 (least recently used), not 1
console.log(cache.get(2)); // -1
console.log(cache.get(1)); // 'a'
```

The key insight for the interview: recognizing that `Map`'s insertion-order guarantee can be *repurposed* as a recency tracker by deliberately deleting-and-re-inserting on every access, avoiding the need to hand-roll a doubly linked list + hash map (the "classical" LRU implementation) while still hitting O(1) for both operations.
