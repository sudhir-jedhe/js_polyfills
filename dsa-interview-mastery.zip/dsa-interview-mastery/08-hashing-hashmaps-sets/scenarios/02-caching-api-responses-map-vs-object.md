# Scenario: Caching API Responses — `Map` vs Plain Object

**Scenario:** You're building a client-side cache that stores API responses keyed by a request-config object (or a complex cache key), needs to report its current size for a "cache stats" panel, and entries are added/evicted frequently as users navigate. Would you reach for a plain object or a `Map`, and why?

**Approach:**

`Map` is the right call here for three concrete reasons that all map directly onto this scenario's requirements:

```js
class ResponseCache {
  #store = new Map();
  #maxEntries;
  constructor(maxEntries = 100) { this.#maxEntries = maxEntries; }

  set(key, response) {
    if (this.#store.size >= this.#maxEntries) {
      const oldestKey = this.#store.keys().next().value; // Map preserves insertion order -> oldest is first
      this.#store.delete(oldestKey);
    }
    this.#store.set(key, response);
  }
  get(key) { return this.#store.get(key); }
  get size() { return this.#store.size; } // O(1), always accurate for the stats panel
}
```

1. **Non-string keys** — if the cache key is derived from a config object rather than forced into a string first, `Map` accepts it directly without silent stringification/collision risk that a plain object would introduce.
2. **`size` for the stats panel** — `Map.prototype.size` is an O(1) maintained counter; doing this with a plain object means recomputing `Object.keys(obj).length` — O(n) — every time the panel refreshes.
3. **Guaranteed insertion order for eviction** — a simple FIFO/LRU-ish eviction policy (evict the oldest entry) only works reliably if iteration order is guaranteed to be insertion order, which `Map` promises unconditionally; a plain object's key order has the numeric-key-reordering caveat that could silently break the "oldest first" assumption if any cache key happens to look like an integer.

A plain object would only be preferable here if the cache needed to be `JSON.stringify`'d directly (e.g. persisted to `localStorage` as-is) — in that case you'd either accept the trade-offs or convert with `Object.fromEntries(map)` at the serialization boundary.
