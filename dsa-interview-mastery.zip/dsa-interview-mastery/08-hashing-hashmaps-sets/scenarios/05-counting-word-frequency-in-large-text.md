# Scenario: Counting Word Frequency in a Large Text Corpus

**Scenario:** You need to process a multi-million-word text corpus and report the top N most frequent words. What's the right structure for the counting phase, and how do you avoid re-introducing an O(n²) or O(n log n) bottleneck when extracting the "top N"?

**Approach:**

The counting phase is a textbook hash map frequency counter — O(n) total to build, since each word lookup/increment is O(1) average:

```js
function wordFrequencies(words) {
  const freq = new Map();
  for (const word of words) {
    freq.set(word, (freq.get(word) ?? 0) + 1);
  }
  return freq;
}
```

The naive next step — sort all unique words by frequency and slice the top N — costs O(u log u), where `u` is the number of *unique* words (potentially still large for a big corpus with a long tail of rare words). If N is small relative to `u`, a **min-heap of size N** is the better follow-up: push each `[word, count]` pair, and if the heap exceeds size N, pop the smallest, giving O(u log N) total — meaningfully cheaper than a full sort when `N << u`. (See the heaps topic for the priority-queue "top-K" pattern in depth — this is the canonical example of hashing and heaps composing together: hashing solves the counting sub-problem, a heap solves the selection sub-problem.)

```js
function topNWords(words, n) {
  const freq = wordFrequencies(words);
  return [...freq.entries()]
    .sort((a, b) => b[1] - a[1]) // fine for moderate unique-word counts; swap for a min-heap if u is huge and n is small
    .slice(0, n);
}
```

The scenario-level lesson: hashing solves "count occurrences fast," but recognizing that a *second*, different data-structure decision (sort vs heap) governs the "select top N" step is what separates a merely-correct answer from a scalable one — don't reach for one structure and assume it solves the whole problem end to end.
