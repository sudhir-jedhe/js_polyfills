# Scenario: Deduplicating a Large Dataset

**Scenario:** You receive a stream of ~500,000 user IDs (with duplicates) and need to build a list of unique IDs, then repeatedly check "has this ID already been processed?" as more IDs stream in. A colleague's first draft uses an array and `array.includes(id)` for each check. What's wrong with that, and what would you change?

**Approach:**

`array.includes` is an O(n) linear scan. Called once per incoming ID against an array that itself grows to 500,000 entries, the whole dedup process becomes O(n²) — roughly 250 billion comparisons in the worst case, which will visibly hang. Swapping the array for a `Set` fixes this outright:

```js
// O(n^2) — includes() re-scans the whole array on every single check
function dedupeSlow(ids) {
  const unique = [];
  for (const id of ids) {
    if (!unique.includes(id)) unique.push(id); // O(n) scan, n times over
  }
  return unique;
}

// O(n) — Set.has() and Set.add() are O(1) average
function dedupeFast(ids) {
  const seen = new Set();
  for (const id of ids) seen.add(id); // duplicates silently ignored
  return [...seen];
}

// Or, since dedup is exactly what Set is designed for, this collapses to one line:
const uniqueIds = [...new Set(ids)];
```

The fix isn't just "use a different method" — it's recognizing the shape of the problem: repeated membership checks against a growing collection is *the* textbook signal for a hash-based structure. `Set` gives O(1) average `has`/`add`, turning an O(n²) approach into O(n) (plus O(n) space for the set itself) — for 500,000 IDs, this is the difference between milliseconds and a process that never finishes in practice.
