# Scenario: Fast Pair Lookup in an Array

**Scenario:** You're given an array of transaction amounts and need to repeatedly check "does a value that completes a target sum exist elsewhere in the array?" — the classic shape behind two-sum-style problems. A naive nested-loop check is O(n²). What structure would you reach for and why?

**Approach:**

A hash map (or `Set` if you only need existence, not an associated index/value) turns this into a single O(n) pass. As you iterate once, you check "have I already seen `target - current`?" using O(1) average lookups, and record the current value into the map before moving to the next element.

```js
function twoSumIndices(nums, target) {
  const seen = new Map(); // value -> index
  for (let i = 0; i < nums.length; i++) {
    const complement = target - nums[i];
    if (seen.has(complement)) return [seen.get(complement), i];
    seen.set(nums[i], i);
  }
  return null;
}
```

The key design decision is recognizing that "does X exist / what index was X at" is a **membership + lookup** problem, and any time you see "check if I've seen this before" or "find a complementary value" in a single pass, a hash map replaces an O(n) inner search with O(1) average lookup — collapsing overall complexity from O(n²) to O(n) at the cost of O(n) extra space. This space-for-time trade-off is one of the most common patterns in interview problem-solving, and recognizing it quickly is often the difference between a brute-force answer and the "optimal" one an interviewer is fishing for.
