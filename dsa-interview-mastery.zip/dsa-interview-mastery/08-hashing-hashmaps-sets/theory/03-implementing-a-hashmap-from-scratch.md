# Implementing a Hash Map From Scratch

A classic interview exercise: build a working hash map supporting `set`, `get`, `has`, and `delete`, using separate chaining (the more forgiving strategy to implement correctly under time pressure).

```js
class HashMap {
  constructor(initialCapacity = 8) {
    this.capacity = initialCapacity;
    this.size = 0;
    this.buckets = new Array(this.capacity).fill(null).map(() => []);
  }

  #hash(key) {
    const str = String(key);
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = (hash * 31 + str.charCodeAt(i)) >>> 0; // >>> 0 keeps it a non-negative 32-bit int
    }
    return hash % this.capacity;
  }

  set(key, value) {
    const index = this.#hash(key);
    const chain = this.buckets[index];
    for (const pair of chain) {
      if (pair[0] === key) { pair[1] = value; return; } // overwrite existing key
    }
    chain.push([key, value]);
    this.size++;
    if (this.size / this.capacity > 0.75) this.#resize(); // keep load factor bounded
  }

  get(key) {
    const chain = this.buckets[this.#hash(key)];
    for (const [k, v] of chain) if (k === key) return v;
    return undefined;
  }

  has(key) {
    const chain = this.buckets[this.#hash(key)];
    return chain.some(([k]) => k === key);
  }

  delete(key) {
    const chain = this.buckets[this.#hash(key)];
    const i = chain.findIndex(([k]) => k === key);
    if (i === -1) return false;
    chain.splice(i, 1);
    this.size--;
    return true;
  }

  #resize() {
    const oldBuckets = this.buckets;
    this.capacity *= 2;
    this.buckets = new Array(this.capacity).fill(null).map(() => []);
    this.size = 0;
    for (const chain of oldBuckets) {
      for (const [k, v] of chain) this.set(k, v); // rehash every entry into the new, larger table
    }
  }
}

const map = new HashMap();
map.set('name', 'Ada');
map.set('lang', 'JS');
console.log(map.get('name')); // 'Ada'
console.log(map.has('missing')); // false
map.delete('lang');
console.log(map.get('lang')); // undefined
```

## The pieces that matter to an interviewer

- **The hash function** converts any key into a bucket index — see `01-hash-functions-and-hashing-basics.md` for why the multiply-by-prime pattern works reasonably well for strings.
- **Collision handling** — each bucket is an array (a chain) of `[key, value]` pairs, so multiple keys landing on the same index coexist safely.
- **Resizing (rehashing)** — as `size / capacity` (the **load factor**) climbs past a threshold (commonly 0.75), every entry must be recomputed into a larger table, because the bucket index formula (`hash % capacity`) depends on `capacity`. This is why a single `set` call can occasionally be O(n) (the resize itself) even though `set` is O(1) amortized overall — the same amortized-cost argument used for JS array `push`.
- **Key stringification** — `String(key)` handles numbers, strings, and other primitives uniformly, but note this is also a source of bugs: `map.set(1, 'a')` and `map.set('1', 'b')` would collide in this naive implementation, unlike a real `Map` which distinguishes them by type. Fixing that requires storing the original key alongside a type tag, or accepting the trade-off explicitly.

## Complexity summary

| Operation | Average case | Worst case (all keys collide) |
|---|---|---|
| `set` | O(1) | O(n) |
| `get` | O(1) | O(n) |
| `has` | O(1) | O(n) |
| `delete` | O(1) | O(n) |
| `resize` (amortized into `set`) | O(1) amortized, O(n) for the resizing call itself | — |
