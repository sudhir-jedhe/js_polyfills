# When Hashing Gives O(1) — and When It Degrades

"Hash maps are O(1)" is the headline every candidate memorizes, and it's the source of a very common follow-up trap: **O(1) is an average-case, amortized claim, not a worst-case guarantee.** Knowing exactly why it holds — and exactly when it doesn't — is what separates a memorized fact from real understanding.

## Why average case is O(1)

Assuming:
1. A hash function that distributes keys roughly uniformly across buckets, and
2. The **load factor** (`size / capacity`) is kept below some constant threshold (commonly ~0.75) via resizing,

...then each bucket holds, on average, a small constant number of entries (`O(1)` expected chain length), so hashing to a bucket and scanning its tiny chain is `O(1)` expected time — independent of `n`, the total number of entries in the table.

## Why the worst case is O(n)

If every key you insert happens to hash to the **same bucket** — either through bad luck with a weak hash function, or a deliberately crafted adversarial input (a real attack class called **hash-flooding**, historically used to DoS servers that hashed untrusted user input like URL query strings into a table with a predictable hash function) — every operation degenerates into scanning one giant chain of length `n`. That's `O(n)` per lookup, exactly as bad as an unsorted array or linked list.

```js
// Pathological worst case: every key deliberately collides into the same bucket
class BadHashMap {
  #hash(key) { return 0; } // constant hash — EVERY key goes to bucket 0
  // ... every set/get/delete degenerates to O(n) — this "hash map" is a linked list wearing a mask
}
```

Real-world defenses: modern language runtimes (V8, the JVM, CPython) either randomize their hash seed per-process (so an attacker can't predict collisions ahead of time) or, like Java's `HashMap`, convert an overly-long chain into a balanced tree (`O(log n)` worst case per bucket) once it crosses a threshold.

## Why resizing is required for the O(1) claim to hold at all

Without resizing, as you keep inserting into a **fixed-size** table, the load factor climbs without bound, chains get longer and longer, and average lookup time drifts toward `O(n)` even with a perfectly uniform hash function — more entries just keep piling into the same fixed number of buckets. Resizing (doubling capacity and rehashing everything once load factor crosses the threshold) is what keeps the *average* chain length bounded by a constant as `n` grows. This is also why a single `set` call can occasionally cost `O(n)` — the resize itself — but that cost is **amortized** to `O(1)` across all inserts (same argument as dynamic array `push`/doubling), because each element only gets rehashed `O(log n)` times total across all resizes, spread across `n` inserts.

## Quick reference

| Scenario | Time complexity |
|---|---|
| Good hash function, load factor bounded, typical input | O(1) average, O(1) amortized |
| Good hash function, table never resized, load factor unbounded | Degrades toward O(n/buckets) → effectively O(n) as inserts pile up |
| Weak/predictable hash function, adversarial input (hash-flooding) | O(n) worst case per operation |
| Every key produces a distinct hash, but table isn't resized and starts too small | Still degrades — bucket *count*, not just hash quality, bounds performance |

## The interview-ready one-liner

"Hash map operations are O(1) on **average**, assuming a well-distributed hash function and a load factor kept in check by resizing — but the **worst case is O(n)** if too many keys collide into the same bucket, which is why production hash table implementations randomize hash seeds or fall back to tree-based buckets to defend against adversarial inputs."
