# Collision Resolution: Separate Chaining vs Open Addressing

A **collision** happens when two different keys hash to the same bucket index. With a fixed number of buckets and an unbounded number of possible keys, collisions are mathematically inevitable (pigeonhole principle) — a real hash map implementation *must* have a strategy for handling them. The two dominant strategies are separate chaining and open addressing.

## Separate chaining

Each bucket holds a small secondary structure (usually a linked list, sometimes a small array or, in modern JVMs, a balanced tree once a bucket gets large) that stores *all* entries hashing to that index.

```js
// buckets[i] = [[key1, val1], [key2, val2], ...]  <- a chain of entries at index i
function chainInsert(buckets, key, value, bucketCount) {
  const index = hash(key) % bucketCount;
  if (!buckets[index]) buckets[index] = [];
  const chain = buckets[index];
  for (const pair of chain) {
    if (pair[0] === key) { pair[1] = value; return; } // update existing key
  }
  chain.push([key, value]); // new key in this bucket
}
```

- Insert/lookup/delete: hash to the bucket, then linearly scan the (usually tiny) chain.
- Degrades gracefully: even with many collisions, you just get a longer list at that one index — the rest of the table is unaffected.
- Handles a load factor `>= 1` fine (more entries than buckets) since each bucket can grow indefinitely.

## Open addressing

There's only ever one entry per slot in the underlying array. On a collision, the algorithm **probes** for the next open slot according to a fixed sequence.

```js
// linear probing: on collision, try index+1, index+2, ... (wrapping around)
function openAddressInsert(table, key, value) {
  let index = hash(key) % table.length;
  let i = 0;
  while (table[index] !== undefined && table[index].key !== key) {
    i++;
    index = (hash(key) + i) % table.length; // linear probe
  }
  table[index] = { key, value };
}
```

Common probing sequences:
- **Linear probing** (`index + 1, +2, +3...`) — simple, cache-friendly, but prone to **primary clustering** (long runs of filled slots that grow and merge).
- **Quadratic probing** (`index + 1², +2², +3²...`) — spreads probes out more, reduces clustering, but can fail to find an empty slot even when one exists if the table isn't sized/probed carefully.
- **Double hashing** (`index + i * hash2(key)`) — uses a second hash function to compute the probe step, giving the best distribution of the three, at the cost of computing two hashes.

Open addressing **requires** the load factor to stay below 1 (you physically cannot store more entries than slots), and deletion is trickier — you can't just null out a slot, because that would break the probe chain for later entries; implementations use a special "deleted"/tombstone marker instead.

## Side-by-side comparison

| Aspect | Separate Chaining | Open Addressing |
|---|---|---|
| Extra memory per bucket | Yes — pointers/list nodes | No — everything lives in the flat array |
| Load factor can exceed 1? | Yes | No — hard ceiling at 1.0 |
| Cache locality | Poor (chases pointers) | Good (probes nearby array slots) |
| Deletion | Simple — remove from the chain | Needs tombstones to preserve probe chains |
| Worst case (many collisions) | Degrades to O(k) per bucket, structure stays intact | Degrades to long probe sequences, can thrash the whole table |
| Used by | Java's `HashMap` (chaining + tree-ification), most textbook implementations | Python's `dict`, many low-level/embedded hash tables |

## Where JS's `Map`/`Set` fit in

JavaScript doesn't expose which strategy V8 uses under the hood (it's an implementation detail, and it has changed across engine versions), and you're never expected to reimplement it for day-to-day code. What interviewers actually want is (a) understanding that collisions are unavoidable and (b) being able to build a working hash map yourself with one of these two strategies, which `03-implementing-a-hashmap-from-scratch.md` walks through end to end.
