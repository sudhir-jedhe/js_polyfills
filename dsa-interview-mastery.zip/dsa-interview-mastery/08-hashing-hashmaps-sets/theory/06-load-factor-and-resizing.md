# Load Factor and Resizing

**Load factor** is the single number that governs a hash table's performance: `loadFactor = size / capacity`, where `size` is the number of stored entries and `capacity` is the number of buckets/slots. It's the practical link between the abstract "O(1) average case" claim and how a real hash table stays fast as it grows.

## Why load factor matters

- **Too high** (many entries per bucket) → longer chains in separate chaining, or long probe sequences in open addressing → lookups degrade toward O(n).
- **Too low** (mostly empty buckets) → wasted memory, and in open addressing specifically, an artificially low load factor is sometimes kept on purpose because performance craters as load factor approaches 1.0 (probe sequences get very long searching for the last few open slots).

## Typical thresholds

| Strategy | Common resize threshold | Why |
|---|---|---|
| Separate chaining | ~0.75 | Chains can technically exceed 1 entry/bucket without breaking, so a slightly higher threshold is fine |
| Open addressing | ~0.5–0.7 | Physically cannot reach 1.0 (no room left), and probe sequences get expensive well before that hard ceiling |

## Resizing mechanics

```js
#resize() {
  const oldBuckets = this.buckets;
  this.capacity *= 2;                                   // typically double
  this.buckets = new Array(this.capacity).fill(null).map(() => []);
  this.size = 0;
  for (const chain of oldBuckets) {
    for (const [k, v] of chain) this.set(k, v);          // re-hash EVERY entry — indices depend on capacity
  }
}
```

Resizing must **rehash every existing entry**, not just copy them over, because `hash(key) % capacity` changes when `capacity` changes — an entry that lived at index 3 in a 8-bucket table might belong at index 11 in a 16-bucket table. This full-table rehash is the expensive O(n) step that gets amortized across many O(1) inserts (see `05-when-hashing-is-o1-vs-when-it-degrades.md` for the amortized-cost argument).

## Doubling (not incrementing) capacity

Growing capacity by a fixed increment (e.g. +10 buckets each time) would mean resizing — an O(n) operation — happens every O(1/n) inserts on average, i.e. resize cost isn't amortized away and total cost across n inserts becomes O(n²). **Doubling** capacity means resizes become exponentially rarer as the table grows, which is exactly what makes the amortized cost per insert O(1) — the same reasoning that applies to JS array `push` and dynamic array growth generally.

## Shrinking on delete (and why many implementations skip it)

Symmetrically, some hash table implementations shrink capacity when load factor drops too low after deletions, to reclaim memory. Many practical implementations (including JS engines' internal `Map`/`Set` handling in most cases) don't bother, favoring simplicity and avoiding "thrashing" — repeatedly resizing up and down when insert/delete calls alternate near a threshold boundary.

## Interview-relevant takeaway

If asked to implement a hash map, always mention (even if you don't fully code it under time pressure): what your resize threshold is, that you double capacity, and that resizing requires rehashing every entry — this signals you understand *why* the O(1) average case holds, not just that it does.
