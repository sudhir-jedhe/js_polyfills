# `Map`/`Set` vs Plain Object — The Classic Comparison

JavaScript gives you two ways to build a hash-based key/value store: the plain `{}` object (which has always supported this informally) and the dedicated `Map` class (ES2015+). `Set` is `Map`'s single-value cousin, compared against using an array or object-as-a-set. Interviewers ask this constantly because "just use an object" is the wrong answer more often than people assume.

## Map vs Object

| Aspect | `Map` | Plain Object |
|---|---|---|
| Key types | **Any value** — objects, functions, `NaN`, even `undefined`/`null` — compared by SameValueZero | Only strings and symbols — any other key (including numbers and objects) is coerced to a string via `String(key)` |
| Iteration order | **Guaranteed insertion order**, always | Insertion order for string keys, **but integer-like keys are reordered numerically first** (a well-known trap) |
| Size | `map.size` — O(1), always accurate | No built-in property — `Object.keys(obj).length` is O(n) |
| Iterability | Directly iterable (`for...of`, spread, `.forEach`) | Not directly iterable — needs `Object.keys/values/entries` first |
| Prototype pollution risk | None — a `Map` has no default keys | `{}` inherits from `Object.prototype`, so keys like `"toString"` or `"__proto__"` can collide with inherited members unless you use `Object.create(null)` or `Map` |
| Performance for frequent add/remove | Optimized for this — engines specifically tune `Map` for add/delete-heavy workloads | Can be slower for heavy add/delete due to hidden-class/shape transitions in the engine |
| JSON serialization | Not directly serializable — needs manual conversion (`Object.fromEntries(map)`) | Native `JSON.stringify` support |
| Default/prototype methods in the way | None | `hasOwnProperty`, `toString`, `constructor`, etc. are all "there" unless guarded against |

```js
const obj = {};
obj[1] = 'a';
obj['01'] = 'b';
console.log(Object.keys(obj)); // ['1', '01'] — but note '1' sorts first even though '01' was NOT inserted first... 
// actually integer-like keys ('1') are always iterated in ascending numeric order BEFORE string keys, regardless of insertion order

const map = new Map();
map.set(1, 'a');
map.set('01', 'b');
console.log([...map.keys()]); // [1, '01'] — exact insertion order, and 1 (number) !== '01' (string), two distinct entries
```

## Set vs Array vs Object-as-a-Set

| Aspect | `Set` | Array (with `.includes`) | Object as a set (`{key: true}`) |
|---|---|---|---|
| `has(x)` / membership check | O(1) average | O(n) — linear scan | O(1) average, but keys are string-coerced |
| Duplicate values | Automatically rejected on `add` | Allowed — you must dedupe manually | Automatically rejected (same key overwrites) |
| Storing non-string values distinctly | Yes — object references, numbers, etc. all kept distinct | Yes | No — everything becomes a string key |
| Iteration order | Insertion order | Index order | Same insertion-order caveats as plain objects |
| Built-in dedupe idiom | `[...new Set(array)]` | — | — |

```js
const unique = [...new Set([1, 2, 2, 3, '2'])]; // [1, 2, 3, '2'] — number 2 and string '2' are distinct
```

## When to actually reach for each

- **Use `Map`** when keys aren't guaranteed to be strings, when you need reliable size/iteration order, when keys/values churn frequently, or when using non-string keys (objects as keys, e.g. mapping DOM nodes to metadata) is the whole point.
- **Use plain objects** for fixed-shape records (basically "structs") — anywhere you'd reach for a class-like shape, JSON serialization is needed, or you're destructuring known property names. Object literal syntax and JSON compatibility still make them the right default for structured data, not for dynamic hash-table use.
- **Use `Set`** anywhere you need "unique values + fast membership test" — deduplication, tracking "visited" nodes in graph traversal, or set operations (union/intersection).
- **Use arrays** when order-by-position and duplicates matter, or the collection is small enough that O(n) `.includes` genuinely doesn't matter (a handful of items).
