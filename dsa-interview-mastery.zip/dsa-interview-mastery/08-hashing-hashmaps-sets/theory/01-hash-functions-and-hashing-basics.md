# Hash Functions and Hashing Basics

A hash function takes an arbitrary key (a string, number, object) and maps it to a fixed-size integer — a **hash code** — which is then reduced (usually via modulo) to an index into a fixed-size array called a **bucket array**. This is the trick that lets hash-based structures answer "is this key present?" in O(1) average time instead of scanning every entry: instead of searching, you compute *where the key must be* and jump straight there.

```js
function simpleStringHash(str, bucketCount) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = (hash * 31 + str.charCodeAt(i)) % bucketCount; // 31 is a common odd prime multiplier
  }
  return hash;
}

simpleStringHash('cat', 16); // some index 0-15, deterministic every time
```

## Properties a good hash function needs

- **Deterministic** — the same key must always produce the same hash code. If it didn't, you could never find a key you already inserted.
- **Fast to compute** — O(1) relative to key size (or O(k) for a key of length k), since hashing happens on every insert/lookup/delete.
- **Uniform distribution** — keys should spread evenly across buckets. A hash function that dumps everything into bucket 0 turns your O(1) hash map into an O(n) linked list in disguise.
- **Deterministic ≠ reversible** — you cannot (and don't need to) recover the original key from its hash code alone; hashing is one-way, unlike encoding.

## Why modulo the bucket count

The raw hash code from a function like the one above is a large integer; the bucket array only has, say, 16 slots. `hash % bucketCount` folds that large number down into a valid array index. This is also why **bucket count matters**: a bad bucket count (e.g. a small power of 2 with a hash function that has poor low-bit entropy) can cause clustering even with an otherwise decent hash function — a classic reason many hash map implementations prefer prime-sized bucket arrays or mix bits (`hash ^ (hash >>> 16)`) before the modulo.

## Hashing numbers vs strings vs objects

| Key type | How it's typically hashed |
|---|---|
| Integer | Often used directly (or with a bit-mixing step) — already a fixed-size number |
| String | Accumulated character-by-character (like the polynomial hash above) |
| Float | Bit pattern of the IEEE-754 representation is hashed, since direct equality is unreliable |
| Object | Hashed by reference/identity by default (two structurally-equal objects hash differently) unless the language defines value-based hashing |

In JavaScript, you never write a hash function yourself when using `Map`/`Set`/objects — the engine hashes for you internally — but understanding this mechanism is exactly what's being tested when an interviewer asks you to build a hash map from scratch (see `03-implementing-a-hashmap-from-scratch.md`).

## The one guarantee hashing gives you — and the one it doesn't

Hashing guarantees **average-case O(1)** lookup/insert/delete when the hash function distributes keys well and the load factor is kept low. It does **not** guarantee worst-case O(1) — if every key collides into the same bucket (either by bad luck or an adversarial input crafted to exploit a known hash function), you degrade to O(n) per operation. This distinction — average vs worst case — is covered in depth in `05-when-hashing-is-o1-vs-when-it-degrades.md`.
