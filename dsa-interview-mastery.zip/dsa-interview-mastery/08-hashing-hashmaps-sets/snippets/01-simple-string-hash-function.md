# Simple Polynomial String Hash Function

```js
function hashString(str, bucketCount = 1024) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = (hash * 31 + str.charCodeAt(i)) >>> 0; // >>> 0 forces unsigned 32-bit, avoids negative results
  }
  return hash % bucketCount;
}

console.log(hashString('cat'));   // deterministic index, e.g. 785
console.log(hashString('cat'));   // same input -> same output, always
console.log(hashString('act'));   // different order -> (usually) different index
```
