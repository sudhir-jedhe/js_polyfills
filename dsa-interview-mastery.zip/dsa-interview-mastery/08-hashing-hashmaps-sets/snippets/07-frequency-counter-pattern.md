# Frequency Counter Pattern (via `Map`)

```js
function frequencyCounter(items) {
  const freq = new Map();
  for (const item of items) {
    freq.set(item, (freq.get(item) ?? 0) + 1); // ?? handles the "not seen yet" case cleanly
  }
  return freq;
}

const counts = frequencyCounter(['a', 'b', 'a', 'c', 'b', 'a']);
console.log(counts.get('a')); // 3
console.log(counts.get('c')); // 1
console.log([...counts.entries()]); // [['a',3], ['b',2], ['c',1]]

// Classic use: anagram check in O(n) via frequency comparison instead of sorting both strings
function isAnagram(s1, s2) {
  if (s1.length !== s2.length) return false;
  const freq = frequencyCounter(s1.split(''));
  for (const ch of s2) {
    if (!freq.get(ch)) return false; // 0 or undefined -> not enough of this char left
    freq.set(ch, freq.get(ch) - 1);
  }
  return true;
}
console.log(isAnagram('listen', 'silent')); // true
```
