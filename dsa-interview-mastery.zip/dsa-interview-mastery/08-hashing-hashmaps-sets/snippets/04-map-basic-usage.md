# `Map` Basic Usage

```js
const scores = new Map();
scores.set('alice', 90);
scores.set('bob', 85);
scores.set(42, 'numeric key works too');

console.log(scores.get('alice')); // 90
console.log(scores.has('carol')); // false
console.log(scores.size);         // 3

for (const [key, value] of scores) {
  console.log(key, '->', value); // iterates in guaranteed insertion order
}

scores.delete('bob');
console.log([...scores.keys()]); // ['alice', 42]
```
