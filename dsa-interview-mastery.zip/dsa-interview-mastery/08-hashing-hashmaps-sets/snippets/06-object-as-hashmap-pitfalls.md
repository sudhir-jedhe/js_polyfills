# Object-as-Hash-Map Pitfalls

```js
const counts = {};
counts['apple'] = 1;
counts['toString'] = 5; // shadows Object.prototype.toString — usually harmless, but risky

console.log(counts.hasOwnProperty('apple'));  // true
console.log('constructor' in counts);          // true — inherited, NOT actually set by you!
console.log(counts.hasOwnProperty('constructor')); // false — hasOwnProperty tells the real story

// Safer: a null-prototype object has no inherited members to collide with
const safeCounts = Object.create(null);
safeCounts['apple'] = 1;
console.log('constructor' in safeCounts); // false — no prototype chain at all
console.log(safeCounts.hasOwnProperty);   // undefined — this method doesn't even exist here

// Numeric-looking keys get silently reordered ahead of insertion-ordered string keys:
const obj = {};
obj['b'] = 1;
obj['2'] = 2;
obj['a'] = 3;
obj['1'] = 4;
console.log(Object.keys(obj)); // ['1', '2', 'b', 'a'] — integer-like keys first, ascending, THEN insertion order
```
