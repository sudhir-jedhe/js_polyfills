# `Set` Basic Usage and Array Deduplication

```js
const seen = new Set();
seen.add(1);
seen.add(2);
seen.add(2); // duplicate — silently ignored
console.log(seen.size); // 2
console.log(seen.has(1)); // true

// The classic one-liner dedupe idiom:
const nums = [1, 2, 2, 3, 3, 3, 4];
const unique = [...new Set(nums)];
console.log(unique); // [1, 2, 3, 4]

// Set operations (union / intersection / difference) via spread + filter:
const a = new Set([1, 2, 3]);
const b = new Set([2, 3, 4]);
const union = new Set([...a, ...b]);                          // {1,2,3,4}
const intersection = new Set([...a].filter((x) => b.has(x)));  // {2,3}
const difference = new Set([...a].filter((x) => !b.has(x)));   // {1}
```
