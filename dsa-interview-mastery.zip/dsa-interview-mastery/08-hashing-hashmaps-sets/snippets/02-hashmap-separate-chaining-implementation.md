# Minimal Hash Map — Separate Chaining

```js
class ChainingHashMap {
  constructor(capacity = 8) {
    this.capacity = capacity;
    this.buckets = Array.from({ length: capacity }, () => []);
  }
  #index(key) {
    const str = String(key);
    let h = 0;
    for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0;
    return h % this.capacity;
  }
  set(key, value) {
    const chain = this.buckets[this.#index(key)];
    const existing = chain.find((p) => p[0] === key);
    if (existing) existing[1] = value;
    else chain.push([key, value]);
  }
  get(key) {
    const found = this.buckets[this.#index(key)].find((p) => p[0] === key);
    return found ? found[1] : undefined;
  }
}

const m = new ChainingHashMap();
m.set('a', 1);
m.set('b', 2);
console.log(m.get('a'), m.get('b'), m.get('missing')); // 1 2 undefined
```
