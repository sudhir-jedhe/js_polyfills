# Minimal Hash Map — Open Addressing (Linear Probing)

```js
const DELETED = Symbol('deleted'); // tombstone marker — preserves probe chains after removal

class OpenAddressingHashMap {
  constructor(capacity = 8) {
    this.capacity = capacity;
    this.size = 0;
    this.slots = new Array(capacity).fill(undefined);
  }
  #hash(key) {
    const str = String(key);
    let h = 0;
    for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0;
    return h % this.capacity;
  }
  set(key, value) {
    let index = this.#hash(key);
    for (let i = 0; i < this.capacity; i++) {
      const probe = (index + i) % this.capacity; // linear probing
      const slot = this.slots[probe];
      if (slot === undefined || slot === DELETED || slot.key === key) {
        this.slots[probe] = { key, value };
        this.size++;
        return;
      }
    }
    throw new Error('Table full'); // a real impl would resize before this happens
  }
  get(key) {
    let index = this.#hash(key);
    for (let i = 0; i < this.capacity; i++) {
      const slot = this.slots[(index + i) % this.capacity];
      if (slot === undefined) return undefined; // empty slot -> key definitely not present
      if (slot !== DELETED && slot.key === key) return slot.value;
    }
    return undefined;
  }
}

const m = new OpenAddressingHashMap();
m.set('x', 10);
m.set('y', 20);
console.log(m.get('x'), m.get('y')); // 10 20
```
