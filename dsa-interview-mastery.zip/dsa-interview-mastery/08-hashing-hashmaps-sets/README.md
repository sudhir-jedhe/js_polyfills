# Hashing, Hash Maps & Sets

Hashing is the mechanism that turns "search through everything" into "jump straight to the answer" — it's what lets `Map`, `Set`, and plain objects offer average O(1) lookup, insert, and delete, and it underpins an enormous share of "optimal" interview solutions (two-sum-style problems, deduplication, frequency counting, caching). This topic covers how hash functions and collision resolution actually work under the hood, how to implement a hash map from scratch, the classic `Map`/`Set` vs plain-object comparison, and exactly when hashing's O(1) promise holds — and when it quietly degrades to O(n).

## Folder structure

- **`theory/`** — hash functions and their required properties, collision resolution (separate chaining vs open addressing), implementing a hash map from scratch, `Map`/`Set` vs plain object, when hashing is O(1) vs when it degrades, and load factor/resizing.
- **`snippets/`** — 7 focused, runnable examples: a string hash function, both collision-resolution strategies implemented, `Map`/`Set` basics, object-as-hash-map pitfalls, and the frequency-counter pattern.
- **`output-based/`** — 7 "predict the output / what's the complexity?" questions covering key coercion, `NaN` handling, reference vs value equality, and collision degradation, each with full reasoning.
- **`scenarios/`** — 5 real-world situations: choosing a hash map for O(1) pair lookup, caching API responses, deduplicating a large dataset, designing an LRU cache, and counting word frequency at scale.
- **`interview-qa/`** — 15 Q&A pairs across 3 themed files: hashing fundamentals, `Map`/`Set` vs object, and collision resolution/performance.
- **`problems/`** — 7 hands-on coding challenges: two sum, group anagrams, longest consecutive sequence, first non-repeating character, valid anagram, an LRU cache, and subarray sum equals k.
- **`assets/`** — placeholder for diagrams (see `assets/README.md`).

## What's covered

- How hash functions work and what properties make one "good" (deterministic, fast, uniform)
- Collision resolution: separate chaining vs open addressing (linear/quadratic probing, double hashing), with a side-by-side comparison
- Building a working hash map from scratch in JavaScript, including resizing/rehashing
- `Map`/`Set` vs plain object: key types, iteration order, `size`, prototype pollution risk, and performance
- Exactly when hashing gives O(1) average case, and when adversarial input or a bad hash function degrades it to O(n)
- Load factor and why doubling capacity (not incrementing) is what makes resizing amortized O(1)
- Classic problems: two sum, group anagrams, longest consecutive sequence, first non-repeating character, valid anagram, LRU cache, subarray sum equals k
