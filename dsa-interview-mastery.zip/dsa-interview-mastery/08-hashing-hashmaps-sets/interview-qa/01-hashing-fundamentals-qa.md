# Interview Q&A — Hashing Fundamentals

**Q: What does a hash function do, and what makes one "good"?**
A hash function maps an arbitrary key to a fixed-size integer, which is then reduced (typically via modulo) to a bucket index. A good hash function is deterministic (same key always produces the same hash), fast to compute, and distributes keys roughly uniformly across buckets, so lookups don't cluster into a few overloaded buckets.

**Q: Why does a hash map give O(1) average-case lookup instead of O(n)?**
Because a well-distributed hash function plus a bounded load factor keeps the average number of entries per bucket constant, independent of the total number of entries `n`. Instead of scanning all `n` entries, you compute the target bucket directly and scan only that bucket's small chain — an O(1) expected operation.

**Q: What's a collision, and is it avoidable?**
A collision is when two different keys hash to the same bucket index. It's not avoidable in general — with a fixed number of buckets and an unbounded key space, the pigeonhole principle guarantees collisions will eventually happen. A real hash table implementation must have an explicit strategy (chaining or open addressing) to handle them correctly.

**Q: What's the load factor, and why does it matter?**
Load factor is `size / capacity` — the ratio of stored entries to available buckets. As it climbs, chains get longer (or open-addressing probe sequences get longer), degrading average-case performance toward O(n). Hash tables resize (typically doubling capacity and rehashing every entry) once load factor crosses a threshold (commonly ~0.75) to keep operations close to O(1).

**Q: Is a hash map's O(1) claim guaranteed, or just typical?**
Just typical — it's an average-case, amortized guarantee, not a worst case. If a hash function distributes poorly (or is deliberately exploited via adversarial "hash-flooding" input), every key can collide into the same bucket, degrading every operation to O(n), identical to a linked list.
