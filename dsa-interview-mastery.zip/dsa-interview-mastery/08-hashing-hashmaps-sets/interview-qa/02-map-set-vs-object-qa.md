# Interview Q&A — Map/Set vs Object

**Q: What key types does a plain object support, versus `Map`?**
A plain object only supports string and symbol keys — anything else (numbers, objects, booleans) gets coerced to a string via `String(key)` before being used. `Map` accepts any value as a key — objects, functions, `NaN`, `undefined` — without coercion, and distinguishes keys by type (the number `1` and the string `'1'` are separate `Map` keys, but the same object key).

**Q: Does iteration order differ between `Map` and plain objects?**
Yes. `Map` always iterates in exact insertion order, for every key type, no exceptions. Plain objects mostly preserve insertion order for string keys, but integer-like keys (`'1'`, `'2'`, etc.) are always iterated first, in ascending numeric order, regardless of when they were actually assigned — a frequently-missed edge case.

**Q: How do you get the number of entries in each, and what's the complexity difference?**
`map.size` is a maintained O(1) property. A plain object has no equivalent — you must call `Object.keys(obj).length` (or `Object.values`/`Object.entries`), which is O(n) because it has to allocate and populate a whole new array of keys before you can read its length.

**Q: Why might using a plain object as a hash map be risky?**
Because every plain object inherits from `Object.prototype` by default, so keys like `"toString"`, `"constructor"`, or `"hasOwnProperty"` can silently collide with inherited members — `'toString' in obj` returns `true` even if you never set it. Using `Map`, or `Object.create(null)` for a prototype-less object, avoids this class of bug entirely.

**Q: When would you still choose a plain object over `Map`?**
When representing a fixed-shape record/struct with known property names (not a dynamic dictionary), when native JSON serialization matters (`Map` isn't directly `JSON.stringify`-able), or when destructuring named properties is central to how the data is consumed — object literal syntax and tooling (autocomplete, type systems) are built around this use case.

**Q: What's the equivalent comparison for `Set`?**
`Set` gives O(1) average membership checks (`has`) and automatic dedup on `add`, versus an array's O(n) `.includes`/`.indexOf`, or a plain object used as a fake set (`{key: true}`), which forces every value through string-key coercion and loses the ability to store distinct non-string values cleanly.
