# Interview Q&A — Collision Resolution and Performance

**Q: Explain separate chaining.**
Each bucket holds a small secondary structure (typically a linked list or array) containing every key/value pair that hashes to that index. On collision, the new entry is simply appended to that bucket's chain rather than displacing anything. Lookup requires hashing to the bucket, then scanning the (usually short) chain for a matching key.

**Q: Explain open addressing, and name two probing strategies.**
In open addressing, every entry lives directly in the underlying array — there's no secondary structure. On collision, the algorithm probes for the next available slot according to a fixed sequence. Linear probing tries `index+1, index+2, ...`; quadratic probing tries `index+1², index+2², ...` to reduce clustering; double hashing uses a second hash function to compute the probe step, giving the best distribution of the three.

**Q: Why is deletion trickier in open addressing than in chaining?**
In chaining, deleting an entry just removes it from its bucket's list — nothing else is affected. In open addressing, entries rely on an unbroken probe sequence to be found; simply nulling out a deleted slot would make later entries (that probed past it during insertion) unreachable. Implementations solve this with a tombstone marker that says "empty, but keep probing past me" rather than "empty, stop here."

**Q: What causes a hash map to degrade to O(n), and how do real systems defend against it?**
A hash function that distributes keys poorly — or an attacker crafting inputs that all hash to the same bucket ("hash-flooding") — collapses every bucket lookup into scanning one giant chain, O(n) per operation. Real language runtimes defend against this by randomizing the hash seed per process (so collisions can't be predicted ahead of time) and/or converting overly long chains into a balanced tree structure once they cross a size threshold, capping worst case at O(log n) instead of O(n).

**Q: Why does resizing use doubling instead of adding a fixed number of buckets each time?**
Doubling capacity means resize operations become exponentially rarer as the table grows, which is what makes the *amortized* cost per insert O(1) — each element is only rehashed O(log n) times total across all resizes, spread across n inserts. Growing by a fixed increment instead would mean resizing roughly every constant number of inserts, making total cost across n inserts O(n²) rather than O(n).
