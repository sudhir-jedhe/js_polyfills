# Problem: Subarray Sum Equals K

## Problem Statement

Given an array of integers `nums` and an integer `k`, return the total number of **contiguous** subarrays whose elements sum to exactly `k`. The array may contain negative numbers.

## Constraints

- `1 <= nums.length <= 2 * 10^4`
- `-1000 <= nums[i] <= 1000`
- `-10^7 <= k <= 10^7`
- Negative numbers rule out a sliding-window approach (window sums aren't monotonic), so hashing on prefix sums is the intended technique.

## Examples

```
Input: nums = [1, 1, 1], k = 2
Output: 2                      // [1,1] (indices 0-1) and [1,1] (indices 1-2)

Input: nums = [1, 2, 3], k = 3
Output: 2                       // [1,2] and [3]

Input: nums = [1, -1, 0], k = 0
Output: 3                       // [1,-1], [0], [1,-1,0]
```

## Approach

Let `prefixSum[i]` be the sum of `nums[0..i]`. A subarray `nums[j+1..i]` sums to `k` exactly when `prefixSum[i] - prefixSum[j] === k`, i.e. `prefixSum[j] === prefixSum[i] - k`. So while scanning left to right and maintaining a running sum, at each index you ask: "how many earlier prefix sums equal `runningSum - k`?" — a hash map from prefix-sum-value to how many times it's occurred answers that in O(1) average, turning an O(n²) brute-force (checking every subarray) into a single O(n) pass.

## Solution

```js
function subarraySum(nums, k) {
  const prefixCounts = new Map();
  prefixCounts.set(0, 1); // empty prefix (sum 0) occurs once -- needed for subarrays starting at index 0
  let runningSum = 0;
  let count = 0;

  for (const num of nums) {
    runningSum += num;
    const needed = runningSum - k;
    count += prefixCounts.get(needed) ?? 0; // every earlier prefix sum equal to `needed` yields a valid subarray ending here
    prefixCounts.set(runningSum, (prefixCounts.get(runningSum) ?? 0) + 1);
  }
  return count;
}

module.exports = { subarraySum };

// --- verification ---
console.log(subarraySum([1, 1, 1], 2));    // 2
console.log(subarraySum([1, 2, 3], 3));    // 2
console.log(subarraySum([1, -1, 0], 0));   // 3
```

## Complexity

- **Time:** O(n) — one pass, O(1) average map operations per element.
- **Space:** O(n) — up to n distinct prefix sums stored in the map.

**Why `prefixCounts.set(0, 1)` matters:** without seeding a count of 1 for prefix sum `0`, any subarray that starts at index 0 and itself sums exactly to `k` (making `runningSum - k === 0`) would never be counted, since there's no "earlier" prefix sum of 0 recorded to match against.
