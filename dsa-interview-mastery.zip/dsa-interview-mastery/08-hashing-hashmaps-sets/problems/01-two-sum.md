# Problem: Two Sum

## Problem Statement

Given an array of integers `nums` and an integer `target`, return the indices of the two numbers that add up to `target`. You may assume exactly one valid answer exists, and you may not use the same element twice.

## Constraints

- `2 <= nums.length <= 10^4`
- `-10^9 <= nums[i], target <= 10^9`
- Exactly one valid pair exists.

## Examples

```
Input: nums = [2, 7, 11, 15], target = 9
Output: [0, 1]              // nums[0] + nums[1] == 9

Input: nums = [3, 2, 4], target = 6
Output: [1, 2]               // nums[1] + nums[2] == 6

Input: nums = [3, 3], target = 6
Output: [0, 1]
```

## Approach

Brute force checks every pair — O(n²). Instead, make a single pass, and for each element check whether its **complement** (`target - nums[i]`) has already been seen, using a hash map from value to index. Since map lookups are O(1) average, this collapses the whole algorithm to a single O(n) pass.

## Solution

```js
function twoSum(nums, target) {
  const seen = new Map(); // value -> index
  for (let i = 0; i < nums.length; i++) {
    const complement = target - nums[i];
    if (seen.has(complement)) {
      return [seen.get(complement), i];
    }
    seen.set(nums[i], i); // record AFTER checking, so we never pair an element with itself
  }
  return []; // no valid pair (shouldn't happen given the problem's guarantee)
}

module.exports = { twoSum };

// --- verification ---
console.log(twoSum([2, 7, 11, 15], 9)); // [0, 1]
console.log(twoSum([3, 2, 4], 6));       // [1, 2]
console.log(twoSum([3, 3], 6));          // [0, 1]
```

## Complexity

- **Time:** O(n) — one pass, O(1) average map operations per element.
- **Space:** O(n) — the map can hold up to n-1 entries before finding the match.

The critical detail that trips people up: check for the complement **before** inserting the current element into the map, otherwise `nums[i]` could pair with itself when `target === 2 * nums[i]`.
