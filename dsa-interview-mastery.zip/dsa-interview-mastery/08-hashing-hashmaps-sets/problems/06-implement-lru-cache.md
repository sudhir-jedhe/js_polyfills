# Problem: Implement an LRU Cache

## Problem Statement

Design a data structure for a Least Recently Used (LRU) cache. It should support:
- `get(key)` — return the value if the key exists, else `-1`. This also counts as "using" the key.
- `put(key, value)` — insert or update the value for a key. If inserting a new key would exceed capacity, evict the least recently used key first.

Both operations must run in O(1) average time.

## Constraints

- `1 <= capacity <= 3000`
- `0 <= key, value <= 10^4`
- Up to `2 * 10^5` calls to `get`/`put` total.

## Examples

```
LRUCache cache = new LRUCache(2);
cache.put(1, 1);       // cache: {1=1}
cache.put(2, 2);       // cache: {1=1, 2=2}
cache.get(1);           // returns 1, and marks 1 as most-recently-used
cache.put(3, 3);        // capacity exceeded -> evicts 2 (least recently used); cache: {1=1, 3=3}
cache.get(2);           // returns -1 (evicted)
cache.put(4, 4);        // evicts 1; cache: {3=3, 4=4}
cache.get(1);           // -1
cache.get(3);           // 3
cache.get(4);           // 4
```

## Approach

`Map` in JavaScript already guarantees insertion order, and lets you re-insert a key to move it to the "most recent" end of that order — deleting then re-setting a key on every access is enough to track recency without hand-building a doubly linked list. Eviction just means removing whatever key iterates first (the least recently used).

## Solution

```js
class LRUCache {
  #capacity;
  #map = new Map();

  constructor(capacity) {
    this.#capacity = capacity;
  }

  get(key) {
    if (!this.#map.has(key)) return -1;
    const value = this.#map.get(key);
    this.#map.delete(key);
    this.#map.set(key, value); // re-insert: moves to the "most recent" end of iteration order
    return value;
  }

  put(key, value) {
    if (this.#map.has(key)) {
      this.#map.delete(key); // remove old position so the re-insert below moves it to the end
    } else if (this.#map.size >= this.#capacity) {
      const lruKey = this.#map.keys().next().value; // first in iteration order = least recently used
      this.#map.delete(lruKey);
    }
    this.#map.set(key, value);
  }
}

module.exports = { LRUCache };

// --- verification ---
const cache = new LRUCache(2);
cache.put(1, 1);
cache.put(2, 2);
console.log(cache.get(1)); // 1
cache.put(3, 3);            // evicts key 2
console.log(cache.get(2)); // -1
cache.put(4, 4);            // evicts key 1
console.log(cache.get(1)); // -1
console.log(cache.get(3)); // 3
console.log(cache.get(4)); // 4
```

## Complexity

- **Time:** O(1) average for both `get` and `put` — `Map`'s `get`/`set`/`delete` are all O(1) average, and `.keys().next().value` reads the first key without materializing the whole key list.
- **Space:** O(capacity) — the map never holds more than `capacity` entries.

**Note on the "classical" solution:** many textbooks implement this with a hand-rolled doubly linked list + a plain hash map (map from key to list node) to get O(1) removal from the middle of the list. Using JS's `Map` and its insertion-order guarantee achieves the same complexity with far less code — worth mentioning both if the interviewer wants to see you understand *why* the classical version needs a linked list at all (arrays can't delete-from-middle in O(1); `Map` sidesteps that by not needing "delete from middle," only "delete this key, then re-add it").
