# Problem: Longest Consecutive Sequence

## Problem Statement

Given an unsorted array of integers, find the length of the longest run of consecutive integers (values that form an unbroken sequence like `4, 5, 6, 7`), without sorting the array. The algorithm must run in O(n) time.

## Constraints

- `0 <= nums.length <= 10^5`
- `-10^9 <= nums[i] <= 10^9`
- Must run in O(n) — sorting first (O(n log n)) does not satisfy the intended solution, though it's a valid slower fallback.

## Examples

```
Input: [100, 4, 200, 1, 3, 2]
Output: 4              // the sequence 1, 2, 3, 4

Input: [0, 3, 7, 2, 5, 8, 4, 6, 0, 1]
Output: 9               // 0 through 8
```

## Approach

Put every number into a `Set` for O(1) membership checks. The key trick: only start counting a sequence from a number that is a **sequence start** — i.e. `num - 1` is NOT in the set. For every such start, walk forward (`num+1`, `num+2`, ...) counting how far the consecutive run extends. Because every number is only ever the start of at most one counted run (numbers in the middle of a run are skipped, never re-walked), the total work across all iterations is O(n), not O(n²).

## Solution

```js
function longestConsecutive(nums) {
  const numSet = new Set(nums);
  let longest = 0;

  for (const num of numSet) {
    if (numSet.has(num - 1)) continue; // not a sequence start -- skip, it'll be counted from its true start
    let length = 1;
    let current = num;
    while (numSet.has(current + 1)) {
      current++;
      length++;
    }
    longest = Math.max(longest, length);
  }
  return longest;
}

module.exports = { longestConsecutive };

// --- verification ---
console.log(longestConsecutive([100, 4, 200, 1, 3, 2])); // 4
console.log(longestConsecutive([0, 3, 7, 2, 5, 8, 4, 6, 0, 1])); // 9
console.log(longestConsecutive([])); // 0
```

## Complexity

- **Time:** O(n) — building the set is O(n); the nested `while` loop looks like it could be O(n²), but because it only ever runs starting from true sequence-starts (each number visited by the inner loop is visited exactly once across the *entire* algorithm), total work across all outer iterations is O(n).
- **Space:** O(n) — the `Set` holding every number.

The `numSet.has(num - 1)` skip is the whole trick — without it, this degrades to re-walking every sub-sequence from every starting point, which is O(n²) in the worst case (e.g. a fully consecutive array).
