# Problem: First Non-Repeating Character

## Problem Statement

Given a string, return the index of the first character that does not repeat anywhere else in the string. Return `-1` if every character repeats.

## Constraints

- `1 <= s.length <= 10^5`
- `s` consists of lowercase English letters (extendable to any characters).

## Examples

```
Input: "leetcode"
Output: 0        // 'l' never repeats, and it's first

Input: "loveleetcode"
Output: 2         // 'v' is the first character with no other occurrence

Input: "aabb"
Output: -1
```

## Approach

Two passes, both O(n), using a frequency map: first pass builds a count of every character; second pass walks the string in order and returns the index of the first character whose total count is exactly 1. This is strictly better than a naive approach that, for each character, re-scans the whole string to check for a duplicate (O(n²)).

## Solution

```js
function firstUniqChar(s) {
  const freq = new Map();
  for (const ch of s) {
    freq.set(ch, (freq.get(ch) ?? 0) + 1); // pass 1: count every character
  }
  for (let i = 0; i < s.length; i++) {
    if (freq.get(s[i]) === 1) return i;    // pass 2: first index with count 1
  }
  return -1;
}

module.exports = { firstUniqChar };

// --- verification ---
console.log(firstUniqChar("leetcode"));     // 0
console.log(firstUniqChar("loveleetcode")); // 2
console.log(firstUniqChar("aabb"));         // -1
```

## Complexity

- **Time:** O(n) — two linear passes over the string.
- **Space:** O(k) — where k is the number of distinct characters (bounded, e.g. 26 for lowercase-only input, so effectively O(1) in that case; O(n) in the worst case for arbitrary Unicode input).

**Why not one pass?** You could try to track "first unique so far" incrementally, but a character seen once early on might turn into a duplicate later in the string — you can't know a character is *permanently* unique until you've seen the entire string, hence the need for the count-first, then-scan-in-order two-pass structure.
