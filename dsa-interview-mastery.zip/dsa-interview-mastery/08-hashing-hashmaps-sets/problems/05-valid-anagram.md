# Problem: Valid Anagram

## Problem Statement

Given two strings `s` and `t`, return `true` if `t` is an anagram of `s` (uses exactly the same characters, same counts, any order), and `false` otherwise.

## Constraints

- `1 <= s.length, t.length <= 5 * 10^4`
- Lowercase English letters (extendable to Unicode with a `Map` instead of a fixed-size array).

## Examples

```
Input: s = "anagram", t = "nagaram"
Output: true

Input: s = "rat", t = "car"
Output: false

Input: s = "aacc", t = "ccac"
Output: false     // same letters, but wrong counts (t has 3 c's, s has 2)
```

## Approach

Quick length check first — different lengths can never be anagrams, no need to do any counting. Then build a frequency count of `s`, and **decrement** for each character of `t` as you scan it; if any count would go negative (or a character in `t` was never in `s` at all), it's not an anagram. If every decrement stays valid, the strings match.

## Solution

```js
function isAnagram(s, t) {
  if (s.length !== t.length) return false;

  const freq = new Map();
  for (const ch of s) freq.set(ch, (freq.get(ch) ?? 0) + 1);

  for (const ch of t) {
    const count = freq.get(ch);
    if (!count) return false; // undefined (never seen) or already decremented to 0
    freq.set(ch, count - 1);
  }
  return true;
}

module.exports = { isAnagram };

// --- verification ---
console.log(isAnagram("anagram", "nagaram")); // true
console.log(isAnagram("rat", "car"));          // false
console.log(isAnagram("aacc", "ccac"));        // false
```

## Complexity

- **Time:** O(n) — one pass to build the frequency map, one pass to consume it.
- **Space:** O(k) — k distinct characters; O(1) effectively for a bounded alphabet (e.g. 26 lowercase letters), O(n) in the worst case for arbitrary Unicode.

**Alternative approach:** sort both strings and compare (`O(n log n)`) — simpler to write, but strictly worse asymptotically than the O(n) hashing approach; worth mentioning both and explaining the trade-off if asked.
