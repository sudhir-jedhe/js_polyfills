# Problem: Group Anagrams

## Problem Statement

Given an array of strings, group the anagrams together. Anagrams are words made of exactly the same letters, rearranged. You can return the groups in any order.

## Constraints

- `1 <= strs.length <= 10^4`
- `0 <= strs[i].length <= 100`
- `strs[i]` consists of lowercase English letters only.

## Examples

```
Input: ["eat", "tea", "tan", "ate", "nat", "bat"]
Output: [["eat","tea","ate"], ["tan","nat"], ["bat"]]

Input: [""]
Output: [[""]]
```

## Approach

Two strings are anagrams if and only if their sorted characters are identical. Use that sorted form (or a character-frequency signature) as a hash map key, and group every original string under its canonical key. This turns "find all strings that are permutations of each other" into a single-pass grouping problem via hashing, instead of comparing every pair (which would be O(n²)).

## Solution

```js
function groupAnagrams(strs) {
  const groups = new Map(); // canonical key -> array of original strings
  for (const str of strs) {
    const key = str.split('').sort().join(''); // canonical form: sorted characters
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(str);
  }
  return [...groups.values()];
}

module.exports = { groupAnagrams };

// --- verification ---
console.log(groupAnagrams(["eat", "tea", "tan", "ate", "nat", "bat"]));
// [ [ 'eat', 'tea', 'ate' ], [ 'tan', 'nat' ], [ 'bat' ] ]
console.log(groupAnagrams([""])); // [ [ '' ] ]
```

## Complexity

- **Time:** O(n * k log k) — n strings, each sorted in O(k log k) where k is the string's length.
- **Space:** O(n * k) — storing every string, grouped, plus their keys.

**Optimization note:** if k can be large, a character-count signature (e.g. a 26-length count array joined into a string, `"1a0b2c..."`) builds the key in O(k) instead of O(k log k), improving overall time to O(n * k) — worth mentioning as a follow-up even if you implement the simpler sort-based key first.
