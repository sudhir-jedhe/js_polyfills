# Interview Q&A — Sliding Window

**Q: What's the difference between fixed-size and variable-size sliding window?**
Fixed-size window maintains a constant window length `k` as it slides one position at a time across the array, used when the problem gives you a specific window size (e.g. "max sum of any 5 consecutive elements"). Variable-size window grows and shrinks dynamically based on a condition, used for "longest/shortest subarray or substring satisfying property X" problems, where the window size itself is what you're solving for.

**Q: In the variable-size sliding window template, why is the overall time complexity O(n) despite a `while` loop nested inside a `for` loop?**
Because the `left` pointer only ever moves forward and never resets — across the *entire* run of the algorithm, `left` can advance at most `n` times total, no matter how many times the outer `for` loop iterates. So even though there's a nested loop, the *combined* work of every shrink step across the whole algorithm is bounded by O(n), not O(n²) — this is an amortized analysis argument, not something visible from looking at any single iteration in isolation.

**Q: How do you decide whether to record the answer inside or after the shrink loop?**
It depends on whether you're maximizing or minimizing the window length. For "longest window satisfying a condition," shrink *while the window is invalid*, then record the length *after* the shrink loop completes (once the window is valid again). For "shortest window satisfying a condition," shrink *while the window is still valid*, recording the length on every successful shrink *inside* the loop — since an even smaller valid window might exist by shrinking further.

**Q: Why does sliding window fail on arrays containing negative numbers?**
The shrink step assumes removing an element from the left of the window always moves the window's aggregate in a predictable direction (e.g. always decreases the sum). With negative numbers, removing an element can move the aggregate in the *opposite* direction of what's expected (subtracting a negative number increases the sum), which breaks the greedy "shrink until valid, then never look back" logic — the algorithm can permanently discard a valid window it can never reconsider, since `left` never moves backward. Prefix-sum + hashmap is the correct tool once negative numbers are in play.
