# Interview Q&A — Prefix Sum

**Q: What problem does a prefix sum array solve, and what's the complexity tradeoff?**
It answers "what's the sum of any range `[left, right]`" in O(1) after an O(n) one-time preprocessing pass, instead of O(n) per query if you re-sum the range from scratch every time. The tradeoff is O(n) extra space for the prefix array itself — worthwhile whenever multiple range queries will be made against the same, unchanging array.

**Q: Why is `prefix[i]` typically defined as "sum of elements before index i," with a leading `prefix[0] = 0`, rather than "sum through index i inclusive"?**
The leading-zero, offset-by-one convention makes the range-sum formula uniform for every range, including ranges that start at index 0 — `rangeSum(left, right) = prefix[right + 1] - prefix[left]` works without a special case. If `prefix[i]` instead meant "sum through index i inclusive" (no leading zero), a range starting at index 0 would need special-casing (`left === 0 ? prefix[right] : prefix[right] - prefix[left - 1]`), since there'd be no valid "index -1" entry to subtract.

**Q: How does prefix sum combine with a hashmap to count subarrays summing to a target k?**
For a running sum `prefixSum[j]` at index `j`, a subarray ending at `j` sums to `k` exactly when some earlier running sum equals `prefixSum[j] - k`. Storing every running sum seen so far in a hashmap (value → count of times seen) lets you check "how many earlier positions have that exact running sum" in O(1) at each step, turning what would otherwise be an O(n²) search for matching range pairs into a single O(n) pass.

**Q: Why must the hashmap be seeded with `{0: 1}` before the loop starts, in the subarray-sum-equals-k pattern?**
This represents the "empty prefix" — a running sum of `0` before any elements have been processed — which is what allows a subarray *starting at index 0* to be found. Without it, a subarray from index 0 through some index `j` where `prefixSum[j] === k` exactly would never be counted, since there'd be no recorded prior running sum of `0` to match against `prefixSum[j] - k = 0`.
