# Interview Q&A — Two Pointers

**Q: What's the difference between opposite-direction and same-direction two pointers?**
Opposite-direction pointers start at both ends of a (typically sorted) sequence and converge toward each other based on a comparison against a target — used for pair-finding problems like two-sum on sorted data or container with most water. Same-direction pointers start at or near the same end and move independently, usually with one scanning ahead (`fast`) and one marking a boundary (`slow`) — used for in-place partitioning, deduplication, and cycle detection.

**Q: Why does opposite-direction two pointers require a sorted array?**
The technique relies on knowing which direction to move deterministically: if the current pair's sum is too small, moving `left` up is guaranteed to increase the sum (and only moving `left` can do that, since decreasing `right` can only decrease or hold the sum), and symmetrically for a sum that's too large. Without sort order, there's no such guarantee — moving either pointer could increase or decrease the sum unpredictably, so the technique can't safely skip any pairs.

**Q: What's the time and space complexity of the two-pointer technique compared to a brute-force nested loop?**
Two pointers is O(n) time and O(1) extra space, since each pointer moves at most n times total (a combined 2n pointer moves across the whole run). Brute force checking every pair is O(n²) time. The tradeoff is that two pointers generally requires sorted input (or a problem structure that doesn't need sorting, like same-direction dedup) to work correctly.

**Q: How does the "fast and slow pointer" technique detect a cycle in a linked list?**
Both pointers start at the head; `slow` advances one node per step, `fast` advances two. If there's no cycle, `fast` reaches the end (`null`) first and the loop terminates. If there is a cycle, `fast` eventually laps `slow` and they land on the same node — this is Floyd's cycle detection ("tortoise and hare"), and it's a same-direction two-pointer pattern with unequal speeds rather than unequal starting positions.
