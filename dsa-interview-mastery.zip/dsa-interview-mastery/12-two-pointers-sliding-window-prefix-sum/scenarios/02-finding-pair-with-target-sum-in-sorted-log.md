# Scenario: Finding Two Sensor Readings That Sum to a Target

**Scenario:** A sensor log stores readings in a sorted array (sorted by value, not time). You need to find whether any two distinct readings sum to exactly a target calibration value, and ideally return their indices. What's the right approach, and what's the naive alternative you're improving on?

**Approach:** sorted input plus "find a pair" is the textbook signal for **opposite-direction two pointers**:

```js
function findPairSummingTo(sortedReadings, target) {
  let left = 0, right = sortedReadings.length - 1;
  while (left < right) {
    const sum = sortedReadings[left] + sortedReadings[right];
    if (sum === target) return [left, right];
    if (sum < target) left++;
    else right--;
  }
  return null;
}
```

The naive alternative is a nested loop checking every pair — O(n²). Two pointers exploits the sort order: if the current sum is too small, the *only* way to increase it is to move `left` up (since decreasing `right` can only decrease or keep the sum the same); symmetric logic applies for a sum that's too large. This guarantees the whole array is scanned in O(n) with O(1) extra space, no hashmap needed (unlike the unsorted two-sum variant, which does need a hashmap since it can't rely on sort order).

**Follow-up:** "what if the log isn't sorted?" — either sort it first (O(n log n), then apply this same technique — often still a net win if multiple queries will run against the same data), or use a hashmap-based single-pass two-sum (O(n) time, O(n) space) if sorting isn't desirable and only one query is needed.
