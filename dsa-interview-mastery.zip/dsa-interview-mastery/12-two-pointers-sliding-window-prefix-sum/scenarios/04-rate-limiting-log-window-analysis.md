# Scenario: Finding the Shortest Burst That Exceeds a Request Threshold

**Scenario:** An API request log gives you a chronological array of request counts per minute for a service. You need to find the **shortest** contiguous window of minutes where the total request count reaches or exceeds a suspicious-traffic threshold, to help pinpoint exactly when a burst started. All counts are non-negative. How do you approach it?

**Approach:** "shortest contiguous window satisfying a condition" with non-negative values is the signature of a **variable-size sliding window**, using the "shrink while valid" variant (since we're minimizing, not maximizing):

```js
function shortestBurstWindow(requestCounts, threshold) {
  let left = 0, sum = 0, minLen = Infinity;

  for (let right = 0; right < requestCounts.length; right++) {
    sum += requestCounts[right]; // expand

    while (sum >= threshold) {    // shrink WHILE valid — keep trying to shrink further
      minLen = Math.min(minLen, right - left + 1); // record on every valid shrink
      sum -= requestCounts[left];
      left++;
    }
  }
  return minLen === Infinity ? 0 : minLen; // 0 if no window ever reached the threshold
}
```

This is the mirror image of the "longest window" template: because we're minimizing, the answer is recorded *inside* the shrink loop (every time the window is still valid after shrinking, that's a candidate for the shortest one found so far), rather than after the shrink loop finishes. Non-negative counts guarantee the window's sum only grows as it expands and only shrinks as elements leave — the monotonic property that makes sliding window sound here (unlike the negative-numbers pitfall covered in `../output-based/05-sliding-window-negative-numbers-pitfall.md`).

**Follow-up:** "what if request counts could be negative (e.g. representing a net change, not a raw count)?" — that breaks the monotonic assumption sliding window relies on; you'd need to reconsider whether prefix-sum-based techniques fit instead, though "shortest subarray with sum at least K" under negative numbers is a genuinely harder problem (typically solved with a monotonic deque over prefix sums, beyond plain two pointers).
