# Scenario: Detecting Anomalous Spending in a Rolling Window

**Scenario:** You have a sorted-by-time array of a user's daily transaction amounts (all non-negative), and you need to flag whether any consecutive 7-day window sums to more than a fraud threshold. How would you approach it, and why?

**Approach:** this is a **fixed-size sliding window** problem — the window size (7 days) is known and constant, and you need an aggregate (sum) over every such window across the array:

```js
function hasAnomalousWindow(dailyAmounts, windowSize, threshold) {
  let windowSum = 0;
  for (let i = 0; i < windowSize; i++) windowSum += dailyAmounts[i];
  if (windowSum > threshold) return true;

  for (let i = windowSize; i < dailyAmounts.length; i++) {
    windowSum += dailyAmounts[i] - dailyAmounts[i - windowSize]; // slide by one day
    if (windowSum > threshold) return true;
  }
  return false;
}
```

Recomputing the 7-day sum from scratch at every starting day would be O(n · 7); sliding the window instead does one addition and one subtraction per day, giving O(n). Because all amounts are non-negative, there's no risk of the sliding-window-with-negative-numbers pitfall — the aggregate updates cleanly and predictably as the window moves.

**Follow-up the interviewer might ask:** "what if you need the *earliest* window that's anomalous, not just whether one exists?" — same code, just return the starting index `i - windowSize + 1` instead of `true` on the first hit, since the scan is already left-to-right in chronological order.
