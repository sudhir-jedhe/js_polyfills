# Scenario: Answering Many Range-Total Queries on a Dashboard

**Scenario:** A revenue dashboard stores daily revenue for a full year in an array. Users repeatedly ask "what was total revenue between day X and day Y?" for many different arbitrary ranges, potentially hundreds of times per session as they explore the data. How do you avoid recomputing each range sum from scratch?

**Approach:** many repeated range-sum queries over a **fixed, unchanging** array is the exact use case prefix sums are built for — preprocess once in O(n), then answer every query in O(1):

```js
function buildPrefixSum(dailyRevenue) {
  const prefix = new Array(dailyRevenue.length + 1).fill(0);
  for (let i = 0; i < dailyRevenue.length; i++) {
    prefix[i + 1] = prefix[i] + dailyRevenue[i];
  }
  return prefix;
}

function revenueBetween(prefix, startDay, endDay) { // inclusive
  return prefix[endDay + 1] - prefix[startDay];
}
```

Without prefix sums, `q` queries over `n` days costs O(n · q) in the worst case (recomputing each range from scratch). With prefix sums it's O(n) once, then O(1) per query — for `q` in the hundreds and `n` in the hundreds, this is the difference between a dashboard that recalculates visibly on every interaction and one that responds instantly.

**Follow-up:** "what if new revenue data streams in daily and the array keeps growing?" — the prefix array can be extended incrementally (`prefix.push(prefix[prefix.length - 1] + newDayRevenue)`) in O(1) amortized per new day, without rebuilding the whole array from scratch, as long as data is only ever appended (not edited in the middle — an edit would require recomputing every prefix entry after that point, or switching to a Fenwick tree / binary indexed tree for O(log n) updates, worth mentioning as a stronger answer).
