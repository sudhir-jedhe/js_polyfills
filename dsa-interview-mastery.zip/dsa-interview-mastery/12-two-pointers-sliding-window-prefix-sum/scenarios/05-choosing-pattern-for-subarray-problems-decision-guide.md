# Scenario: An Interviewer Gives You a Vague "Subarray" Problem — What Do You Ask?

**Scenario:** The prompt is deliberately underspecified: "Given an array, find something about its subarrays related to a sum." Before writing a line of code, what questions do you ask to figure out which of two-pointers, sliding window, or prefix sum actually applies?

**The clarifying questions, and what each answer tells you:**

1. **"Can the array contain negative numbers?"** If yes, sliding window's shrink logic is unsound (see the negative-numbers pitfall) — lean toward prefix-sum + hashmap. If the array is guaranteed non-negative, sliding window is likely the more space-efficient option.

2. **"Am I looking for a specific pair/pair-count, or a contiguous range (subarray/substring)?"** Pairs (not necessarily adjacent) on sorted data → two pointers. Contiguous ranges → sliding window or prefix sum, decided by question 1.

3. **"Is the window/range size fixed, or do I need to find the best size myself?"** Fixed size → fixed-size sliding window. Variable, with "longest"/"shortest" in the prompt → variable-size sliding window (assuming non-negative values) or prefix-sum + hashmap otherwise.

4. **"Will there be repeated queries against the same array, or is this a one-time computation?"** Repeated range-sum queries → prefix sum is worth the O(n) preprocessing investment. A single pass, one-time answer → a plain sliding window or two-pointer scan is usually simpler and avoids the extra O(n) space a hashmap-based prefix-sum approach uses.

## Decision approach

```
Is it about pairs of elements (not necessarily contiguous)?
├── Yes, and array is sorted (or can be sorted) → two pointers
└── No, it's about a contiguous range/subarray →
    Can values be negative?
    ├── No → sliding window (fixed or variable size, per the prompt)
    └── Yes → prefix sum (+ hashmap if counting/finding subarrays by sum)
```

**Why asking matters more than guessing:** picking the wrong technique here isn't just slower — it can silently produce *wrong* answers (sliding window on negative numbers doesn't error, it just returns an incorrect result), which is far worse in an interview than picking a technique that's merely suboptimal. Asking these questions up front, out loud, before coding is itself a strong signal — it shows the tradeoffs are understood, not just memorized as templates to pattern-match against keywords.
