Diagrams (pointer movement, window expand/shrink animations, prefix sum arrays) for this topic will be added here.
