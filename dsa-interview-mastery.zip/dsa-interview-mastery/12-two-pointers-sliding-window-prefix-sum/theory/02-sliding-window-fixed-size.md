# Sliding Window: Fixed Size

A fixed-size sliding window maintains a "view" of exactly `k` consecutive elements as it slides across an array or string, updating a running aggregate (sum, count, max, etc.) incrementally instead of recomputing it from scratch at every position.

## The naive approach (what sliding window replaces)

```js
function maxSumBruteForce(nums, k) {
  let maxSum = -Infinity;
  for (let i = 0; i <= nums.length - k; i++) {
    let sum = 0;
    for (let j = i; j < i + k; j++) sum += nums[j]; // recompute the whole window every time
    maxSum = Math.max(maxSum, sum);
  }
  return maxSum;
}
// O(n * k) — recomputing each window's sum from scratch is the waste
```

## The fixed-size sliding window pattern

```js
function maxSumWindow(nums, k) {
  let windowSum = 0;
  for (let i = 0; i < k; i++) windowSum += nums[i]; // build the first window once

  let maxSum = windowSum;
  for (let i = k; i < nums.length; i++) {
    windowSum += nums[i] - nums[i - k]; // add the new element, remove the one leaving the window
    maxSum = Math.max(maxSum, windowSum);
  }
  return maxSum;
}
// O(n) — each element is added to the running sum exactly once and removed exactly once
```

The key idea: sliding the window by one position doesn't require summing `k` elements again — it only requires **one addition** (the new element entering on the right) and **one subtraction** (the old element leaving on the left). This turns O(n·k) work into O(n) work, since each array element is touched a constant number of times total across the whole scan (once when it enters the window, once when it leaves).

## General fixed-size template

```js
function fixedWindow(arr, k) {
  let result = /* initial aggregate over arr[0..k-1] */;

  for (let right = k; right < arr.length; right++) {
    const left = right - k;
    // update result: incorporate arr[right] entering, remove arr[left] leaving
    result = update(result, arr[right], arr[left]);
  }
  return result;
}
```

## When fixed-size applies

The window size `k` is known and constant throughout — "maximum sum of any `k` consecutive elements," "average of every window of size `k`," "check if any window of size `k` contains a duplicate." If the window's size needs to *change* based on a condition (e.g. "smallest window whose sum is at least `x`"), that's the variable-size variant covered in `03-sliding-window-variable-size-expand-shrink-template.md`, not this one.
