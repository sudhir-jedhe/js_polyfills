# Sliding Window: Variable Size (Expand/Shrink Template)

A variable-size sliding window grows and shrinks dynamically based on a condition, rather than sliding a fixed-length view. It's the go-to pattern for "longest/shortest substring or subarray satisfying some property" problems, and it always follows the same explicit two-phase template.

## The expand/shrink template

```js
function variableWindow(arr) {
  let left = 0;
  let windowState = /* whatever needs tracking: a running sum, a Map of char counts, etc. */;
  let best = /* initial answer: 0, Infinity, etc. depending on min/max being sought */;

  for (let right = 0; right < arr.length; right++) {
    // 1. EXPAND — incorporate arr[right] into the window
    windowState = addToWindow(windowState, arr[right]);

    // 2. SHRINK — while the window violates the condition, shrink from the left
    while (windowIsInvalid(windowState)) {
      windowState = removeFromWindow(windowState, arr[left]);
      left++;
    }

    // 3. RECORD — the window [left, right] is now valid; update the answer
    best = updateBest(best, right - left + 1);
  }
  return best;
}
```

The loop variable `right` only ever moves forward, once, across the whole array — and `left` also only ever moves forward, never backward. This is what guarantees the O(n) total time bound: even though there's a `while` loop nested inside a `for` loop, `left` can advance at most `n` times *in total* across the *entire* run (not per iteration of `right`), so the combined work of every shrink step across the whole algorithm is bounded by O(n), not O(n²).

## Worked example: longest substring without repeating characters

```js
function lengthOfLongestSubstring(s) {
  const seen = new Map(); // char -> last index seen
  let left = 0;
  let maxLen = 0;

  for (let right = 0; right < s.length; right++) {
    const char = s[right];
    if (seen.has(char) && seen.get(char) >= left) {
      left = seen.get(char) + 1; // shrink: jump left past the previous occurrence
    }
    seen.set(char, right);        // expand: record this character's newest position
    maxLen = Math.max(maxLen, right - left + 1); // record
  }
  return maxLen;
}
```

Here the "shrink" step is a direct jump rather than a `while` loop, since a `Map` already tells us exactly how far `left` needs to move — both are valid implementations of the same expand/shrink idea; a `while` loop is used when the shrink condition can't be resolved in one step (e.g. "shrink until the sum is small enough," which might take several removals).

## Choosing "shrink while invalid" vs "shrink while valid"

| Goal | Shrink condition | What gets recorded |
|---|---|---|
| **Longest** window satisfying a property | Shrink *while the window is invalid* (property violated) | Record the window length *after* the shrink loop, once valid again |
| **Shortest** window satisfying a property | Shrink *while the window is (still) valid* | Record the window length *inside* the shrink loop, on every valid shrink, since shrinking further might still be valid and produce an even shorter window |

Minimum window substring (`../problems/03-minimum-window-substring.md`) is the canonical "shortest window" example — recording happens *while* shrinking, because the goal is to shrink as much as possible while the window is still valid, and every one of those valid, shrinking states is a candidate for the final answer.
