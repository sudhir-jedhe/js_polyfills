# Prefix Sum Technique

A prefix sum array precomputes running totals so that the sum of **any** subarray can be answered in O(1) after a single O(n) preprocessing pass — instead of re-summing a range from scratch (O(n) per query) every time one is asked for.

## Building a prefix sum array

```js
function buildPrefixSum(nums) {
  const prefix = new Array(nums.length + 1).fill(0); // prefix[i] = sum of nums[0..i-1]
  for (let i = 0; i < nums.length; i++) {
    prefix[i + 1] = prefix[i] + nums[i];
  }
  return prefix;
}

const nums = [2, 4, -1, 3, 5];
const prefix = buildPrefixSum(nums);
console.log(prefix); // [0, 2, 6, 5, 8, 13]
```

`prefix[i]` holds the sum of everything *before* index `i` in the original array — deliberately offset by one, with `prefix[0] = 0` representing "the sum of zero elements." This offset is what makes range queries clean, including ranges that start at index 0.

## Range sum query in O(1)

```js
// sum of nums[left..right] inclusive
function rangeSum(prefix, left, right) {
  return prefix[right + 1] - prefix[left];
}

console.log(rangeSum(prefix, 1, 3)); // nums[1]+nums[2]+nums[3] = 4 + -1 + 3 = 6
```

The sum of any range `[left, right]` is `prefix[right + 1] - prefix[left]` — everything up to and including `right`, minus everything before `left`, leaving exactly the elements from `left` to `right`. Without the `+1` offset (i.e. defining `prefix[i]` as "sum through index `i` inclusive"), the formula would need an awkward special case for `left === 0`; the offset-by-one convention avoids that entirely.

## Why this matters: amortizing repeated range queries

| Approach | Preprocessing | Per-query cost | Best for |
|---|---|---|---|
| Naive re-sum each query | none | O(n) per query | A single query, or very few |
| Prefix sum array | O(n) once | O(1) per query | Many queries over the same fixed array |

If a problem asks for a single subarray sum, computing it directly is fine. The moment a problem implies **multiple** range-sum queries (or needs to compare sums of many different subarrays to find the best one, as in subarray-sum problems), prefix sums turn what would be O(n) per query into O(1) per query, for a total of O(n + q) instead of O(n · q) across `q` queries.

## 2D prefix sums (brief note)

The same idea extends to 2D grids for rectangular-region sum queries, using inclusion-exclusion: `prefix[r][c] = grid[r][c] + prefix[r-1][c] + prefix[r][c-1] - prefix[r-1][c-1]` (subtracting the double-counted overlap). This is a natural follow-up an interviewer might ask after a 1D prefix sum problem, worth knowing exists even if the array-based topic here focuses on 1D.
