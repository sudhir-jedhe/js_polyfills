# Two-Pointer Technique: Opposite-Direction and Same-Direction

The two-pointer technique replaces a nested loop (O(n²)) with two index variables that move through a sequence according to a rule, doing O(n) total work. It comes in two distinct shapes that solve different problem families — knowing which one a problem calls for is the actual interview skill.

## Opposite-direction (converging) pointers

One pointer starts at the left end, one at the right end, and they move toward each other based on a comparison, typically on a **sorted** array.

```js
function twoSumSorted(nums, target) {
  let left = 0, right = nums.length - 1;
  while (left < right) {
    const sum = nums[left] + nums[right];
    if (sum === target) return [left, right];
    if (sum < target) left++;   // sum too small — need a bigger value, move left pointer up
    else right--;                // sum too big — need a smaller value, move right pointer down
  }
  return [-1, -1];
}
```

This works *because* the array is sorted: moving `left` up strictly increases the sum, moving `right` down strictly decreases it, so every step is a guaranteed, correct move toward the target — no combination is ever skipped. Classic uses: two-sum on a sorted array, container with most water, valid palindrome checks, three-sum's inner loop (after fixing one element and sorting the rest).

## Same-direction (fast/slow) pointers

Both pointers start at (or near) the same end and move independently in the same direction, typically one scanning ahead (`fast`) while the other marks a boundary or write position (`slow`).

```js
function removeDuplicates(nums) { // nums is sorted
  let slow = 0;
  for (let fast = 1; fast < nums.length; fast++) {
    if (nums[fast] !== nums[slow]) {
      slow++;
      nums[slow] = nums[fast]; // slow marks the boundary of "unique elements written so far"
    }
  }
  return slow + 1; // count of unique elements
}
```

`fast` explores ahead looking for the next relevant element; `slow` tracks where the next "kept" element should be written, only advancing when a genuinely new value is found. This shape also covers cycle detection (Floyd's tortoise and hare, where `fast` moves 2 steps for every 1 step of `slow`) and in-place array partitioning (e.g. moving all zeros to the end).

## Comparison

| Aspect | Opposite-direction | Same-direction |
|---|---|---|
| Starting positions | Both ends of the array | Same end (often both start at/near index 0) |
| Movement rule | Move based on a comparison against a target/condition | One pointer scans ahead; the other lags to mark a boundary |
| Typical precondition | Usually requires a sorted array | Works on sorted or unsorted data, depending on the problem |
| Classic problems | Two-sum (sorted), container with most water, valid palindrome | Remove duplicates, partition arrays, cycle detection, sliding window's own left/right pointers |

## Why two pointers beats brute force

A brute-force nested loop checking every pair is O(n²). Two pointers exploits a monotonic property of the data (sortedness, or "elements only need to be visited once") to guarantee that each pointer only ever moves forward, for a combined total of at most 2n pointer moves — giving O(n) time using O(1) extra space, since no auxiliary data structure is needed.
