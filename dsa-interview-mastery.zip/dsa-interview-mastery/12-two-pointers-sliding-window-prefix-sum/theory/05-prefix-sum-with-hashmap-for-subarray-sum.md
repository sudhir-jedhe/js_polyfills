# Prefix Sum + HashMap: Counting/Finding Subarrays by Sum

Plain prefix sums answer "what's the sum of this specific range" in O(1). A different, very common interview question asks the reverse: "how many subarrays sum to exactly `k`" (or "does *any* subarray sum to `k`"), without being told the range up front. Combining a running prefix sum with a hashmap solves this in a single O(n) pass.

## The core insight

If `prefixSum[j]` is the sum of everything from the start up through index `j`, and `prefixSum[i]` is the sum through some earlier index `i`, then the sum of the subarray strictly between them, `nums[i+1..j]`, is `prefixSum[j] - prefixSum[i]`. We want that difference to equal `k`:

```
prefixSum[j] - prefixSum[i] = k
        =>     prefixSum[i] = prefixSum[j] - k
```

So at each position `j`, instead of searching backward for a matching `i`, we ask: "have I seen a running sum equal to `currentSum - k` before?" A hashmap from `running sum -> count of times seen` answers that in O(1), turning an O(n²) brute-force double loop into a single O(n) pass.

## Implementation: count subarrays summing to k

```js
function subarraySum(nums, k) {
  const seen = new Map();
  seen.set(0, 1); // an empty prefix (sum 0) has been "seen" once — handles subarrays starting at index 0

  let runningSum = 0;
  let count = 0;

  for (const num of nums) {
    runningSum += num;
    const needed = runningSum - k;
    if (seen.has(needed)) {
      count += seen.get(needed); // every prior index with this running sum forms a valid subarray ending here
    }
    seen.set(runningSum, (seen.get(runningSum) || 0) + 1);
  }
  return count;
}

console.log(subarraySum([1, 1, 1], 2)); // 2 — [1,1] (indices 0-1) and [1,1] (indices 1-2)
console.log(subarraySum([1, 2, 3], 3)); // 2 — [1,2] and [3]
```

## Why `seen.set(0, 1)` before the loop matters

Without seeding the map with `0 -> 1`, a subarray that starts at index 0 (where `prefixSum[i] = 0` conceptually, "before the array begins") would never be found, since there's no explicit "index -1" running sum recorded to match against. This is one of the most common off-by-one bugs in this pattern — always initialize the map with the empty-prefix case before the loop starts.

## When to reach for this pattern

- "Number of subarrays with sum equal to k" (this problem, exactly)
- "Longest subarray with sum equal to k" (store the *first* index each running sum was seen, instead of a count, and track the max `j - i`)
- "Subarray sum divisible by k" (store running sums *modulo* k instead of the raw sum — same map-lookup idea, different key)
- Any "does there exist / how many / what's the longest contiguous range matching X" question where a plain nested loop would be O(n²)

The two-pointer/sliding-window techniques from earlier in this topic generally require the window's aggregate to be **monotonic** as the window grows (e.g. all-positive numbers, so a bigger window always means a bigger sum). Prefix-sum-plus-hashmap has no such requirement — it works even with negative numbers in the array, which is exactly the case where sliding window silently breaks (see `../output-based/05-window-with-negative-numbers-pitfall.md`).
