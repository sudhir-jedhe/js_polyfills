# Choosing Between Two Pointers, Sliding Window, and Prefix Sum

All three techniques avoid an O(n²) brute-force scan, but they solve different shapes of problem. Confusing them — reaching for sliding window when prefix-sum-plus-hashmap is what the problem actually needs — is one of the most common ways candidates get stuck mid-interview.

## Decision framework

**1. Does the problem involve a *contiguous* range (subarray/substring), or arbitrary pairs/elements?**
- Arbitrary pairs from a sorted collection (e.g. "find two numbers that sum to target") → **two pointers** (opposite-direction).
- In-place partitioning or deduplication of a sequence → **two pointers** (same-direction, fast/slow).
- Contiguous subarray or substring → continue to question 2.

**2. For a contiguous range: does the window's validity change *monotonically* as it grows (all-positive sums, or a count that only increases as the window grows)?**
- Yes, and you need the longest/shortest/best contiguous range satisfying a condition → **sliding window** (variable-size, expand/shrink).
- Yes, and the range length is fixed and given → **sliding window** (fixed-size).
- No — the array can contain negative numbers, or the property isn't monotonic as the window grows (shrinking doesn't reliably fix a violation) → sliding window's shrink logic breaks; go to question 3.

**3. Do you need to answer range-sum queries, or count/find subarrays matching a sum condition, especially with negative numbers involved?**
- Yes → **prefix sum** (plain, for O(1) range queries) or **prefix sum + hashmap** (for "count/find subarrays summing to k").

## Comparison table

| Technique | Best for | Requires sorted input? | Handles negative numbers? | Typical complexity |
|---|---|---|---|---|
| Two pointers (opposite) | Pair-finding in a sorted array | Yes | Yes | O(n) time, O(1) space |
| Two pointers (same-direction) | In-place partition/dedup, cycle detection | No | Yes | O(n) time, O(1) space |
| Sliding window (fixed) | Aggregate over every window of size k | No | Yes (for sum/max, doesn't rely on monotonic shrink) | O(n) time, O(1) space |
| Sliding window (variable) | Longest/shortest contiguous range meeting a condition | No | **No** — needs a monotonic window property | O(n) time, O(1)–O(k) space |
| Prefix sum | O(1) range-sum queries after O(n) preprocessing | No | Yes | O(n) preprocessing, O(1) per query |
| Prefix sum + hashmap | Count/find subarrays summing to k | No | **Yes** — this is its main advantage over sliding window | O(n) time, O(n) space |

## The single most useful rule of thumb

If a subarray-sum problem mentions or allows **negative numbers**, sliding window is very likely the wrong tool (shrinking the window doesn't reliably reduce the sum when negative numbers are involved, so the "shrink while invalid" logic isn't sound) — reach for prefix sum + hashmap instead. If the array is guaranteed non-negative, sliding window is usually the more memory-efficient choice (O(1) or O(k) space vs. prefix-sum-plus-hashmap's O(n) map). This one distinction resolves the majority of "which pattern do I use" hesitation on subarray problems.
