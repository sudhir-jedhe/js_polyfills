# Problem: Subarray Sum Equals K

## Problem Statement

Given an array of integers `nums` and an integer `k`, return the total number of contiguous subarrays whose sum equals `k`. The array may contain negative numbers.

## Constraints

- `1 <= nums.length <= 2 * 10^4`
- `-1000 <= nums[i] <= 1000`
- `-10^7 <= k <= 10^7`

## Examples

```
Input: nums = [1,1,1], k = 2
Output: 2

Input: nums = [1,2,3], k = 3
Output: 2   ([1,2] and [3])

Input: nums = [1,-1,0], k = 0
Output: 3   ([1,-1], [0], [1,-1,0])
```

## Approach

Because negative numbers are allowed, sliding window is unsound here (see `../output-based/05-sliding-window-negative-numbers-pitfall.md`). Prefix sum + hashmap is the correct tool: track a running sum as we scan once left to right, and for each position, check how many earlier positions had a running sum equal to `currentSum - k` — each such earlier position marks the start of a subarray ending here that sums to exactly `k`.

## Solution

```js
function subarraySum(nums, k) {
  const seen = new Map();
  seen.set(0, 1); // empty prefix — handles subarrays starting at index 0

  let runningSum = 0;
  let count = 0;

  for (const num of nums) {
    runningSum += num;
    const needed = runningSum - k;
    count += seen.get(needed) || 0;
    seen.set(runningSum, (seen.get(runningSum) || 0) + 1);
  }
  return count;
}

module.exports = { subarraySum };

// --- verification ---
console.log(subarraySum([1, 1, 1], 2));   // 2
console.log(subarraySum([1, 2, 3], 3));   // 2
console.log(subarraySum([1, -1, 0], 0));  // 3
```

## Complexity

- **Time:** O(n) — a single pass, with O(1) map operations per element.
- **Space:** O(n) — the hashmap can hold up to n distinct running-sum values in the worst case.
