# Problem: Minimum Window Substring

## Problem Statement

Given two strings `s` and `t`, return the shortest substring of `s` that contains every character of `t` (including duplicates — if `t` has two `'a'`s, the window must contain at least two `'a'`s). Return `""` if no such window exists.

## Constraints

- `1 <= s.length, t.length <= 10^5`
- `s` and `t` consist of English letters.

## Examples

```
Input: s = "ADOBECODEBANC", t = "ABC"
Output: "BANC"

Input: s = "a", t = "aa"
Output: ""   (s doesn't have two 'a's, so no valid window exists)
```

## Approach

Variable-size sliding window, "shrink while valid" variant (this is a *shortest*-window problem): expand `right`, tracking how many characters of `t` are currently satisfied within the window using a frequency map and a `satisfied` counter. Once the window contains everything `t` needs, aggressively shrink from the left — recording the window length at every point it's still valid — until shrinking further would break the constraint.

## Solution

```js
function minWindow(s, t) {
  if (t.length > s.length) return '';

  const need = new Map();
  for (const c of t) need.set(c, (need.get(c) || 0) + 1);

  const windowCounts = new Map();
  let required = need.size;   // number of DISTINCT characters that must be fully satisfied
  let satisfied = 0;

  let left = 0;
  let bestLen = Infinity, bestStart = 0;

  for (let right = 0; right < s.length; right++) {
    const c = s[right];
    windowCounts.set(c, (windowCounts.get(c) || 0) + 1);      // expand

    if (need.has(c) && windowCounts.get(c) === need.get(c)) {
      satisfied++;                                              // this character just became fully satisfied
    }

    while (satisfied === required) {                            // shrink WHILE valid
      if (right - left + 1 < bestLen) {
        bestLen = right - left + 1;
        bestStart = left;
      }
      const leftChar = s[left];
      windowCounts.set(leftChar, windowCounts.get(leftChar) - 1);
      if (need.has(leftChar) && windowCounts.get(leftChar) < need.get(leftChar)) {
        satisfied--;                                             // removing this char broke the requirement
      }
      left++;
    }
  }

  return bestLen === Infinity ? '' : s.slice(bestStart, bestStart + bestLen);
}

module.exports = { minWindow };

// --- verification ---
console.log(minWindow('ADOBECODEBANC', 'ABC')); // "BANC"
console.log(minWindow('a', 'aa'));                // ""
console.log(minWindow('a', 'a'));                 // "a"
```

## Complexity

- **Time:** O(|s| + |t|) — building `need` is O(|t|); the main scan is O(|s|) since `right` moves forward once across the string and `left` also only ever moves forward, so total pointer movement is bounded by O(|s|).
- **Space:** O(|t|) — for the `need` map (bounded by the alphabet size of `t`, at most 52 for English letters) and the `windowCounts` map (bounded similarly).
