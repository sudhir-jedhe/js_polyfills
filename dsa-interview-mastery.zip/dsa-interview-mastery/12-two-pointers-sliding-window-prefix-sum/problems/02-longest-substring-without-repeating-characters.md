# Problem: Longest Substring Without Repeating Characters

## Problem Statement

Given a string `s`, find the length of the longest substring without repeating characters.

## Constraints

- `0 <= s.length <= 5 * 10^4`
- `s` consists of English letters, digits, symbols, and spaces.

## Examples

```
Input: s = "abcabcbb"
Output: 3   ("abc")

Input: s = "bbbbb"
Output: 1   ("b")

Input: s = "pwwkew"
Output: 3   ("wke")
```

## Approach

Variable-size sliding window: expand `right` one character at a time, and whenever the incoming character has already been seen *within the current window*, jump `left` forward to just past that character's last occurrence. A `Map` from character to its most recent index makes each shrink an O(1) direct jump instead of a `while` loop that removes characters one at a time.

## Solution

```js
function lengthOfLongestSubstring(s) {
  const lastSeen = new Map(); // char -> most recent index
  let left = 0;
  let maxLen = 0;

  for (let right = 0; right < s.length; right++) {
    const char = s[right];
    if (lastSeen.has(char) && lastSeen.get(char) >= left) {
      left = lastSeen.get(char) + 1; // shrink: jump past the previous occurrence
    }
    lastSeen.set(char, right);        // expand: record this occurrence
    maxLen = Math.max(maxLen, right - left + 1);
  }
  return maxLen;
}

module.exports = { lengthOfLongestSubstring };

// --- verification ---
console.log(lengthOfLongestSubstring('abcabcbb')); // 3
console.log(lengthOfLongestSubstring('bbbbb'));     // 1
console.log(lengthOfLongestSubstring('pwwkew'));    // 3
console.log(lengthOfLongestSubstring(''));           // 0
```

## Complexity

- **Time:** O(n) — each character is visited by `right` exactly once; `left` only ever moves forward, so its total movement across the whole run is also bounded by n.
- **Space:** O(min(n, alphabet size)) for the `Map` — at most one entry per distinct character that can appear in the current window.
