# Problem: Three Sum

## Problem Statement

Given an integer array `nums`, return all unique triplets `[a, b, c]` such that `a + b + c === 0`. The solution set must not contain duplicate triplets.

## Constraints

- `3 <= nums.length <= 3000`
- `-10^5 <= nums[i] <= 10^5`

## Examples

```
Input: nums = [-1,0,1,2,-1,-4]
Output: [[-1,-1,2],[-1,0,1]]

Input: nums = [0,1,1]
Output: []

Input: nums = [0,0,0]
Output: [[0,0,0]]
```

## Approach

Sort the array first, then fix one element (`nums[i]`) and run opposite-direction two pointers over the remainder to find pairs summing to `-nums[i]` — reducing three-sum to "two-sum on sorted data" run once per fixed element. Skip duplicate values both for the fixed element and for `left`/`right` after a match, to avoid pushing the same triplet more than once.

## Solution

```js
function threeSum(nums) {
  nums.sort((a, b) => a - b);
  const result = [];

  for (let i = 0; i < nums.length - 2; i++) {
    if (nums[i] > 0) break;                          // smallest remaining can't sum to 0 anymore
    if (i > 0 && nums[i] === nums[i - 1]) continue;   // skip duplicate "fixed" elements

    let left = i + 1, right = nums.length - 1;
    while (left < right) {
      const sum = nums[i] + nums[left] + nums[right];
      if (sum === 0) {
        result.push([nums[i], nums[left], nums[right]]);
        while (left < right && nums[left] === nums[left + 1]) left++; // skip duplicate lefts
        while (left < right && nums[right] === nums[right - 1]) right--; // skip duplicate rights
        left++;
        right--;
      } else if (sum < 0) {
        left++;
      } else {
        right--;
      }
    }
  }
  return result;
}

module.exports = { threeSum };

// --- verification ---
console.log(threeSum([-1, 0, 1, 2, -1, -4])); // [[-1,-1,2],[-1,0,1]]
console.log(threeSum([0, 1, 1]));               // []
console.log(threeSum([0, 0, 0]));               // [[0,0,0]]
```

## Complexity

- **Time:** O(n²) — sorting is O(n log n); the outer loop runs O(n) times, and each fixed element runs an O(n) two-pointer scan, dominating the total.
- **Space:** O(n) or O(log n) depending on the sort algorithm's internal space usage, excluding the output; the two-pointer scan itself uses O(1) extra space.
