# Problem: Container With Most Water

## Problem Statement

Given `n` non-negative integers `height` where each represents a vertical line at position `i`, find two lines that, together with the x-axis, form a container that holds the most water. Return the maximum amount of water it can store. (The container's capacity is `width * min(height of the two lines)` — water can't rise above the shorter line.)

## Constraints

- `2 <= height.length <= 10^5`
- `0 <= height[i] <= 10^4`

## Examples

```
Input: height = [1,8,6,2,5,4,8,3,7]
Output: 49

Input: height = [1,1]
Output: 1
```

## Approach

Brute force checks every pair of lines — O(n²). Two pointers starting at both ends does better: the area for any pair is capped by the *shorter* of the two lines, so for a fixed shorter line, moving the *other* (taller) pointer inward can never increase the area (width shrinks, and the height cap is still the same shorter line). This means it's always safe to discard the shorter line and move that pointer inward — it can never be part of a better solution than what's already been considered — while keeping the taller line in place gives it a chance to pair with an even taller line later.

## Solution

```js
function maxArea(height) {
  let left = 0, right = height.length - 1;
  let best = 0;

  while (left < right) {
    const width = right - left;
    const area = Math.min(height[left], height[right]) * width;
    best = Math.max(best, area);

    if (height[left] < height[right]) {
      left++;   // left is the limiting (shorter) line — move it, it can't do better here
    } else {
      right--;  // right is the limiting line (or they're tied) — move it instead
    }
  }
  return best;
}

module.exports = { maxArea };

// --- verification ---
console.log(maxArea([1, 8, 6, 2, 5, 4, 8, 3, 7])); // 49
console.log(maxArea([1, 1]));                       // 1
```

## Complexity

- **Time:** O(n) — each pointer moves at most n times total, so at most 2n steps overall, compared to O(n²) for checking every pair.
- **Space:** O(1) — only two pointers and a running best, no auxiliary data structure.
