# Problem: Product of Array Except Self

## Problem Statement

Given an integer array `nums`, return an array `answer` where `answer[i]` is the product of all elements of `nums` except `nums[i]`. Solve it in O(n) time without using division, and (as a follow-up) using O(1) extra space excluding the output array.

## Constraints

- `2 <= nums.length <= 10^5`
- `-30 <= nums[i] <= 30`
- The product of any prefix or suffix is guaranteed to fit in a 32-bit integer.

## Examples

```
Input: nums = [1,2,3,4]
Output: [24,12,8,6]

Input: nums = [-1,1,0,-3,3]
Output: [0,0,9,0,0]
```

## Approach

This is a **prefix product** (the same idea as prefix sum, with multiplication instead of addition): `answer[i]` needs the product of everything to its left times the product of everything to its right. Compute a prefix-product pass left-to-right, then a suffix-product pass right-to-left, combining them — and do the second pass in place, using a single rolling variable instead of a separate suffix array, to hit the O(1)-extra-space follow-up.

## Solution

```js
function productExceptSelf(nums) {
  const n = nums.length;
  const answer = new Array(n).fill(1);

  // Pass 1: answer[i] = product of everything BEFORE i
  let prefix = 1;
  for (let i = 0; i < n; i++) {
    answer[i] = prefix;
    prefix *= nums[i];
  }

  // Pass 2: multiply in the product of everything AFTER i, using a rolling suffix product
  let suffix = 1;
  for (let i = n - 1; i >= 0; i--) {
    answer[i] *= suffix;
    suffix *= nums[i];
  }

  return answer;
}

module.exports = { productExceptSelf };

// --- verification ---
console.log(productExceptSelf([1, 2, 3, 4]));       // [24, 12, 8, 6]
console.log(productExceptSelf([-1, 1, 0, -3, 3]));  // [0, 0, 9, 0, 0]
```

## Complexity

- **Time:** O(n) — two linear passes over the array.
- **Space:** O(1) extra space (excluding the required `answer` output array) — only two rolling scalar variables (`prefix`, `suffix`) are used, rather than separate prefix and suffix arrays.
