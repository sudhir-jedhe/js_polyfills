# Problem: Maximum Sum Subarray of Size K

## Problem Statement

Given an array of integers `nums` and an integer `k`, find the maximum sum of any contiguous subarray of exactly size `k`.

## Constraints

- `1 <= k <= nums.length <= 10^5`
- `-10^4 <= nums[i] <= 10^4`

## Examples

```
Input: nums = [2,1,5,1,3,2], k = 3
Output: 9   ([5,1,3])

Input: nums = [2,3,4,1,5], k = 2
Output: 7   ([3,4])
```

## Approach

Classic fixed-size sliding window. Build the sum of the first window once, then slide one position at a time, updating the sum with a single addition (element entering) and a single subtraction (element leaving) instead of re-summing the whole window from scratch each time.

## Solution

```js
function maxSumSubarrayOfSizeK(nums, k) {
  let windowSum = 0;
  for (let i = 0; i < k; i++) windowSum += nums[i];

  let maxSum = windowSum;
  for (let i = k; i < nums.length; i++) {
    windowSum += nums[i] - nums[i - k]; // slide: add entering, remove leaving
    maxSum = Math.max(maxSum, windowSum);
  }
  return maxSum;
}

module.exports = { maxSumSubarrayOfSizeK };

// --- verification ---
console.log(maxSumSubarrayOfSizeK([2, 1, 5, 1, 3, 2], 3)); // 9
console.log(maxSumSubarrayOfSizeK([2, 3, 4, 1, 5], 2));     // 7
```

## Complexity

- **Time:** O(n) — building the first window is O(k), and each of the remaining `n - k` slides does O(1) work, for O(n) total (as opposed to the O(n · k) naive approach that resums every window).
- **Space:** O(1) — only a running sum and max are tracked, no auxiliary array.
