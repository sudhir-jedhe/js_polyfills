# Two Pointers, Sliding Window & Prefix Sum

Three closely related array/string techniques that each replace an O(n²) brute-force scan with an O(n) or O(n log n) pass. Two pointers walks two index variables through a sequence (converging from both ends, or scanning in the same direction at different speeds) to find pairs or partition data in place. Sliding window maintains a contiguous "view" into an array or string — fixed or variable length — updating an aggregate incrementally as the view slides instead of recomputing it from scratch. Prefix sum precomputes running totals so that any range sum, or any question about subarrays matching a sum condition, can be answered in O(1) per query after one O(n) preprocessing pass. These three show up constantly in interviews because a large share of "medium" array/string problems are really a single one of these patterns wearing a different costume — the actual skill being tested is recognizing which one a given problem needs, especially since sliding window quietly produces *wrong* answers (not errors) once negative numbers enter the picture.

## Folder structure

- **`theory/`** — two-pointer technique (opposite vs. same-direction), fixed-size sliding window, variable-size sliding window with the expand/shrink template made explicit, prefix sum fundamentals, prefix sum combined with a hashmap for subarray-sum problems, and a decision framework for choosing between all three.
- **`snippets/`** — 7 focused, runnable code examples: sorted two-sum, in-place duplicate removal, fixed-size window max sum, variable-size window template, a basic prefix sum array, prefix-sum + hashmap subarray counting, and three-sum via sort-then-two-pointers.
- **`output-based/`** — 7 "trace through this" questions covering container-with-most-water pointer movement, a longest-substring window trace, a prefix-sum off-by-one bug, a subarray-sum-equals-k hashmap trace, the sliding-window-with-negative-numbers pitfall (with a fully worked wrong-answer trace), a three-sum duplicate-skip trace, and a fixed-window incremental-slide trace.
- **`scenarios/`** — 5 real-world engineering scenarios: anomalous spending detection (fixed window), pair-finding in a sorted sensor log (two pointers), repeated dashboard range queries (prefix sum), shortest suspicious-traffic burst (variable window), and a clarifying-questions decision guide for vague "subarray" prompts.
- **`interview-qa/`** — 12 Q&A pairs across 3 themed files: two pointers, sliding window, and prefix sum.
- **`problems/`** — 7 hands-on coding challenges: container with most water, longest substring without repeating characters, minimum window substring, subarray sum equals K, three sum, maximum sum subarray of size K, and product of array except self — each with a full JavaScript solution and Big-O analysis.
- **`assets/`** — placeholder for diagrams (pointer movement, window expand/shrink animations, prefix sum arrays).

## What's covered

- Opposite-direction (converging) vs. same-direction (fast/slow) two pointers, and why the opposite-direction variant needs sorted input
- Fixed-size sliding window's incremental "add entering, remove leaving" update, replacing O(n·k) resummation with O(n)
- The variable-size expand/shrink template, including the "record inside vs. after the shrink loop" distinction for shortest- vs. longest-window problems
- Prefix sum arrays for O(1) range-sum queries, and the offset-by-one convention that avoids special-casing range start at index 0
- Prefix sum + hashmap for counting/finding subarrays matching a target sum — the correct tool once negative numbers rule out sliding window
- A concrete decision framework (with a worked, numerically-verified failure case) for choosing the right technique instead of guessing
- Hands-on: container with most water, longest substring without repeating characters, minimum window substring, subarray sum equals K, three sum, max sum subarray of size K, and product of array except self
