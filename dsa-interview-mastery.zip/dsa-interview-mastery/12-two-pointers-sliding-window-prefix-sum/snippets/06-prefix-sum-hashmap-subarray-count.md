# Prefix Sum + HashMap — Count Subarrays Summing to k

```js
function subarraySum(nums, k) {
  const seen = new Map();
  seen.set(0, 1); // empty prefix, handles subarrays starting at index 0

  let runningSum = 0, count = 0;
  for (const num of nums) {
    runningSum += num;
    count += seen.get(runningSum - k) || 0;
    seen.set(runningSum, (seen.get(runningSum) || 0) + 1);
  }
  return count;
}

console.log(subarraySum([1, 1, 1], 2));       // 2
console.log(subarraySum([1, -1, 0], 0));      // 3 -> [1,-1], [0], [1,-1,0]
```

Works correctly with negative numbers, unlike sliding window — the O(n) single-pass hashmap lookup replaces an O(n²) nested-loop search for matching ranges.
