# Two Sum on a Sorted Array — Opposite-Direction Pointers

```js
function twoSumSorted(nums, target) {
  let left = 0, right = nums.length - 1;
  while (left < right) {
    const sum = nums[left] + nums[right];
    if (sum === target) return [left, right];
    if (sum < target) left++;
    else right--;
  }
  return [-1, -1];
}

console.log(twoSumSorted([1, 3, 4, 6, 8, 10], 10)); // [2, 3] -> nums[2]+nums[3] = 4+6=10
console.log(twoSumSorted([2, 7, 11, 15], 9));         // [0, 1]
```

O(n) time, O(1) space — each pointer moves at most n times total, for at most 2n total steps, compared to O(n²) for checking every pair.
