# Prefix Sum Array — O(1) Range Sum Queries

```js
function buildPrefixSum(nums) {
  const prefix = new Array(nums.length + 1).fill(0);
  for (let i = 0; i < nums.length; i++) {
    prefix[i + 1] = prefix[i] + nums[i];
  }
  return prefix;
}

function rangeSum(prefix, left, right) { // inclusive range [left, right]
  return prefix[right + 1] - prefix[left];
}

const nums = [2, 4, -1, 3, 5];
const prefix = buildPrefixSum(nums);
console.log(rangeSum(prefix, 1, 3)); // 6  -> 4 + -1 + 3
console.log(rangeSum(prefix, 0, 4)); // 13 -> whole array
```

O(n) to build once, then O(1) per query — ideal when many range-sum queries hit the same underlying array.
