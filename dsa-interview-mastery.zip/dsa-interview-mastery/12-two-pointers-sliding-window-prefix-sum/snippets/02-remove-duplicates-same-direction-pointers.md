# Remove Duplicates In Place — Same-Direction Pointers

```js
function removeDuplicates(nums) { // nums is sorted
  if (nums.length === 0) return 0;
  let slow = 0;
  for (let fast = 1; fast < nums.length; fast++) {
    if (nums[fast] !== nums[slow]) {
      slow++;
      nums[slow] = nums[fast];
    }
  }
  return slow + 1;
}

const arr = [1, 1, 2, 2, 2, 3, 4, 4];
const len = removeDuplicates(arr);
console.log(len, arr.slice(0, len)); // 4 [1, 2, 3, 4]
```

`slow` only advances (and writes) when `fast` finds a genuinely new value — the array is compacted in place, O(n) time, O(1) extra space.
