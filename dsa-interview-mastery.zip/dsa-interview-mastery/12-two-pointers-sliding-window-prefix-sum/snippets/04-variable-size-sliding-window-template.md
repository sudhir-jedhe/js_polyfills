# Variable-Size Sliding Window — Longest Subarray with Sum ≤ Limit

```js
function longestSubarraySumAtMost(nums, limit) {
  let left = 0, sum = 0, maxLen = 0;

  for (let right = 0; right < nums.length; right++) {
    sum += nums[right];                    // expand

    while (sum > limit) {                   // shrink while invalid
      sum -= nums[left];
      left++;
    }

    maxLen = Math.max(maxLen, right - left + 1); // record — window is valid here
  }
  return maxLen;
}

console.log(longestSubarraySumAtMost([2, 1, 1, 3, 2, 1], 5)); // 3 -> e.g. [2,1,1] or [1,1,3], each sums to <= 5
```

This only works because all values are non-negative — shrinking the window from the left is guaranteed to reduce `sum`. With negative numbers present, reach for prefix-sum + hashmap instead (see `../theory/05-prefix-sum-with-hashmap-for-subarray-sum.md`).
