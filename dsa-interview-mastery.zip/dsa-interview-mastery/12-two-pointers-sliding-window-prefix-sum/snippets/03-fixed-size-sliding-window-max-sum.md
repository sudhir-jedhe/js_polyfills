# Fixed-Size Sliding Window — Maximum Sum of Any Window of Size k

```js
function maxSumWindow(nums, k) {
  let windowSum = 0;
  for (let i = 0; i < k; i++) windowSum += nums[i];

  let maxSum = windowSum;
  for (let i = k; i < nums.length; i++) {
    windowSum += nums[i] - nums[i - k]; // slide: add entering element, remove leaving element
    maxSum = Math.max(maxSum, windowSum);
  }
  return maxSum;
}

console.log(maxSumWindow([2, 1, 5, 1, 3, 2], 3)); // 9 -> window [5,1,3]
```

O(n) time — each element is added once (entering) and subtracted once (leaving), instead of re-summing every window from scratch.
