# What Does This Output? — Longest Substring Without Repeating Characters

```js
function lengthOfLongestSubstring(s) {
  const seen = new Map();
  let left = 0, maxLen = 0;
  for (let right = 0; right < s.length; right++) {
    const c = s[right];
    if (seen.has(c) && seen.get(c) >= left) {
      left = seen.get(c) + 1;
    }
    seen.set(c, right);
    maxLen = Math.max(maxLen, right - left + 1);
  }
  return maxLen;
}
console.log(lengthOfLongestSubstring('abcabcbb'));
```

**Answer:** `3`

**Why:** trace it — `right=0('a')`: not seen, `seen={a:0}`, window `[0,0]`, `maxLen=1`. `right=1('b')`: `seen={a:0,b:1}`, window `[0,1]`, `maxLen=2`. `right=2('c')`: window `[0,2]`, `maxLen=3`. `right=3('a')`: `'a'` was last seen at index 0, which is `>= left(0)`, so `left` jumps to `1`; window is now `[1,3]` = `"bca"`, `maxLen` stays `3`. `right=4('b')`: `'b'` seen at index 1, `>= left(1)`, so `left` jumps to `2`; window `[2,4]` = `"cab"`, `maxLen` stays `3`. `right=5('c')`: similarly `left` jumps to `3`; window `[3,5]` = `"abc"`, still length 3. `right=6('b')`: `'b'` last seen at index 4, which is `>= left(3)`, so `left` jumps to `5`; window `[5,6]` = `"cb"`. `right=7('b')`: `'b'` seen at 6, `left` jumps to `7`; window `[7,7]` = `"b"`. The longest window ever recorded across the whole scan is 3 (`"abc"`), so that's the final answer — even though the string is 8 characters long and contains no window of length 4 or more without a repeat.
