# What Does This Output? — The Prefix Sum Off-by-One Bug

```js
function rangeSum(nums, left, right) {
  const prefix = [0];
  for (const n of nums) prefix.push(prefix[prefix.length - 1] + n);
  return prefix[right] - prefix[left]; // BUG
}
console.log(rangeSum([1, 2, 3, 4, 5], 1, 3)); // intent: sum of nums[1..3] = 2+3+4 = 9
```

**Answer:** `5` (wrong — the correct answer is `9`)

**Why:** `prefix` is built as `[0, 1, 3, 6, 10, 15]`, where `prefix[i]` is the sum of `nums[0..i-1]` (everything *before* index `i`). The correct formula for an inclusive range `[left, right]` is `prefix[right + 1] - prefix[left]` — because `prefix[right + 1]` includes everything through index `right`, and subtracting `prefix[left]` removes everything before `left`, leaving exactly `nums[left..right]`. The buggy version uses `prefix[right] - prefix[left]` (missing the `+1`), which computes `prefix[3] - prefix[1] = 6 - 1 = 5` — the sum of `nums[1..2]` (`2 + 3 = 5`), silently **excluding** `nums[right]` (`nums[3] = 4`) entirely. This off-by-one is the single most common prefix-sum bug: always double-check whether your `prefix` array is 0-indexed-with-a-leading-zero (as here) or aligned 1:1 with the original array, and make sure the range formula matches that convention consistently.
