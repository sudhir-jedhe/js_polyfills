# What Does This Output? — Three Sum Duplicate-Skipping Trace

```js
function threeSum(nums) {
  nums.sort((a, b) => a - b);
  const result = [];
  for (let i = 0; i < nums.length - 2; i++) {
    if (i > 0 && nums[i] === nums[i - 1]) continue;
    let left = i + 1, right = nums.length - 1;
    while (left < right) {
      const sum = nums[i] + nums[left] + nums[right];
      if (sum === 0) {
        result.push([nums[i], nums[left], nums[right]]);
        while (left < right && nums[left] === nums[left + 1]) left++;
        while (left < right && nums[right] === nums[right - 1]) right--;
        left++; right--;
      } else if (sum < 0) left++;
      else right--;
    }
  }
  return result;
}
console.log(threeSum([-2, 0, 0, 2, 2]));
```

**Answer:** `[[-2, 0, 2]]`

**Why:** sorted input is `[-2, 0, 0, 2, 2]`. At `i=0` (`nums[i]=-2`): `left=1(0), right=4(2)`, `sum = -2+0+2 = 0` — a match, push `[-2, 0, 2]`. The two inner `while` loops then skip past duplicate values adjacent to `left` and `right` (`nums[1]===nums[2]` both `0`, so `left` advances to `2`; `nums[4]===nums[3]` both `2`, so `right` retreats to `3`), then `left++`/`right--` moves them past each other (`left=3, right=2`), ending the inner loop for `i=0`. At `i=1` (`nums[1]=0`): not equal to `nums[0]=-2`, so it proceeds — but every combination it finds (`0+0+2=2`, then shrinking `right`) never re-hits zero without repeating the same triple already found, so no new result is pushed. At `i=2` (`nums[2]=0`): `nums[2] === nums[1]` (`0 === 0`), so the outer duplicate-skip fires and this iteration is skipped entirely via `continue` — without it, the algorithm would re-discover `[0, ...]` combinations and produce duplicate triples in the output. The loop ends at `i=3` since `i < nums.length - 2` (`3 < 3`) is false. Both duplicate-skip lines (`i > 0 && nums[i] === nums[i-1]` on the outer loop, and the two inner `while` loops around `left`/`right`) are what keep three-sum's output a set of *distinct* triples despite the input containing repeated values.
