# What Does This Output? — Subarray Sum Equals K, Step by Step

```js
function subarraySum(nums, k) {
  const seen = new Map([[0, 1]]);
  let runningSum = 0, count = 0;
  for (const num of nums) {
    runningSum += num;
    count += seen.get(runningSum - k) || 0;
    seen.set(runningSum, (seen.get(runningSum) || 0) + 1);
  }
  return count;
}
console.log(subarraySum([1, 2, 3], 3));
```

**Answer:** `2`

**Why:** trace the map state — start: `seen = {0: 1}`, `runningSum = 0`, `count = 0`. Process `1`: `runningSum = 1`; need `1 - 3 = -2`, not in `seen`, `count` unchanged; `seen = {0:1, 1:1}`. Process `2`: `runningSum = 3`; need `3 - 3 = 0`, `seen.get(0) = 1`, so `count += 1` → `count = 1` (this is the subarray `[1, 2]`, which sums to `3`); `seen = {0:1, 1:1, 3:1}`. Process `3`: `runningSum = 6`; need `6 - 3 = 3`, `seen.get(3) = 1`, so `count += 1` → `count = 2` (this is the subarray `[3]` alone, ending at the last index, whose sum minus a running sum of `3` back at index 1 gives exactly this single-element subarray). Final `count = 2`, matching the two subarrays `[1,2]` and `[3]` that each sum to `3`. Note that `[1,2,3]` itself sums to `6`, not `3`, so it's correctly not counted.
