# What Does This Output? — Sliding Window Breaks With Negative Numbers

```js
function longestSubarraySumAtMost(nums, limit) {
  let left = 0, sum = 0, maxLen = 0;
  for (let right = 0; right < nums.length; right++) {
    sum += nums[right];
    while (sum > limit) {
      sum -= nums[left];
      left++;
    }
    maxLen = Math.max(maxLen, right - left + 1);
  }
  return maxLen;
}
console.log(longestSubarraySumAtMost([1, -1, 5, -2, 3], 3));
```

**Answer:** `2` — and this is **wrong**. The true longest subarray with sum ≤ 3 is `[1, -1, 5, -2]` (sum = 3), which has length 4.

**Why:** trace it — `right=0`: `sum=1`, `maxLen=1`. `right=1`: `sum=0`, `maxLen=2`. `right=2`: `sum=5 > 3`, shrink: subtract `nums[0]=1` → `sum=4`, still `>3`; subtract `nums[1]=-1` → `sum=5` (subtracting a *negative* number **increased** the sum!), still `>3`; subtract `nums[2]=5` → `sum=0`, `left=3`. Now `left(3) > right(2)`, an empty/invalid window — `maxLen` stays `2`. `right=3`: `sum=0+(-2)=-2`, window `[3,3]`, length 1. `right=4`: `sum=-2+3=1`, window `[3,4]`, length 2. Final `maxLen=2`.

The bug is structural, not a typo: the greedy "shrink from the left while over the limit" logic assumes that removing elements from the left always *reduces* the sum, and that once `left` has moved forward it never needs to move back. Both assumptions fail with negative numbers — subtracting a negative number increases the sum (as seen at `right=2`), and the true optimal window `[0,3]` was destroyed by an over-eager shrink that can never be undone, since `left` only moves forward. This is exactly why sliding window requires a monotonic property (all non-negative values) to be sound — see `../theory/06-choosing-between-two-pointers-sliding-window-prefix-sum.md`. With negative numbers, prefix-sum + hashmap is the correct tool instead.
