# What Does This Output? — Container With Most Water Pointer Trace

```js
function maxArea(height) {
  let left = 0, right = height.length - 1, best = 0;
  while (left < right) {
    const area = Math.min(height[left], height[right]) * (right - left);
    best = Math.max(best, area);
    if (height[left] < height[right]) left++;
    else right--;
  }
  return best;
}
console.log(maxArea([1, 8, 6, 2, 5, 4, 8, 3, 7]));
```

**Answer:** `49`

**Why:** trace the pointers — `left=0(1), right=8(7)`: area `= 1 * 8 = 8`; since `height[left] < height[right]`, move `left++`. `left=1(8), right=8(7)`: area `= 7 * 7 = 49` (the eventual max); since `height[right] < height[left]`, move `right--`. From here the pointers keep converging (`right` decrements through `3, 4, 6, 6...`), and every subsequent area is smaller because the width (`right - left`) keeps shrinking faster than the limiting height grows. The greedy rule — always move the pointer at the *shorter* line — is provably safe: keeping the shorter line in place could never produce a larger area than swapping it for *any* other line, since the shorter line is what caps the area regardless of what's on the other side. That's why it's safe to permanently discard it and never reconsider it, letting the whole scan finish in O(n) instead of checking every pair in O(n²).
