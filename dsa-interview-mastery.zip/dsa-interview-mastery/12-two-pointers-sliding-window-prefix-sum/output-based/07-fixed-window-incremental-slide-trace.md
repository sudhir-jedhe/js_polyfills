# What Does This Output? — Fixed Window Incremental Sum Trace

```js
function maxSumWindow(nums, k) {
  let windowSum = 0;
  for (let i = 0; i < k; i++) windowSum += nums[i];
  let maxSum = windowSum;
  console.log('initial window sum:', windowSum);
  for (let i = k; i < nums.length; i++) {
    windowSum += nums[i] - nums[i - k];
    console.log(`slide to i=${i}: windowSum=${windowSum}`);
    maxSum = Math.max(maxSum, windowSum);
  }
  return maxSum;
}
console.log('result:', maxSumWindow([1, 3, -1, -3, 5, 3, 6, 7], 3));
```

**Answer:**
```
initial window sum: 3
slide to i=3: windowSum=-1
slide to i=4: windowSum=1
slide to i=5: windowSum=5
slide to i=6: windowSum=14
slide to i=7: windowSum=16
result: 16
```

**Why:** the initial window covers indices `[0,1,2]` = `[1,3,-1]`, summing to `3`. Each subsequent slide does exactly one addition (the entering element `nums[i]`) and one subtraction (the leaving element `nums[i-k]`) — at `i=3`: `windowSum = 3 + nums[3] - nums[0] = 3 + (-3) - 1 = -1`, covering `[3,-1,-3]`. This continues through `i=7`, where the window `[3,6,7]` (indices 5-7) reaches the maximum sum of `16`. Note that `windowSum` is never recomputed from scratch after the first window — every step does exactly 2 arithmetic operations regardless of `k`, which is what keeps this O(n) instead of O(n·k).
