# Topological Sort

A **topological sort** of a directed acyclic graph (DAG) is a linear ordering of all vertices such that for every directed edge `u -> v`, `u` appears **before** `v` in the ordering. It only exists for DAGs — if the graph has a cycle, no valid linear ordering can satisfy every edge constraint (a classic real-world instance: course prerequisites, where a cycle means the courses are impossible to schedule at all).

There are two standard algorithms; both run in `O(V + E)` and either is an acceptable interview answer, but they build the ordering in fundamentally different ways.

## Kahn's Algorithm (BFS-based, using in-degree)

Repeatedly remove vertices that have **zero incoming edges** (no unsatisfied prerequisites), and each time a vertex is removed, decrement the in-degree of everything it points to — some of those may now reach zero in-degree themselves and become eligible next.

```js
function topologicalSortKahn(graph, vertices) {
  const inDegree = new Map(vertices.map(v => [v, 0]));
  for (const v of vertices) {
    for (const neighbor of graph.get(v)) {
      inDegree.set(neighbor, inDegree.get(neighbor) + 1);
    }
  }

  const queue = vertices.filter(v => inDegree.get(v) === 0);
  const order = [];

  while (queue.length) {
    const node = queue.shift();
    order.push(node);
    for (const neighbor of graph.get(node)) {
      inDegree.set(neighbor, inDegree.get(neighbor) - 1);
      if (inDegree.get(neighbor) === 0) queue.push(neighbor);
    }
  }

  // if not all vertices got ordered, the graph has a cycle
  return order.length === vertices.length ? order : null;
}
```

Kahn's algorithm gives cycle detection **for free**: if the graph has a cycle, the vertices in that cycle never reach in-degree zero (each depends on another vertex within the same cycle), so they're never added to `order` — checking `order.length === vertices.length` at the end tells you unambiguously whether a valid topological order exists.

## DFS-based (postorder + reverse)

Run DFS, and every time a node finishes (all its descendants are fully processed — the same "black" state from cycle detection), push it onto a stack. Once DFS completes for all vertices, popping the stack (equivalently, reversing the finish order) gives a valid topological order.

```js
function topologicalSortDFS(graph, vertices) {
  const visited = new Set();
  const stack = [];

  function dfs(node) {
    visited.add(node);
    for (const neighbor of graph.get(node)) {
      if (!visited.has(neighbor)) dfs(neighbor);
    }
    stack.push(node); // push on "finish", i.e. postorder
  }

  for (const v of vertices) {
    if (!visited.has(v)) dfs(v);
  }

  return stack.reverse();
}
```

The intuition: a node is only pushed onto the stack once **everything reachable from it** has already finished and been pushed — so by construction, everything that must come after a node in the ordering is already below it on the stack, meaning reversing the stack puts "comes first" nodes at the front. Note this version doesn't detect cycles on its own — pair it with the 3-color (white/gray/black) cycle check from the cycle-detection theory file if the input isn't guaranteed to be a DAG.

## Comparison

| | Kahn's (BFS) | DFS-based |
|---|---|---|
| Mechanism | Repeatedly remove zero-in-degree nodes | Postorder finish times, reversed |
| Cycle detection | Built-in (leftover nodes = cycle) | Needs separate 3-color check |
| Data structure | Queue + in-degree counts | Recursion stack + explicit output stack |
| Time / Space | `O(V + E)` / `O(V)` | `O(V + E)` / `O(V)` |

## Note on non-uniqueness

A topological order is generally **not unique** — any DAG with more than one "no dependency" starting node, or branches that don't depend on each other, has multiple valid orderings. This is worth stating explicitly in an interview: if your output differs from an expected answer, both can still be correct as long as every directed edge constraint (`u` before `v`) is respected.
