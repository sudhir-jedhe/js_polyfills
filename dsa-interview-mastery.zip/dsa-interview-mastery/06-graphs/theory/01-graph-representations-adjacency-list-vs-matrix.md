# Graph Representations: Adjacency List vs. Adjacency Matrix

A graph is `G = (V, E)` — a set of vertices and a set of edges connecting pairs of them. Before any traversal or algorithm, you need to decide how to actually store that structure in memory. The two standard choices trade space for edge-lookup speed in opposite directions.

## Adjacency List

Each vertex maps to a list of its neighbors. In JS, typically a `Map` (or plain object) from vertex to an array (or `Set`) of adjacent vertices.

```js
// Undirected graph:  A - B, A - C, B - C, C - D
const graph = new Map([
  ['A', ['B', 'C']],
  ['B', ['A', 'C']],
  ['C', ['A', 'B', 'D']],
  ['D', ['C']],
]);
```

- **Space:** `O(V + E)` — only stores edges that actually exist.
- **Check if edge (u, v) exists:** `O(degree(u))` — must scan `u`'s neighbor list (or `O(1)` if using a `Set` instead of an array).
- **Iterate all neighbors of a vertex:** `O(degree(u))` — exactly the list you'd walk anyway, no wasted work.
- **Best for:** sparse graphs (`E` much smaller than `V²`), which is the overwhelming majority of real-world and interview graphs (social networks, road maps, dependency graphs).

## Adjacency Matrix

A `V × V` 2D array/grid where `matrix[i][j]` is truthy (or holds a weight) if an edge exists from `i` to `j`.

```js
// Same graph, indices A=0, B=1, C=2, D=3
const matrix = [
  [0, 1, 1, 0], // A
  [1, 0, 1, 0], // B
  [1, 1, 0, 1], // C
  [0, 0, 1, 0], // D
];
```

- **Space:** `O(V²)` — allocated regardless of how many edges actually exist.
- **Check if edge (u, v) exists:** `O(1)` — direct index into the grid.
- **Iterate all neighbors of a vertex:** `O(V)` — must scan the entire row even if the vertex only has 1 real neighbor.
- **Best for:** dense graphs (`E` close to `V²`), or when "does an edge exist between these two specific vertices" is the dominant, frequently-repeated query.

## Comparison table

| | Adjacency List | Adjacency Matrix |
|---|---|---|
| Space | `O(V + E)` | `O(V²)` |
| Add edge | `O(1)` | `O(1)` |
| Check edge (u,v) exists | `O(degree(u))`, or `O(1)` with a `Set` | `O(1)` |
| Iterate neighbors of u | `O(degree(u))` | `O(V)` |
| Good for | Sparse graphs (most real-world graphs) | Dense graphs, frequent edge-existence checks |
| Typical interview default | **Yes — almost always this** | Rare, unless explicitly dense or matrix-shaped input |

## Practical note

Most interview problems either hand you an adjacency list directly, or hand you something matrix-shaped (like a grid of `0`s and `1`s for "number of islands") where the matrix representation *is* the input, not a deliberate choice. When you're building the representation yourself from an edge list, default to an adjacency list (`Map<vertex, Set<neighbor>>` in JS) unless you have a specific reason to expect a dense graph.
