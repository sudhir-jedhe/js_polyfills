# Connected Components

A **connected component** in an undirected graph is a maximal set of vertices such that every vertex in the set is reachable from every other vertex in that same set, via some path (not necessarily direct). A graph can consist of multiple, entirely separate components with no edges between them at all — this is the "disconnected graph" case, and it's the reason traversal code needs an **outer loop over all vertices**, not just a single BFS/DFS call from one arbitrary starting vertex.

```
Component 1: A - B - C        Component 2: D - E        Component 3: F (isolated)
```

## Counting connected components

Run BFS or DFS from every not-yet-visited vertex; each such run discovers exactly one full component, and the number of times you have to *start* a fresh traversal (because the current vertex wasn't already visited by a previous run) is the number of components.

```js
function countConnectedComponents(graph, vertices) {
  const visited = new Set();
  let count = 0;

  function dfs(node) {
    visited.add(node);
    for (const neighbor of graph.get(node)) {
      if (!visited.has(neighbor)) dfs(neighbor);
    }
  }

  for (const v of vertices) {
    if (!visited.has(v)) {
      count++;
      dfs(v);
    }
  }

  return count;
}
```

This same "outer loop over all vertices, skip if already visited" pattern is exactly what correct cycle detection and topological sort also need — any graph algorithm that starts a traversal from "a" vertex has to account for the possibility that not every vertex is reachable from that one starting point.

## Union-Find (Disjoint Set Union) as an alternative

For problems that specifically ask about connectivity — "are these two nodes in the same component," "how many components after adding these edges one at a time," "will adding this edge create a cycle" — a **Union-Find** (Disjoint Set Union) structure is often a cleaner and more efficient fit than repeated BFS/DFS, especially when edges are added incrementally rather than all being known upfront.

```js
class UnionFind {
  constructor(n) {
    this.parent = Array.from({ length: n }, (_, i) => i);
    this.rank = new Array(n).fill(0);
  }
  find(x) {
    if (this.parent[x] !== x) this.parent[x] = this.find(this.parent[x]); // path compression
    return this.parent[x];
  }
  union(x, y) {
    const rootX = this.find(x), rootY = this.find(y);
    if (rootX === rootY) return false; // already connected -> this edge would create a cycle
    if (this.rank[rootX] < this.rank[rootY]) [x, y] = [y, x]; // union by rank
    this.parent[this.find(y)] = this.find(x);
    if (this.rank[rootX] === this.rank[rootY]) this.rank[rootX]++;
    return true;
  }
}
```

With path compression and union by rank, `find`/`union` run in amortized `O(α(n))` — the inverse Ackermann function, effectively constant for any input size that could realistically occur.

## When to use BFS/DFS vs. Union-Find for connectivity

| | BFS/DFS component counting | Union-Find |
|---|---|---|
| All edges known upfront | Natural fit | Also works, slightly more setup |
| Edges arriving incrementally / online queries | Requires re-traversal each time — expensive | Natural fit — `union` incorporates new edges cheaply |
| "Would adding this edge create a cycle" | Would need a fresh traversal to check | `union` returns this for free (same root = cycle) |
| Typical complexity | `O(V + E)` per full pass | `O(E · α(V))` amortized total across all unions |
