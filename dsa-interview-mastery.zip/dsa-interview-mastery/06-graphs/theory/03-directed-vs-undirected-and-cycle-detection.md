# Directed vs. Undirected Graphs, and Cycle Detection

## Directed vs. undirected

- **Undirected graph:** an edge `(u, v)` means `u` and `v` are mutually connected — you can traverse in either direction. Represented by adding `v` to `u`'s list **and** `u` to `v`'s list.
- **Directed graph (digraph):** an edge `u -> v` is one-way — being able to reach `v` from `u` says nothing about reaching `u` from `v`. Represented by adding `v` to `u`'s list only.

```js
// Undirected: add both directions
function addUndirectedEdge(graph, u, v) {
  graph.get(u).push(v);
  graph.get(v).push(u);
}

// Directed: add one direction only
function addDirectedEdge(graph, u, v) {
  graph.get(u).push(v);
}
```

This distinction matters enormously for cycle detection — the two require genuinely different algorithms, and using the undirected approach on a directed graph (or vice versa) gives wrong answers.

## Cycle detection in an undirected graph

A plain `visited` set is almost enough, with one adjustment: when DFS-ing from a node, you'll immediately see the edge back to whichever node you just came **from** — that's not a cycle, it's just the edge you arrived on. So you must track the parent and ignore that one specific back-edge; any other already-visited neighbor found indicates a genuine cycle.

```js
function hasCycleUndirected(graph, vertices) {
  const visited = new Set();

  function dfs(node, parent) {
    visited.add(node);
    for (const neighbor of graph.get(node)) {
      if (!visited.has(neighbor)) {
        if (dfs(neighbor, node)) return true;
      } else if (neighbor !== parent) {
        return true; // reached an already-visited node that isn't where we came from -> cycle
      }
    }
    return false;
  }

  for (const v of vertices) {
    if (!visited.has(v) && dfs(v, null)) return true; // handles disconnected components too
  }
  return false;
}
```

## Cycle detection in a directed graph

A plain `visited` set is **not enough** here — reaching an already-visited node via a different path doesn't necessarily mean a cycle (in a DAG, multiple paths can converge on the same node without any cycle existing). What actually indicates a cycle is reaching a node that is **currently on the active recursion path** (i.e., an ancestor in the current DFS branch, not just visited at some earlier point). This requires three states per node instead of two:

- **White (unvisited)** — not yet reached.
- **Gray (visiting)** — currently on the active DFS path (an ancestor of the node currently being processed).
- **Black (visited/done)** — fully processed, DFS has returned from it; safe to reach from anywhere else.

```js
function hasCycleDirected(graph, vertices) {
  const WHITE = 0, GRAY = 1, BLACK = 2;
  const state = new Map(vertices.map(v => [v, WHITE]));

  function dfs(node) {
    state.set(node, GRAY);
    for (const neighbor of graph.get(node)) {
      if (state.get(neighbor) === GRAY) return true;               // back-edge to an ancestor -> cycle
      if (state.get(neighbor) === WHITE && dfs(neighbor)) return true;
    }
    state.set(node, BLACK); // fully done, safe forever after
    return false;
  }

  for (const v of vertices) {
    if (state.get(v) === WHITE && dfs(v)) return true;
  }
  return false;
}
```

A `GRAY` node found again means the current path has looped back on itself — a genuine cycle. A `BLACK` node found again just means two different branches both happen to reach a common downstream node, which is completely normal in a DAG and not a cycle.

## Comparison

| | Undirected cycle detection | Directed cycle detection |
|---|---|---|
| States needed | 2 (visited / unvisited) | 3 (white / gray / black) |
| Extra bookkeeping | Track immediate parent, to ignore the trivial back-edge | Track "on current path" (gray), separate from "done" (black) |
| Why it differs | An edge always implies mutual reachability, so "already seen, not my parent" always means a cycle | Reachability isn't mutual — an already-visited node might just be a shared descendant of two different branches, not a cycle |
| Time | `O(V + E)` | `O(V + E)` |
