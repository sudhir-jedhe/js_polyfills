# Shortest Path: BFS (Unweighted) and Dijkstra's Algorithm (Weighted, Non-Negative)

Which shortest-path approach is correct depends entirely on whether the graph's edges have weights.

## Unweighted graphs — plain BFS

If every edge counts equally ("fewest hops" rather than "cheapest cost"), plain BFS already solves shortest path, because BFS explores in expanding rings of distance from the source — the **first** time any node is reached is guaranteed to be via the minimum number of edges.

```js
function shortestPathBFS(graph, start) {
  const dist = new Map([[start, 0]]);
  const queue = [start];
  while (queue.length) {
    const node = queue.shift();
    for (const neighbor of graph.get(node)) {
      if (!dist.has(neighbor)) {
        dist.set(neighbor, dist.get(node) + 1); // one more hop than the node that discovered it
        queue.push(neighbor);
      }
    }
  }
  return dist; // Map<vertex, minimum number of edges from start>
}
```

Runs in `O(V + E)` — no priority queue needed, because every edge has the same implicit "weight" of 1, so FIFO order already matches increasing distance order.

## Weighted graphs (non-negative weights) — Dijkstra's Algorithm

When edges have different costs, BFS's guarantee breaks — a path with more hops can still be cheaper than a path with fewer, more expensive hops. Dijkstra's algorithm generalizes the idea: instead of a plain FIFO queue, use a **min-priority queue** keyed on "current known shortest distance to this node," always expanding the closest not-yet-finalized node next (a greedy strategy: once a node is popped with its shortest distance, that distance is guaranteed final, because any other path to it would have to go through a node that's already farther away).

```js
// MinHeap assumed available — see the heaps topic for a from-scratch implementation
function dijkstra(graph, start) {
  // graph: Map<vertex, Array<[neighbor, weight]>>
  const dist = new Map();
  for (const v of graph.keys()) dist.set(v, Infinity);
  dist.set(start, 0);

  const pq = new MinHeap((a, b) => a.dist - b.dist);
  pq.push({ node: start, dist: 0 });

  while (!pq.isEmpty()) {
    const { node, dist: d } = pq.pop();
    if (d > dist.get(node)) continue; // stale entry — a shorter path was already found and processed

    for (const [neighbor, weight] of graph.get(node)) {
      const newDist = d + weight;
      if (newDist < dist.get(neighbor)) {
        dist.set(neighbor, newDist);
        pq.push({ node: neighbor, dist: newDist });
      }
    }
  }

  return dist; // Map<vertex, shortest weighted distance from start>
}
```

### Why Dijkstra requires non-negative weights

The greedy "once popped, distance is final" guarantee relies on the fact that adding more edges can only ever *increase* a path's total distance, never decrease it — so no unexplored, farther-away node could ever provide a shortcut back to something already finalized. A negative edge breaks this: a path that looked longer so far could suddenly become shorter after crossing a negative edge, and Dijkstra has no mechanism to revisit an already-finalized node to account for that. Graphs with negative weights (but no negative cycles) require **Bellman-Ford** instead, which is deliberately less greedy (it relaxes every edge up to `V - 1` times) specifically to tolerate this case, at the cost of `O(V · E)` instead of Dijkstra's near-linear-with-log-factor time.

## Comparison

| | BFS (unweighted) | Dijkstra (weighted, non-negative) |
|---|---|---|
| Data structure | Plain queue (FIFO) | Min-priority queue (min-heap) |
| Edge weights | All implicitly 1 | Arbitrary non-negative |
| Time | `O(V + E)` | `O((V + E) log V)` with a binary heap |
| Guarantee breaks if... | N/A (always correct for unweighted) | Any negative edge weight exists |

## Complexity note on Dijkstra

Each vertex can be pushed onto the priority queue multiple times (once per edge relaxation that improves its distance), so the heap can hold up to `O(E)` entries; each push/pop is `O(log E) = O(log V)` (since `E` is at most `O(V²)`), giving the standard `O((V + E) log V)` bound with a binary heap. This is exactly why the heaps/priority-queues topic and graph shortest-path are so tightly linked — Dijkstra is one of the most common real justifications for "why would you ever implement a priority queue by hand."
