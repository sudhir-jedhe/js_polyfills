# Graph Traversal: BFS and DFS (with Explicit Visited-Set Handling)

Graph traversal reuses the same BFS/DFS ideas from trees, with one critical addition: **graphs can contain cycles**, so without explicitly tracking which nodes have already been visited, a traversal can loop forever. Trees never need this (there's exactly one path to any node, so no node is ever re-reachable), which is the single biggest structural difference between tree and graph traversal code.

## DFS — recursive

```js
function dfsRecursive(graph, start, visited = new Set()) {
  visited.add(start);
  const order = [start];
  for (const neighbor of graph.get(start)) {
    if (!visited.has(neighbor)) {
      order.push(...dfsRecursive(graph, neighbor, visited));
    }
  }
  return order;
}
```

The `visited` set must be checked **before** recursing (or immediately upon dequeuing/popping, depending on style) — checking too late, or not threading the same `visited` set through every recursive call, is the most common graph-traversal bug and leads to infinite recursion on any graph with a cycle.

## DFS — iterative (explicit stack)

```js
function dfsIterative(graph, start) {
  const visited = new Set([start]);
  const stack = [start];
  const order = [];
  while (stack.length) {
    const node = stack.pop();
    order.push(node);
    for (const neighbor of graph.get(node)) {
      if (!visited.has(neighbor)) {
        visited.add(neighbor); // mark visited at push time, not pop time — see note below
        stack.push(neighbor);
      }
    }
  }
  return order;
}
```

> **Mark-at-push vs. mark-at-pop:** marking a node visited when it's *pushed* (rather than when it's popped) prevents the same node from being pushed onto the stack/queue multiple times by different neighbors before it's ever processed — important on graphs where a node can have several incoming paths discovered before it's dequeued. Some implementations mark-at-pop instead and simply tolerate duplicate stack/queue entries (checking `visited` again at pop time before processing) — both are correct, but mark-at-push is generally more space-efficient.

## BFS — iterative (queue; BFS has no natural recursive form)

```js
function bfs(graph, start) {
  const visited = new Set([start]);
  const queue = [start];
  const order = [];
  while (queue.length) {
    const node = queue.shift();
    order.push(node);
    for (const neighbor of graph.get(node)) {
      if (!visited.has(neighbor)) {
        visited.add(neighbor);
        queue.push(neighbor);
      }
    }
  }
  return order;
}
```

## DFS vs. BFS — when to use which

| | DFS | BFS |
|---|---|---|
| Explores | As deep as possible before backtracking | Layer by layer, outward from the start |
| Data structure | Stack (explicit or call stack) | Queue |
| Good for | Path existence, cycle detection, topological sort, exhaustive search/backtracking | Shortest path in an **unweighted** graph, "closest" / level-based queries |
| Space | `O(h)`-ish in practice, but worst case `O(V)` on a graph (no height guarantee like a tree) | `O(V)` — can hold an entire "frontier" of nodes at once |

The BFS "shortest path in unweighted graph" guarantee is the single most important fact to remember: because BFS explores in strictly expanding rings of distance from the source, the **first** time it reaches any node is guaranteed to be via a shortest (fewest-edges) path — DFS has no such guarantee, since it can reach a distant node quickly down one lucky branch while a much closer node sits unvisited on another branch.

## Complexity (both BFS and DFS)

| | Adjacency list | Adjacency matrix |
|---|---|---|
| Time | `O(V + E)` | `O(V²)` |
| Space | `O(V)` for `visited` + stack/queue | `O(V)` |

The `O(V + E)` bound on an adjacency list comes from visiting every vertex once (`O(V)`) and, across the entire traversal, examining every edge exactly once or twice depending on directed/undirected (`O(E)`) — never more, because the `visited` check skips already-processed neighbors immediately.
