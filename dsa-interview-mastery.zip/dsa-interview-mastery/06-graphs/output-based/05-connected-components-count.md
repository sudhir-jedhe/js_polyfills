# Output: Counting Connected Components in a Disconnected Graph

```js
const vertices = ['A', 'B', 'C', 'D', 'E', 'F', 'G'];
const graph = new Map([
  ['A', ['B']], ['B', ['A', 'C']], ['C', ['B']],
  ['D', ['E']], ['E', ['D']],
  ['F', []],
  ['G', []],
]);

console.log(countConnectedComponents(graph, vertices));
```

**Question:** What does this print?

**Answer:** `4`

**Why:** The outer loop in `countConnectedComponents` visits vertices in array order and only starts a fresh traversal (incrementing `count`) when it finds a vertex that hasn't been visited by any previous traversal. Walking through: `A` is unvisited → `count = 1`, DFS marks `A, B, C` visited. `D` is unvisited → `count = 2`, DFS marks `D, E` visited. `F` is unvisited (it has no edges at all, so its own DFS call visits only itself) → `count = 3`. `G` is unvisited, also isolated → `count = 4`. This demonstrates why the outer "for every vertex, if not visited, start a new traversal" loop is mandatory for any correct graph traversal — a single BFS/DFS call from just one arbitrary starting vertex (e.g., only starting from `A`) would silently miss `D`, `E`, `F`, and `G` entirely, since none of them are reachable from `A`.
