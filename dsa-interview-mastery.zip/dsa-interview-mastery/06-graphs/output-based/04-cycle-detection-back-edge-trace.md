# Output: Tracing Gray-State Cycle Detection on a Directed Graph

```js
const graph = new Map([
  ['A', ['B']],
  ['B', ['C']],
  ['C', ['A', 'D']],
  ['D', []],
]);

console.log(hasCycleDirected(graph, ['A', 'B', 'C', 'D']));
```

**Question:** What does this print, and what's the exact sequence of state transitions that triggers the result?

**Answer:** `true`

**Why:** DFS starts at `A`, marking it `GRAY`. It descends to `B` (`GRAY`), then to `C` (`GRAY`). From `C`, the loop checks its neighbors in order: `A` first — and `A`'s state is currently `GRAY` (it's still on the active recursion path, since the DFS call for `A` hasn't returned yet) — so `state.get('A') === GRAY` is `true`, and the function returns `true` immediately, **without ever visiting `D`**. This is exactly what makes gray-state detection correct where a plain visited set would fail: if the check were simply "has `A` been visited," it would also be `true` (since `A` was indeed visited earlier) — but that alone can't distinguish "cycle" from "`A` is just an already-finished ancestor being revisited from a completely different branch," which is a completely normal, cycle-free situation in a DAG. Only `GRAY` (still actively on the current path) proves an actual back-edge, hence an actual cycle.
