# Output: Topological Sort Can Have Multiple Valid Answers

```js
const vertices = ['a', 'b', 'c', 'd'];
const graph = new Map([
  ['a', ['c']],
  ['b', ['c']],
  ['c', ['d']],
  ['d', []],
]);

console.log(topologicalSortKahn(graph, vertices));
```

**Question:** What does this print? Is `['b', 'a', 'c', 'd']` also a valid answer for the same graph?

**Answer:** `topologicalSortKahn` prints `['a', 'b', 'c', 'd']` for this specific implementation (both `a` and `b` start with in-degree 0, and `a` is processed first only because it appears first in the `vertices` array when the initial queue is built via `.filter()`). And yes — `['b', 'a', 'c', 'd']` is **also** a valid topological order for this graph.

**Why:** Both `a` and `b` have no incoming edges and no dependency relationship with each other, so nothing in the graph's edge set constrains their relative order — the only hard constraints are "`a` before `c`," "`b` before `c`," and "`c` before `d`," and both orderings satisfy all three. This is a general and important fact about topological sort: it produces **a** valid order, not **the** valid order, whenever the DAG has vertices that don't depend on each other (in DAG terms, whenever there's more than one valid "next" choice at some point during the algorithm). An interview answer should verify correctness by checking "does every edge `u -> v` have `u` appearing before `v`," not by comparing against one specific expected array.
