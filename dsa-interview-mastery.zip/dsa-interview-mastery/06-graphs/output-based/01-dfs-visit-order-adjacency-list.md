# Output: DFS Visit Order Depends on Neighbor List Order

```js
const graph = new Map([
  ['A', ['B', 'C', 'D']],
  ['B', ['E']],
  ['C', ['E']],
  ['D', []],
  ['E', []],
]);

console.log(dfsRecursive(graph, 'A'));
console.log(dfsIterative(graph, 'A'));
```

**Question:** What does each traversal print, and why do they differ from each other?

**Answer:** `dfsRecursive` prints `['A', 'B', 'E', 'C', 'D']`. `dfsIterative` prints `['A', 'D', 'C', 'E', 'B']`.

**Why:** The recursive version processes `A`'s neighbors **in list order** (`B` first, so it fully explores `B` and everything reachable from it — `E` — before ever returning to try `C`). The iterative version pushes all of `A`'s neighbors onto a stack in list order (`B`, then `C`, then `D`), but a stack is LIFO, so the **last** one pushed (`D`) is popped and visited **first** — reversing the effective visit order at each branching point compared to the recursive version. Both are valid DFS traversals (both go "deep" before backtracking, and both visit every reachable node exactly once), but they are not guaranteed to produce the same order — an interview answer should note "a valid DFS order" rather than expecting one specific sequence unless the problem pins down the exact stack/recursion mechanics being used.
