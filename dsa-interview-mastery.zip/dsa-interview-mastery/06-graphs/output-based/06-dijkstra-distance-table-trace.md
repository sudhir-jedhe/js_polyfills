# Output: Tracing Dijkstra's Distance Table Step by Step

```js
const graph = new Map([
  ['S', [['A', 2], ['B', 5]]],
  ['A', [['B', 1], ['C', 4]]],
  ['B', [['C', 1]]],
  ['C', []],
]);

console.log(dijkstraSimple(graph, 'S'));
```

**Question:** What does the final distance map print, and what's the shortest path to `C`?

**Answer:** `{ S: 0, A: 2, B: 3, C: 4 }`, and the shortest path to `C` is `S -> A -> B -> C` (cost `2 + 1 + 1 = 4`).

**Why, traced step by step:** Initialize `dist = {S:0, A:∞, B:∞, C:∞}`. Pop `S` (smallest, `0`): relax its edges — `A` becomes `2` (`0+2`), `B` becomes `5` (`0+5`). Pop `A` (smallest remaining, `2`): relax — `B` improves from `5` to `3` (`2+1 < 5`), `C` becomes `6` (`2+4`). Pop `B` (smallest remaining, `3`): relax — `C` improves from `6` to `4` (`3+1 < 6`). Pop `C` (`4`): no outgoing edges, nothing to relax. Final distances: `S:0, A:2, B:3, C:4`. The key moment is `B` being reached **twice** with two different candidate distances (`5` via `S` directly, then `3` via `S->A->B`) — Dijkstra always keeps the smaller of the two and only finalizes a node's distance once it's actually popped as the current minimum, which is exactly why the direct `S->B` edge (weight 5) never wins even though it was discovered first.
