# Output: BFS Visit Order Is Level-by-Level Regardless of List Order Quirks

```js
const graph = new Map([
  ['A', ['C', 'B']],   // note: C listed before B
  ['B', ['D']],
  ['C', ['D']],
  ['D', []],
]);

console.log(bfs(graph, 'A'));
```

**Question:** What does this print?

**Answer:** `['A', 'C', 'B', 'D']`

**Why:** BFS processes neighbors in the order they appear in each node's adjacency list, so from `A` it enqueues `C` then `B` (matching the list order `['C', 'B']`), and dequeues them in that same order (FIFO) — `C` before `B`. Both `B` and `C` point to `D`, but `D` is only enqueued **once**, the first time it's discovered (when `C` is processed, since `C` was dequeued first) — the `visited` check when `B` is later processed prevents `D` from being added a second time. This is the general BFS guarantee: every node appears in the output exactly once, at the position corresponding to the shortest number of hops from the start, and ties in "which same-distance node comes first" are broken purely by adjacency-list order, not any other property of the graph.
