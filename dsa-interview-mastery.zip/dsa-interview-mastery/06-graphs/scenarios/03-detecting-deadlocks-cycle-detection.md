# Scenario: Detecting Deadlocks via Cycle Detection

**Scenario:** In a database or operating system, a deadlock occurs when process A is waiting on a resource held by process B, and process B is (directly or transitively) waiting on a resource held by process A — a circular wait with no way for any of the involved processes to proceed. Given a snapshot of "who is waiting on whom," how would you detect whether a deadlock currently exists?

**Approach:** Model the situation as a **directed** "wait-for graph": each process is a vertex, and a directed edge `P1 -> P2` means "P1 is waiting for a resource currently held by P2." A deadlock exists **if and only if this wait-for graph contains a cycle** — a circular wait is, definitionally, a cycle in this graph.

```js
function hasDeadlock(waitForGraph, processes) {
  return hasCycleDirected(waitForGraph, processes); // exact same algorithm as directed cycle detection
}

const waitForGraph = new Map([
  ['P1', ['P2']], // P1 waiting on a resource held by P2
  ['P2', ['P3']], // P2 waiting on P3
  ['P3', ['P1']], // P3 waiting on P1 — cycle!
]);

console.log(hasDeadlock(waitForGraph, ['P1', 'P2', 'P3'])); // true
```

**Why directed cycle detection specifically (not undirected):** "waiting for" is inherently one-directional — P1 waiting on P2 says nothing about P2 waiting on P1 — so this must use the 3-color (white/gray/black) directed-graph algorithm, not the simpler "track parent" undirected version. Using the undirected algorithm here would be a meaningful bug: it would flag a false deadlock on any situation where two processes both happen to be waiting on a common third process's resources (a completely normal, non-circular fan-in pattern that superficially "revisits" an already-seen node, but isn't a cycle at all in the directed sense).

**Practical framing:** this is exactly how real database engines (and OS schedulers) implement deadlock detection — periodically build the wait-for graph from current lock-holder/lock-waiter state and run a directed cycle check; if found, the system picks one of the processes in the cycle as a "victim" to abort/roll back, breaking the cycle and letting the rest proceed.
