# Scenario: Web Crawler Discovering Isolated Site Clusters

**Scenario:** You're building a web crawler that starts from a list of seed URLs and follows links to discover pages. Leadership wants a report on how many separate "clusters" of websites exist in the crawled dataset — i.e., groups of pages that link to each other (directly or transitively) but have no links at all connecting them to other groups — to identify isolated communities of sites (useful for spam-ring detection, since spam networks often densely link to each other but rarely to the legitimate web).

**Approach:** Model each crawled page as a vertex and each hyperlink as an edge. For the purposes of "does a link exist between these two sites at all," treat the graph as **undirected** (a link from site X to site Y is evidence the two sites are part of the same cluster, regardless of whether Y links back) — this is a deliberate simplification: crawling itself must respect directed links (you can only follow a link in the direction it points), but the *clustering* question ("are these part of the same connected group") is about undirected reachability.

```js
function countSiteClusters(linkGraph, allPages) {
  return countConnectedComponents(linkGraph, allPages); // straightforward reuse
}
```

Each connected component discovered by the standard "loop over all vertices, DFS/BFS from every unvisited one" pattern is exactly one cluster. Isolated single-page components (no inbound or outbound links discovered at all) show up naturally as components of size 1, which is itself a useful signal (dead-end pages, or pages the crawler reached but that reach nothing else).

**Why this is a connected-components problem rather than a shortest-path or traversal-order problem:** the actual question being asked — "how many separate groups exist, with no way to get from one group to another" — has nothing to do with distances or optimal paths between pages within a cluster; it's purely about **reachability partitioning**. This is the tell for reaching specifically for connected-components (or Union-Find, if links arrive incrementally as the crawl progresses rather than being fully known upfront) instead of BFS/DFS-for-shortest-path or topological sort, which solve different questions entirely.

**At crawler scale**, Union-Find is often the more natural fit in practice: as the crawler discovers new links one at a time (rather than having the whole graph upfront), each new discovered link is a `union()` call, and "how many clusters exist so far" is just tracking how many distinct roots remain — avoiding a full graph re-traversal after every single new link found.
