# Scenario: Shortest Driving Route in a Maps App

**Scenario:** You're building the routing engine for a maps app: given a road network and a start/destination, find the shortest route. Roads have different travel times (a highway segment and a side-street segment of the same physical length take different times). A colleague suggests using plain BFS since "it finds shortest paths." Is that correct here?

**Diagnosis:** No — plain BFS finds the path with the **fewest edges** (fewest road segments), not the path with the lowest **total cost** (travel time). A route through 2 congested segments of 20 minutes each (40 minutes total, "2 hops") would incorrectly beat a route through 5 highway segments of 3 minutes each (15 minutes total, "5 hops") under plain BFS, since BFS has no concept of edge weight at all — it would report the 2-hop route as "shortest" even though it's nearly 3x slower.

**Fix — Dijkstra's algorithm:** model intersections as vertices and road segments as **weighted, directed** edges (directed because one-way streets exist; weighted by travel time, not physical distance, since travel time is what actually matters for "shortest route"). Dijkstra's greedy expand-the-closest-unfinalized-node strategy correctly accounts for edge weights, always finding the true minimum-total-cost path as long as weights are non-negative (travel times always are, so this constraint is naturally satisfied here).

```js
const roadNetwork = new Map([
  ['IntersectionA', [['IntersectionB', 3], ['IntersectionC', 20]]], // [neighbor, minutes]
  ['IntersectionB', [['IntersectionC', 20], ['IntersectionD', 3]]],
  ['IntersectionC', [['IntersectionE', 20]]],
  ['IntersectionD', [['IntersectionE', 3]]],
  ['IntersectionE', []],
]);

console.log(dijkstraSimple(roadNetwork, 'IntersectionA'));
// IntersectionE reached in 3+3+3=9 minutes via A-B-D-E (3 hops)
// vs. A-C-E directly at 20+20=40 minutes (2 hops) — Dijkstra correctly prefers the 9-minute route
```

**Follow-up — real maps apps go further than plain Dijkstra:** production routing engines typically use variants like **A\*** (Dijkstra augmented with a heuristic estimate of remaining distance to the destination, to avoid exploring in directions that clearly lead away from the goal) or precomputed hierarchical structures (contraction hierarchies) for continent-scale road networks, since plain Dijkstra exploring outward in every direction from the start is wasteful when the destination is already known — but the core "weighted shortest path, non-negative weights, greedy expand-the-closest-node" idea is the same one Dijkstra formalizes.
