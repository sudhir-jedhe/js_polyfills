# Scenario: "People You May Know" Friend Suggestions

**Scenario:** You're building a "people you may know" feature for a social network: given a user, suggest people who are friends of their friends, but not already their direct friend. The friend graph has millions of users and is heavily interconnected. How do you model it and which traversal fits?

**Approach:** Model users as vertices and friendships as edges in an **undirected** graph (friendship is mutual), represented as an adjacency list — a dense adjacency matrix would need `O(V²)` space for millions of users, which is completely infeasible; the actual friend graph is sparse (average users have a few hundred friends out of millions of total users), so an adjacency list is the only realistic choice.

"Friends of friends" is exactly a **2-hop BFS** from the target user: run BFS from the user, but instead of exploring indefinitely, stop after exactly 2 levels — level 1 is direct friends (to be excluded from suggestions), level 2 is friend-of-friend candidates.

```js
function friendsOfFriends(graph, user) {
  const directFriends = new Set(graph.get(user));
  const suggestions = new Map(); // candidate -> mutual friend count

  for (const friend of directFriends) {
    for (const candidate of graph.get(friend)) {
      if (candidate !== user && !directFriends.has(candidate)) {
        suggestions.set(candidate, (suggestions.get(candidate) || 0) + 1);
      }
    }
  }

  // rank by number of mutual friends (higher = better suggestion)
  return [...suggestions.entries()].sort((a, b) => b[1] - a[1]);
}
```

**Why BFS-style (level-limited) rather than full BFS/DFS:** a full traversal would eventually visit the entire connected component the user belongs to, which for a social network is often "almost everyone" — completely useless as a suggestion list and wildly expensive to compute per-user. Deliberately bounding the exploration to exactly 2 levels turns an otherwise unbounded graph traversal into a fast, local computation, and naturally produces a "mutual friend count" as a side effect (how many level-1 friends point to the same level-2 candidate) — which doubles as the natural ranking signal for the suggestions.

**Scale note:** at real social-network scale, this per-request computation would typically be precomputed/cached offline rather than run live on every profile view, but the underlying graph traversal logic — bounded BFS plus mutual-friend counting — is unchanged regardless of where it runs.
