# Scenario: Resolving Package Install Order in a Build System

**Scenario:** You're writing a package manager. Given a set of packages where some depend on others (`packageA` depends on `packageB` means `B` must be installed before `A`), determine a valid install order — and detect and report an error if the dependencies are contradictory (a circular dependency).

**Approach:** Model packages as vertices and "depends on" relationships as **directed** edges (`A -> B` meaning "install B before A", or the reverse convention — direction just needs to be consistent). This is precisely a **topological sort** problem: the required install order is any linear ordering of packages that respects every dependency edge, which only exists if the dependency graph is a DAG.

```js
function resolveInstallOrder(packages, dependencies) {
  // dependencies: [[package, dependsOn], ...] — package requires dependsOn installed first
  const graph = new Map(packages.map(p => [p, []]));
  for (const [pkg, dep] of dependencies) {
    graph.get(dep).push(pkg); // edge dep -> pkg: dep must come before pkg
  }

  const order = topologicalSortKahn(graph, packages);
  if (order === null) {
    throw new Error('Circular dependency detected — cannot resolve install order');
  }
  return order;
}
```

**Kahn's algorithm specifically (over the DFS-based approach) is a good fit here** because its cycle detection is a natural byproduct of the algorithm itself (`order.length !== packages.length` directly tells you a cycle blocked some packages from ever reaching zero in-degree) — no separate coloring pass needed, and the same in-degree counts double as a natural progress indicator ("N packages remain blocked on unresolved dependencies") if you wanted to report *which* packages are stuck in the cycle for a helpful error message (they're exactly the ones with nonzero in-degree left over after the algorithm terminates).

**Real-world parallel:** this is literally how tools like `npm`, `pip`, `make`, and CI/CD pipeline stages determine execution order — "circular dependency detected" errors from these tools are topological sort failures reported back to the user in domain-specific language.
