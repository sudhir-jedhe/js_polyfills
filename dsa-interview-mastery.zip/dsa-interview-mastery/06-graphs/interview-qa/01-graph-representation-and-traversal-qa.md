# Interview Q&A — Graph Representation and Traversal

**Q: Adjacency list vs. adjacency matrix — how do you decide which to use?**
Default to an adjacency list for sparse graphs (`E` much smaller than `V²`), which covers the vast majority of real-world and interview graphs — it uses `O(V + E)` space instead of a matrix's `O(V²)`, and iterating a vertex's actual neighbors only costs `O(degree(v))` instead of scanning an entire `O(V)` row. Reach for a matrix when the graph is genuinely dense, or when "does an edge exist between these two specific vertices" needs to be `O(1)` and is checked very frequently — the matrix trades memory for that constant-time edge lookup.

**Q: Why does graph traversal need an explicit `visited` set, when tree traversal doesn't?**
Trees guarantee exactly one path from the root to any node and no cycles, so a traversal can never revisit a node by construction. Graphs have no such guarantee — cycles are common, and even acyclic graphs can have multiple paths converging on the same node from different branches — so without explicit tracking, a traversal can revisit nodes indefinitely (infinite loop on a cycle) or at minimum do redundant repeated work.

**Q: What's the practical difference between marking a node visited when it's pushed onto the stack/queue versus when it's popped/dequeued?**
Marking at push time prevents the same node from being added to the stack/queue multiple times by different neighbors before it's ever processed, which is more space-efficient. Marking at pop time is also correct as long as you re-check `visited` immediately upon popping (skip processing if already handled) — but it tolerates duplicate entries sitting in the stack/queue simultaneously, using somewhat more memory in graphs with many converging paths. Both are valid, but push-time marking is the more common default.

**Q: Why is BFS specifically able to guarantee shortest path in an unweighted graph, while DFS cannot?**
BFS explores the graph in expanding "rings" of increasing distance from the source — it fully processes everything at distance 1 before touching anything at distance 2, and so on — so the very first time any node is reached is guaranteed to be via the minimum number of edges. DFS commits to going as deep as possible down one branch before backtracking, with no relationship at all between "how deep the current branch happens to be" and "how close this node actually is to the source" — it can easily reach a distant node quickly while a much closer node (on a different branch) remains completely unvisited.
