# Problem: Course Schedule

## Problem Statement

There are `numCourses` courses labeled `0` to `numCourses - 1`. You're given `prerequisites`, where `prerequisites[i] = [a, b]` means you must take course `b` before course `a`. Return `true` if it's possible to finish all courses (i.e., no circular prerequisite chain), `false` otherwise.

## Examples

```
Input: numCourses = 2, prerequisites = [[1,0]]
Output: true    (take 0, then 1)

Input: numCourses = 2, prerequisites = [[1,0],[0,1]]
Output: false   (0 requires 1, and 1 requires 0 — circular, impossible)
```

## Constraints

- `1 <= numCourses <= 2000`
- `0 <= prerequisites.length <= 5000`
- All pairs `[a, b]` are distinct.

## Approach

This is directed cycle detection wearing a word problem: courses are vertices, `[a, b]` means a directed edge `b -> a` (finish `b` before `a`). All courses can be finished **if and only if the prerequisite graph has no cycle** — a cycle would mean some group of courses circularly depend on each other, with no valid starting point. This is solvable either with the 3-color DFS cycle check, or (equivalently, and arguably more natural given the phrasing) with Kahn's algorithm, where success means every course reaches in-degree zero eventually.

## Solution

```js
function canFinish(numCourses, prerequisites) {
  const graph = new Map();
  for (let i = 0; i < numCourses; i++) graph.set(i, []);
  for (const [course, prereq] of prerequisites) {
    graph.get(prereq).push(course); // prereq -> course
  }

  const inDegree = new Array(numCourses).fill(0);
  for (const course of graph.keys()) {
    for (const next of graph.get(course)) inDegree[next]++;
  }

  const queue = [];
  for (let i = 0; i < numCourses; i++) {
    if (inDegree[i] === 0) queue.push(i);
  }

  let processed = 0;
  while (queue.length) {
    const course = queue.shift();
    processed++;
    for (const next of graph.get(course)) {
      inDegree[next]--;
      if (inDegree[next] === 0) queue.push(next);
    }
  }

  return processed === numCourses; // all courses reached in-degree 0 -> no cycle
}

module.exports = { canFinish };

// --- verification ---
console.log(canFinish(2, [[1, 0]]));         // true
console.log(canFinish(2, [[1, 0], [0, 1]])); // false
console.log(canFinish(4, [[1,0],[2,0],[3,1],[3,2]])); // true — a DAG, e.g. order 0,1,2,3
```

**DFS 3-color alternative:**

```js
function canFinishDFS(numCourses, prerequisites) {
  const graph = new Map();
  for (let i = 0; i < numCourses; i++) graph.set(i, []);
  for (const [course, prereq] of prerequisites) graph.get(prereq).push(course);

  const state = new Array(numCourses).fill(0); // 0=white,1=gray,2=black
  function hasCycle(node) {
    state[node] = 1;
    for (const next of graph.get(node)) {
      if (state[next] === 1) return true;
      if (state[next] === 0 && hasCycle(next)) return true;
    }
    state[node] = 2;
    return false;
  }

  for (let i = 0; i < numCourses; i++) {
    if (state[i] === 0 && hasCycle(i)) return false;
  }
  return true;
}
```

## Complexity

- **Time:** `O(V + E)` where `V = numCourses`, `E = prerequisites.length` — standard graph traversal bound for both approaches.
- **Space:** `O(V + E)` for the adjacency list and in-degree/state arrays.
