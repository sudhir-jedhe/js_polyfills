# Problem: Clone Graph

## Problem Statement

Given a reference to a node in a connected, undirected graph, return a **deep copy** (clone) of the entire graph. Each node has a value and a list of neighbor references.

```js
class GraphNode {
  constructor(val, neighbors = []) {
    this.val = val;
    this.neighbors = neighbors;
  }
}
```

## Examples

```
Input graph: 1 -- 2
             |    |
             4 -- 3

Output: a completely separate set of nodes with identical values and identical
connection structure — no shared node references with the original graph.
```

## Constraints

- Number of nodes: `0 <= n <= 100`
- Node values are unique.
- The graph is connected (all nodes reachable from the given starting node).

## Approach

This is DFS (or BFS) with an extra twist: a **map from original node → cloned node**, used both to avoid infinite loops (the graph can have cycles, and undirected edges mean you'll always see a "back reference" to where you came from) and to correctly wire up neighbor references without creating duplicate clones of the same original node.

## Solution

```js
function cloneGraph(node) {
  if (!node) return null;
  const cloned = new Map(); // original node -> its clone

  function dfs(original) {
    if (cloned.has(original)) return cloned.get(original); // already cloned — reuse, don't re-clone

    const copy = new GraphNode(original.val);
    cloned.set(original, copy); // register BEFORE recursing into neighbors — this is what breaks cycles

    for (const neighbor of original.neighbors) {
      copy.neighbors.push(dfs(neighbor));
    }

    return copy;
  }

  return dfs(node);
}

module.exports = { cloneGraph };

// --- verification ---
const n1 = new GraphNode(1);
const n2 = new GraphNode(2);
const n3 = new GraphNode(3);
const n4 = new GraphNode(4);
n1.neighbors = [n2, n4];
n2.neighbors = [n1, n3];
n3.neighbors = [n2, n4];
n4.neighbors = [n1, n3];

const clonedRoot = cloneGraph(n1);
console.log(clonedRoot.val);                     // 1
console.log(clonedRoot === n1);                   // false — genuinely separate object
console.log(clonedRoot.neighbors.map(n => n.val)); // [2, 4]
console.log(clonedRoot.neighbors[0].neighbors.some(n => n === clonedRoot)); // true — cycle correctly preserved in the clone
```

**Why registering in `cloned` before recursing into neighbors matters:** if the clone were registered *after* fully processing its neighbors, a cycle (e.g., `1 -> 2 -> 1`) would cause infinite recursion — `dfs(2)` would try to clone `1` again, see it's not yet in the map (since `dfs(1)` hasn't finished/registered it yet), and recurse right back into `dfs(2)`, forever. Registering the clone immediately upon first visiting a node — before touching its neighbors — is what makes the cycle "already cloned, just return it" instead of infinite recursion.

## Complexity

- **Time:** `O(V + E)` — every node cloned once, every edge traversed once.
- **Space:** `O(V)` for the `cloned` map plus `O(V)` recursion stack in the worst case (a graph shaped so DFS goes deep before backtracking).
