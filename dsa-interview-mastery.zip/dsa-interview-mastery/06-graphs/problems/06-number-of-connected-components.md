# Problem: Number of Connected Components in an Undirected Graph

## Problem Statement

Given `n` nodes labeled `0` to `n - 1` and a list of undirected `edges`, return the number of connected components in the graph.

## Examples

```
Input: n = 5, edges = [[0,1],[1,2],[3,4]]
Output: 2   (component {0,1,2} and component {3,4})

Input: n = 5, edges = [[0,1],[1,2],[2,3],[3,4]]
Output: 1   (all 5 nodes chained together into one component)
```

## Constraints

- `1 <= n <= 2000`
- `0 <= edges.length <= n * (n - 1) / 2`
- No duplicate edges, no self-loops.

## Approach

Two equally valid standard approaches: BFS/DFS with an outer loop over every vertex (start a fresh traversal, incrementing a counter, each time an unvisited vertex is found), or Union-Find (each edge is a `union()` call; the final count of distinct roots is the component count). Union-Find is shown here since it's the more common "expected" solution for this specific phrasing and generalizes better to follow-ups like "how many components after adding edges one at a time."

## Solution

```js
function countComponents(n, edges) {
  const parent = Array.from({ length: n }, (_, i) => i);
  const rank = new Array(n).fill(0);
  let components = n; // start assuming every node is its own component

  function find(x) {
    if (parent[x] !== x) parent[x] = find(parent[x]); // path compression
    return parent[x];
  }

  function union(x, y) {
    const rootX = find(x), rootY = find(y);
    if (rootX === rootY) return; // already connected — this edge doesn't reduce the component count
    if (rank[rootX] < rank[rootY]) [x, y] = [y, x];
    parent[find(y)] = find(x);
    if (rank[rootX] === rank[rootY]) rank[rootX]++;
    components--; // two previously-separate components just merged into one
  }

  for (const [u, v] of edges) union(u, v);
  return components;
}

module.exports = { countComponents };

// --- verification ---
console.log(countComponents(5, [[0, 1], [1, 2], [3, 4]])); // 2
console.log(countComponents(5, [[0, 1], [1, 2], [2, 3], [3, 4]])); // 1
console.log(countComponents(4, [])); // 4 — no edges at all, every node isolated
```

**BFS/DFS alternative:**

```js
function countComponentsBFS(n, edges) {
  const graph = new Map(Array.from({ length: n }, (_, i) => [i, []]));
  for (const [u, v] of edges) { graph.get(u).push(v); graph.get(v).push(u); }

  const visited = new Set();
  let count = 0;
  for (let i = 0; i < n; i++) {
    if (visited.has(i)) continue;
    count++;
    const queue = [i];
    visited.add(i);
    while (queue.length) {
      const node = queue.shift();
      for (const neighbor of graph.get(node)) {
        if (!visited.has(neighbor)) { visited.add(neighbor); queue.push(neighbor); }
      }
    }
  }
  return count;
}
```

## Complexity

- **Union-Find:** Time `O(E · α(n))` (amortized, effectively linear), Space `O(n)`.
- **BFS/DFS:** Time `O(V + E)`, Space `O(V + E)` for the adjacency list plus `O(V)` for `visited`/queue.
