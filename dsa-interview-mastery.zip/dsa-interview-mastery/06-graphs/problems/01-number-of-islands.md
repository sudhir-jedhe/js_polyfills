# Problem: Number of Islands

## Problem Statement

Given an `m x n` 2D grid of `'1'`s (land) and `'0'`s (water), return the number of islands. An island is surrounded by water and formed by connecting adjacent lands **horizontally or vertically** (not diagonally).

## Examples

```
Input:
[
  ["1","1","0","0","0"],
  ["1","1","0","0","0"],
  ["0","0","1","0","0"],
  ["0","0","0","1","1"]
]
Output: 3
```

## Constraints

- `1 <= m, n <= 300`
- `grid[i][j]` is `'0'` or `'1'`

## Approach

The grid **is** the graph — each cell is a vertex, implicitly connected to its up/down/left/right neighbors (an adjacency-matrix-shaped input, though we never materialize an explicit adjacency list; neighbors are computed on the fly from `(row, col)`). This is exactly the connected-components pattern: loop over every cell, and each time an unvisited land cell is found, that's the start of a brand-new island — flood-fill (DFS or BFS) to mark every connected land cell as visited, then increment the count.

## Solution

```js
function numIslands(grid) {
  if (!grid || !grid.length) return 0;
  const rows = grid.length, cols = grid[0].length;
  const visited = Array.from({ length: rows }, () => new Array(cols).fill(false));
  let islands = 0;

  function dfs(r, c) {
    if (r < 0 || r >= rows || c < 0 || c >= cols) return;
    if (visited[r][c] || grid[r][c] === '0') return;
    visited[r][c] = true;
    dfs(r + 1, c);
    dfs(r - 1, c);
    dfs(r, c + 1);
    dfs(r, c - 1);
  }

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      if (grid[r][c] === '1' && !visited[r][c]) {
        islands++;
        dfs(r, c);
      }
    }
  }

  return islands;
}

module.exports = { numIslands };

// --- verification ---
const grid = [
  ['1', '1', '0', '0', '0'],
  ['1', '1', '0', '0', '0'],
  ['0', '0', '1', '0', '0'],
  ['0', '0', '0', '1', '1'],
];
console.log(numIslands(grid)); // 3
```

**Iterative BFS alternative** (avoids recursion-depth risk on very large grids):

```js
function numIslandsBFS(grid) {
  const rows = grid.length, cols = grid[0].length;
  const visited = Array.from({ length: rows }, () => new Array(cols).fill(false));
  let islands = 0;

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      if (grid[r][c] !== '1' || visited[r][c]) continue;
      islands++;
      const queue = [[r, c]];
      visited[r][c] = true;
      while (queue.length) {
        const [row, col] = queue.shift();
        for (const [dr, dc] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
          const nr = row + dr, nc = col + dc;
          if (nr >= 0 && nr < rows && nc >= 0 && nc < cols && grid[nr][nc] === '1' && !visited[nr][nc]) {
            visited[nr][nc] = true;
            queue.push([nr, nc]);
          }
        }
      }
    }
  }
  return islands;
}
```

## Complexity

- **Time:** `O(rows × cols)` — every cell is visited at most once (the flood-fill marks cells visited, so no cell is ever re-explored across different island searches).
- **Space:** `O(rows × cols)` for the `visited` grid, plus `O(rows × cols)` worst case for the DFS recursion stack / BFS queue (a grid that's entirely one giant island).
