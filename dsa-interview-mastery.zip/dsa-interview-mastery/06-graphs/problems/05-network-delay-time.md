# Problem: Network Delay Time

## Problem Statement

You're given a network of `n` nodes labeled `1` to `n`, and `times`, a list of directed edges `[u, v, w]` meaning a signal travels from node `u` to node `v` in `w` time units. Starting from node `k`, return the minimum time it takes for a signal to reach **all** `n` nodes. If it's impossible for all nodes to receive the signal, return `-1`.

## Examples

```
Input: times = [[2,1,1],[2,3,1],[3,4,1]], n = 4, k = 2
Output: 2   (node 2 reaches 1 and 3 at time 1, then reaches 4 via 3 at time 2 — max delay is 2)

Input: times = [[1,2,1]], n = 2, k = 2
Output: -1  (no edge starting from node 2 — node 1 is unreachable)
```

## Constraints

- `1 <= k <= n <= 100`
- `1 <= times.length <= 6000`
- `1 <= w <= 100` (all weights positive — safe for Dijkstra)
- No self-loops or duplicate directed edges.

## Approach

This is textbook weighted single-source shortest path — exactly what Dijkstra's algorithm computes. Run Dijkstra from `k` to get the shortest distance to every other node, then the answer is the **maximum** of those distances (the signal has "reached everyone" only once even the slowest-to-reach node has gotten it); if any node is still unreachable (`Infinity`), return `-1`.

## Solution

```js
function networkDelayTime(times, n, k) {
  const graph = new Map();
  for (let i = 1; i <= n; i++) graph.set(i, []);
  for (const [u, v, w] of times) graph.get(u).push([v, w]);

  const dist = new Map();
  for (let i = 1; i <= n; i++) dist.set(i, Infinity);
  dist.set(k, 0);

  // simplified O(V^2) selection (swap in a MinHeap for O((V+E) log V) — see heaps topic)
  const unvisited = new Set(graph.keys());
  while (unvisited.size) {
    let current = null;
    for (const node of unvisited) {
      if (current === null || dist.get(node) < dist.get(current)) current = node;
    }
    if (dist.get(current) === Infinity) break;
    unvisited.delete(current);

    for (const [neighbor, weight] of graph.get(current)) {
      const candidate = dist.get(current) + weight;
      if (candidate < dist.get(neighbor)) dist.set(neighbor, candidate);
    }
  }

  const maxDist = Math.max(...dist.values());
  return maxDist === Infinity ? -1 : maxDist;
}

module.exports = { networkDelayTime };

// --- verification ---
console.log(networkDelayTime([[2, 1, 1], [2, 3, 1], [3, 4, 1]], 4, 2)); // 2
console.log(networkDelayTime([[1, 2, 1]], 2, 2)); // -1
console.log(networkDelayTime([[1, 2, 1]], 2, 1)); // 1
```

## Complexity

- **Time:** `O(V²)` with the simplified linear-scan version shown here (fine given `n <= 100`); `O((V + E) log V)` with a binary-heap priority queue, which matters at larger scale.
- **Space:** `O(V + E)` for the adjacency list and distance map.
