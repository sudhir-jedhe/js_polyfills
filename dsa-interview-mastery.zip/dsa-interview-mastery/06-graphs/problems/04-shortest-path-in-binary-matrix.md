# Problem: Shortest Path in a Binary Matrix

## Problem Statement

Given an `n x n` binary grid, find the length of the shortest **clear path** from the top-left cell `(0,0)` to the bottom-right cell `(n-1,n-1)`. A clear path only passes through cells with value `0`, and can move in any of the 8 directions (horizontal, vertical, and diagonal) between adjacent cells. Path length is measured in number of visited cells. Return `-1` if no clear path exists.

## Examples

```
Input: [[0,1],[1,0]]
Output: 2   (path: (0,0) -> (1,1), diagonal move, 2 cells visited)

Input: [[0,0,0],[1,1,0],[1,1,0]]
Output: 4   ((0,0)->(0,1)->(0,2)->(1,2)->(2,2))
```

## Constraints

- `1 <= n <= 100`
- `grid[i][j]` is `0` or `1`
- Both `(0,0)` and `(n-1,n-1)` may themselves be `1` (blocked), which immediately means no path exists.

## Approach

Unweighted shortest path (every move costs "1 cell," regardless of direction) → plain **BFS**, with the grid's 8-directional neighbors computed on the fly instead of an explicit adjacency list. Track distance directly in a `dist` grid (or reuse the input grid to mark visited, if mutation is acceptable) rather than a separate `visited` set, since coordinates map naturally to array indices.

## Solution

```js
function shortestPathBinaryMatrix(grid) {
  const n = grid.length;
  if (grid[0][0] !== 0 || grid[n - 1][n - 1] !== 0) return -1;

  const directions = [
    [-1, -1], [-1, 0], [-1, 1],
    [0, -1],           [0, 1],
    [1, -1],  [1, 0],  [1, 1],
  ];

  const visited = Array.from({ length: n }, () => new Array(n).fill(false));
  visited[0][0] = true;
  const queue = [[0, 0, 1]]; // [row, col, pathLengthSoFar]

  while (queue.length) {
    const [r, c, dist] = queue.shift();
    if (r === n - 1 && c === n - 1) return dist;

    for (const [dr, dc] of directions) {
      const nr = r + dr, nc = c + dc;
      if (
        nr >= 0 && nr < n && nc >= 0 && nc < n &&
        !visited[nr][nc] && grid[nr][nc] === 0
      ) {
        visited[nr][nc] = true;
        queue.push([nr, nc, dist + 1]);
      }
    }
  }

  return -1; // queue exhausted without reaching the target — unreachable
}

module.exports = { shortestPathBinaryMatrix };

// --- verification ---
console.log(shortestPathBinaryMatrix([[0, 1], [1, 0]])); // 2
console.log(shortestPathBinaryMatrix([[0, 0, 0], [1, 1, 0], [1, 1, 0]])); // 4
console.log(shortestPathBinaryMatrix([[1, 0], [0, 0]])); // -1 — start cell itself is blocked
```

## Complexity

- **Time:** `O(n²)` — every cell visited at most once, with a constant 8 neighbor checks per cell.
- **Space:** `O(n²)` for the `visited` grid and the BFS queue in the worst case.
