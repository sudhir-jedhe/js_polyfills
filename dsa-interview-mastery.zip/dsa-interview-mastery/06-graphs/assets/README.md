Diagrams and images for this topic (graph representations, BFS/DFS visit-order walkthroughs, topological sort DAGs) go here.
