# DFS on a Graph — Recursive and Iterative (with Visited Set)

```js
function dfsRecursive(graph, start, visited = new Set(), order = []) {
  visited.add(start);
  order.push(start);
  for (const neighbor of graph.get(start)) {
    if (!visited.has(neighbor)) dfsRecursive(graph, neighbor, visited, order);
  }
  return order;
}

function dfsIterative(graph, start) {
  const visited = new Set([start]);
  const stack = [start];
  const order = [];
  while (stack.length) {
    const node = stack.pop();
    order.push(node);
    for (const neighbor of graph.get(node)) {
      if (!visited.has(neighbor)) {
        visited.add(neighbor);
        stack.push(neighbor);
      }
    }
  }
  return order;
}

const graph = new Map([
  ['A', ['B', 'C']],
  ['B', ['A', 'D']],
  ['C', ['A', 'D']],
  ['D', ['B', 'C']],
]);

console.log(dfsRecursive(graph, 'A')); // ['A', 'B', 'D', 'C']
console.log(dfsIterative(graph, 'A')); // ['A', 'C', 'D', 'B']  — order differs: stack pops neighbors in reverse push order
```
