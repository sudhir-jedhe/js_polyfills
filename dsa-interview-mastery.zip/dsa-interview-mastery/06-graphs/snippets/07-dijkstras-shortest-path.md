# Dijkstra's Shortest Path (Simplified, Array-Scan Priority Selection)

For interview settings without a heap on hand, a simplified `O(V²)` Dijkstra (linear scan to find the minimum instead of a heap) is a perfectly reasonable starting point before optimizing to a heap-based `O((V+E) log V)` version (see the heaps topic for a from-scratch `MinHeap`).

```js
function dijkstraSimple(graph, start) {
  // graph: Map<vertex, Array<[neighbor, weight]>>
  const dist = new Map();
  for (const v of graph.keys()) dist.set(v, Infinity);
  dist.set(start, 0);

  const unvisited = new Set(graph.keys());

  while (unvisited.size) {
    // pick the unvisited node with the smallest known distance
    let current = null;
    for (const node of unvisited) {
      if (current === null || dist.get(node) < dist.get(current)) current = node;
    }
    if (dist.get(current) === Infinity) break; // remaining nodes are unreachable
    unvisited.delete(current);

    for (const [neighbor, weight] of graph.get(current)) {
      const candidate = dist.get(current) + weight;
      if (candidate < dist.get(neighbor)) dist.set(neighbor, candidate);
    }
  }

  return dist;
}

const graph = new Map([
  ['A', [['B', 4], ['C', 1]]],
  ['B', [['D', 1]]],
  ['C', [['B', 2], ['D', 5]]],
  ['D', []],
]);

console.log(dijkstraSimple(graph, 'A'));
// Map { A -> 0, B -> 3 (A-C-B: 1+2), C -> 1, D -> 4 (A-C-B-D: 1+2+1) }
```
