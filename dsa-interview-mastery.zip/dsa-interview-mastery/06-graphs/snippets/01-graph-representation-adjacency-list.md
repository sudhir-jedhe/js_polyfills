# Building an Adjacency List from an Edge List

```js
function buildAdjacencyList(vertices, edges, directed = false) {
  const graph = new Map(vertices.map(v => [v, []]));
  for (const [u, v] of edges) {
    graph.get(u).push(v);
    if (!directed) graph.get(v).push(u);
  }
  return graph;
}

const vertices = ['A', 'B', 'C', 'D'];
const edges = [['A', 'B'], ['A', 'C'], ['B', 'C'], ['C', 'D']];

const undirected = buildAdjacencyList(vertices, edges, false);
console.log(undirected.get('C')); // ['A', 'B', 'D']

const directed = buildAdjacencyList(vertices, edges, true);
console.log(directed.get('C')); // ['D']  — only outgoing edges from C
console.log(directed.get('A')); // ['B', 'C']
```
