# Cycle Detection — Undirected Graph (Track Parent)

```js
function hasCycleUndirected(graph, vertices) {
  const visited = new Set();

  function dfs(node, parent) {
    visited.add(node);
    for (const neighbor of graph.get(node)) {
      if (!visited.has(neighbor)) {
        if (dfs(neighbor, node)) return true;
      } else if (neighbor !== parent) {
        return true; // reached a visited node that isn't the one we just came from
      }
    }
    return false;
  }

  for (const v of vertices) {
    if (!visited.has(v) && dfs(v, null)) return true;
  }
  return false;
}

const tree = new Map([['A', ['B', 'C']], ['B', ['A']], ['C', ['A']]]);
console.log(hasCycleUndirected(tree, ['A', 'B', 'C'])); // false — this is just a tree, no cycle

const withCycle = new Map([['A', ['B', 'C']], ['B', ['A', 'C']], ['C', ['A', 'B']]]);
console.log(hasCycleUndirected(withCycle, ['A', 'B', 'C'])); // true — A-B-C-A triangle
```
