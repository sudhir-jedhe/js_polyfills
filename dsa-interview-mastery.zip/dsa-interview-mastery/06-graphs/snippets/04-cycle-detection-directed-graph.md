# Cycle Detection — Directed Graph (3-Color / White-Gray-Black)

```js
function hasCycleDirected(graph, vertices) {
  const WHITE = 0, GRAY = 1, BLACK = 2;
  const state = new Map(vertices.map(v => [v, WHITE]));

  function dfs(node) {
    state.set(node, GRAY); // currently on the active path
    for (const neighbor of graph.get(node)) {
      if (state.get(neighbor) === GRAY) return true;             // back-edge to an ancestor
      if (state.get(neighbor) === WHITE && dfs(neighbor)) return true;
    }
    state.set(node, BLACK); // fully processed, safe
    return false;
  }

  for (const v of vertices) {
    if (state.get(v) === WHITE && dfs(v)) return true;
  }
  return false;
}

const dag = new Map([['A', ['B']], ['B', ['C']], ['C', []]]);
console.log(hasCycleDirected(dag, ['A', 'B', 'C'])); // false

const cyclic = new Map([['A', ['B']], ['B', ['C']], ['C', ['A']]]);
console.log(hasCycleDirected(cyclic, ['A', 'B', 'C'])); // true — A -> B -> C -> A
```
