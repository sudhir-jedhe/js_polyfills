# Topological Sort — Kahn's Algorithm and DFS-Based

```js
function topologicalSortKahn(graph, vertices) {
  const inDegree = new Map(vertices.map(v => [v, 0]));
  for (const v of vertices) {
    for (const neighbor of graph.get(v)) inDegree.set(neighbor, inDegree.get(neighbor) + 1);
  }

  const queue = vertices.filter(v => inDegree.get(v) === 0);
  const order = [];
  while (queue.length) {
    const node = queue.shift();
    order.push(node);
    for (const neighbor of graph.get(node)) {
      inDegree.set(neighbor, inDegree.get(neighbor) - 1);
      if (inDegree.get(neighbor) === 0) queue.push(neighbor);
    }
  }
  return order.length === vertices.length ? order : null; // null => cycle, no valid order
}

function topologicalSortDFS(graph, vertices) {
  const visited = new Set();
  const stack = [];
  function dfs(node) {
    visited.add(node);
    for (const neighbor of graph.get(node)) {
      if (!visited.has(neighbor)) dfs(neighbor);
    }
    stack.push(node);
  }
  for (const v of vertices) if (!visited.has(v)) dfs(v);
  return stack.reverse();
}

const vertices = ['shirt', 'jacket', 'pants', 'shoes', 'socks'];
const graph = new Map([
  ['shirt', ['jacket']],
  ['pants', ['shoes', 'jacket']],
  ['socks', ['shoes']],
  ['jacket', []],
  ['shoes', []],
]);

console.log(topologicalSortKahn(graph, vertices));
// e.g. ['shirt', 'pants', 'socks', 'jacket', 'shoes'] — one of several valid orders
console.log(topologicalSortDFS(graph, vertices));
// e.g. ['socks', 'pants', 'shoes', 'shirt', 'jacket'] — also valid, different order, same constraints respected
```
