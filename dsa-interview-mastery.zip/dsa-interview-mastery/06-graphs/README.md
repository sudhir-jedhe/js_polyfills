# Graphs

A graph is a set of nodes (vertices) connected by edges, with no restriction on how many connections a node can have or whether those connections are one-way — which makes graphs the most general-purpose data structure covered in this repo, and the one that models the widest range of real systems: social networks, road maps, dependency chains, web page links, and more. Interviewers lean on graphs heavily because the topic forces you to combine several prior topics at once — traversal (BFS/DFS), recursion, queues/stacks, and careful state tracking (visited sets) — while also introducing genuinely new concepts like cycle detection, topological ordering, and shortest-path algorithms that don't come up anywhere else in a typical DSA curriculum.

## Folder structure

- **`theory/`** — graph representations (adjacency list vs. matrix), BFS/DFS traversal mechanics, directed vs. undirected graphs & cycle detection, topological sort, shortest path (BFS for unweighted, Dijkstra conceptually), and connected components.
- **`snippets/`** — 7 focused, runnable code examples: adjacency list representation, DFS (recursive & iterative), BFS, cycle detection (directed and undirected), topological sort (both algorithms), and Dijkstra's algorithm.
- **`output-based/`** — 6 "what order does this visit nodes / what does this algorithm produce" questions with the answer worked out step by step.
- **`scenarios/`** — 5 real-world situations where a specific graph algorithm is the right tool: social networks, build systems, deadlock detection, mapping apps, and web crawlers.
- **`interview-qa/`** — 9 Q&A pairs grouped into 3 themed files: representation/traversal, cycle detection/topological sort, and shortest path/complexity.
- **`problems/`** — 6 hands-on coding challenges: number of islands, course schedule, clone graph, shortest path in a binary matrix, network delay time (Dijkstra), and number of connected components.
- **`assets/`** — placeholder for diagrams/images (see `assets/README.md`).

## What's covered

- Adjacency list vs. adjacency matrix: space/time tradeoffs and when to use each
- BFS and DFS on graphs — recursive and iterative, with explicit `visited` set handling (critical for graphs, since unlike trees they can contain cycles)
- Directed vs. undirected graphs, and cycle detection for each (the algorithms genuinely differ — a "gray/visiting" state is required for directed graphs, not just a plain visited set)
- Topological sort via both Kahn's algorithm (BFS + in-degree) and DFS-based (postorder + reverse)
- Shortest path basics: BFS for unweighted shortest path, Dijkstra's algorithm (conceptual + implementation) for weighted non-negative graphs
- Connected components in undirected graphs
- Classic problems: number of islands, course schedule (cycle detection in disguise), clone graph, unweighted/weighted shortest path
