# Stacks & Queues

Stacks (LIFO) and queues (FIFO) are simple to define but easy to implement inefficiently — this topic covers both array-based and linked-list-based implementations of each, why `Array.shift()` is a common performance trap for queues, the circular queue (ring buffer) as the efficient fixed-capacity alternative, implementing one structure in terms of the other (queue-from-two-stacks and vice versa), the monotonic stack pattern (one of the most-missed high-leverage patterns in interviews), and a light preview of priority queues ahead of the full topic at `07-heaps-priority-queues`.

## Folder structure

- **`theory/`** — stack implementations (array vs linked-list), queue implementations (including the `shift()` trap and its fixes), circular queues, implementing one structure with the other, the monotonic stack pattern, and a priority queue preview.
- **`snippets/`** — 7 runnable examples: array-based stack, linked-list-based queue, circular queue, monotonic-stack next-greater-element, valid-parentheses checker, queue-from-two-stacks, and a min-stack.
- **`output-based/`** — 6 "what's the output / complexity?" questions covering the `shift()`-based queue's hidden O(n²), a full monotonic-stack trace, the call stack as a literal LIFO structure, amortized analysis of the two-stack queue, circular-queue wraparound tracing, and min-stack behavior after pops.
- **`scenarios/`** — 4 real-world scenarios: an undo stack for a drawing app, choosing between a circular buffer and a dynamic queue for unpredictable job volume, stack-based nested-syntax validation, and a monotonic deque for sliding-window maximums.
- **`interview-qa/`** — 3 themed Q&A files: fundamentals, monotonic stack and composite patterns, and design/tradeoffs.
- **`problems/`** — 7 hands-on coding challenges: valid parentheses, next greater element, queue using two stacks, min stack, evaluate Reverse Polish Notation, sliding window maximum, and design a circular queue.
- **`assets/`** — placeholder for diagrams (see `assets/README.md`).

## What's covered

- Array-based and linked-list-based stacks and queues, with exact complexity for each operation
- Why `Array.prototype.shift()` silently turns a queue's dequeue into O(n) (and O(n²) over a full drain), and both standard fixes
- The circular queue (ring buffer): true O(1) enqueue/dequeue via modulo-wrapped indices, no shifting or reallocation
- Implementing a queue with two stacks (O(1) amortized both ends) and a stack with two queues (one side is inherently O(n))
- The monotonic stack pattern: turning O(n²) "next greater/smaller element"-style problems into O(n), and recognizing when it applies
- A light preview of priority queues and why neither an unsorted nor sorted array gives O(log n) on both insert and extract
- Hands-on: valid parentheses, next greater element, queue-from-two-stacks, min stack, RPN evaluation, sliding window maximum (monotonic deque), and a circular queue — each with full complexity analysis
