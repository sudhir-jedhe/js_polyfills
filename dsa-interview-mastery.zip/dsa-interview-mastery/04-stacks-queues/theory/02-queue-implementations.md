# Queue Implementations: Array-Based and Linked-List-Based

A queue is a **FIFO** (first-in, first-out) structure supporting `enqueue` (add to the back) and `dequeue` (remove from the front). Getting the array-based implementation right requires more care than a stack, because naive use of `Array.shift()` is a classic performance trap.

## The naive (and slow) array-based queue

```js
class NaiveArrayQueue {
  #items = [];

  enqueue(value) {
    this.#items.push(value); // O(1) amortized — fine
  }

  dequeue() {
    return this.#items.shift(); // O(n) — BAD: every remaining element must shift left
  }
}
```
`shift()` is O(n) because every remaining element must be re-indexed one position to the left. Calling this once per dequeue across n operations gives O(n²) total — a common, easy-to-miss performance bug.

## Better array-based queue: a lazy front-index pointer

Instead of physically shifting elements out, track a `frontIndex` and only "logically" remove from the front — physically compact the array occasionally rather than on every dequeue.

```js
class ArrayQueue {
  #items = [];
  #frontIndex = 0;

  enqueue(value) {
    this.#items.push(value); // O(1) amortized
  }

  dequeue() {
    if (this.isEmpty()) throw new Error('Queue is empty');
    const value = this.#items[this.#frontIndex];
    this.#frontIndex++;

    // periodically reclaim space once "wasted" front slots dominate the array
    if (this.#frontIndex > this.#items.length / 2) {
      this.#items = this.#items.slice(this.#frontIndex);
      this.#frontIndex = 0;
    }
    return value; // O(1) amortized
  }

  peek() {
    if (this.isEmpty()) throw new Error('Queue is empty');
    return this.#items[this.#frontIndex];
  }

  isEmpty() {
    return this.#frontIndex >= this.#items.length;
  }
}
```
This gets `dequeue` down to O(1) amortized — same amortization argument as dynamic array resizing (see `01-big-o-complexity-analysis/theory/06-amortized-analysis-and-best-average-worst-case.md`): the occasional O(k) compaction, spread across the k dequeues that led up to it, averages out to O(1) per operation.

## Linked-list-based queue (the cleanest O(1) guarantee)

Maintain both `head` (front, for dequeue) and `tail` (back, for enqueue) pointers on a singly linked list — both operations touch only one end each, no shifting, no amortization needed at all.

```js
class QueueNode {
  constructor(value, next = null) {
    this.value = value;
    this.next = next;
  }
}

class LinkedQueue {
  #head = null;
  #tail = null;
  #size = 0;

  enqueue(value) {
    const node = new QueueNode(value);
    if (this.#tail) this.#tail.next = node;
    else this.#head = node;
    this.#tail = node;
    this.#size++; // O(1), always
  }

  dequeue() {
    if (this.isEmpty()) throw new Error('Queue is empty');
    const value = this.#head.value;
    this.#head = this.#head.next;
    if (!this.#head) this.#tail = null;
    this.#size--;
    return value; // O(1), always
  }

  isEmpty() {
    return this.#size === 0;
  }
}
```

## Comparison

| Aspect | Naive array (`shift`) | Compacting array | Linked list |
|---|---|---|---|
| `enqueue` | O(1) amortized | O(1) amortized | O(1) always |
| `dequeue` | O(n) | O(1) amortized | O(1) always |
| Extra memory | None | Occasional temporary waste | Extra pointer per node |

**Interview takeaway:** if asked to implement a queue with an array, never use `shift()` naively in a loop — either use the front-index compaction trick above, or reach for a circular buffer (`03-circular-queue.md`) for a fixed-capacity, allocation-free O(1) guarantee.
