# Stack Implementations: Array-Based and Linked-List-Based

A stack is a **LIFO** (last-in, first-out) structure supporting `push` (add to the top), `pop` (remove from the top), and `peek` (view the top without removing). Two common backing implementations, both achieving O(1) for all three operations — but for different underlying reasons.

## Array-based stack

The natural fit: use the *end* of a JS array as the "top" of the stack, so `push`/`pop` map directly onto `Array.prototype.push`/`pop` — both O(1) (amortized for `push`).

```js
class ArrayStack {
  #items = [];

  push(value) {
    this.#items.push(value); // O(1) amortized
  }

  pop() {
    if (this.isEmpty()) throw new Error('Stack is empty');
    return this.#items.pop(); // O(1)
  }

  peek() {
    if (this.isEmpty()) throw new Error('Stack is empty');
    return this.#items[this.#items.length - 1]; // O(1)
  }

  isEmpty() {
    return this.#items.length === 0; // O(1)
  }

  get size() {
    return this.#items.length; // O(1)
  }
}
```
**Crucial detail:** the array's *end* must be used as the stack's top, not the front — using `unshift`/`shift` instead would make every operation O(n), defeating the point of a stack entirely.

## Linked-list-based stack

Use the *head* of a singly linked list as the "top" — both insertion and removal at the head of a singly linked list are O(1), with no amortization caveats at all (unlike array `push`, which is O(1) *amortized* due to occasional resizes).

```js
class StackNode {
  constructor(value, next = null) {
    this.value = value;
    this.next = next;
  }
}

class LinkedStack {
  #top = null;
  #size = 0;

  push(value) {
    this.#top = new StackNode(value, this.#top); // O(1), always
    this.#size++;
  }

  pop() {
    if (this.isEmpty()) throw new Error('Stack is empty');
    const value = this.#top.value;
    this.#top = this.#top.next;
    this.#size--;
    return value; // O(1), always
  }

  peek() {
    if (this.isEmpty()) throw new Error('Stack is empty');
    return this.#top.value; // O(1)
  }

  isEmpty() {
    return this.#size === 0;
  }

  get size() {
    return this.#size;
  }
}
```

## Comparison

| Aspect | Array-based | Linked-list-based |
|---|---|---|
| `push` | O(1) amortized | O(1) always |
| `pop` | O(1) always | O(1) always |
| `peek` | O(1) | O(1) |
| Memory overhead | None beyond elements | Extra pointer per node |
| Cache locality | Good (contiguous) | Poor (scattered nodes) |

**In practice:** the array-based version is almost always preferred in JS for its simplicity and cache locality — the linked-list version's main advantage (no amortization) is rarely worth the extra per-node memory overhead unless push operations must have a hard, uniform O(1) guarantee with zero variance (e.g. certain real-time or latency-sensitive systems).
