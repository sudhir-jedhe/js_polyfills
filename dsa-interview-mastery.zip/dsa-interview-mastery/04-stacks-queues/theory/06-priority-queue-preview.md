# Priority Queue — Light Preview

A priority queue is a queue variant where each element has an associated priority, and `dequeue` always returns the element with the **highest** (or lowest) priority, regardless of insertion order — a plain queue's FIFO ordering is replaced with "priority order." This is only a brief preview; the full topic, including a from-scratch binary heap implementation, lives in `07-heaps-priority-queues`.

## Why a plain array or sorted array isn't the efficient answer

```js
// Naive: unsorted array, O(n) to find-and-remove the max/min each time
class NaivePriorityQueue {
  #items = [];
  enqueue(value, priority) { this.#items.push({ value, priority }); } // O(1)
  dequeue() {
    let bestIdx = 0;
    for (let i = 1; i < this.#items.length; i++) {
      if (this.#items[i].priority > this.#items[bestIdx].priority) bestIdx = i;
    }
    return this.#items.splice(bestIdx, 1)[0].value; // O(n) scan + O(n) splice
  }
}
// enqueue: O(1), dequeue: O(n) -- fine for small n, doesn't scale
```

A sorted array flips the cost instead: O(n) `enqueue` (must insert at the correct sorted position, shifting elements) but O(1) `dequeue` (always take from the sorted end). Neither array-based approach gives O(log n) for *both* operations.

## The efficient structure: a binary heap

A binary heap (typically implemented as an array with implicit parent/child index math, not actual node/pointer objects) achieves **O(log n)** for both `enqueue` (called "insert" or "push") and `dequeue` (called "extract-max" or "extract-min") — by maintaining a much weaker ordering guarantee than a fully sorted array (only "each parent is more extreme than its children," not "everything is fully sorted"), which is cheap to restore after each operation via a single O(log n) "bubble up" or "bubble down" pass, rather than a full re-sort.

| Structure | Enqueue | Dequeue (get highest priority) |
|---|---|---|
| Unsorted array | O(1) | O(n) |
| Sorted array | O(n) | O(1) |
| Binary heap | O(log n) | O(log n) |

## Where priority queues show up

Dijkstra's shortest path, task schedulers (always run the highest-priority pending task next), event simulation (always process the next-soonest event), and the "k-th largest/smallest element" family of problems. JS has no built-in priority queue/heap (unlike some languages), so implementing one from array-backed heap logic is itself a common interview exercise — covered in full in `07-heaps-priority-queues`.

## The connection to this topic

A priority queue is conceptually "a queue where the dequeue order is priority-based instead of insertion-based" — worth knowing that relationship exists here, even though the efficient implementation (a heap) is a genuinely different underlying structure from the stack/queue implementations covered elsewhere in this topic, not a variation on the linked-list or circular-buffer queues above.
