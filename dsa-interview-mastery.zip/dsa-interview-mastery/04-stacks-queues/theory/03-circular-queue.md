# Circular Queue (Ring Buffer)

A circular queue is a fixed-capacity queue backed by a single pre-allocated array, where `front` and `tail` indices wrap around ("modulo the capacity") instead of ever shifting elements. This gives true O(1) enqueue/dequeue with zero re-allocation and zero shifting — the standard structure for bounded buffers (streaming windows, producer/consumer buffers, `03-linked-lists/scenarios/04-streaming-log-processor-with-bounded-memory.md`).

## Implementation

```js
class CircularQueue {
  #items;
  #capacity;
  #frontIdx = 0;
  #size = 0;

  constructor(capacity) {
    this.#capacity = capacity;
    this.#items = new Array(capacity);
  }

  enqueue(value) {
    if (this.isFull()) throw new Error('Queue is full');
    const insertIdx = (this.#frontIdx + this.#size) % this.#capacity; // wrap around
    this.#items[insertIdx] = value;
    this.#size++;
  }

  dequeue() {
    if (this.isEmpty()) throw new Error('Queue is empty');
    const value = this.#items[this.#frontIdx];
    this.#frontIdx = (this.#frontIdx + 1) % this.#capacity; // wrap around
    this.#size--;
    return value;
  }

  peek() {
    if (this.isEmpty()) throw new Error('Queue is empty');
    return this.#items[this.#frontIdx];
  }

  isEmpty() { return this.#size === 0; }
  isFull() { return this.#size === this.#capacity; }
}

const cq = new CircularQueue(3);
cq.enqueue(1); cq.enqueue(2); cq.enqueue(3);
console.log(cq.dequeue()); // 1
cq.enqueue(4); // wraps into the slot vacated by 1, without shifting anything
console.log([cq.dequeue(), cq.dequeue(), cq.dequeue()]); // [2, 3, 4]
```

## Why the modulo wrap-around matters

Both `enqueue` and `dequeue` compute their target index with `% capacity`, meaning once the physical array index reaches the end, the next insertion wraps back to index 0 — reusing the storage slots vacated by earlier dequeues, rather than growing the array or shifting remaining elements. This is what makes both operations truly O(1) with no amortization needed at all: no resize, no compaction, no shift, ever — the array is allocated once, upfront, at the queue's fixed capacity.

## Complexity

| Operation | Complexity |
|---|---|
| `enqueue` | O(1) |
| `dequeue` | O(1) |
| `peek` | O(1) |
| Space | O(capacity), fixed, allocated once |

## When to use a circular queue over a dynamic queue

Use it whenever the maximum size is known and fixed ahead of time — sliding window buffers over a stream, task schedulers with a bounded queue depth, producer/consumer ring buffers in audio/video processing. It trades the ability to grow unboundedly for a hard memory ceiling and the best possible cache locality and operation guarantees.
