# Implementing a Queue with Two Stacks, and Vice Versa

A recurring interview exercise: build one structure using only operations from the other. Both directions are worth knowing cold.

## Queue using two stacks

The idea: use one stack (`inStack`) for incoming elements, and a second stack (`outStack`) to serve elements out in the correct (reversed-back-to-original) order. Reversing a stack's contents by popping into another stack flips their order — exactly what's needed to turn LIFO into FIFO.

```js
class QueueFromStacks {
  #inStack = [];
  #outStack = [];

  enqueue(value) {
    this.#inStack.push(value); // O(1) amortized
  }

  dequeue() {
    if (this.#outStack.length === 0) {
      // move everything from inStack to outStack, reversing order
      while (this.#inStack.length > 0) {
        this.#outStack.push(this.#inStack.pop());
      }
    }
    if (this.#outStack.length === 0) throw new Error('Queue is empty');
    return this.#outStack.pop(); // O(1)
  }
}
```

**Complexity — the amortized argument:** `enqueue` is always O(1). `dequeue` can be O(n) in the worst case (when `outStack` is empty and everything must be transferred from `inStack`), but each individual element is moved from `inStack` to `outStack` **at most once** across its entire lifetime in the queue — so summed over any sequence of n operations, total transfer work is O(n), making `dequeue` **O(1) amortized**, the same style of argument as dynamic array resizing.

## Stack using two queues

The idea: to make the most recently enqueued element come out first (simulating LIFO with FIFO-only primitives), rotate the queue after each push so the newest element ends up at the front.

```js
class StackFromQueues {
  #q1 = []; // using arrays as queues here for simplicity (push = enqueue, shift = dequeue conceptually)

  push(value) {
    this.#q1.push(value);
    // rotate: move every element that was already in front of the new one to the back
    for (let i = 0; i < this.#q1.length - 1; i++) {
      this.#q1.push(this.#q1.shift());
    }
  }

  pop() {
    if (this.#q1.length === 0) throw new Error('Stack is empty');
    return this.#q1.shift(); // front of q1 is always the most recently pushed element
  }

  peek() {
    return this.#q1[0];
  }
}
```
**Complexity:** `push` is O(n) every time (the rotation touches every existing element), `pop` is O(1). This is the "expensive push" variant; a symmetric "expensive pop" variant exists too, but at least one operation is always O(n) when simulating a stack purely with queue primitives — there's no way to make both O(1) with only two queues, unlike the queue-from-two-stacks case, which achieves O(1) amortized on both ends.

## Why the two directions aren't symmetric

Queue-from-two-stacks achieves O(1) amortized for both `enqueue` and `dequeue`, but stack-from-two-queues cannot achieve O(1) worst-case *or* amortized on both `push` and `pop` — one of them is inherently O(n). This asymmetry is a good "gotcha" to mention proactively in an interview: it demonstrates you understand *why* the amortized argument works in one direction (each element moves between stacks at most once, ever) but structurally cannot in the other (every push must reposition all existing elements, every single time, not just occasionally).

## Quick reference

| Simulation | Cheap operation | Expensive operation |
|---|---|---|
| Queue from 2 stacks | `enqueue`: O(1) | `dequeue`: O(1) amortized |
| Stack from 2 queues | `pop`: O(1) | `push`: O(n) every time |
