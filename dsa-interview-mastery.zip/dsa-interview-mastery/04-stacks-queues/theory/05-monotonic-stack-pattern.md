# The Monotonic Stack Pattern

A monotonic stack maintains its elements in strictly increasing or strictly decreasing order at all times, by popping off elements that would violate that order before pushing a new one. It's one of the highest-leverage, most-often-missed patterns in interviews — it turns an apparent O(n²) "for each element, scan the rest" problem into O(n), because every element is pushed and popped **at most once** across the entire run.

## The canonical problem: Next Greater Element

For each element in an array, find the next element to its right that's strictly greater than it (or `-1` if none exists).

```js
function nextGreaterElement(nums) {
  const result = new Array(nums.length).fill(-1);
  const stack = []; // stores INDICES, kept in decreasing-value order

  for (let i = 0; i < nums.length; i++) {
    // pop every index whose value is smaller than the current element —
    // the current element IS their "next greater element"
    while (stack.length > 0 && nums[stack[stack.length - 1]] < nums[i]) {
      const idx = stack.pop();
      result[idx] = nums[i];
    }
    stack.push(i);
  }

  return result;
}

console.log(nextGreaterElement([2, 1, 2, 4, 3])); // [4, 2, 4, -1, -1]
```

## Why this is O(n), not O(n²)

Even though there's a `while` loop nested inside a `for` loop, each index is pushed onto the stack exactly once and popped off at most once — total push operations are exactly n, and total pop operations are at most n, so total work across the *entire* run (not per-iteration) is O(n), not O(n²). This is a direct parallel to the amortized-cost reasoning used for dynamic array resizing: don't count "worst case per iteration," count total work across all iterations combined.

## Recognizing when a monotonic stack applies

| Problem phrase | Fit |
|---|---|
| "Next greater/smaller element" | Classic monotonic (decreasing/increasing) stack |
| "Daily temperatures" (days until a warmer day) | Same pattern, tracking indices |
| "Largest rectangle in histogram" | Monotonic increasing stack of indices, popping to compute widths |
| "Trapping rain water" | Monotonic stack tracking potential wall boundaries |
| "Remove k digits to make the smallest number" | Monotonic increasing stack, greedily popping larger digits |

The common thread: whenever a problem asks "for each element, what's the next/previous element to the left/right satisfying some ordering condition," a naive solution scans forward/backward from every element (O(n²)); a monotonic stack answers it in one O(n) pass by maintaining just enough ordered history to resolve each query the instant it becomes resolvable.

## Increasing vs decreasing stacks

- **Decreasing stack** (pop while top < current): used for "next **greater** element" — each pop means "this new, bigger element is the answer for whatever I just popped."
- **Increasing stack** (pop while top > current): used for "next **smaller** element" — same logic, inverted.

## Complexity summary

**Time: O(n)** — every element is pushed once and popped at most once, regardless of how the `while` loop appears to nest inside the `for` loop.
**Space: O(n)** — worst case (e.g. a strictly increasing input for the "next greater element" problem), every index remains on the stack simultaneously before any pops occur.
