# Problem: Next Greater Element

## Problem Statement

Given an array `nums`, for each element find the next element to its right that is strictly greater than it. If no such element exists, use `-1`.

## Constraints

- `1 <= nums.length <= 10^5`
- Elements may repeat.
- Must solve better than the O(n²) brute force (nested loop scanning forward from each index).

## Examples

```
nextGreaterElement([2,1,2,4,3]) → [4,2,4,-1,-1]
nextGreaterElement([5,4,3,2,1]) → [-1,-1,-1,-1,-1]
```

## Approach

Maintain a monotonic (decreasing) stack of **indices** as you scan left to right. Before pushing the current index, pop off every index on the stack whose value is smaller than the current element — the current element is, by definition, the "next greater element" for each of those popped indices. Any index still on the stack at the end never found a next-greater element, and its result stays `-1`.

## Solution

```js
function nextGreaterElement(nums) {
  const result = new Array(nums.length).fill(-1);
  const stack = []; // indices, values strictly decreasing bottom-to-top

  for (let i = 0; i < nums.length; i++) {
    while (stack.length > 0 && nums[stack[stack.length - 1]] < nums[i]) {
      const idx = stack.pop();
      result[idx] = nums[i];
    }
    stack.push(i);
  }

  return result;
}
```

## Complexity Analysis

**Time: O(n)** — despite the nested `while` inside the `for`, each index is pushed onto the stack exactly once and popped at most once across the entire run, so total operations are bounded by 2n, i.e. O(n) — not O(n²) like the brute-force nested-loop scan.
**Space: O(n)** — worst case (a strictly decreasing input array), every index remains on the stack simultaneously, none ever popped, until the function returns.
