# Problem: Implement a Min Stack

## Problem Statement

Design a stack that supports `push`, `pop`, `top`, and `getMin` — all in O(1) time.

## Constraints

- Up to `3 * 10^4` total operations.
- `getMin` must not scan the stack — it must be a direct O(1) lookup.

## Examples

```
const ms = new MinStack();
ms.push(-2); ms.push(0); ms.push(-3);
ms.getMin(); // -3
ms.pop();
ms.top();     // 0
ms.getMin(); // -2
```

## Approach

Maintain a second, parallel "mins" stack alongside the main data stack. Every push records, on the mins stack, the minimum value seen so far *including* the newly pushed value (`Math.min(newValue, currentMin)`). Every pop removes from both stacks together. This way, the top of the mins stack always reflects the correct minimum for whatever's currently on the main stack — popping correctly "rolls back" to the previous minimum, since that previous minimum was recorded before the just-removed value was ever pushed.

## Solution

```js
class MinStack {
  #items = [];
  #mins = [];

  push(value) {
    this.#items.push(value);
    const currentMin = this.#mins.length === 0
      ? value
      : Math.min(value, this.#mins[this.#mins.length - 1]);
    this.#mins.push(currentMin);
  }

  pop() {
    this.#mins.pop();
    return this.#items.pop();
  }

  top() {
    return this.#items[this.#items.length - 1];
  }

  getMin() {
    return this.#mins[this.#mins.length - 1];
  }
}
```

## Complexity Analysis

**Time: O(1)** for all four operations — each does a fixed, constant amount of work (array end push/pop/index access), regardless of stack size.
**Space: O(n)** — the `#mins` stack duplicates one entry per element on the main stack, doubling memory usage compared to a plain stack, in exchange for guaranteed O(1) `getMin` (versus O(n) if `getMin` scanned the main stack directly).
