# Problem: Implement a Queue Using Two Stacks

## Problem Statement

Implement a FIFO queue (`enqueue`, `dequeue`, `peek`, `isEmpty`) using only stack primitives (`push`, `pop`, `peek`/top, checking emptiness) — no other queue-like structure allowed.

## Constraints

- All four operations must be supported.
- `dequeue`/`peek` should be O(1) amortized (not O(n) every single call).
- Up to `10^4` total operations across the object's lifetime.

## Examples

```
q.enqueue(1); q.enqueue(2); q.enqueue(3);
q.dequeue(); // 1
q.enqueue(4);
q.dequeue(); // 2
q.dequeue(); // 3
q.dequeue(); // 4
```

## Approach

Use two stacks: `inStack` receives every `enqueue` directly (always O(1)). `outStack` serves `dequeue`/`peek` requests; when it's empty, transfer everything from `inStack` by repeatedly popping and pushing — this reverses the order, turning the "most recent on top" LIFO order back into the correct oldest-first order needed for FIFO. Once transferred, elements stay on `outStack` until popped, so the expensive transfer only happens when genuinely necessary.

## Solution

```js
class QueueFromStacks {
  #inStack = [];
  #outStack = [];

  enqueue(value) {
    this.#inStack.push(value);
  }

  #transferIfNeeded() {
    if (this.#outStack.length === 0) {
      while (this.#inStack.length > 0) {
        this.#outStack.push(this.#inStack.pop());
      }
    }
  }

  dequeue() {
    this.#transferIfNeeded();
    if (this.#outStack.length === 0) throw new Error('Queue is empty');
    return this.#outStack.pop();
  }

  peek() {
    this.#transferIfNeeded();
    if (this.#outStack.length === 0) throw new Error('Queue is empty');
    return this.#outStack[this.#outStack.length - 1];
  }

  isEmpty() {
    return this.#inStack.length === 0 && this.#outStack.length === 0;
  }
}
```

## Complexity Analysis

**Time: `enqueue` — O(1) always. `dequeue`/`peek` — O(1) amortized** (occasionally O(n) when a transfer is triggered, but each element is moved between the two stacks at most once across its entire lifetime in the queue, so the total transfer work across any sequence of n operations is O(n), averaging to O(1) per operation).
**Space: O(n)** — the two stacks together hold at most n elements at any time.
