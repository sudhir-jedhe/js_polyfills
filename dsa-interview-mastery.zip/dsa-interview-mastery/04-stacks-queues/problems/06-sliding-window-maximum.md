# Problem: Sliding Window Maximum

## Problem Statement

Given an array `nums` and a window size `k`, return an array of the maximum value in each contiguous window of size `k` as it slides from left to right across the array.

## Constraints

- `1 <= k <= nums.length <= 10^5`
- Must run better than the O(n·k) brute force (recomputing the max by scanning each window fully).

## Examples

```
maxSlidingWindow([1,3,-1,-3,5,3,6,7], 3) → [3,3,5,5,6,7]
maxSlidingWindow([1], 1)                    → [1]
```

## Approach

Use a monotonic decreasing deque storing **indices**. For each new index: first, remove indices from the *front* of the deque that have fallen outside the current window (`index <= currentIndex - k`); then remove indices from the *back* whose values are smaller than the current value (they can never be the max again while the current, larger value remains in play); then push the current index. The window's maximum is always the value at the index still sitting at the *front* of the deque.

## Solution

```js
function maxSlidingWindow(nums, k) {
  const deque = []; // indices, values strictly decreasing front-to-back
  const result = [];

  for (let i = 0; i < nums.length; i++) {
    // remove indices that fell out of the window on the left
    if (deque.length > 0 && deque[0] <= i - k) {
      deque.shift();
    }

    // remove indices whose values are smaller than the current one
    while (deque.length > 0 && nums[deque[deque.length - 1]] < nums[i]) {
      deque.pop();
    }

    deque.push(i);

    if (i >= k - 1) {
      result.push(nums[deque[0]]); // front of the deque holds the current window's max
    }
  }

  return result;
}
```

## Complexity Analysis

**Time: O(n)** — each index is pushed onto the deque exactly once and removed (from either end) at most once across the entire run, so total deque operations are bounded by O(n) despite the per-iteration `while` loop and front-eviction check; this is the same "total work across the whole run, not per iteration" argument as the monotonic stack pattern, extended to both ends.
**Space: O(k)** — the deque holds at most k indices at any time (older, out-of-window, or smaller-value indices are continuously evicted), plus O(n) for the output array.

**Note:** this implementation uses `Array.shift()` for front-removal, which is technically O(n) per call in the worst case for a plain array — for a fully rigorous O(n) guarantee (not just O(n) amortized in practice for typical inputs), a true double-ended queue structure (e.g. backed by a doubly linked list or an index-tracked circular buffer) should replace the front-eviction step in a production implementation.
