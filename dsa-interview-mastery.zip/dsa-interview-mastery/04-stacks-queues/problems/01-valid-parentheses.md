# Problem: Valid Parentheses

## Problem Statement

Given a string containing only the characters `(`, `)`, `{`, `}`, `[`, `]`, determine if the input is valid — every opening bracket must be closed by the same type of bracket, and brackets must close in the correct order (proper nesting).

## Constraints

- `1 <= s.length <= 10^4`
- `s` consists only of bracket characters.

## Examples

```
isValid('()[]{}') → true
isValid('(]')       → false
isValid('([)]')     → false  (wrong nesting order, even though counts balance)
isValid('{[]}')     → true
```

## Approach

Push every opening bracket onto a stack. On every closing bracket, check that it matches the type of whatever's currently on top of the stack (popping it if so); if it doesn't match, or the stack is empty when a closer is encountered, the string is invalid. At the end, the string is valid only if the stack is empty (no unmatched openers remain).

## Solution

```js
function isValid(s) {
  const stack = [];
  const pairs = { ')': '(', ']': '[', '}': '{' };

  for (const ch of s) {
    if (ch === '(' || ch === '[' || ch === '{') {
      stack.push(ch);
    } else {
      if (stack.pop() !== pairs[ch]) return false;
    }
  }

  return stack.length === 0;
}
```

## Complexity Analysis

**Time: O(n)** — single pass over the string, O(1) work (push/pop) per character.
**Space: O(n)** — worst case (all opening brackets, e.g. `'((((('`), the stack holds every character before returning `false` at the end (or throughout, if the string were valid and all-openers-then-all-closers).
