# Problem: Evaluate Reverse Polish Notation

## Problem Statement

Evaluate an arithmetic expression given in Reverse Polish Notation (postfix notation), represented as an array of tokens (numbers and the operators `+`, `-`, `*`, `/`). Division should truncate toward zero.

## Constraints

- `1 <= tokens.length <= 10^4`
- Valid RPN expression is guaranteed (no malformed input to handle).
- Division truncates toward zero (e.g. `-7 / 2 = -3`, not `-4`).

## Examples

```
evalRPN(['2','1','+','3','*'])            → 9    ((2 + 1) * 3)
evalRPN(['4','13','5','/','+'])            → 6    (4 + (13 / 5))
evalRPN(['10','6','9','3','+','-11','*','/','*','17','+','5','+']) → 22
```

## Approach

Postfix notation is naturally evaluated with a stack: push numbers as encountered; whenever an operator token appears, pop the two most recent operands (the second-popped is the left operand, the first-popped is the right operand — order matters for `-` and `/`), apply the operator, and push the result back. At the end, exactly one value remains on the stack — the final answer.

## Solution

```js
function evalRPN(tokens) {
  const stack = [];

  for (const token of tokens) {
    if (['+', '-', '*', '/'].includes(token)) {
      const right = stack.pop();
      const left = stack.pop();
      let result;
      switch (token) {
        case '+': result = left + right; break;
        case '-': result = left - right; break;
        case '*': result = left * right; break;
        case '/': result = Math.trunc(left / right); break; // truncate toward zero
      }
      stack.push(result);
    } else {
      stack.push(Number(token));
    }
  }

  return stack.pop();
}
```

## Complexity Analysis

**Time: O(n)** — single pass over the tokens, O(1) work (a couple of pops/pushes and an arithmetic operation) per token.
**Space: O(n)** — worst case (all operands, no operators until the very end), the stack holds up to n values before any are consumed.
