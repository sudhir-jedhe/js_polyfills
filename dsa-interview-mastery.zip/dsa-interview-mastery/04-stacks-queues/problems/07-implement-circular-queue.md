# Problem: Design a Circular Queue

## Problem Statement

Implement a fixed-capacity circular queue supporting `enqueue(value)`, `dequeue()`, `front()` (peek), `isEmpty()`, and `isFull()`, all in O(1), using a single pre-allocated array (no resizing, no shifting).

## Constraints

- Capacity is fixed at construction time, up to `1000`.
- `enqueue` on a full queue and `dequeue`/`front` on an empty queue should fail gracefully (return `false`/`null`, or throw — be explicit about the contract).

## Examples

```
const cq = new CircularQueue(3);
cq.enqueue(1); cq.enqueue(2); cq.enqueue(3);
cq.isFull();   // true
cq.dequeue();  // 1
cq.enqueue(4); // succeeds — reuses the slot vacated by 1
cq.front();    // 2
```

## Approach

Track a `frontIdx` (the logical front) and a `size` counter over a fixed-length array. The insertion index for `enqueue` is computed as `(frontIdx + size) % capacity` — this correctly wraps around to reuse array slots vacated by earlier dequeues, without ever shifting elements or reallocating. `dequeue` reads from `frontIdx`, then advances `frontIdx` forward (also wrapping via modulo) and decrements `size`.

## Solution

```js
class CircularQueue {
  #items;
  #capacity;
  #frontIdx = 0;
  #size = 0;

  constructor(capacity) {
    this.#capacity = capacity;
    this.#items = new Array(capacity);
  }

  enqueue(value) {
    if (this.isFull()) return false;
    const insertIdx = (this.#frontIdx + this.#size) % this.#capacity;
    this.#items[insertIdx] = value;
    this.#size++;
    return true;
  }

  dequeue() {
    if (this.isEmpty()) return false;
    this.#frontIdx = (this.#frontIdx + 1) % this.#capacity;
    this.#size--;
    return true;
  }

  front() {
    return this.isEmpty() ? -1 : this.#items[this.#frontIdx];
  }

  isEmpty() {
    return this.#size === 0;
  }

  isFull() {
    return this.#size === this.#capacity;
  }
}
```

## Complexity Analysis

**Time: O(1)** for every operation (`enqueue`, `dequeue`, `front`, `isEmpty`, `isFull`) — each does a fixed, constant amount of index arithmetic and array access, with no shifting, no scanning, and no resizing.
**Space: O(capacity)** — the backing array is allocated once, upfront, at the fixed requested capacity, and never grows or shrinks.
