// Valid parentheses / balanced brackets check using a stack — O(n) time, O(n) space

function isValid(str) {
  const stack = [];
  const pairs = { ')': '(', ']': '[', '}': '{' };

  for (const ch of str) {
    if (ch === '(' || ch === '[' || ch === '{') {
      stack.push(ch);
    } else if (ch in pairs) {
      if (stack.pop() !== pairs[ch]) return false; // mismatched or empty stack
    }
  }

  return stack.length === 0; // true only if every opener was matched and closed
}

console.log(isValid('()[]{}'));   // true
console.log(isValid('(]'));       // false
console.log(isValid('([)]'));     // false -- wrong nesting order
console.log(isValid('{[]}'));     // true
