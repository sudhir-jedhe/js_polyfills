// Array-based stack — O(1) push/pop/peek using the array's end as the top

class ArrayStack {
  #items = [];

  push(value) {
    this.#items.push(value); // O(1) amortized
  }

  pop() {
    if (this.isEmpty()) throw new Error('Stack is empty');
    return this.#items.pop(); // O(1)
  }

  peek() {
    if (this.isEmpty()) throw new Error('Stack is empty');
    return this.#items[this.#items.length - 1]; // O(1)
  }

  isEmpty() {
    return this.#items.length === 0;
  }
}

const stack = new ArrayStack();
stack.push(1);
stack.push(2);
stack.push(3);
console.log(stack.peek()); // 3
console.log(stack.pop());  // 3
console.log(stack.pop());  // 2
console.log(stack.isEmpty()); // false
