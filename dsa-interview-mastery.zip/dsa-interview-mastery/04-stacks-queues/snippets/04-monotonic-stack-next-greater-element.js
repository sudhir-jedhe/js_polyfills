// Monotonic (decreasing) stack solving "next greater element" in O(n)

function nextGreaterElement(nums) {
  const result = new Array(nums.length).fill(-1);
  const stack = []; // indices, values kept in decreasing order from bottom to top

  for (let i = 0; i < nums.length; i++) {
    while (stack.length > 0 && nums[stack[stack.length - 1]] < nums[i]) {
      const idx = stack.pop();
      result[idx] = nums[i];
    }
    stack.push(i);
  }

  return result;
}
// O(n) time -- each index is pushed once and popped at most once across the whole run

console.log(nextGreaterElement([2, 1, 2, 4, 3])); // [4, 2, 4, -1, -1]
console.log(nextGreaterElement([5, 4, 3, 2, 1]));  // [-1, -1, -1, -1, -1] -- strictly decreasing, nothing beats anything later
