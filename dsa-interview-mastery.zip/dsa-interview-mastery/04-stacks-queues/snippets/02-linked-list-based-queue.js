// Linked-list-based queue — O(1) enqueue/dequeue with head/tail pointers, no shifting ever

class QueueNode {
  constructor(value, next = null) {
    this.value = value;
    this.next = next;
  }
}

class LinkedQueue {
  #head = null;
  #tail = null;
  #size = 0;

  enqueue(value) {
    const node = new QueueNode(value);
    if (this.#tail) this.#tail.next = node;
    else this.#head = node;
    this.#tail = node;
    this.#size++;
  }

  dequeue() {
    if (this.isEmpty()) throw new Error('Queue is empty');
    const value = this.#head.value;
    this.#head = this.#head.next;
    if (!this.#head) this.#tail = null;
    this.#size--;
    return value;
  }

  isEmpty() {
    return this.#size === 0;
  }
}

const q = new LinkedQueue();
q.enqueue('a');
q.enqueue('b');
q.enqueue('c');
console.log(q.dequeue()); // 'a'
console.log(q.dequeue()); // 'b'
q.enqueue('d');
console.log(q.dequeue()); // 'c'
console.log(q.dequeue()); // 'd'
