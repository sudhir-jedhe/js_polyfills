// Fixed-capacity circular queue — O(1) enqueue/dequeue, no shifting, no reallocation

class CircularQueue {
  #items;
  #capacity;
  #frontIdx = 0;
  #size = 0;

  constructor(capacity) {
    this.#capacity = capacity;
    this.#items = new Array(capacity);
  }

  enqueue(value) {
    if (this.isFull()) throw new Error('Queue is full');
    const insertIdx = (this.#frontIdx + this.#size) % this.#capacity;
    this.#items[insertIdx] = value;
    this.#size++;
  }

  dequeue() {
    if (this.isEmpty()) throw new Error('Queue is empty');
    const value = this.#items[this.#frontIdx];
    this.#frontIdx = (this.#frontIdx + 1) % this.#capacity;
    this.#size--;
    return value;
  }

  isEmpty() { return this.#size === 0; }
  isFull() { return this.#size === this.#capacity; }
}

const ring = new CircularQueue(3);
ring.enqueue(1);
ring.enqueue(2);
ring.enqueue(3);
console.log(ring.dequeue()); // 1 -- frees up a slot
ring.enqueue(4);              // wraps around into the freed slot
console.log([ring.dequeue(), ring.dequeue(), ring.dequeue()]); // [2, 3, 4]
