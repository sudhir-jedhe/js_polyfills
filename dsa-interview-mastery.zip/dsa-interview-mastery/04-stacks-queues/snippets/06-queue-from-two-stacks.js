// Simulating a FIFO queue using two LIFO stacks — O(1) enqueue, O(1) amortized dequeue

class QueueFromStacks {
  #inStack = [];
  #outStack = [];

  enqueue(value) {
    this.#inStack.push(value);
  }

  dequeue() {
    if (this.#outStack.length === 0) {
      while (this.#inStack.length > 0) {
        this.#outStack.push(this.#inStack.pop()); // reverses order once
      }
    }
    if (this.#outStack.length === 0) throw new Error('Queue is empty');
    return this.#outStack.pop();
  }
}

const q = new QueueFromStacks();
q.enqueue(1);
q.enqueue(2);
q.enqueue(3);
console.log(q.dequeue()); // 1 -- FIFO order preserved despite using two LIFO stacks internally
q.enqueue(4);
console.log(q.dequeue()); // 2
console.log(q.dequeue()); // 3
console.log(q.dequeue()); // 4
