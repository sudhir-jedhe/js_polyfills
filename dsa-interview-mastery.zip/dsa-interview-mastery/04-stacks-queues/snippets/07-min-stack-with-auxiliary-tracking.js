// Min-stack: a stack that supports getMin() in O(1), via a parallel auxiliary stack

class MinStack {
  #items = [];
  #mins = []; // #mins[i] = the minimum value among #items[0..i]

  push(value) {
    this.#items.push(value);
    const currentMin = this.#mins.length === 0
      ? value
      : Math.min(value, this.#mins[this.#mins.length - 1]);
    this.#mins.push(currentMin); // O(1) -- tracks running min alongside each push
  }

  pop() {
    this.#mins.pop();
    return this.#items.pop(); // O(1)
  }

  top() {
    return this.#items[this.#items.length - 1]; // O(1)
  }

  getMin() {
    return this.#mins[this.#mins.length - 1]; // O(1) -- no scan needed
  }
}

const ms = new MinStack();
ms.push(5);
ms.push(2);
ms.push(7);
console.log(ms.getMin()); // 2
ms.pop(); // removes 7
console.log(ms.getMin()); // 2 -- unchanged
ms.pop(); // removes 2
console.log(ms.getMin()); // 5 -- correctly falls back to the next minimum
