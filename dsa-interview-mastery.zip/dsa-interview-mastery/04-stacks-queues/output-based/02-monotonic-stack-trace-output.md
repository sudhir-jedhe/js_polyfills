# What's the Output? — Tracing a Monotonic Stack

```js
function dailyTemperatures(temps) {
  const result = new Array(temps.length).fill(0);
  const stack = []; // indices, decreasing temperature from bottom to top

  for (let i = 0; i < temps.length; i++) {
    while (stack.length > 0 && temps[stack[stack.length - 1]] < temps[i]) {
      const prevIdx = stack.pop();
      result[prevIdx] = i - prevIdx;
    }
    stack.push(i);
  }
  return result;
}

console.log(dailyTemperatures([73, 74, 75, 71, 69, 72, 76, 73]));
```

**Answer:**
```
[1, 1, 4, 2, 1, 1, 0, 0]
```

**Why:** Each output value is "how many days until a warmer temperature." Tracing the stack (holding indices, values kept in decreasing order):
- `i=0` (73): stack empty, push 0. Stack: `[0]`
- `i=1` (74): `74 > temps[0]=73` → pop 0, `result[0] = 1-0 = 1`. Push 1. Stack: `[1]`
- `i=2` (75): `75 > temps[1]=74` → pop 1, `result[1] = 2-1 = 1`. Push 2. Stack: `[2]`
- `i=3` (71): `71 < temps[2]=75` → no pop. Push 3. Stack: `[2,3]`
- `i=4` (69): `69 < temps[3]=71` → no pop. Push 4. Stack: `[2,3,4]`
- `i=5` (72): `72 > temps[4]=69` → pop 4, `result[4]=1`. `72 > temps[3]=71` → pop 3, `result[3]=2`. `72 < temps[2]=75` → stop. Push 5. Stack: `[2,5]`
- `i=6` (76): `76 > temps[5]=72` → pop 5, `result[5]=1`. `76 > temps[2]=75` → pop 2, `result[2]=4`. Push 6. Stack: `[6]`
- `i=7` (73): `73 < temps[6]=76` → no pop. Push 7. Stack: `[6,7]`

Indices 6 and 7 (values 76, 73) never get popped — no warmer day follows them in the array — so their `result` entries stay at their initialized default, `0`. This confirms the O(n) claim: despite the nested `while`, across the whole trace each index was pushed exactly once and popped at most once.
