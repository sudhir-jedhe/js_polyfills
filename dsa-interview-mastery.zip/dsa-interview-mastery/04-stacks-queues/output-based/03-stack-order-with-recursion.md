# What's the Output? — Implicit Stack Order via Recursion

```js
function traverse(n) {
  if (n === 0) return;
  console.log('entering', n);
  traverse(n - 1);
  console.log('leaving', n);
}

traverse(3);
```

**Answer:**
```
entering 3
entering 2
entering 1
leaving 1
leaving 2
leaving 3
```

**Why:** Every recursive call pushes a new frame onto the language's call stack — itself a LIFO structure. `traverse(3)` logs "entering 3" then immediately calls `traverse(2)` (pushing a new frame) before it has a chance to log "leaving 3"; this continues down to `traverse(0)`, which returns immediately (the base case), and only then does the stack start **unwinding**: each frame resumes exactly where it left off, in reverse (LIFO) order of how they were entered, printing "leaving" messages from the innermost (most recently entered) call outward to the outermost. This is precisely why recursion depth counts as O(n) space — every one of those "entering" frames is genuinely alive and unfinished, holding its own local state, until its matching "leaving" line runs — the call stack **is** a stack, in the literal data-structure sense, not just a metaphor.
