# What's the Output? — Tracing Circular Queue Wraparound

```js
class CircularQueue {
  #items; #capacity; #frontIdx = 0; #size = 0;
  constructor(capacity) { this.#capacity = capacity; this.#items = new Array(capacity); }
  enqueue(v) {
    const idx = (this.#frontIdx + this.#size) % this.#capacity;
    this.#items[idx] = v;
    this.#size++;
  }
  dequeue() {
    const v = this.#items[this.#frontIdx];
    this.#frontIdx = (this.#frontIdx + 1) % this.#capacity;
    this.#size--;
    return v;
  }
}

const cq = new CircularQueue(4);
cq.enqueue('a'); cq.enqueue('b'); cq.enqueue('c');
console.log(cq.dequeue()); // ?
console.log(cq.dequeue()); // ?
cq.enqueue('d'); cq.enqueue('e'); cq.enqueue('f');
console.log(cq.dequeue()); // ?
console.log(cq.dequeue()); // ?
```

**Answer:**
```
a
b
c
d
```

**Why:** Trace the internal state (`capacity=4`, indices 0-3):
- `enqueue('a')`: `idx = (0+0)%4 = 0` → items[0]='a', size=1
- `enqueue('b')`: `idx = (0+1)%4 = 1` → items[1]='b', size=2
- `enqueue('c')`: `idx = (0+2)%4 = 2` → items[2]='c', size=3
- `dequeue()`: returns items[0]='a', frontIdx becomes `(0+1)%4=1`, size=2 → **'a'**
- `dequeue()`: returns items[1]='b', frontIdx becomes `(1+1)%4=2`, size=1 → **'b'**
- `enqueue('d')`: `idx = (2+1)%4 = 3` → items[3]='d', size=2
- `enqueue('e')`: `idx = (2+2)%4 = 0` → **wraps around**, overwriting the now-vacated slot 0 with 'e', size=3
- `enqueue('f')`: `idx = (2+3)%4 = 1` → wraps, overwrites vacated slot 1 with 'f', size=4
- `dequeue()`: returns items[2]='c' (frontIdx is still 2, unaffected by the enqueues), frontIdx becomes `(2+1)%4=3`, size=3 → **'c'**
- `dequeue()`: returns items[3]='d', frontIdx becomes `(3+1)%4=0`, size=2 → **'d'**

The key insight: `frontIdx` and the insertion index are computed independently via modulo arithmetic — enqueues after a dequeue correctly reuse the physical array slots that earlier dequeues vacated, without ever shifting existing elements or reallocating the array.
