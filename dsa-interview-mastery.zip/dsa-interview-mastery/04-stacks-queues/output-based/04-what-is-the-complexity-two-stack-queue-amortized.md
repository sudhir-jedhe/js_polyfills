# What's the Time Complexity? — Two-Stack Queue Under a Mixed Operation Sequence

```js
class QueueFromStacks {
  #inStack = [];
  #outStack = [];
  enqueue(v) { this.#inStack.push(v); }
  dequeue() {
    if (this.#outStack.length === 0) {
      while (this.#inStack.length > 0) this.#outStack.push(this.#inStack.pop());
    }
    return this.#outStack.pop();
  }
}

const q = new QueueFromStacks();
for (let i = 0; i < n; i++) q.enqueue(i);
for (let i = 0; i < n; i++) q.dequeue();
```

**Question:** The first `dequeue()` call triggers a full transfer of all n elements from `inStack` to `outStack` — that single call is O(n). Does that mean this queue implementation is worse than the naive `shift()`-based one from `01-what-is-the-complexity-shift-based-queue.md`?

**Answer:** No — despite that one expensive call, the total cost across all n `dequeue()` calls combined is still `O(n)`, giving `O(1)` amortized per dequeue, strictly better than the `shift()`-based version's `O(n)` per dequeue (`O(n²)` total).

**Why:** The key distinction is *how many times* each individual element gets moved, summed across its entire lifetime in the structure. In the two-stack queue, each element is pushed onto `inStack` once (during `enqueue`) and popped off then pushed onto `outStack` at most once (during whichever `dequeue` call triggers the transfer) — after that, it just sits on `outStack` until its own `pop()`. So across all n elements, the *total* number of push/pop operations involved in transfers is bounded by `2n` (each element moved at most twice total), not `n` per dequeue call. The first `dequeue()` looking expensive in isolation is exactly the amortized-analysis situation covered in `01-big-o-complexity-analysis/theory/06-amortized-analysis-and-best-average-worst-case.md` — a single operation can spike in cost, but the *sequence* still averages out to O(1) per operation, which is a fundamentally different (and better) guarantee than the naive `shift()` version's O(n) *every single time*.
