# What's the Time Complexity? — A Queue Built With `Array.shift()`

```js
class NaiveQueue {
  #items = [];
  enqueue(v) { this.#items.push(v); }
  dequeue() { return this.#items.shift(); }
}

const q = new NaiveQueue();
for (let i = 0; i < n; i++) q.enqueue(i);
for (let i = 0; i < n; i++) q.dequeue();
```

**Question:** What's the total time complexity of the dequeue loop?

**Answer:** `O(n²)` for the full dequeue loop — not `O(n)`.

**Why:** `Array.prototype.shift()` is O(n) because removing the first element requires re-indexing every remaining element one position to the left. In the dequeue loop, the queue starts with `n` elements and shrinks by one on each call — so the total cost is `n + (n-1) + (n-2) + ... + 1 = O(n²)`. This is a very common trap: `enqueue` (using `push`) looks and is O(1) amortized, so the whole structure "feels" efficient, but the `dequeue` side silently makes any loop that drains the queue quadratic overall. The fix is either a lazy front-index pointer (`../theory/02-queue-implementations.md`) or a circular buffer (`../theory/03-circular-queue.md`), both of which bring `dequeue` down to O(1) amortized or O(1) always.
