# What's the Output? — Min-Stack After a Sequence of Pushes and Pops

```js
class MinStack {
  #items = []; #mins = [];
  push(v) {
    this.#items.push(v);
    this.#mins.push(this.#mins.length === 0 ? v : Math.min(v, this.#mins[this.#mins.length - 1]));
  }
  pop() { this.#mins.pop(); return this.#items.pop(); }
  getMin() { return this.#mins[this.#mins.length - 1]; }
}

const ms = new MinStack();
ms.push(3);
ms.push(1);
ms.push(4);
console.log(ms.getMin());
ms.pop(); // removes 4
console.log(ms.getMin());
ms.push(0);
console.log(ms.getMin());
ms.pop(); // removes 0
ms.pop(); // removes 1
console.log(ms.getMin());
```

**Answer:**
```
1
1
0
3
```

**Why:** The `#mins` auxiliary stack tracks, at each position, the minimum value seen *up to and including that push* — not just a single global minimum variable. Trace: push(3) → mins=[3]; push(1) → mins=[3,1] (1 < 3); push(4) → mins=[3,1,1] (4 is not less than 1, so the running min stays 1). `getMin()` → **1**. `pop()` removes the top of both `#items` (4) and `#mins` (1, the min *as of* the 4-push) → mins=[3,1]. `getMin()` → **1** (correctly falls back to the min as of the push before 4, which was still 1). `push(0)` → mins=[3,1,0]. `getMin()` → **0**. `pop()` removes 0 and its mins entry → mins=[3,1]. `pop()` removes 1 and its mins entry → mins=[3]. `getMin()` → **3**. This is why the auxiliary stack must store a min *snapshot per push*, not a single mutable variable — a single variable couldn't "roll back" to the correct previous minimum after a pop.
