# Interview Q&A — Stack and Queue Fundamentals

**Q: What's the core ordering difference between a stack and a queue?**
A stack is LIFO (last-in, first-out) — the most recently added element is the first one removed. A queue is FIFO (first-in, first-out) — the earliest added element is the first one removed. Both support O(1) insertion and removal when implemented correctly, but at opposite "ends" conceptually.

**Q: Why is it a mistake to implement a queue's dequeue with `Array.prototype.shift()`?**
`shift()` removes the first element and re-indexes every remaining element one position to the left, making it O(n) per call. Used in a loop draining n elements, this produces O(n²) total, even though each individual `enqueue` (via `push`) is O(1) amortized — the queue "looks" efficient at a glance but has a hidden quadratic cost on the dequeue side.

**Q: What are the two standard fixes for the `shift()` problem?**
Either track a lazy `frontIndex` into the array and only physically compact/reallocate occasionally (giving O(1) amortized dequeue), or use a fixed-capacity circular queue with modulo-wrapped indices (giving O(1) dequeue, always, with no amortization needed at all, at the cost of a fixed maximum capacity).

**Q: Why is the JS call stack literally a stack, not just named similarly?**
Every function call pushes a new frame containing local variables and the return address onto the call stack; when a function returns, its frame is popped. This is a literal LIFO structure — the most recently called (and not-yet-returned) function is always the next one to finish, which is exactly why recursive function calls unwind in reverse order of how they were entered.

**Q: What's the complexity of `push`/`pop` for an array-based stack versus a linked-list-based stack?**
Array-based: `push` is O(1) amortized (occasional resize), `pop` is O(1) always. Linked-list-based (using the head as the top): both `push` and `pop` are O(1) always, with no amortization caveat at all, at the cost of extra per-node pointer memory and worse cache locality than a contiguous array.
