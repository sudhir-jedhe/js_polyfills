# Output: Min-Heap Array State After a Sequence of Inserts

```js
const minHeap = new MinHeap();
[5, 3, 8, 1, 9].forEach(n => minHeap.push(n));
console.log(minHeap.heap);
```

**Question:** What does `minHeap.heap` look like after inserting `5, 3, 8, 1, 9` in that order?

**Answer:** `[1, 3, 8, 5, 9]`

**Why, traced step by step:**
- Push `5` → `[5]`. Only element, nothing to bubble.
- Push `3` → append: `[5, 3]`. `3`'s parent (index 0) is `5`; `3 < 5`, swap → `[3, 5]`.
- Push `8` → append: `[3, 5, 8]`. `8`'s parent (index 0) is `3`; `8 >= 3`, no swap → `[3, 5, 8]`.
- Push `1` → append: `[3, 5, 8, 1]`. `1` is at index 3, parent is `Math.floor((3-1)/2) = 1`, which holds `5`; `1 < 5`, swap → `[3, 1, 8, 5]`. Continue bubbling: `1` now at index 1, parent is index 0 (`3`); `1 < 3`, swap → `[1, 3, 8, 5]`.
- Push `9` → append: `[1, 3, 8, 5, 9]`. `9`'s parent is index `Math.floor((4-1)/2) = 1`, which holds `3`; `9 >= 3`, no swap. Final: `[1, 3, 8, 5, 9]`.

**Key takeaway:** the resulting array is *a* valid min-heap (root `1` is indeed the smallest, and every parent ≤ its children), but it is **not** a sorted array — heap order only constrains parent-vs-child, not siblings or any global ordering, which is why `heap[3] = 5` and `heap[4] = 9` even though `5 < 9` doesn't need to (and in this case does) hold across unrelated branches.
