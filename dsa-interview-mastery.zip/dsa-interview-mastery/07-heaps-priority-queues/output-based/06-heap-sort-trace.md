# Output: Tracing Heap Sort Step by Step

```js
console.log(heapSort([4, 10, 3, 5, 1]));
```

**Question:** What are the intermediate array states during `heapSort([4, 10, 3, 5, 1])`, and what's the final output?

**Answer:** Final output: `[1, 3, 4, 5, 10]`.

**Why, traced step by step:**

**Phase 1 — build max-heap** (start from last non-leaf, index `Math.floor(5/2)-1 = 1`):
- `i=1` (`10`): children `5`(idx3), `1`(idx4). `10` already largest, no swap.
- `i=0` (`4`): children `10`(idx1), `3`(idx2). Largest child is `10`; `4 < 10`, swap → `[10, 4, 3, 5, 1]`. Continue sifting `4` (now at index 1): children `5`(idx3), `1`(idx4); largest is `5`; `4 < 5`, swap → `[10, 5, 3, 4, 1]`.
- Max-heap built: `[10, 5, 3, 4, 1]`.

**Phase 2 — repeated extract-max, shrinking boundary:**
- `end=4`: swap root(`10`) with `arr[4]`(`1`) → `[1, 5, 3, 4, 10]`. Heapify over `[0..3]`: `i=0`(`1`), children `5`,`3`; largest `5`, swap → `[5, 1, 3, 4, 10]`; continue at idx1(`1`), child idx3=`4`; swap → `[5, 4, 3, 1, 10]`.
- `end=3`: swap root(`5`) with `arr[3]`(`1`) → `[1, 4, 3, 5, 10]`. Heapify over `[0..2]`: `i=0`(`1`), children `4`,`3`; largest `4`, swap → `[4, 1, 3, 5, 10]`.
- `end=2`: swap root(`4`) with `arr[2]`(`3`) → `[3, 1, 4, 5, 10]`. Heapify over `[0..1]`: `i=0`(`3`), child `1`; `3 >= 1`, no swap.
- `end=1`: swap root(`3`) with `arr[1]`(`1`) → `[1, 3, 4, 5, 10]`. Heapify over `[0..0]`: single element, nothing to do.

Final sorted array: `[1, 3, 4, 5, 10]`. Each extraction places the current maximum of the shrinking unsorted region immediately after the previous maximum's final position — building the sorted order from the **end of the array backward**, which is why the array is sorted **ascending** even though a **max**-heap was used throughout.
