# Output: Computing Parent/Child Indices Directly

```js
const parent = (i) => Math.floor((i - 1) / 2);
const leftChild = (i) => 2 * i + 1;
const rightChild = (i) => 2 * i + 2;

console.log(parent(6));
console.log(leftChild(2));
console.log(rightChild(2));
console.log(parent(leftChild(4)));
```

**Question:** What does each line print?

**Answer:**
```
parent(6)              -> 2
leftChild(2)            -> 5
rightChild(2)            -> 6
parent(leftChild(4))    -> 4
```

**Why:** `parent(6) = Math.floor((6-1)/2) = Math.floor(2.5) = 2` — index 6's parent is index 2. `leftChild(2) = 2*2+1 = 5` and `rightChild(2) = 2*2+2 = 6` — which, cross-checking against the first answer, confirms consistency: index 6 (computed as `rightChild(2)`) has `parent(6) = 2`, exactly matching. The last line demonstrates that `parent` and `leftChild`/`rightChild` are proper inverses of each other for a left child specifically: `leftChild(4) = 9`, and `parent(9) = Math.floor((9-1)/2) = 4` — you always land back on the original index. This inverse relationship (and the equivalent for `rightChild`) is worth verifying by hand at least once, since it's the exact property that guarantees the array-index math correctly encodes a genuine tree structure with no ambiguity.
