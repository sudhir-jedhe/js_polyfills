# Output: Is This Array a Valid Min-Heap?

```js
function isValidMinHeap(arr) {
  const n = arr.length;
  for (let i = 0; i < n; i++) {
    const left = 2 * i + 1, right = 2 * i + 2;
    if (left < n && arr[i] > arr[left]) return false;
    if (right < n && arr[i] > arr[right]) return false;
  }
  return true;
}

console.log(isValidMinHeap([1, 3, 2, 7, 6, 5, 9]));
console.log(isValidMinHeap([1, 3, 2, 0, 6, 5, 9]));
console.log(isValidMinHeap([1, 2, 3, 4, 5, 6]));
```

**Question:** What does each call print?

**Answer:** `true`, `false`, `true`.

**Why:** The first array `[1, 3, 2, 7, 6, 5, 9]`: check every parent-child pair — index 0 (`1`) vs. children `3, 2`: fine. Index 1 (`3`) vs. children `7, 6`: fine. Index 2 (`2`) vs. children `5, 9`: fine. No violation anywhere → `true`. Note that `arr[3]=7 > arr[2]=2` looks alarming at first glance, but `7` and `2` are **not** in a parent-child relationship (`7` is at index 3, its parent is index 1 which holds `3`, not index 2) — this is exactly why a heap only needs a **local**, parent-to-immediate-child check at every index, unlike a BST which needs a global bound check.

The second array `[1, 3, 2, 0, 6, 5, 9]` fails: index 1 (`3`) has left child at index 3, which is `0` — `3 > 0` violates the min-heap property (a parent must never exceed a child) → `false`.

The third array `[1, 2, 3, 4, 5, 6]` (which happens to be sorted ascending): checking every pair confirms every parent is ≤ both children → `true`. This illustrates that a sorted array **always** happens to satisfy the min-heap property (since `arr[i] <= arr[j]` for any `i < j` in ascending order, and children always have larger indices than their parent) — but the reverse is not true: a valid min-heap is very often **not** sorted, as shown in the earlier insert-sequence example.
