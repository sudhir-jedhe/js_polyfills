# Output: Counting Swaps — buildHeap vs. n Repeated Inserts

```js
let swapCount = 0;

function heapifyDownCounting(arr, heapSize, i) {
  while (true) {
    const left = 2 * i + 1, right = 2 * i + 2;
    let smallest = i;
    if (left < heapSize && arr[left] < arr[smallest]) smallest = left;
    if (right < heapSize && arr[right] < arr[smallest]) smallest = right;
    if (smallest === i) break;
    [arr[i], arr[smallest]] = [arr[smallest], arr[i]];
    swapCount++;
    i = smallest;
  }
}

const arr = [9, 8, 7, 6, 5, 4, 3, 2, 1]; // worst-case-ish reverse-sorted input, n = 9
for (let i = Math.floor(arr.length / 2) - 1; i >= 0; i--) {
  heapifyDownCounting(arr, arr.length, i);
}
console.log(swapCount);
```

**Question:** Roughly how many swaps does bottom-up `buildHeap` perform on this 9-element array, and how does that compare to inserting the same 9 elements one at a time into an empty heap?

**Answer:** `buildHeap` performs `7` swaps for this input (verify by tracing: `i=3` sifts `6` down past `2` then `1` — 1 swap; `i=2` sifts `7` down past `3` — 1 swap; `i=1` sifts `8` down two levels — 2 swaps; `i=0` sifts `9` down three levels — 3 swaps; total `1+1+2+3=7`). Inserting the same 9 elements one at a time (via repeated `push`, each triggering `heapifyUp`) performs more swaps in the worst case — up to `O(n log n)` total across all `n` inserts, versus `buildHeap`'s `O(n)` total.

**Why:** Bottom-up `buildHeap` only calls `heapifyDown` on **non-leaf** nodes (indices `0` through `Math.floor(n/2) - 1`, here `0..3`), and crucially, the vast majority of nodes in *any* complete tree sit near the bottom — leaves (roughly half of all nodes) need **zero** sift operations, nodes one level up sift at most 1 step, and only the single root can potentially sift all the way down `O(log n)` levels. Summing that geometric-ish distribution across all levels converges to `O(n)` total work rather than `O(n log n)`. Repeated single-element inserts don't get this benefit — every one of the `n` inserts can, in the worst case, bubble all the way up through `O(log n)` levels, since each insert only has local information about the one path from a leaf to the root, not the whole tree's structure at once — hence the `O(n log n)` bound for that approach.
