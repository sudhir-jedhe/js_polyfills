# Output: Min-Heap Array State After extractMin

```js
const heap = [1, 3, 2, 7, 4, 5, 9]; // a valid min-heap
console.log(extractMin(heap));
console.log(heap);
```

**Question:** What does `extractMin` return, and what does the array look like afterward?

**Answer:** Returns `1`. Array becomes `[2, 3, 5, 7, 4, 9]`.

**Why, traced step by step:** `extractMin` saves `heap[0] = 1` as the return value, pops the **last** element (`9`) off the array, and places it at the now-empty root: `[9, 3, 2, 7, 4, 5]` (length 6). Then `heapifyDown` runs from index 0:
- At index 0 (`9`): children are index 1 (`3`) and index 2 (`2`). Smaller child is `2` (index 2). `9 > 2`, swap → `[2, 3, 9, 7, 4, 5]`.
- Continue from index 2 (`9`): children are index `2*2+1=5` (`5`) and index `2*2+2=6` (out of bounds, array length is 6, so only index 5 exists). Smaller relevant child is `5`. `9 > 5`, swap → `[2, 3, 5, 7, 4, 9]`.
- Continue from index 5 (`9`): children would be index 11 and 12, both out of bounds — no children, loop ends.

Final array: `[2, 3, 5, 7, 4, 9]`.

**Why swap-with-last instead of just shifting everything left:** shifting every remaining element to fill the gap at the root would be `O(n)`. Moving the last element into the vacated root and sifting it down is only `O(log n)`, since it only ever needs to travel down at most `height` levels — this is the entire reason extraction is efficient.
