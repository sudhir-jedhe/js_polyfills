# Heap Sort

Heap sort uses a heap's "root is always the extreme element" property to produce a fully sorted array, entirely **in place** with no extra array allocation (unlike merge sort), by repeatedly extracting the max (for ascending output) and placing it at the end of the shrinking unsorted region.

## Algorithm

1. **Build a max-heap** from the input array, in place, using bottom-up heapify — `O(n)`.
2. Repeatedly: **swap the root (current maximum) with the last element of the current unsorted region**, shrink the "heap size" boundary by one (excluding the now-placed element), then `heapifyDown` from the root to restore the heap property over the smaller remaining region.
3. After `n - 1` such extractions, the array is fully sorted in ascending order.

```js
function heapSort(arr) {
  const n = arr.length;

  // Step 1: build max-heap in place, O(n)
  for (let i = Math.floor(n / 2) - 1; i >= 0; i--) {
    heapifyDown(arr, n, i);
  }

  // Step 2: repeatedly extract max, place at the end, shrink heap boundary
  for (let end = n - 1; end > 0; end--) {
    [arr[0], arr[end]] = [arr[end], arr[0]]; // move current max to its final sorted position
    heapifyDown(arr, end, 0); // restore heap property over arr[0..end-1] only
  }

  return arr;
}

function heapifyDown(arr, heapSize, i) {
  while (true) {
    const left = 2 * i + 1;
    const right = 2 * i + 2;
    let largest = i;
    if (left < heapSize && arr[left] > arr[largest]) largest = left;
    if (right < heapSize && arr[right] > arr[largest]) largest = right;
    if (largest === i) break;
    [arr[i], arr[largest]] = [arr[largest], arr[i]];
    i = largest;
  }
}

console.log(heapSort([5, 3, 8, 1, 9, 2])); // [1, 2, 3, 5, 8, 9]
```

Note the max-heap (not min-heap) choice for **ascending** output: extracting the max repeatedly and placing each one at the shrinking array's *end* naturally builds the sorted order from the back forward.

## Complexity and properties

| | Value |
|---|---|
| Time (build heap) | `O(n)` |
| Time (n extractions, each `O(log n)`) | `O(n log n)` |
| Overall time | `O(n log n)` — all cases (best, average, worst) |
| Space | `O(1)` extra — sorts in place, unlike merge sort's `O(n)` |
| Stable? | **No** — equal elements can be reordered relative to each other, since swaps during heapify don't preserve original relative order |

## Heap sort vs. quicksort vs. merge sort — quick comparison

| | Heap Sort | Quicksort | Merge Sort |
|---|---|---|---|
| Worst-case time | `O(n log n)` (guaranteed) | `O(n²)` (rare, poor pivot choices) | `O(n log n)` (guaranteed) |
| Extra space | `O(1)` | `O(log n)` (recursion stack) | `O(n)` |
| Stable | No | No (typically) | Yes |
| Practical speed | Generally slower in practice (poor cache locality from jumping around the array) | Usually fastest in practice despite worst case | Solid, predictable |

Heap sort's main selling point is the **combination** of `O(n log n)` worst-case guarantee **and** `O(1)` extra space — quicksort matches the space but not the worst-case time guarantee, and merge sort matches the time guarantee but not the space. In practice, quicksort (or hybrid approaches like introsort) is more commonly used in language standard libraries because heap sort's cache-unfriendly memory access pattern makes it slower in real-world benchmarks despite the same asymptotic bound.
