# Binary Heap Structure and Array Representation

A **binary heap** is a **complete** binary tree (every level fully filled except possibly the last, which fills left to right with no gaps) that additionally satisfies a **heap property**:

- **Min-heap:** every parent's value is ≤ both of its children's values (the minimum element is always at the root).
- **Max-heap:** every parent's value is ≥ both of its children's values (the maximum element is always at the root).

Note this is a much weaker ordering guarantee than a BST — a heap only constrains parent-vs-child, not left-vs-right or any relationship between siblings/cousins, which is exactly why heap operations are cheaper (`O(log n)` insert/remove, but no `O(log n)` arbitrary search — a heap doesn't support efficient "find value X" the way a BST does).

## Why "complete" enables an array representation

Because a complete binary tree has no gaps (every level is packed left-to-right), its shape is **entirely determined by the node count** — there's no need to store explicit `left`/`right` child pointers at all. Instead, a heap is stored as a plain flat array, with parent-child relationships computed purely from index arithmetic:

```
Heap (min-heap):              Array representation:
        1                     index:  0  1  2  3  4  5  6
       / \                    value:  1  3  2  5  4  8  9
      3   2
     / \ / \
    5  4 8  9
```

## The index math (memorize this cold)

| Relationship | Formula (0-indexed array) |
|---|---|
| Parent of index `i` | `Math.floor((i - 1) / 2)` |
| Left child of index `i` | `2i + 1` |
| Right child of index `i` | `2i + 2` |

```js
const parent = (i) => Math.floor((i - 1) / 2);
const leftChild = (i) => 2 * i + 1;
const rightChild = (i) => 2 * i + 2;

// verify against the array above: value at index 3 is 5
console.log(parent(3));       // 1 -> array[1] = 3, which is 5's parent. Correct.
console.log(leftChild(1));    // 3 -> array[3] = 5, 3's left child. Correct.
console.log(rightChild(1));   // 4 -> array[4] = 4, 3's right child. Correct.
```

## Why an array beats an explicit node/pointer tree here

- **No pointer overhead** — no `left`/`right`/`parent` object references to allocate and follow, just arithmetic on plain integer indices into a contiguous array.
- **Cache-friendly** — contiguous memory access patterns are significantly faster in practice than chasing pointers scattered across the heap (the memory heap, not the data structure — unfortunate naming collision).
- **Trivial "last element" access** — the last element in a complete tree is always simply the array's last index, which is exactly what heap insert/delete operations need to swap with (see the heapify-up/down theory file).

## Complete vs. other binary tree shapes (quick reminder)

| Shape | Guarantee |
|---|---|
| **Complete** (what heaps require) | Every level full except possibly the last, which fills left-to-right with no gaps |
| **Full** | Every node has 0 or 2 children (says nothing about level-fullness) |
| **Perfect** | Every level fully filled, all leaves at the same depth (strictest — always complete and full too) |

A heap's completeness is exactly what guarantees `O(log n)` height for `n` elements — `height = floor(log₂ n)` — which is the foundation for every `O(log n)` heap operation.
