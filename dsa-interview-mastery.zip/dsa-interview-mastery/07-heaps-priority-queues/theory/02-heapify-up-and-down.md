# Heapify Up and Heapify Down

Both heap operations that change the element count (`insert` and `extractMin`/`extractMax`) work by making a small, possibly heap-property-violating change at one end of the array, then "bubbling" that violation toward its correct resting place via repeated swaps. Which direction you bubble depends on which operation just happened.

## Heapify Up (sift-up) — used after `insert`

Insert always appends the new element at the **end** of the array (the next available complete-tree slot), which may violate the heap property against its new parent. Fix it by repeatedly comparing the new element to its parent and swapping upward until either the property holds or the root is reached.

```js
function heapifyUp(heap, index) {
  while (index > 0) {
    const parentIndex = Math.floor((index - 1) / 2);
    if (heap[index] >= heap[parentIndex]) break; // min-heap: already correctly placed
    [heap[index], heap[parentIndex]] = [heap[parentIndex], heap[index]];
    index = parentIndex; // continue bubbling from the new position
  }
}

// insert(5) into min-heap [1, 3, 2, 7, 4]
const heap = [1, 3, 2, 7, 4];
heap.push(5); // append: [1, 3, 2, 7, 4, 5] — 5's parent is index 2 (value 2), no violation, loop breaks immediately
heapifyUp(heap, heap.length - 1);
console.log(heap); // [1, 3, 2, 7, 4, 5] — unchanged, 5 >= 2 already satisfies min-heap property
```

Each swap moves the element up exactly one level, and there are at most `height = O(log n)` levels to climb, so `heapifyUp` is `O(log n)`.

## Heapify Down (sift-down) — used after `extractMin`/`extractMax`

Extracting the root removes the single most important element, leaving a hole at index 0. Rather than shifting everything (expensive), take the **last** element in the array, move it to the now-empty root position, shrink the array by one, and then bubble that relocated element **down** by repeatedly swapping it with its **smaller** child (min-heap) until the property holds.

```js
function heapifyDown(heap, index) {
  const n = heap.length;
  while (true) {
    const left = 2 * index + 1;
    const right = 2 * index + 2;
    let smallest = index;

    if (left < n && heap[left] < heap[smallest]) smallest = left;
    if (right < n && heap[right] < heap[smallest]) smallest = right;
    if (smallest === index) break; // both children are >= current — correctly placed

    [heap[index], heap[smallest]] = [heap[smallest], heap[index]];
    index = smallest;
  }
}

function extractMin(heap) {
  const min = heap[0];
  const last = heap.pop();
  if (heap.length > 0) {
    heap[0] = last;
    heapifyDown(heap, 0);
  }
  return min;
}

console.log(extractMin([1, 3, 2, 7, 4, 5])); // 1
```

## Critical detail: compare against the **smaller** (or larger) child, not just one arbitrarily

A common bug is comparing the sifting element to only its left child (or always picking one side). The correct rule (min-heap): find whichever of the two children is smaller, and swap with *that* one — swapping with the larger child could leave the heap property violated against the smaller child that got skipped.

## Complexity summary

| Operation | Time | Why |
|---|---|---|
| `heapifyUp` | `O(log n)` | At most one swap per level, `O(log n)` levels |
| `heapifyDown` | `O(log n)` | Same — at most one swap per level |
| `insert` (append + heapifyUp) | `O(log n)` | Dominated by heapifyUp |
| `extractMin`/`extractMax` (swap-with-last + pop + heapifyDown) | `O(log n)` | Dominated by heapifyDown |
| `peek` (read root) | `O(1)` | Root is always `heap[0]` |
