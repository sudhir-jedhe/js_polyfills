# Min-Heap vs. Max-Heap

The only difference between a min-heap and a max-heap is the direction of every comparison — the array representation, index math, and overall structure are identical.

| | Min-Heap | Max-Heap |
|---|---|---|
| Root holds | The smallest element | The largest element |
| Parent-child invariant | `parent <= child` | `parent >= child` |
| `heapifyUp` swap condition | Swap if `child < parent` | Swap if `child > parent` |
| `heapifyDown` swap target | Swap with the **smaller** child | Swap with the **larger** child |
| Typical uses | Dijkstra's algorithm, kth **largest** element (counterintuitively — see below), scheduling "smallest deadline first" | kth **smallest** element, "largest first" scheduling, max-heap-based heap sort (ascending output) |

## A flip trick worth knowing: implementing a max-heap using a min-heap

Since JavaScript arrays and generic comparators make it easy to invert comparisons, many implementations get both behaviors from **one** heap class by accepting a custom comparator function, rather than writing separate `MinHeap` and `MaxHeap` classes:

```js
class Heap {
  constructor(compare) {
    this.data = [];
    this.compare = compare; // (a, b) => negative if a should be higher priority (closer to root)
  }
  // ... insert/extract use this.compare(...) < 0 instead of a hardcoded < or >
}

const minHeap = new Heap((a, b) => a - b);       // smaller values bubble toward the root
const maxHeap = new Heap((a, b) => b - a);       // larger values bubble toward the root
```

A simpler ad hoc trick when you only have a `MinHeap` and need max-heap behavior for numbers: **negate every value on insert, and negate again on extraction.** Pushing `-x` into a min-heap makes the most negative (i.e., originally largest) `x` bubble to the root.

```js
const minHeap = new MinHeap();
for (const num of [3, 1, 4, 1, 5]) minHeap.push(-num); // store negated
console.log(-minHeap.pop()); // 5 — the "max" comes out first, via the min-heap's normal behavior
```

## The counterintuitive part: kth **largest** uses a **min**-heap

This trips people up constantly. To find the kth largest element efficiently, you maintain a **min-heap of size k** containing the k largest elements seen so far — the heap's root (the minimum of that top-k group) is the *cutoff*: any new element smaller than the current root can't possibly be in the top k, so it's discarded immediately without even entering the heap; the moment a new element beats the root, the root (now guaranteed not to be in the true top k) is popped and the new element takes its place. After processing everything, the min-heap's root **is** the kth largest element. The reasoning is symmetric for kth smallest, which uses a max-heap of size k instead.

## Choosing which to use — a simple heuristic

Ask: "which extreme do I need repeated, efficient access to?" If the answer is "the smallest," use a min-heap. If "the largest," use a max-heap. For "kth largest/smallest of size k," the heap type is the **opposite** of the target — because the heap's root needs to represent the *weakest* member of the current top-k group, so it can be evicted the moment something better shows up.
