# Implementing a Priority Queue from Scratch in JavaScript

JavaScript's standard library has arrays, `Map`, and `Set` — but **no built-in heap or priority queue**, unlike Python (`heapq`), Java (`PriorityQueue`), or C++ (`priority_queue`). This makes "implement a priority queue" one of the most common from-scratch implementation asks in JS-specific interviews, both as a standalone question and as a prerequisite for problems like Dijkstra's algorithm, merge-k-sorted-lists, and top-K anything.

A priority queue is just a binary heap wrapped with queue-shaped method names (`enqueue`/`dequeue` instead of `insert`/`extract`) and, critically, a **custom comparator** so it can prioritize arbitrary objects, not just raw numbers.

```js
class PriorityQueue {
  constructor(compare = (a, b) => a - b) {
    this.heap = [];
    this.compare = compare; // returns < 0 if a has higher priority than b
  }

  size() { return this.heap.length; }
  isEmpty() { return this.heap.length === 0; }
  peek() { return this.heap[0]; }

  push(value) {
    this.heap.push(value);
    this._heapifyUp(this.heap.length - 1);
  }

  pop() {
    if (this.heap.length === 0) return undefined;
    const top = this.heap[0];
    const last = this.heap.pop();
    if (this.heap.length > 0) {
      this.heap[0] = last;
      this._heapifyDown(0);
    }
    return top;
  }

  _heapifyUp(i) {
    while (i > 0) {
      const parent = Math.floor((i - 1) / 2);
      if (this.compare(this.heap[i], this.heap[parent]) >= 0) break;
      [this.heap[i], this.heap[parent]] = [this.heap[parent], this.heap[i]];
      i = parent;
    }
  }

  _heapifyDown(i) {
    const n = this.heap.length;
    while (true) {
      const left = 2 * i + 1;
      const right = 2 * i + 2;
      let best = i;
      if (left < n && this.compare(this.heap[left], this.heap[best]) < 0) best = left;
      if (right < n && this.compare(this.heap[right], this.heap[best]) < 0) best = right;
      if (best === i) break;
      [this.heap[i], this.heap[best]] = [this.heap[best], this.heap[i]];
      i = best;
    }
  }
}
```

## Usage — the comparator makes it work for anything

```js
// numbers, min-priority (smallest number = highest priority)
const pq = new PriorityQueue((a, b) => a - b);
[5, 1, 8, 2].forEach(n => pq.push(n));
console.log(pq.pop()); // 1
console.log(pq.pop()); // 2

// objects — e.g. task scheduler, lower "priority" number = more urgent
const tasks = new PriorityQueue((a, b) => a.priority - b.priority);
tasks.push({ name: 'send email', priority: 3 });
tasks.push({ name: 'fix outage', priority: 1 });
tasks.push({ name: 'write docs', priority: 5 });
console.log(tasks.pop().name); // 'fix outage' — lowest priority number dequeued first
```

## Building from an existing array in O(n) instead of n × O(log n)

If you already have all `n` elements upfront (rather than pushing them one at a time), calling `push` in a loop costs `O(n log n)` overall. A **bottom-up heapify** builds the same valid heap in `O(n)`: call `heapifyDown` starting from the last **non-leaf** node and working backward to the root, skipping leaves entirely (a leaf is trivially already a valid 1-node heap).

```js
function buildHeap(arr, compare = (a, b) => a - b) {
  const heap = [...arr];
  const n = heap.length;
  const lastNonLeaf = Math.floor(n / 2) - 1;
  for (let i = lastNonLeaf; i >= 0; i--) {
    heapifyDownInPlace(heap, i, compare);
  }
  return heap;
}
```

This `O(n)` bound (rather than the more intuitive-seeming `O(n log n)`) comes from the fact that most nodes in a complete tree are near the bottom, close to their final resting place — only a small fraction of nodes are near the root and need to sift down through many levels, and the math works out to a convergent sum that's linear in `n`. This is a genuinely common interview follow-up ("can you build the heap faster than n inserts?") worth having ready.
