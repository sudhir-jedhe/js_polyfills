# Heaps & Priority Queues

A binary heap is a complete binary tree stored compactly in a plain array, with one ordering invariant (min-heap: every parent ≤ its children; max-heap: every parent ≥ its children) that makes "find the smallest/largest element" an `O(1)` operation and "insert" / "remove the smallest/largest" `O(log n)` operations. This is one of the most practically important interview topics precisely because **JavaScript has no built-in heap or priority queue** — unlike arrays, maps, and sets, you're expected to know how to build one from scratch, and this "implement a priority queue" ask shows up constantly, both standalone and as a required building block inside bigger problems (Dijkstra's algorithm, merge k sorted lists, top-K anything).

## Folder structure

- **`theory/`** — binary heap structure & array representation, heapify up/down mechanics, min-heap vs. max-heap, building a priority queue from scratch, and heap sort.
- **`snippets/`** — 6 focused, runnable code examples: a `MinHeap` class, a `MaxHeap` class, in-place array heapify, a priority queue with a custom comparator, heap sort, and kth-largest via a heap.
- **`output-based/`** — 6 "what does the heap array look like / what's the parent-child index" questions with the answer worked out step by step.
- **`scenarios/`** — 4 real-world situations where a heap is the right structure: task scheduling by priority, merging sorted log streams, trending-topic top-K tracking, and Dijkstra's priority queue choice.
- **`interview-qa/`** — 9 Q&A pairs grouped into 3 themed files: heap fundamentals, implementation/complexity, and applications.
- **`problems/`** — 6 hands-on coding challenges: kth largest element, merge k sorted lists, top k frequent elements, find median from a data stream, k closest points to origin, and last stone weight.
- **`assets/`** — placeholder for diagrams/images (see `assets/README.md`).

## What's covered

- The complete-binary-tree shape and its array representation: `parent(i) = floor((i-1)/2)`, `leftChild(i) = 2i+1`, `rightChild(i) = 2i+2`
- `heapifyUp` (sift-up, used after insert) and `heapifyDown` (sift-down, used after extracting the root)
- Min-heap vs. max-heap — the same code with one comparison flipped
- A from-scratch, generic `PriorityQueue` implementation with a custom comparator (since this is the standard "implement it" interview ask in JS)
- `buildHeap` in `O(n)` (bottom-up heapify) vs. `n` repeated inserts in `O(n log n)` — and why the difference matters
- Heap sort — `O(n log n)` time, `O(1)` extra space, not stable
- Classic problems: kth largest, merge k sorted lists, top-K frequent, running median (two-heap technique), k closest points, last stone weight
