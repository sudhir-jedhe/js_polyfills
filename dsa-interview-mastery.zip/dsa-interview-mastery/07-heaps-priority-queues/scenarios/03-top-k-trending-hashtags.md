# Scenario: Tracking the Top-K Trending Hashtags in Real Time

**Scenario:** A social platform needs a "trending now" feature: given a continuous stream of posts, each tagged with hashtags, maintain the top 10 most-used hashtags at any given moment, updated as new posts arrive. The total number of distinct hashtags ever seen can be huge (millions), but you only ever need the current top 10.

**Diagnosis:** Re-sorting the entire hashtag frequency table every time a new post arrives, just to read off the top 10, is wasteful — that's `O(m log m)` per update where `m` is the number of distinct hashtags, when you only actually care about a tiny slice of that sorted order.

**Fix — maintain frequency counts in a hash map, and a min-heap of size k for the current top-k:** update the count for the tagged hashtag in `O(1)` via the hash map on every new post. To get "current top 10" efficiently without re-sorting everything, maintain a min-heap capped at size `k` (`10`), using the same "min-heap of size k gives the top-k" pattern as the kth-largest-element problem: any candidate whose count is less than the heap's current minimum can't be in the top 10, so it's skipped; anything that beats the current minimum evicts it.

```js
function getTopKHashtags(hashtagCounts, k) {
  // hashtagCounts: Map<hashtag, count> — the up-to-date frequency table
  const minHeap = new PriorityQueue((a, b) => a.count - b.count);

  for (const [hashtag, count] of hashtagCounts) {
    minHeap.push({ hashtag, count });
    if (minHeap.size() > k) minHeap.pop(); // evict the current lowest-count entry
  }

  const result = [];
  while (!minHeap.isEmpty()) result.push(minHeap.pop());
  return result.reverse(); // heap pops smallest first — reverse for highest-count-first display
}
```

**Why a min-heap of size k, not a max-heap of all hashtags:** a max-heap containing *every* distinct hashtag would need `O(m)` space and `O(log m)` per update regardless of `k` — wasteful when `m` (millions of hashtags) vastly exceeds `k` (10). Capping the heap at size `k` bounds its size to a small constant, and only hashtags that are genuinely competitive for the top-10 spot ever get pushed onto it (in a full streaming implementation, this rebuild would be triggered periodically/incrementally, not from scratch on every single post — but the top-k extraction logic itself is exactly this `O(m log k)` heap pattern, dramatically cheaper than `O(m log m)` full sorting when `k` is small and `m` is large).

**General pattern to recognize:** "top-K out of a huge or streaming dataset" is one of the strongest, most reliable heap signals in interviews — whenever `k` is small relative to the total data size, a size-`k` heap turns an `O(m log m)` sort into an `O(m log k)` streaming-friendly computation.
