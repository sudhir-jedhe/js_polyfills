# Scenario: Building a Priority-Based Task Scheduler

**Scenario:** You're building a background job scheduler: jobs are submitted continuously with a priority level, and a worker process should always pull the highest-priority pending job next, regardless of submission order. New jobs can be added at any time, even while other jobs are waiting. What data structure fits, and why not a sorted array?

**Diagnosis:** A sorted array (keeping jobs ordered by priority at all times) gives `O(1)` access to the highest-priority job, but every **insertion** of a new job requires finding its correct position and shifting elements to make room — `O(n)` per insert. A plain unsorted array/queue gives `O(1)` insert but requires an `O(n)` linear scan every time you need "the highest priority job" — neither extreme is good when both operations (frequent inserts as jobs stream in, frequent extraction as the worker processes them) need to be fast.

**Fix — a binary heap (priority queue):** a heap gives `O(log n)` insert **and** `O(log n)` extraction of the highest-priority element, with `O(1)` peek — the right balance for a workload where both operations happen constantly and neither can be neglected.

```js
// lower number = more urgent, dequeued first
const jobQueue = new PriorityQueue((a, b) => a.priority - b.priority);

jobQueue.push({ id: 'resize-image-42', priority: 5 });
jobQueue.push({ id: 'send-password-reset-email', priority: 1 }); // urgent — security-sensitive
jobQueue.push({ id: 'generate-weekly-report', priority: 8 });

// worker loop
while (!jobQueue.isEmpty()) {
  const job = jobQueue.pop(); // always the current most urgent
  console.log('processing:', job.id);
}
// processing: send-password-reset-email
// processing: resize-image-42
// processing: generate-weekly-report
```

**Follow-up — dynamic priority changes ("aging"):** many real schedulers need to gradually increase a stale job's priority the longer it waits, to avoid starvation. A plain binary heap doesn't support efficient "decrease the priority of an arbitrary already-inserted element" (finding an arbitrary element is `O(n)`, since a heap has no fast search) — that requires either an **indexed/updatable priority queue** (maintaining a hash map from job ID to its current heap index, updated on every swap, so an arbitrary element's position is always known in `O(1)`) or periodically rebuilding the heap. Worth naming this limitation explicitly if an interviewer pushes on it — it's a genuine, well-known heap limitation, not something to paper over.
