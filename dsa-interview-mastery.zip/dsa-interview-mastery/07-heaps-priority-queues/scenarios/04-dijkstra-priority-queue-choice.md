# Scenario: Why Dijkstra's Algorithm Specifically Needs a Priority Queue

**Scenario:** An interviewer asks you to implement Dijkstra's shortest-path algorithm and you reach for a plain array to track "unvisited nodes with their current known distances," scanning it linearly each iteration to find the minimum. They then ask: "how would you speed this up?" What's the expected answer, and why does it matter?

**Diagnosis:** The naive approach — a plain array/set of unvisited nodes, linearly scanned every iteration to find the current minimum-distance node — costs `O(V)` per "find the minimum" operation, and this happens once per vertex processed, giving `O(V²)` total just for the minimum-finding part (plus `O(E)` for edge relaxation, so `O(V² + E)` overall). This is perfectly fine for small or dense graphs, but scales poorly for large sparse graphs, where `E` is much closer to `V` than to `V²`.

**Fix — a min-priority queue keyed on current known distance:** since Dijkstra's core loop is fundamentally "repeatedly extract the not-yet-finalized node with the smallest known distance, then possibly update (decrease) some neighbors' distances" — that's precisely what a min-heap-backed priority queue is built for. Swapping the linear scan for a heap-based priority queue brings the minimum-extraction cost down from `O(V)` to `O(log V)` per operation.

```js
function dijkstra(graph, start) {
  const dist = new Map();
  for (const v of graph.keys()) dist.set(v, Infinity);
  dist.set(start, 0);

  const pq = new PriorityQueue((a, b) => a.dist - b.dist);
  pq.push({ node: start, dist: 0 });

  while (!pq.isEmpty()) {
    const { node, dist: d } = pq.pop();
    if (d > dist.get(node)) continue; // stale entry from an earlier, since-improved push — skip it

    for (const [neighbor, weight] of graph.get(node)) {
      const newDist = d + weight;
      if (newDist < dist.get(neighbor)) {
        dist.set(neighbor, newDist);
        pq.push({ node: neighbor, dist: newDist }); // push a fresh, better entry rather than mutating in place
      }
    }
  }
  return dist;
}
```

**Why "push a new entry" instead of "decrease the existing entry's priority":** a textbook Dijkstra description says "decrease-key" the neighbor's priority in the queue — but a plain binary heap doesn't support efficient arbitrary decrease-key without also maintaining a hash map from node to its current heap index (an "indexed priority queue"), which is real extra complexity. The pragmatic, commonly-accepted JS interview approach instead just **pushes a new entry** every time a shorter distance is found, leaving old, now-stale entries in the heap, and simply **skips** any popped entry whose recorded distance no longer matches the current best-known distance (the `if (d > dist.get(node)) continue` check) — trading a slightly larger heap (up to `O(E)` entries instead of `O(V)`) for much simpler code, without changing the overall `O((V+E) log V)` complexity class.

**Takeaway for the interview:** naming "min-priority queue, because I always need the next-closest unfinalized node efficiently" as the reason a heap fits Dijkstra — not just "heaps are fast" — is what demonstrates real understanding of *why* the algorithm and the data structure pair together.
