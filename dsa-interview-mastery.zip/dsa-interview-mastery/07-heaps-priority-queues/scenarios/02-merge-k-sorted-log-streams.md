# Scenario: Merging K Sorted Log Streams into One Timeline

**Scenario:** You're building a log aggregation tool that pulls logs from `k` different servers. Each server's individual log stream is already sorted by timestamp (logs are appended in order), but you need to merge all `k` streams into one single, globally time-ordered stream for display — and `k` can be large (hundreds of servers), with each stream potentially very long (can't load an entire stream fully into memory at once).

**Diagnosis:** Naively concatenating all streams and sorting the combined result is `O(N log N)` where `N` is the total number of log lines across all servers — wasteful, since it throws away the fact that each individual stream is *already* sorted. A pairwise merge (merge stream 1 with stream 2, then merge that result with stream 3, and so on) does better but still degrades to `O(N · k)` in the worst case, since each of the `k` merge passes touches a large fraction of the accumulated result.

**Fix — a min-heap holding one "current head" entry per stream:** initialize the heap with the first (earliest) entry from each of the `k` streams, tagged with which stream it came from. Repeatedly pop the minimum (globally earliest timestamp across all streams' current heads), emit it, and push the **next** entry from that same stream (if any) back into the heap. This never needs more than `k` entries in the heap at once, regardless of how long each individual stream is.

```js
function mergeKSortedStreams(streams) {
  // streams: array of k arrays, each already sorted by timestamp
  const minHeap = new PriorityQueue((a, b) => a.entry.timestamp - b.entry.timestamp);
  const pointers = new Array(streams.length).fill(0);

  streams.forEach((stream, streamIndex) => {
    if (stream.length > 0) {
      minHeap.push({ entry: stream[0], streamIndex });
      pointers[streamIndex] = 1;
    }
  });

  const merged = [];
  while (!minHeap.isEmpty()) {
    const { entry, streamIndex } = minHeap.pop();
    merged.push(entry);

    const nextIndex = pointers[streamIndex];
    if (nextIndex < streams[streamIndex].length) {
      minHeap.push({ entry: streams[streamIndex][nextIndex], streamIndex });
      pointers[streamIndex] = nextIndex + 1;
    }
  }

  return merged;
}
```

**Why this beats naive concatenate-and-sort:** the heap never holds more than `k` elements at a time (one "current candidate" per stream), so each pop/push is `O(log k)` rather than `O(log N)` — and since every one of the `N` total entries is pushed and popped exactly once, the total cost is `O(N log k)`, which is significantly better than `O(N log N)` whenever `k` (number of streams) is much smaller than `N` (total log volume) — a very common real-world shape (hundreds of servers, millions of log lines).

**This is the exact same pattern as "merge k sorted linked lists"** — a classic interview problem — just with log entries instead of linked-list nodes and array indices instead of `.next` pointers.
