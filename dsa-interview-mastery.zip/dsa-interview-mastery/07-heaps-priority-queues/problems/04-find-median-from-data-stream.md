# Problem: Find Median from a Data Stream

## Problem Statement

Design a data structure that supports adding integers one at a time from a stream (`addNum`) and, at any point, efficiently returning the median of all numbers added so far (`findMedian`).

## Examples

```
addNum(1); addNum(2);
findMedian(); // 1.5  (average of 1 and 2)
addNum(3);
findMedian(); // 2    (middle of 1, 2, 3)
```

## Constraints

- Up to `5 * 10^4` calls total to `addNum` and `findMedian` combined.
- `-10^5 <= num <= 10^5`

## Approach

The classic **two-heap** technique: maintain a max-heap (`lower`) holding the smaller half of all numbers seen so far, and a min-heap (`upper`) holding the larger half, keeping their sizes balanced (differing by at most 1 element). The median is then always immediately available from the two heaps' roots — no scanning or sorting needed at query time.

On every `addNum`: decide which heap the new number belongs in by comparing it to `lower`'s current max, push it there, then rebalance sizes if they've drifted more than 1 apart by moving one element across.

## Solution

```js
class MedianFinder {
  constructor() {
    this.lower = new PriorityQueue((a, b) => b - a); // max-heap: smaller half
    this.upper = new PriorityQueue((a, b) => a - b);  // min-heap: larger half
  }

  addNum(num) {
    if (this.lower.isEmpty() || num <= this.lower.peek()) {
      this.lower.push(num);
    } else {
      this.upper.push(num);
    }

    // rebalance: keep sizes equal, or lower ahead by at most 1
    if (this.lower.size() > this.upper.size() + 1) {
      this.upper.push(this.lower.pop());
    } else if (this.upper.size() > this.lower.size()) {
      this.lower.push(this.upper.pop());
    }
  }

  findMedian() {
    if (this.lower.size() > this.upper.size()) return this.lower.peek();
    return (this.lower.peek() + this.upper.peek()) / 2;
  }
}

module.exports = { MedianFinder };

// --- verification ---
const mf = new MedianFinder();
mf.addNum(1);
mf.addNum(2);
console.log(mf.findMedian()); // 1.5
mf.addNum(3);
console.log(mf.findMedian()); // 2
mf.addNum(0);
console.log(mf.findMedian()); // 1.5  (sorted so far: 0,1,2,3 -> avg of middle two)
```

**Why size balancing must never drift more than 1:** if `lower` (smaller half) and `upper` (larger half) sizes ever differed by more than 1, the median could no longer be read directly from just the two roots — you'd need to know how far "into" the larger heap the true middle element sits, defeating the whole point. Enforcing the balance invariant on every single insert is what keeps `findMedian` an `O(1)` operation.

## Complexity

- **`addNum`:** `O(log n)` — one heap push plus at most one rebalancing push/pop, each `O(log n)`.
- **`findMedian`:** `O(1)` — direct root reads.
- **Space:** `O(n)` total across both heaps.
