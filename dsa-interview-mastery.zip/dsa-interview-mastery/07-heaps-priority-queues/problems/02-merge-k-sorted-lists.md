# Problem: Merge K Sorted Linked Lists

## Problem Statement

Given an array of `k` linked lists, each already sorted in ascending order, merge them all into one single sorted linked list and return its head.

```js
class ListNode {
  constructor(val, next = null) {
    this.val = val;
    this.next = next;
  }
}
```

## Examples

```
Input: lists = [[1,4,5], [1,3,4], [2,6]]
Output: [1,1,2,3,4,4,5,6]
```

## Constraints

- `0 <= k <= 10^4`
- `0 <= length of each list <= 500`
- `-10^4 <= Node.val <= 10^4`

## Approach

Maintain a min-heap holding the **current head node** of each of the `k` lists (never more than `k` nodes in the heap at once). Repeatedly pop the globally smallest head, append it to the result, and if that node had a `.next`, push that next node into the heap in its place — the exact same "one representative per source, refill on pop" pattern as merging k sorted arrays/streams.

## Solution

```js
function mergeKLists(lists) {
  const minHeap = new PriorityQueue((a, b) => a.val - b.val);

  for (const node of lists) {
    if (node) minHeap.push(node);
  }

  const dummy = new ListNode(0);
  let tail = dummy;

  while (!minHeap.isEmpty()) {
    const node = minHeap.pop();
    tail.next = node;
    tail = tail.next;
    if (node.next) minHeap.push(node.next);
  }

  return dummy.next;
}

module.exports = { mergeKLists };

// --- verification ---
function buildList(arr) {
  const dummy = new ListNode(0);
  let tail = dummy;
  for (const v of arr) { tail.next = new ListNode(v); tail = tail.next; }
  return dummy.next;
}
function listToArray(node) {
  const out = [];
  while (node) { out.push(node.val); node = node.next; }
  return out;
}

const lists = [buildList([1, 4, 5]), buildList([1, 3, 4]), buildList([2, 6])];
console.log(listToArray(mergeKLists(lists))); // [1, 1, 2, 3, 4, 4, 5, 6]
console.log(listToArray(mergeKLists([])));      // []
```

## Complexity

- **Time:** `O(N log k)` where `N` is the total number of nodes across all lists — every node is pushed and popped exactly once (`O(log k)` each, since the heap never exceeds size `k`).
- **Space:** `O(k)` for the heap, plus `O(N)` for the output list (though the output reuses existing nodes rather than allocating new ones, so no extra node-allocation cost beyond the merged structure itself).
