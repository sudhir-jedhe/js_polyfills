# Problem: K Closest Points to Origin

## Problem Statement

Given an array of `points` where `points[i] = [x, y]`, return the `k` points closest to the origin `(0, 0)`, using standard Euclidean distance. The answer can be returned in any order.

## Examples

```
Input: points = [[1,3],[-2,2]], k = 1
Output: [[-2,2]]   (distance sqrt(8) ≈ 2.83, vs sqrt(10) ≈ 3.16 for [1,3])

Input: points = [[3,3],[5,-1],[-2,4]], k = 2
Output: [[3,3],[-2,4]]
```

## Constraints

- `1 <= k <= points.length <= 10^4`
- `-10^4 <= x, y <= 10^4`

## Approach

Same size-k-heap pattern used throughout this topic, just with squared Euclidean distance as the comparison key (no need for an actual `Math.sqrt` — since square root is monotonically increasing, comparing squared distances gives identical ordering while avoiding unnecessary floating-point operations). Maintain a **max-heap of size k**: push points, and evict the current farthest one whenever the heap exceeds size `k` — the opposite heap type from "kth largest," since here we want to keep the k *closest* (smallest distance) and therefore need fast access to the current *worst* (farthest) of the tracked group in order to evict it.

## Solution

```js
function kClosest(points, k) {
  const squaredDist = ([x, y]) => x * x + y * y;

  const maxHeap = new PriorityQueue((a, b) => squaredDist(b) - squaredDist(a)); // farthest at the root

  for (const point of points) {
    maxHeap.push(point);
    if (maxHeap.size() > k) maxHeap.pop(); // evict the current farthest of the tracked group
  }

  const result = [];
  while (!maxHeap.isEmpty()) result.push(maxHeap.pop());
  return result;
}

module.exports = { kClosest };

// --- verification ---
console.log(kClosest([[1, 3], [-2, 2]], 1)); // [[-2, 2]]
console.log(kClosest([[3, 3], [5, -1], [-2, 4]], 2)); // [[-2,4], [3,3]] (order may vary; both are the 2 closest)
```

**Why a max-heap here, when "kth largest" used a min-heap:** the rule is "the heap needs fast access to whichever element should be evicted next." For "k largest," the weakest member of the tracked top-k group is the *smallest* one, so a min-heap fits. For "k closest," the weakest member of the tracked closest-k group is the *farthest* one, so a max-heap fits — the heap type always ends up being the "opposite" of the quantity you're ultimately optimizing for, because it needs to expose the current worst candidate for eviction, not the current best one.

## Complexity

- **Time:** `O(n log k)` — `n` pushes/pops, each `O(log k)` since the heap is capped at size `k`.
- **Space:** `O(k)` for the heap.
