# Problem: Top K Frequent Elements

## Problem Statement

Given an integer array `nums` and an integer `k`, return the `k` most frequent elements. The answer can be returned in any order.

## Examples

```
Input: nums = [1,1,1,2,2,3], k = 2
Output: [1,2]

Input: nums = [1], k = 1
Output: [1]
```

## Constraints

- `1 <= nums.length <= 10^5`
- `k` is always valid (`1 <= k <= number of distinct elements`).

## Approach

Two-step pattern: first, count frequencies with a hash map (`O(n)`). Then, rather than sorting all distinct elements by frequency (`O(m log m)` for `m` distinct elements), use a **min-heap of size k** keyed on frequency — same "cap the heap at size k, evict the weakest" pattern as kth-largest-element, just applied to (element, frequency) pairs instead of raw numbers.

## Solution

```js
function topKFrequent(nums, k) {
  const freq = new Map();
  for (const num of nums) freq.set(num, (freq.get(num) || 0) + 1);

  const minHeap = new PriorityQueue((a, b) => a.count - b.count);
  for (const [num, count] of freq) {
    minHeap.push({ num, count });
    if (minHeap.size() > k) minHeap.pop();
  }

  const result = [];
  while (!minHeap.isEmpty()) result.push(minHeap.pop().num);
  return result;
}

module.exports = { topKFrequent };

// --- verification ---
console.log(topKFrequent([1, 1, 1, 2, 2, 3], 2)); // [2, 1] — order may vary; both are the 2 most frequent
console.log(topKFrequent([1], 1));                  // [1]
console.log(topKFrequent([4, 1, -1, 2, -1, 2, 3], 2)); // [-1, 2] — both appear twice, tied for most frequent
```

**Alternative — bucket sort in `O(n)`:** since frequency can never exceed `nums.length`, you can allocate `n + 1` buckets (index = frequency, value = list of elements with that frequency) and read off the top `k` from the highest-index buckets downward — this beats the heap's `O(n log k)` with a true `O(n)`, at the cost of being a less generally-reusable pattern (works because frequency has a small bounded range here; wouldn't generalize to, say, "top k highest-priced items" where the sort key has unbounded range).

## Complexity

- **Heap approach — Time:** `O(n log k)` — `O(n)` to build the frequency map, then `O(m log k)` for the heap operations where `m` is the number of distinct elements (`m <= n`).
- **Space:** `O(n)` for the frequency map, `O(k)` for the heap.
