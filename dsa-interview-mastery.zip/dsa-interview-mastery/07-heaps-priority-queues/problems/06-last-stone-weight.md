# Problem: Last Stone Weight

## Problem Statement

You're given an array of integers `stones`, each representing a stone's weight. Repeatedly pick the two **heaviest** stones and smash them together: if they're equal weight, both are destroyed; otherwise, the lighter stone is destroyed and the heavier one's new weight becomes `heavier - lighter`. Continue until at most one stone remains. Return that stone's weight, or `0` if none remain.

## Examples

```
Input: stones = [2,7,4,1,8,1]
Output: 1
Explanation: pick 7,8 -> smash -> 1 remains. Stones: [2,4,1,1,1]
             pick 2,4 -> smash -> 2 remains. Stones: [2,1,1,1]
             pick 1,2 -> smash -> 1 remains. Stones: [1,1,1]
             pick 1,1 -> both destroyed.     Stones: [1]
             Output: 1
```

## Constraints

- `1 <= stones.length <= 30`
- `1 <= stones[i] <= 1000`

## Approach

"Repeatedly grab the two current largest" is a direct max-heap application: build a max-heap of all stone weights, then repeatedly pop the top two, compute the smash result, and push the result back (if nonzero) — continue until at most one stone remains in the heap.

## Solution

```js
function lastStoneWeight(stones) {
  const maxHeap = new PriorityQueue((a, b) => b - a);
  for (const stone of stones) maxHeap.push(stone);

  while (maxHeap.size() > 1) {
    const first = maxHeap.pop();
    const second = maxHeap.pop();
    if (first !== second) {
      maxHeap.push(first - second);
    }
    // if equal, both are destroyed — nothing pushed back
  }

  return maxHeap.isEmpty() ? 0 : maxHeap.peek();
}

module.exports = { lastStoneWeight };

// --- verification ---
console.log(lastStoneWeight([2, 7, 4, 1, 8, 1])); // 1
console.log(lastStoneWeight([1]));                  // 1
console.log(lastStoneWeight([1, 1]));               // 0 — equal stones, both destroyed, none remain
console.log(lastStoneWeight([3, 7, 2]));            // 2  (7-3=4, then 4-2=2)
```

## Complexity

- **Time:** `O(n log n)` — building the initial heap is `O(n)` via bottom-up buildHeap (or `O(n log n)` via `n` individual pushes), and each of the up to `n - 1` smash iterations does `O(1)` pops/pushes at `O(log n)` each.
- **Space:** `O(n)` for the heap.
