# Problem: Kth Largest Element in an Array

## Problem Statement

Given an integer array `nums` and an integer `k`, return the kth largest element in the array — specifically the kth largest in **sorted order**, not the kth distinct element (duplicates count individually).

## Examples

```
Input: nums = [3,2,1,5,6,4], k = 2
Output: 5

Input: nums = [3,2,3,1,2,4,5,5,6], k = 4
Output: 4
```

## Constraints

- `1 <= k <= nums.length <= 10^5`
- `-10^4 <= nums[i] <= 10^4`

## Approach

Maintain a **min-heap of size k**. Push every element; whenever the heap grows past size `k`, pop the minimum (it's guaranteed not to be among the true top-k largest, since at least `k` other elements are currently at least as large). After processing the whole array, the heap's root is exactly the kth largest — this works in `O(n log k)`, notably better than a full `O(n log n)` sort when `k` is small relative to `n`.

## Solution

```js
function findKthLargest(nums, k) {
  const minHeap = new PriorityQueue((a, b) => a - b);

  for (const num of nums) {
    minHeap.push(num);
    if (minHeap.size() > k) minHeap.pop();
  }

  return minHeap.peek();
}

module.exports = { findKthLargest };

// --- verification ---
console.log(findKthLargest([3, 2, 1, 5, 6, 4], 2));             // 5
console.log(findKthLargest([3, 2, 3, 1, 2, 4, 5, 5, 6], 4));    // 4
console.log(findKthLargest([1], 1));                              // 1
```

**Alternative — Quickselect (average `O(n)`, worst case `O(n²)`):** a partition-based approach (like quicksort, but only recursing into the side that contains the target index) can beat the heap's `O(n log k)` on average, at the cost of a worse worst case and in-place array mutation. The heap approach is generally preferred in interviews unless average-case speed is explicitly the focus, since it's simpler to reason about and has no bad-input pathological case.

## Complexity

- **Time:** `O(n log k)` — `n` pushes/pops, each `O(log k)` since the heap never exceeds size `k`.
- **Space:** `O(k)` for the heap.
