Diagrams and images for this topic (heap-as-tree vs. array layout, heapify up/down walkthroughs) go here.
