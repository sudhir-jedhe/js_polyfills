# Priority Queue with a Custom Comparator

```js
class PriorityQueue {
  constructor(compare = (a, b) => a - b) {
    this.heap = [];
    this.compare = compare;
  }
  size() { return this.heap.length; }
  isEmpty() { return this.heap.length === 0; }
  peek() { return this.heap[0]; }
  push(value) {
    this.heap.push(value);
    this._up(this.heap.length - 1);
  }
  pop() {
    if (!this.heap.length) return undefined;
    const top = this.heap[0];
    const last = this.heap.pop();
    if (this.heap.length) { this.heap[0] = last; this._down(0); }
    return top;
  }
  _up(i) {
    while (i > 0) {
      const p = Math.floor((i - 1) / 2);
      if (this.compare(this.heap[i], this.heap[p]) >= 0) break;
      [this.heap[i], this.heap[p]] = [this.heap[p], this.heap[i]];
      i = p;
    }
  }
  _down(i) {
    const n = this.heap.length;
    while (true) {
      const l = 2 * i + 1, r = 2 * i + 2;
      let best = i;
      if (l < n && this.compare(this.heap[l], this.heap[best]) < 0) best = l;
      if (r < n && this.compare(this.heap[r], this.heap[best]) < 0) best = r;
      if (best === i) break;
      [this.heap[i], this.heap[best]] = [this.heap[best], this.heap[i]];
      i = best;
    }
  }
}

// Task scheduler: lower `priority` number = more urgent = dequeued first
const tasks = new PriorityQueue((a, b) => a.priority - b.priority);
tasks.push({ name: 'fix outage', priority: 1 });
tasks.push({ name: 'write docs', priority: 5 });
tasks.push({ name: 'code review', priority: 2 });

console.log(tasks.pop().name); // 'fix outage'
console.log(tasks.pop().name); // 'code review'
console.log(tasks.pop().name); // 'write docs'
```
