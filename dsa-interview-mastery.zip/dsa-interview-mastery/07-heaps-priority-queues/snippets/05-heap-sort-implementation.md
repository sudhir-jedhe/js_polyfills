# Heap Sort Implementation

```js
function heapSort(arr) {
  const n = arr.length;

  for (let i = Math.floor(n / 2) - 1; i >= 0; i--) {
    heapifyDown(arr, n, i);
  }

  for (let end = n - 1; end > 0; end--) {
    [arr[0], arr[end]] = [arr[end], arr[0]];
    heapifyDown(arr, end, 0);
  }

  return arr;
}

function heapifyDown(arr, heapSize, i) {
  while (true) {
    const left = 2 * i + 1, right = 2 * i + 2;
    let largest = i;
    if (left < heapSize && arr[left] > arr[largest]) largest = left;
    if (right < heapSize && arr[right] > arr[largest]) largest = right;
    if (largest === i) break;
    [arr[i], arr[largest]] = [arr[largest], arr[i]];
    i = largest;
  }
}

console.log(heapSort([5, 3, 8, 1, 9, 2, 7])); // [1, 2, 3, 5, 7, 8, 9]
console.log(heapSort([1]));                    // [1]
console.log(heapSort([]));                     // []
```
