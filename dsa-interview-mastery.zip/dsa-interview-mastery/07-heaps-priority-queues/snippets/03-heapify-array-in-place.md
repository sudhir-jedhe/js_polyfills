# Heapify an Existing Array In Place — O(n) Build

```js
function heapifyDown(arr, heapSize, i, compare) {
  while (true) {
    const left = 2 * i + 1, right = 2 * i + 2;
    let best = i;
    if (left < heapSize && compare(arr[left], arr[best]) < 0) best = left;
    if (right < heapSize && compare(arr[right], arr[best]) < 0) best = right;
    if (best === i) break;
    [arr[i], arr[best]] = [arr[best], arr[i]];
    i = best;
  }
}

function buildHeap(arr, compare = (a, b) => a - b) {
  const n = arr.length;
  // start from the last non-leaf node, work back to the root
  for (let i = Math.floor(n / 2) - 1; i >= 0; i--) {
    heapifyDown(arr, n, i, compare);
  }
  return arr;
}

const unsorted = [9, 4, 7, 1, 3, 8, 2];
console.log(buildHeap(unsorted)); // [1, 3, 2, 4, 9, 8, 7] — a valid min-heap (exact layout can vary; root is always the min)
console.log(unsorted[0]);         // 1 — root is always the minimum after buildHeap
```

Building via `buildHeap` is `O(n)` total, versus `O(n log n)` for pushing each element one at a time into an initially-empty heap — the difference matters when all `n` elements are known upfront (e.g. heap sort's first phase).
