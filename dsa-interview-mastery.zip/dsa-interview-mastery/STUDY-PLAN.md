# Suggested Study Plan

A 4-week plan, ~45–60 min/day (longer sessions on problem-heavy days).

## Week 1 — Foundations & linear structures

- Day 1: `01-big-o-complexity-analysis` (get this cold — everything else is described in these terms)
- Day 2–3: `02-arrays-strings`
- Day 4–5: `03-linked-lists`
- Day 6–7: `04-stacks-queues` (monotonic stack pattern — don't skip)

## Week 2 — Trees, graphs & heaps

- Day 1–3: `05-trees-bst` (traversals cold, both recursive and iterative)
- Day 4–6: `06-graphs` (BFS/DFS, cycle detection, topological sort)
- Day 7: `07-heaps-priority-queues`

## Week 3 — Hashing & the classic algorithms

- Day 1–2: `08-hashing-hashmaps-sets`
- Day 3–4: `09-sorting-algorithms`
- Day 5: `10-searching-algorithms` (binary search off-by-one bugs — drill until automatic)
- Day 6–7: Review — `output-based/` for topics 1–10

## Week 4 — The interview-differentiator patterns

- Day 1–2: `11-recursion-backtracking`
- Day 3–4: `12-two-pointers-sliding-window-prefix-sum`
- Day 5–6: `13-dynamic-programming` (the highest-leverage topic — do the memoization/tabulation dual
  implementation in `theory/` slowly, it's the key mental model)
- Day 7: Full review — every `interview-qa/` folder, timed self-quiz on `problems/`

## Interview-week fast pass

1. `output-based/` for `05-trees-bst`, `06-graphs`, `13-dynamic-programming` — tracing execution is the
   fastest signal on whether you actually understand a structure/algorithm
2. `problems/` for `12-two-pointers-sliding-window-prefix-sum` and `13-dynamic-programming` — these two
   patterns show up in the majority of medium/hard interview questions
3. Comparison tables inside `theory/` across the repo — array vs linked list, BFS vs DFS, memoization vs
   tabulation, stable vs unstable sorts
4. Redo 2-3 `problems/` per topic from scratch, no looking at the solution first, timed
