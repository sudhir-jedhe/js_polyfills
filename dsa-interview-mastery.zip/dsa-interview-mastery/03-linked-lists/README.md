# Linked Lists

Linked lists trade an array's O(1) random access for O(1) insertion/removal at the ends (and, with a direct node reference, anywhere) — understanding exactly when that tradeoff is worth it, and mastering the handful of pointer-manipulation patterns that solve most linked-list problems, is the core of this topic. It covers singly vs doubly linked lists, implementing one from scratch in JS, the fast/slow pointer pattern (cycle detection, finding the middle), reversal and merging techniques, honest tradeoffs against arrays (including why arrays usually win in JS specifically), and the classic problems interviewers reach for again and again.

## Folder structure

- **`theory/`** — singly vs doubly linked lists, implementing a linked list from scratch, the fast/slow pointer pattern, reversal and merging patterns, linked list vs array tradeoffs, and a survey of common problem patterns.
- **`snippets/`** — 7 runnable examples: node construction helpers, a doubly linked list with O(1) node removal, iterative reversal, Floyd's cycle detection, merging two sorted lists, finding the middle node, and single-pass n-th-from-end removal.
- **`output-based/`** — 6 "what's the output / complexity?" questions covering reference mutation during reversal, recursive vs iterative space cost, the classic "forgot to save `next`" bug, linked-list vs array middle-finding complexity, shared-node mutation across two lists, and the O(n²) cost of appending without a tail pointer.
- **`scenarios/`** — 4 real-world scenarios: designing an LRU cache's backing structure, modeling editor undo/redo history, diagnosing a production hang/leak from an accidental cycle, and choosing a circular buffer over a linked list for a bounded stream.
- **`interview-qa/`** — 3 themed Q&A files: fundamentals, patterns and techniques, and tradeoffs/design.
- **`problems/`** — 7 hands-on coding challenges: reverse a linked list, detect a cycle and find its start, merge two sorted lists, remove the n-th node from the end, palindrome check, add two numbers as linked lists, and remove duplicates from an unsorted list.
- **`assets/`** — placeholder for diagrams (see `assets/README.md`).

## What's covered

- Singly vs doubly linked lists, with a full complexity comparison against each other and against arrays
- A complete from-scratch JS implementation (append, prepend, insert, delete, find) with a maintained tail pointer for O(1) append
- The fast/slow pointer pattern: cycle detection, finding the middle, and finding the cycle's starting node
- Iterative vs recursive reversal (same time, different space), and merging sorted lists via relinking (not copying)
- Honest tradeoffs: when a linked list genuinely beats an array in JS, and why arrays usually win by default
- Common composable patterns: dummy head nodes, lead-offset pointers, multi-pass vs single-pass tradeoffs
- Hands-on: reverse a list, detect/locate a cycle, merge two sorted lists, remove the n-th-from-end node, palindrome check, add two numbers, and de-duplicate an unsorted list — each with full complexity analysis
