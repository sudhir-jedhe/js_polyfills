# Implementing a Linked List From Scratch in JS

A full singly linked list implementation, with the core operations interviewers expect: append, prepend, insert at index, delete by value, and search.

```js
class ListNode {
  constructor(value, next = null) {
    this.value = value;
    this.next = next;
  }
}

class LinkedList {
  constructor() {
    this.head = null;
    this.tail = null;
    this.size = 0;
  }

  // O(1) — tail pointer means no traversal needed
  append(value) {
    const node = new ListNode(value);
    if (!this.head) {
      this.head = this.tail = node;
    } else {
      this.tail.next = node;
      this.tail = node;
    }
    this.size++;
    return this;
  }

  // O(1) — always operates at the head
  prepend(value) {
    const node = new ListNode(value, this.head);
    this.head = node;
    if (!this.tail) this.tail = node;
    this.size++;
    return this;
  }

  // O(n) — must walk to the insertion point
  insertAt(index, value) {
    if (index <= 0) return this.prepend(value);
    if (index >= this.size) return this.append(value);

    const node = new ListNode(value);
    let prev = this.head;
    for (let i = 0; i < index - 1; i++) prev = prev.next;

    node.next = prev.next;
    prev.next = node;
    this.size++;
    return this;
  }

  // O(n) — must find the node (and its predecessor) by value
  delete(value) {
    if (!this.head) return false;

    if (this.head.value === value) {
      this.head = this.head.next;
      if (!this.head) this.tail = null;
      this.size--;
      return true;
    }

    let prev = this.head;
    while (prev.next && prev.next.value !== value) prev = prev.next;

    if (!prev.next) return false; // not found

    prev.next = prev.next.next;
    if (prev.next === null) this.tail = prev; // removed the last node
    this.size--;
    return true;
  }

  // O(n) — linear scan, no shortcuts (unlike a sorted array + binary search)
  find(value) {
    let current = this.head;
    while (current) {
      if (current.value === value) return current;
      current = current.next;
    }
    return null;
  }

  toArray() {
    const result = [];
    let current = this.head;
    while (current) {
      result.push(current.value);
      current = current.next;
    }
    return result;
  }
}

const list = new LinkedList();
list.append(1).append(2).append(3).prepend(0);
console.log(list.toArray()); // [0, 1, 2, 3]
list.delete(2);
console.log(list.toArray()); // [0, 1, 3]
```

## Why maintaining a `tail` pointer matters

Without a `tail` reference, `append` would require walking the entire list to find the last node — O(n) instead of O(1). Maintaining `head`, `tail`, and `size` as the list is built (rather than recomputing them on demand) is what keeps the common operations fast; this is the same "maintain running state incrementally" principle that shows up throughout DSA (e.g. Kadane's algorithm, sliding windows).

## Complexity summary for this implementation

| Operation | Complexity | Why |
|---|---|---|
| `append` | O(1) | Direct via `tail` pointer |
| `prepend` | O(1) | Direct via `head` pointer |
| `insertAt(index)` | O(n) | Must walk to the index |
| `delete(value)` | O(n) | Must scan to find the value |
| `find(value)` | O(n) | Linear scan, no random access |
