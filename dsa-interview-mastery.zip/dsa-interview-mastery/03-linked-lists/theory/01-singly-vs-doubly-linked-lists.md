# Singly vs Doubly Linked Lists

A linked list is a sequence of nodes where each node holds a value and a reference (pointer) to the next node — unlike an array, elements are **not** stored contiguously in memory, so there's no way to jump directly to "index 5" without walking from the head.

## Singly linked list

Each node points only **forward**, to the next node.

```js
class ListNode {
  constructor(value, next = null) {
    this.value = value;
    this.next = next;
  }
}

// 1 -> 2 -> 3 -> null
const head = new ListNode(1, new ListNode(2, new ListNode(3)));
```

Traversal is one-directional: given a node, you can reach everything after it, but you cannot walk backward to what came before it without re-traversing from the head.

## Doubly linked list

Each node points both forward (`next`) **and** backward (`prev`).

```js
class DoublyListNode {
  constructor(value, next = null, prev = null) {
    this.value = value;
    this.next = next;
    this.prev = prev;
  }
}
```

This enables O(1) backward traversal from any node, and O(1) removal of a node **if you already have a reference to it** (no need to re-scan from the head to find its predecessor, since `node.prev` is already known).

## Complexity comparison

| Operation | Singly linked list | Doubly linked list | Array |
|---|---|---|---|
| Access by index | O(n) | O(n) | O(1) |
| Insert/remove at head | O(1) | O(1) | O(n) |
| Insert/remove at tail (no tail pointer) | O(n) | O(1) (with tail pointer) | O(1) amortized |
| Insert/remove given a node reference | O(n) (must find predecessor) | O(1) | O(n) (must shift) |
| Traverse forward | O(n) | O(n) | O(n) |
| Traverse backward | Not possible without re-traversal | O(n) | O(n) |
| Extra memory per node | 1 pointer | 2 pointers | 0 (contiguous) |

## Why the "insert/remove given a node reference" row matters

This is the single biggest practical advantage of a doubly linked list: if you already hold a reference to a node (e.g. from a `Map<key, node>` in an LRU cache), removing it is truly O(1) — you can directly access `node.prev` and `node.next` to relink around it. In a singly linked list, even with a direct node reference, removing it requires knowing its predecessor to update `predecessor.next`, and finding that predecessor means re-scanning from the head — O(n) — unless a predecessor reference happens to already be tracked separately.

## When to use which

- **Singly linked list:** simplest option, half the memory overhead per node, sufficient whenever you only need forward traversal (e.g. implementing a stack, a basic queue, or a simple ordered sequence built one direction).
- **Doubly linked list:** needed when you require O(1) removal given a node reference (LRU caches), backward traversal, or a deque (double-ended queue) supporting O(1) operations at both ends.
