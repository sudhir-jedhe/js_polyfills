# Common Linked List Problem Patterns

A survey of the recurring techniques that combine to solve the majority of linked-list interview problems — most problems are a composition of two or three of these.

## 1. Dummy head node

Simplifies edge cases where the head itself might be removed or replaced. See `04-reversal-and-merging-patterns.md`.

```js
const dummy = new ListNode(0, head);
// operate using dummy.next as the "real" head reference throughout
return dummy.next;
```

## 2. Fast/slow pointers

Cycle detection, finding the middle, finding the k-th-from-end node. See `03-fast-slow-pointer-pattern.md`.

## 3. Multi-pass with a length count

Some problems are more naturally solved with a first pass to count the length, then a second pass to act at a computed position — trading a second full traversal for simpler logic than a single-pass two-pointer trick.

```js
function removeNthFromEndTwoPass(head, n) {
  let length = 0;
  for (let node = head; node; node = node.next) length++; // pass 1: count

  const dummy = new ListNode(0, head);
  let prev = dummy;
  for (let i = 0; i < length - n; i++) prev = prev.next; // pass 2: walk to predecessor

  prev.next = prev.next.next;
  return dummy.next;
}
// O(n) time (two passes, still linear), O(1) space
```

## 4. One-pass with a lead offset (the "gap" technique)

The single-pass alternative to the pattern above: advance one pointer `n` steps ahead first, then move both pointers together — when the lead pointer reaches the end, the trailing pointer is exactly at the target position.

```js
function removeNthFromEndOnePass(head, n) {
  const dummy = new ListNode(0, head);
  let fast = dummy;
  let slow = dummy;

  for (let i = 0; i < n; i++) fast = fast.next; // lead pointer n steps ahead

  while (fast.next) {
    fast = fast.next;
    slow = slow.next;
  }

  slow.next = slow.next.next; // slow.next is now the n-th node from the end
  return dummy.next;
}
// O(n) time (single pass), O(1) space
```

## 5. Reversal (full or partial)

Reversing all or part of a list in place, using the `prev`/`current`/`next` iterative technique. See `04-reversal-and-merging-patterns.md`.

## 6. Merge / interleave

Combining two (or more) lists by relinking existing nodes rather than allocating new ones — merging sorted lists, or interleaving two lists' nodes alternately.

## Pattern recognition cheat sheet

| Problem phrase | Likely pattern |
|---|---|
| "Detect a cycle" / "does this list loop" | Fast/slow pointers |
| "Find the middle" | Fast/slow pointers |
| "k-th node from the end" | One-pass lead-offset, or two-pass length count |
| "Reverse [all / a portion of] the list" | Iterative prev/current/next reversal |
| "Merge two sorted lists" | Dummy node + relinking merge |
| "Remove duplicates" / "remove a value" | Dummy node + predecessor tracking |
| "Is this list a palindrome" | Fast/slow to find middle + reverse second half + compare |
