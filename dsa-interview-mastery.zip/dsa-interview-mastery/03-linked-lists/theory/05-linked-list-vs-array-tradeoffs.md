# Linked List vs Array: Real Tradeoffs

Interviewers frequently ask "when would you use a linked list over an array?" — the honest answer is "rarely, in JS specifically, but here's exactly when it's the right call."

## Complexity comparison

| Operation | Array | Singly Linked List |
|---|---|---|
| Access by index | O(1) | O(n) |
| Search (unsorted) | O(n) | O(n) |
| Insert/remove at start | O(n) | O(1) |
| Insert/remove at end | O(1) amortized | O(1) with tail pointer, O(n) without |
| Insert/remove in middle (given position) | O(n) (shifting) | O(n) to find + O(1) to relink |
| Insert/remove given a direct node/element reference | O(n) (still must shift) | O(1) (singly: need predecessor too — see note) | 
| Memory overhead | None beyond elements (contiguous) | Extra pointer per node (2x for doubly) |
| Cache locality | Excellent (contiguous memory) | Poor (nodes scattered in heap memory) |

**Note on "insert/remove given a reference":** for a singly linked list, truly O(1) removal-given-a-reference requires also having (or being able to derive) the predecessor; a doubly linked list makes this genuinely O(1) since `node.prev` is directly available.

## Why arrays usually win in practice, especially in JS

JS engines heavily optimize contiguous array storage — cache locality (elements sitting next to each other in memory means fewer cache misses during iteration) makes array traversal faster in practice than linked-list traversal, even though both are "O(n)" asymptotically; the constant factor difference is significant on real hardware. Additionally, JS doesn't expose raw memory/pointers the way C/C++ does, so a "linked list" in JS is really just objects referencing other objects via properties, which carries meaningfully more per-node overhead (object header, property storage) than a native pointer would in a lower-level language.

## When a linked list is genuinely the better choice

- **Frequent insertions/removals at the front, with no need for index-based access** — a linked list does this in O(1); an array requires O(n) shifting via `unshift`/`shift`.
- **Building an LRU cache** — combined with a hash map, a doubly linked list gives O(1) "move to front" and O(1) eviction from the back, which an array cannot match without O(n) shifting.
- **Implementing another data structure's internals** — stacks and queues are frequently implemented with a linked list under the hood specifically to guarantee O(1) push/pop or enqueue/dequeue without amortization caveats (see `04-stacks-queues`).
- **Unknown, highly dynamic size with frequent mid-list insertion at a known node** (e.g. a text editor's undo history, or a playlist with frequent reordering) where you already hold node references and want to avoid the shifting cost of an array.
- **You don't need random access at all** — if nothing in your algorithm ever asks for "the 500th element directly," you lose nothing by giving up O(1) index access.

## When to stick with an array (the common case)

If you need index-based random access, better cache performance, less memory overhead per element, or you're doing more reading/iterating than inserting/removing at arbitrary positions — which describes the overwhelming majority of real-world code — an array is simpler and faster. Reach for a linked list deliberately, for a specific structural reason, not as a default.
