# Reversal and Merging Patterns

Two more foundational linked-list manipulations that show up constantly, both as standalone problems and as building blocks inside larger ones.

## Reversing a singly linked list (iterative)

```js
function reverseList(head) {
  let prev = null;
  let current = head;

  while (current) {
    const next = current.next; // save before overwriting
    current.next = prev;        // reverse the pointer
    prev = current;             // advance prev
    current = next;             // advance current
  }

  return prev; // new head
}
```
**Time: O(n), Space: O(1)** — each node's `next` pointer is rewritten exactly once, using three tracking variables.

## Reversing a singly linked list (recursive)

```js
function reverseListRecursive(head) {
  if (!head || !head.next) return head; // base case: empty or single node

  const newHead = reverseListRecursive(head.next); // reverses everything after head
  head.next.next = head; // make the next node point back to this one
  head.next = null;        // this node becomes the new tail
  return newHead;
}
```
**Time: O(n), Space: O(n)** — same number of pointer rewrites as the iterative version, but the recursion stack holds n frames at its deepest point, making this strictly worse in space than the iterative version despite being arguably more elegant — a good example of when "the more elegant recursive solution" costs something the iterative one doesn't.

## Merging two sorted linked lists

```js
function mergeTwoLists(l1, l2) {
  const dummy = new ListNode(0); // placeholder simplifies edge-case handling at the head
  let tail = dummy;

  while (l1 && l2) {
    if (l1.value <= l2.value) {
      tail.next = l1;
      l1 = l1.next;
    } else {
      tail.next = l2;
      l2 = l2.next;
    }
    tail = tail.next;
  }

  tail.next = l1 || l2; // attach whichever list has leftover nodes
  return dummy.next;
}
```
**Time: O(n + m), Space: O(1)** — where n and m are the two input lengths; this reuses the existing nodes (relinking pointers) rather than allocating new ones, so it's O(1) *extra* space, not counting the input/output list itself.

## The "dummy node" trick

Using a placeholder `dummy` node before the real head is a standard technique that eliminates special-casing "is this the very first node?" — instead of separately handling "attach to an empty result" vs "attach to an existing tail," every attachment goes through `tail.next = ...` uniformly, and the real result is simply `dummy.next` at the end. This pattern recurs across nearly every linked-list problem that builds or modifies a list (merging, removing nodes, partitioning).

## Reversing a sub-portion of a list (combining both patterns)

Problems like "reverse nodes from position m to n" combine dummy nodes with the iterative reversal technique: walk to position `m-1` using a dummy-anchored pointer, then apply the same `prev`/`current`/`next` reversal loop only within that sub-range, and finally reconnect the reversed segment's ends back into the surrounding list — still O(n) time, O(1) space, just with more careful pointer bookkeeping at the reconnection points.
