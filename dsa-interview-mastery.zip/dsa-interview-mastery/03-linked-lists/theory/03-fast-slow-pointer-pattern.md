# The Fast/Slow Pointer Pattern (Floyd's Algorithm)

The fast/slow pointer technique (also called "Floyd's cycle detection" or "the tortoise and the hare") uses two pointers traversing a linked list at different speeds — typically one step vs two steps per iteration — to solve a surprising range of problems in O(n) time and O(1) space, where a naive approach would need O(n) extra space.

## Cycle detection

```js
function hasCycle(head) {
  let slow = head;
  let fast = head;

  while (fast && fast.next) {
    slow = slow.next;       // moves 1 step
    fast = fast.next.next;  // moves 2 steps
    if (slow === fast) return true; // they've met -> cycle exists
  }
  return false; // fast reached the end -> no cycle
}
```

**Why it works:** if there's no cycle, `fast` reaches `null` and the loop ends normally. If there **is** a cycle, `fast` enters the cycle and starts "lapping" `slow` inside it — since `fast` closes the gap between them by exactly 1 node per iteration (it gains 2 steps while `slow` gains 1), it's mathematically guaranteed to catch up to `slow` within at most one full loop around the cycle, so they will always eventually land on the same node.

**Time: O(n), Space: O(1)** — versus the naive O(n) *space* alternative of storing every visited node in a `Set` and checking membership each step (also O(n) time, but with O(n) extra space instead of O(1)).

## Finding the middle of a list in one pass

```js
function findMiddle(head) {
  let slow = head;
  let fast = head;
  while (fast && fast.next) {
    slow = slow.next;
    fast = fast.next.next;
  }
  return slow; // when fast reaches the end, slow is at the middle
}
```
When `fast` (moving 2x speed) reaches the end, `slow` (moving 1x speed) has covered exactly half the distance — landing on the middle node, in a single pass, without first counting the list's length.

## Finding the start of a cycle (Floyd's full algorithm)

Once `hasCycle` detects a meeting point, a second phase finds exactly where the cycle *begins*:

```js
function detectCycleStart(head) {
  let slow = head;
  let fast = head;

  // Phase 1: determine if a cycle exists, find the meeting point
  while (fast && fast.next) {
    slow = slow.next;
    fast = fast.next.next;
    if (slow === fast) {
      // Phase 2: reset one pointer to head, advance both at 1x speed
      let ptr = head;
      while (ptr !== slow) {
        ptr = ptr.next;
        slow = slow.next;
      }
      return ptr; // the node where the cycle begins
    }
  }
  return null; // no cycle
}
```

**Why phase 2 works (brief):** if the distance from `head` to the cycle start is `a`, and the meeting point is `b` steps into the cycle, the math of the meeting condition works out so that walking `a` more steps from both `head` and the meeting point (at the same 1x speed) lands both pointers on the cycle's start node simultaneously.

**Time: O(n), Space: O(1)** for both phases combined.

## Why this pattern is worth memorizing

Fast/slow pointers turn "detect a cycle," "find the middle," and "find the k-th node from the end" (advance one pointer k steps first, then move both together) into O(1)-space single-pass solutions, where the intuitive first approach (a `Set` of visited nodes, or two separate passes to count length then re-traverse) would cost O(n) extra space or an extra full pass.
