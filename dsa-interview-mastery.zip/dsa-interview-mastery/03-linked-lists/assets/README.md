Placeholder for diagrams (node/pointer diagrams, fast/slow pointer visualizations, etc.) related to this topic. Nothing here yet.
