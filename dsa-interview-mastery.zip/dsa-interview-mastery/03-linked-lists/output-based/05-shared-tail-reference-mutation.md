# What's the Output? — Two Lists Sharing a Tail Segment

```js
class ListNode {
  constructor(value, next = null) { this.value = value; this.next = next; }
}

const shared = new ListNode(3, new ListNode(4));
const listA = new ListNode(1, new ListNode(2, shared));
const listB = new ListNode(9, shared); // listB's tail IS the same node object as listA's tail

shared.value = 999; // mutate the shared node directly

function toArray(head) {
  const result = [];
  for (let n = head; n; n = n.next) result.push(n.value);
  return result;
}

console.log(toArray(listA));
console.log(toArray(listB));
```

**Answer:**
```
[1, 2, 999, 4]
[9, 999, 4]
```

**Why:** `listA` and `listB` were deliberately constructed to share the *same* node object (`shared`) as part of both lists — this is legal and sometimes intentional (e.g. two paths converging in a graph-like structure, or an intersection-of-two-lists problem setup), but it means mutating that shared node's `.value` is visible through **both** lists, since there's only one underlying node object in memory, referenced from two different places. This is the linked-list analog of the array/object reference-sharing behavior covered in `02-arrays-strings` — the key insight for interviews is that "two lists" doesn't necessarily mean "two fully separate sets of nodes"; problems like "find the intersection point of two linked lists" are built entirely around this possibility of shared tail nodes, and detecting *where* two lists start sharing nodes (by reference, not by value) is itself a common interview question.
