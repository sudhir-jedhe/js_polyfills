# What's the Output? — Forgetting to Save `next` Before Overwriting It

```js
class ListNode {
  constructor(value, next = null) { this.value = value; this.next = next; }
}

function buggyReverse(head) {
  let prev = null;
  let current = head;
  while (current) {
    current.next = prev;    // BUG: overwrites current.next before we've saved it
    prev = current;
    current = current.next; // this now reads the value we JUST overwrote above
  }
  return prev;
}

const list = new ListNode(1, new ListNode(2, new ListNode(3)));
console.log(buggyReverse(list));
```

**Answer:** A list containing only the single node `{ value: 1, next: null }` — nodes 2 and 3 are permanently lost (orphaned, unreachable, and effectively garbage) — not a reversed three-node list.

**Why:** On the first iteration, `current` points at node `1`, and `current.next` points at node `2`. The buggy line `current.next = prev` immediately overwrites node `1`'s `next` pointer to `null` (since `prev` starts as `null`) — but this destroys the *only* reference the code had to node `2`, **before** `current = current.next` gets a chance to read it. The next line then reads the now-corrupted `current.next` (which is `null`), so `current` becomes `null` and the loop exits immediately — having processed only node `1`. Nodes `2` and `3` were never visited at all; they simply became unreachable the instant node `1`'s pointer was overwritten. The fix is exactly what the correct implementation does: save `next` into a temporary variable **before** reassigning `current.next`:

```js
const next = current.next; // save first
current.next = prev;        // safe to overwrite now
```

This is one of the most common linked-list bugs — any in-place pointer rewrite must capture the "next" reference before mutating the pointer that provides it, or that part of the list becomes permanently unreachable.
