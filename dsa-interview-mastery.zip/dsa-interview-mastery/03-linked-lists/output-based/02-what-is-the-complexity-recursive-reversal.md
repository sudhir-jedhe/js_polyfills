# What's the Time and Space Complexity? — Recursive Reversal

```js
function reverseListRecursive(head) {
  if (!head || !head.next) return head;
  const newHead = reverseListRecursive(head.next);
  head.next.next = head;
  head.next = null;
  return newHead;
}
```

**Question:** Is this the same complexity as the iterative version?

**Answer:** Same time complexity, **different** space complexity. Time: O(n) for both. Space: O(n) for the recursive version, O(1) for the iterative version.

**Why:** Both versions rewrite each node's `next` pointer exactly once, so both do O(n) total work — same time complexity. But the recursive version calls itself once per node before doing any pointer-rewriting work (the rewriting happens on the way back *up* the call stack, after the base case is hit), meaning all `n` stack frames are alive simultaneously at the deepest point of recursion before any unwinding begins. That's O(n) additional space consumed by the call stack — space the iterative version never uses, since it tracks state with three simple variables (`prev`, `current`, `next`) rather than the language runtime's call stack. This is a common follow-up question: "can you do this without extra space?" — the answer is yes, but only by switching to the iterative version.
