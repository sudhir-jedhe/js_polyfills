# What's the Time Complexity? — Finding the Middle: Linked List vs Array

```js
// Linked list version
function findMiddleList(head) {
  let slow = head, fast = head;
  while (fast && fast.next) {
    slow = slow.next;
    fast = fast.next.next;
  }
  return slow;
}

// Array version
function findMiddleArray(arr) {
  return arr[Math.floor(arr.length / 2)];
}
```

**Question:** Both are described as "find the middle element" — are they the same complexity?

**Answer:** Both are correctly described as O(n) *in the worst case for accessing an arbitrary element*, but they arrive there very differently: the array version is actually **O(1)**, while the linked list version is genuinely **O(n)**.

**Why:** `arr.length` is an O(1) property read on an array (tracked directly, not recomputed), and `arr[i]` is O(1) direct-offset access — so `findMiddleArray` is O(1) overall, full stop. `findMiddleList`, by contrast, has no way to know the list's length without traversing it (linked lists don't track length unless a wrapper class explicitly maintains a counter, as in `02-implementing-a-linked-list-from-scratch.md`), and even after knowing the length, jumping straight to "node number k" isn't possible — nodes can only be reached by walking `.next` pointers one at a time from the head. The fast/slow pointer technique is specifically how you find the middle **in one pass without first knowing the length** — but that pass is still O(n), since `fast` must walk the entire list (in half-steps of 2, but still proportional to n) to detect when it runs out. This is the core structural cost of not having contiguous, indexable memory: linked lists trade O(1) random access for O(1) head insertion, and there's no way around that tradeoff for this particular operation.
