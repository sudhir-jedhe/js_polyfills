# What's the Output? — Reversal Mutates the Original Node References

```js
class ListNode {
  constructor(value, next = null) { this.value = value; this.next = next; }
}

function reverseList(head) {
  let prev = null, current = head;
  while (current) {
    const next = current.next;
    current.next = prev;
    prev = current;
    current = next;
  }
  return prev;
}

const first = new ListNode(1, new ListNode(2, new ListNode(3)));
const originalFirstNode = first; // still points at the node holding value 1

reverseList(first);

console.log(originalFirstNode.value);
console.log(originalFirstNode.next);
```

**Answer:**
```
1
null
```

**Why:** `reverseList` reverses the list **in place** by rewriting each node's `next` pointer — it doesn't create new nodes or copy values. `originalFirstNode` still refers to the same node object (the one holding `1`), but that node's `.next` has been rewritten during reversal: since it was originally the head, it becomes the new **tail** after reversal, so its `.next` is now `null` (that's what `prev` was initialized to, before that node became the very first one processed). This trips people up because the *variable* `originalFirstNode` never got reassigned — but the *object it points to* was mutated by the function, which is exactly the reference-semantics behavior arrays and linked lists share in JS.
