# What's the Time Complexity? — Repeated Append Without a Tail Pointer

```js
class ListNode {
  constructor(value, next = null) { this.value = value; this.next = next; }
}

function appendNoTail(head, value) {
  if (!head) return new ListNode(value);
  let current = head;
  while (current.next) current = current.next; // walk to the end EVERY call
  current.next = new ListNode(value);
  return head;
}

let head = null;
for (let i = 0; i < n; i++) {
  head = appendNoTail(head, i);
}
```

**Question:** What's the total time complexity of building a list of `n` elements this way?

**Answer:** `O(n²)` total — **not** `O(n)`.

**Why:** Each individual call to `appendNoTail` is `O(k)`, where `k` is the current length of the list at that point, because without a maintained `tail` reference, the function must walk from `head` all the way to the end before it can attach the new node. Across `n` calls, the list length grows from `0` to `n-1`, so total work is `0 + 1 + 2 + ... + (n-1) = O(n²)` — exactly the same triangular-sum reasoning as a nested loop where the inner bound depends on the outer variable (see `01-big-o-complexity-analysis/theory/03-analyzing-loops-and-nested-loops.md`). This is precisely why a well-implemented linked list (as in `02-implementing-a-linked-list-from-scratch.md`) maintains an explicit `tail` pointer — with it, each `append` becomes O(1), and building the same n-element list drops from O(n²) to O(n) overall.
