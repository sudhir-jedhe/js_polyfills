// Floyd's cycle detection (fast/slow pointers) — O(n) time, O(1) space

class ListNode {
  constructor(value, next = null) {
    this.value = value;
    this.next = next;
  }
}

function hasCycle(head) {
  let slow = head;
  let fast = head;

  while (fast && fast.next) {
    slow = slow.next;
    fast = fast.next.next;
    if (slow === fast) return true;
  }
  return false;
}

// Build a list with a cycle: 1 -> 2 -> 3 -> 4 -> back to 2
const n4 = new ListNode(4);
const n3 = new ListNode(3, n4);
const n2 = new ListNode(2, n3);
const n1 = new ListNode(1, n2);
n4.next = n2; // introduces the cycle

console.log(hasCycle(n1)); // true

const cleanList = new ListNode(1, new ListNode(2, new ListNode(3)));
console.log(hasCycle(cleanList)); // false
