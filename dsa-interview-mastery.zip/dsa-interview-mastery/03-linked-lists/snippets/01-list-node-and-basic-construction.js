// Basic ListNode class and a helper to build a list from an array

class ListNode {
  constructor(value, next = null) {
    this.value = value;
    this.next = next;
  }
}

function fromArray(values) {
  const dummy = new ListNode(0);
  let tail = dummy;
  for (const v of values) {
    tail.next = new ListNode(v);
    tail = tail.next;
  }
  return dummy.next; // O(n) time, O(n) space (n new nodes)
}

function toArray(head) {
  const result = [];
  for (let node = head; node; node = node.next) result.push(node.value);
  return result; // O(n) time, O(n) space
}

const head = fromArray([1, 2, 3, 4, 5]);
console.log(toArray(head)); // [1, 2, 3, 4, 5]

module.exports = { ListNode, fromArray, toArray };
