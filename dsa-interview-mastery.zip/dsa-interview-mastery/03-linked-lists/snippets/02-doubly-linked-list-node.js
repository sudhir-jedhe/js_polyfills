// Doubly linked list node with O(1) append/prepend and O(1) removal given a node reference

class DoublyListNode {
  constructor(value, prev = null, next = null) {
    this.value = value;
    this.prev = prev;
    this.next = next;
  }
}

class DoublyLinkedList {
  constructor() {
    this.head = null;
    this.tail = null;
  }

  append(value) {
    const node = new DoublyListNode(value, this.tail, null);
    if (this.tail) this.tail.next = node;
    else this.head = node;
    this.tail = node;
    return node; // return the node so callers can remove it in O(1) later
  }

  // O(1) — no need to search for a predecessor, node.prev is already known
  removeNode(node) {
    if (node.prev) node.prev.next = node.next;
    else this.head = node.next;

    if (node.next) node.next.prev = node.prev;
    else this.tail = node.prev;
  }

  toArray() {
    const result = [];
    for (let n = this.head; n; n = n.next) result.push(n.value);
    return result;
  }
}

const dll = new DoublyLinkedList();
dll.append('a');
const nodeB = dll.append('b');
dll.append('c');
console.log(dll.toArray()); // ['a', 'b', 'c']

dll.removeNode(nodeB); // O(1) -- exactly what a singly linked list cannot do without a predecessor
console.log(dll.toArray()); // ['a', 'c']
