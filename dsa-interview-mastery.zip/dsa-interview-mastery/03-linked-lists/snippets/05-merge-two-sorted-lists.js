// Merge two sorted linked lists by relinking existing nodes — O(n+m) time, O(1) extra space

class ListNode {
  constructor(value, next = null) {
    this.value = value;
    this.next = next;
  }
}

function mergeTwoLists(l1, l2) {
  const dummy = new ListNode(0);
  let tail = dummy;

  while (l1 && l2) {
    if (l1.value <= l2.value) {
      tail.next = l1;
      l1 = l1.next;
    } else {
      tail.next = l2;
      l2 = l2.next;
    }
    tail = tail.next;
  }

  tail.next = l1 || l2;
  return dummy.next;
}

function fromArray(values) {
  const dummy = new ListNode(0);
  let tail = dummy;
  for (const v of values) { tail.next = new ListNode(v); tail = tail.next; }
  return dummy.next;
}

function toArray(head) {
  const result = [];
  for (let n = head; n; n = n.next) result.push(n.value);
  return result;
}

const listA = fromArray([1, 3, 5]);
const listB = fromArray([2, 4, 6, 8]);
console.log(toArray(mergeTwoLists(listA, listB))); // [1, 2, 3, 4, 5, 6, 8]
