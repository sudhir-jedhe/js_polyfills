// Iterative in-place linked list reversal — O(n) time, O(1) space

class ListNode {
  constructor(value, next = null) {
    this.value = value;
    this.next = next;
  }
}

function reverseList(head) {
  let prev = null;
  let current = head;

  while (current) {
    const next = current.next;
    current.next = prev;
    prev = current;
    current = next;
  }

  return prev;
}

function toArray(head) {
  const result = [];
  for (let n = head; n; n = n.next) result.push(n.value);
  return result;
}

const head = new ListNode(1, new ListNode(2, new ListNode(3, new ListNode(4))));
console.log(toArray(head));               // [1, 2, 3, 4]
console.log(toArray(reverseList(head)));  // [4, 3, 2, 1]
