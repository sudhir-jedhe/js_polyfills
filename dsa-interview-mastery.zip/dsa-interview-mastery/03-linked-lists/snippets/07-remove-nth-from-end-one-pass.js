// Remove the n-th node from the end in a single pass using a lead-offset pointer

class ListNode {
  constructor(value, next = null) {
    this.value = value;
    this.next = next;
  }
}

function removeNthFromEnd(head, n) {
  const dummy = new ListNode(0, head);
  let fast = dummy;
  let slow = dummy;

  for (let i = 0; i < n; i++) fast = fast.next; // lead pointer n steps ahead

  while (fast.next) {
    fast = fast.next;
    slow = slow.next;
  }

  slow.next = slow.next.next; // unlink the target node
  return dummy.next;
}

function fromArray(values) {
  const dummy = new ListNode(0);
  let tail = dummy;
  for (const v of values) { tail.next = new ListNode(v); tail = tail.next; }
  return dummy.next;
}

function toArray(head) {
  const result = [];
  for (let n = head; n; n = n.next) result.push(n.value);
  return result;
}

console.log(toArray(removeNthFromEnd(fromArray([1, 2, 3, 4, 5]), 2))); // [1, 2, 3, 5]
console.log(toArray(removeNthFromEnd(fromArray([1]), 1)));               // []
