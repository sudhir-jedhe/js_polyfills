// Find the middle node of a linked list in a single pass — O(n) time, O(1) space

class ListNode {
  constructor(value, next = null) {
    this.value = value;
    this.next = next;
  }
}

function findMiddle(head) {
  let slow = head;
  let fast = head;

  while (fast && fast.next) {
    slow = slow.next;
    fast = fast.next.next;
  }
  return slow; // for even-length lists, this lands on the SECOND of the two middle nodes
}

function fromArray(values) {
  const dummy = new ListNode(0);
  let tail = dummy;
  for (const v of values) { tail.next = new ListNode(v); tail = tail.next; }
  return dummy.next;
}

console.log(findMiddle(fromArray([1, 2, 3, 4, 5])).value);    // 3
console.log(findMiddle(fromArray([1, 2, 3, 4, 5, 6])).value); // 4 -- second middle for even length
