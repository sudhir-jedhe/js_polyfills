# Interview Q&A — Linked List Fundamentals

**Q: What's the fundamental structural difference between an array and a linked list?**
An array stores elements in contiguous memory, enabling O(1) index-based access via direct offset calculation. A linked list stores elements as separate node objects scattered in memory, each holding a reference to the next (and, for doubly linked lists, the previous) node — there's no way to jump directly to "the k-th node" without walking from the head, making access O(n).

**Q: Why is inserting at the head O(1) for a linked list but O(n) for an array?**
Inserting at an array's head requires shifting every existing element one position to the right to make room — O(n). Inserting at a linked list's head only requires creating a new node and pointing it at the current head, then updating the head reference — O(1), completely independent of the list's current length, since no existing node needs to move or be touched.

**Q: What's the difference between a singly and doubly linked list, and what does a doubly linked list cost in exchange for its extra capability?**
A singly linked list's nodes point only forward; a doubly linked list's nodes point both forward and backward. The doubly linked list enables O(1) backward traversal and true O(1) removal given a direct node reference (no predecessor search needed), at the cost of an extra pointer per node (roughly double the per-node memory overhead) and slightly more bookkeeping on every insert/remove to keep both directions consistent.

**Q: Why can't you binary search a linked list, even if it's sorted?**
Binary search relies on O(1) random access to jump directly to the midpoint of a range. A linked list only supports sequential traversal from a known node — reaching "the middle" requires walking from the head (or using two pointers, still an O(n) full traversal), so even on sorted data, there's no way to jump directly to an arbitrary position, which is what makes binary search's O(log n) guarantee possible on arrays but not on linked lists.

**Q: What's a "dummy head node" and why is it used?**
A placeholder node inserted before the real head, used to eliminate special-case handling for operations that might affect the head itself (e.g. removing the first node, or inserting before the current head). Instead of writing separate logic for "is this the first node?", all operations go through the dummy node's `.next` uniformly, and the real result is returned as `dummy.next` — simplifying code and reducing edge-case bugs.
