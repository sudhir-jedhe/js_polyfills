# Interview Q&A — Patterns and Techniques

**Q: How does Floyd's cycle detection algorithm work, and why does it use two pointers moving at different speeds?**
Two pointers start at the head; one ("slow") advances one node per step, the other ("fast") advances two nodes per step. If the list has no cycle, "fast" reaches the end (`null`) and the algorithm concludes no cycle exists. If a cycle exists, "fast" enters it and, because it closes the gap to "slow" by exactly one node per iteration once both are inside the cycle, it's mathematically guaranteed to eventually land on the same node as "slow" — proving a cycle exists in O(n) time and O(1) space, without needing a `Set` of visited nodes (which would also work, but at O(n) space).

**Q: How would you find the k-th node from the end of a linked list in a single pass?**
Advance one pointer `k` steps ahead of a second pointer first, then move both pointers forward together, one step at a time, until the lead pointer reaches the end — at that point, the trailing pointer is exactly `k` nodes from the end. This avoids a two-pass approach (count the length first, then walk to `length - k`), achieving the same O(n) time in a single traversal instead of two.

**Q: Why does reversing a linked list iteratively use O(1) space, while the recursive version uses O(n)?**
The iterative version tracks state (`prev`, `current`, `next`) in a fixed, constant number of variables that get reused each loop iteration. The recursive version calls itself once per node before doing any pointer rewiring, so all n stack frames remain alive simultaneously at the deepest point of recursion (the actual pointer-reversal work happens as the recursion unwinds) — that's O(n) additional memory on the call stack that the iterative approach never needs.

**Q: How do you merge two sorted linked lists without allocating any new nodes?**
Use a dummy node to anchor the result, then repeatedly compare the current heads of both lists, relinking (not copying) whichever node has the smaller value onto the result's tail, and advancing that list's pointer — this reuses the existing node objects from both input lists rather than creating new ones, achieving O(n + m) time and O(1) *extra* space (beyond the pointers already needed to track the traversal).

**Q: What's the general strategy for detecting whether a linked list is a palindrome, in O(n) time and O(1) extra space?**
Use fast/slow pointers to find the middle of the list in one pass, reverse the second half of the list in place (iteratively, O(1) space), then walk two pointers — one from the original head, one from the newly reversed second half's head — comparing values as you go. This avoids the naive O(n) *space* approach of copying all values into an array first and checking that array for palindrome symmetry.
