# Problem: Reverse a Linked List

## Problem Statement

Given the head of a singly linked list, reverse the list in place and return the new head.

## Constraints

- `0 <= list length <= 5000`
- Node values fit in a 32-bit integer.
- Solve iteratively in O(1) extra space (a recursive follow-up is worth knowing but costs O(n) space).

## Examples

```
reverseList(1 -> 2 -> 3 -> 4 -> 5) → 5 -> 4 -> 3 -> 2 -> 1
reverseList(null)                    → null
reverseList(1)                        → 1
```

## Approach

Walk the list once, maintaining three pointers: `prev` (the reversed portion built so far), `current` (the node being processed), and a temporary `next` saved *before* rewriting `current.next`, to avoid losing the rest of the list. At each step, point `current.next` backward at `prev`, then advance both `prev` and `current` forward.

## Solution

```js
class ListNode {
  constructor(value, next = null) {
    this.value = value;
    this.next = next;
  }
}

function reverseList(head) {
  let prev = null;
  let current = head;

  while (current) {
    const next = current.next; // must save before overwriting current.next
    current.next = prev;
    prev = current;
    current = next;
  }

  return prev; // prev is the new head once current becomes null
}
```

## Complexity Analysis

**Time: O(n)** — each node's `next` pointer is rewritten exactly once.
**Space: O(1)** — only three pointer variables (`prev`, `current`, `next`), regardless of list length; no new nodes are allocated.
