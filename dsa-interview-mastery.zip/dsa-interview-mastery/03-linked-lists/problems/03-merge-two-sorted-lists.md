# Problem: Merge Two Sorted Linked Lists

## Problem Statement

Given the heads of two sorted (ascending) singly linked lists, merge them into one sorted list and return its head. The new list should be made by splicing together the nodes of the two input lists (no new node values should be created).

## Constraints

- Combined length up to `5 * 10^4` nodes.
- Both inputs are sorted ascending; either may be empty (`null`).

## Examples

```
mergeTwoLists(1->2->4, 1->3->4) → 1->1->2->3->4->4
mergeTwoLists(null, null)         → null
mergeTwoLists(null, 0)            → 0
```

## Approach

Use a dummy node to anchor the result and avoid special-casing the very first attachment. Walk both lists simultaneously with a `tail` pointer building the result: at each step, attach whichever current node has the smaller value, and advance that list's pointer. Once one list is exhausted, attach the entirety of whatever remains of the other list directly (it's already sorted, so no further comparison is needed).

## Solution

```js
class ListNode {
  constructor(value, next = null) {
    this.value = value;
    this.next = next;
  }
}

function mergeTwoLists(l1, l2) {
  const dummy = new ListNode(0);
  let tail = dummy;

  while (l1 && l2) {
    if (l1.value <= l2.value) {
      tail.next = l1;
      l1 = l1.next;
    } else {
      tail.next = l2;
      l2 = l2.next;
    }
    tail = tail.next;
  }

  tail.next = l1 !== null ? l1 : l2; // attach whichever list has leftover nodes
  return dummy.next;
}
```

## Complexity Analysis

**Time: O(n + m)** — where n and m are the lengths of the two input lists; each node from both lists is visited and attached exactly once.
**Space: O(1)** extra — existing nodes are relinked, not copied; only the dummy node and a constant number of pointer variables are allocated beyond the input lists themselves.
