# Problem: Determine If a Linked List Is a Palindrome

## Problem Statement

Given the head of a singly linked list, determine whether it reads the same forward and backward (a palindrome), in O(n) time and O(1) extra space.

## Constraints

- Up to `10^5` nodes.
- The O(1)-space constraint disallows copying values into an array first (that would be O(n) space) for full credit — though it's a valid, simpler O(n)-space first pass to mention.

## Examples

```
isPalindrome(1->2->2->1) → true
isPalindrome(1->2)         → false
isPalindrome(1)             → true
```

## Approach

Combine three earlier patterns: (1) fast/slow pointers to find the middle of the list in one pass, (2) iterative in-place reversal applied only to the second half, and (3) a two-pointer comparison walking from the original head and the reversed second half's head simultaneously. This avoids the O(n)-space alternative of copying all values into an array and checking that array for symmetry.

## Solution

```js
class ListNode {
  constructor(value, next = null) {
    this.value = value;
    this.next = next;
  }
}

function reverseList(head) {
  let prev = null, current = head;
  while (current) {
    const next = current.next;
    current.next = prev;
    prev = current;
    current = next;
  }
  return prev;
}

function isPalindrome(head) {
  if (!head || !head.next) return true;

  // Step 1: find the middle
  let slow = head, fast = head;
  while (fast && fast.next) {
    slow = slow.next;
    fast = fast.next.next;
  }

  // Step 2: reverse the second half
  let secondHalf = reverseList(slow);
  const secondHalfHead = secondHalf; // kept to optionally restore the list afterward

  // Step 3: compare first half against reversed second half
  let firstHalf = head;
  let result = true;
  while (secondHalf) {
    if (firstHalf.value !== secondHalf.value) {
      result = false;
      break;
    }
    firstHalf = firstHalf.next;
    secondHalf = secondHalf.next;
  }

  reverseList(secondHalfHead); // restore original list structure (good practice, optional)
  return result;
}
```

## Complexity Analysis

**Time: O(n)** — finding the middle is O(n), reversing the second half is O(n/2), and the comparison walk is O(n/2); all sum to O(n).
**Space: O(1)** — reversal happens in place on existing nodes; only a constant number of pointer variables are used, no array or new nodes.
