# Problem: Detect a Cycle and Find Its Starting Node

## Problem Statement

Given the head of a linked list, determine whether it contains a cycle. If it does, return the node where the cycle begins; otherwise return `null`.

## Constraints

- Up to `10^4` nodes.
- Must solve in O(1) extra space (disallows the "store every visited node in a Set" approach for full credit, though it's a valid O(n)-space first pass to mention).

## Examples

```
List: 3 -> 2 -> 0 -> -4 -> (back to node holding 2)
detectCycleStart(head) → the node holding value 2

List: 1 -> 2 -> null
detectCycleStart(head) → null
```

## Approach

Two-phase Floyd's algorithm. Phase 1: fast/slow pointers (1x/2x speed) detect *whether* a cycle exists — if they ever meet, one does. Phase 2: reset one pointer to `head`, then advance both remaining pointers one step at a time simultaneously — they are guaranteed to meet exactly at the cycle's starting node, a consequence of the distance relationships established during phase 1.

## Solution

```js
class ListNode {
  constructor(value, next = null) {
    this.value = value;
    this.next = next;
  }
}

function detectCycleStart(head) {
  let slow = head;
  let fast = head;

  // Phase 1: detect meeting point (if any)
  while (fast && fast.next) {
    slow = slow.next;
    fast = fast.next.next;
    if (slow === fast) {
      // Phase 2: find the start of the cycle
      let ptr = head;
      while (ptr !== slow) {
        ptr = ptr.next;
        slow = slow.next;
      }
      return ptr;
    }
  }

  return null; // fast reached the end -- no cycle
}
```

## Complexity Analysis

**Time: O(n)** — phase 1 takes at most O(n) iterations for `fast` to either exit or meet `slow`; phase 2 takes at most O(n) more steps. Total remains O(n).
**Space: O(1)** — only two (then three, transiently) pointer variables, no auxiliary `Set` or array, regardless of list length.
