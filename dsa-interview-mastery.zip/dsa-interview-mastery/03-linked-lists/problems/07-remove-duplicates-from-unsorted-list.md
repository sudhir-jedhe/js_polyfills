# Problem: Remove Duplicates from an Unsorted Linked List

## Problem Statement

Given the head of an unsorted singly linked list, remove all duplicate values, keeping only the first occurrence of each value, preserving relative order.

## Constraints

- Up to `10^4` nodes.
- Values are not guaranteed sorted (this is what makes a simple adjacent-comparison approach insufficient).
- Provide both an O(n)-time/O(n)-space solution and describe the O(n²)-time/O(1)-space alternative as a follow-up.

## Examples

```
removeDuplicates(1->3->2->3->1->5) → 1->3->2->5
removeDuplicates(1->1->1->1)          → 1
```

## Approach

Because the list is unsorted, a simple "compare each node to the next" pass (which works for a *sorted* list) is insufficient — a value could reappear anywhere later in the list, not just immediately adjacent. Use a `Set` to track values already seen; walk the list once, and whenever the current node's value has already been seen, unlink it by pointing the previous node's `next` past it; otherwise, record it as seen and advance normally.

## Solution

```js
class ListNode {
  constructor(value, next = null) {
    this.value = value;
    this.next = next;
  }
}

function removeDuplicates(head) {
  if (!head) return head;

  const seen = new Set([head.value]);
  let current = head;

  while (current.next) {
    if (seen.has(current.next.value)) {
      current.next = current.next.next; // unlink the duplicate node
    } else {
      seen.add(current.next.value);
      current = current.next;
    }
  }

  return head;
}
```

## Complexity Analysis

**Time: O(n)** — single pass; each node is visited once, and `Set.has`/`Set.add` are O(1) average case.
**Space: O(n)** — the `Set` holds up to n distinct values in the worst case (no duplicates at all).

**Follow-up (no extra space allowed):** without a `Set`, use a nested loop — for each node, scan all nodes after it and unlink any matching duplicates — giving O(n²) time but O(1) extra space. This is the standard time/space tradeoff follow-up interviewers ask once the O(n)/O(n) solution is given.
