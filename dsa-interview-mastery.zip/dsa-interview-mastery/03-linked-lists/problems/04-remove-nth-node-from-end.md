# Problem: Remove the N-th Node From the End of a List

## Problem Statement

Given the head of a linked list and an integer `n`, remove the n-th node from the end of the list and return the (possibly new) head. Solve it in a single pass.

## Constraints

- The list has between `1` and `30` nodes.
- `1 <= n <= list length` (n is always valid — no bounds error case to handle).

## Examples

```
removeNthFromEnd(1->2->3->4->5, 2) → 1->2->3->5
removeNthFromEnd(1, 1)                → null
removeNthFromEnd(1->2, 1)             → 1
```

## Approach

Use a dummy node ahead of `head` so removing the actual head node (when `n` equals the list length) doesn't require special-case logic. Advance a `fast` pointer `n` steps ahead of a `slow` pointer first; then advance both together until `fast` reaches the last node. At that point, `slow` sits exactly one node before the target, ready to unlink it — all in a single traversal.

## Solution

```js
class ListNode {
  constructor(value, next = null) {
    this.value = value;
    this.next = next;
  }
}

function removeNthFromEnd(head, n) {
  const dummy = new ListNode(0, head);
  let fast = dummy;
  let slow = dummy;

  for (let i = 0; i < n; i++) {
    fast = fast.next; // lead pointer n steps ahead
  }

  while (fast.next) {
    fast = fast.next;
    slow = slow.next;
  }

  slow.next = slow.next.next; // unlink the n-th-from-end node
  return dummy.next;
}
```

## Complexity Analysis

**Time: O(L)** — where L is the list length; the lead-offset loop and the simultaneous-advance loop together visit each node at most once (single pass, not two separate full traversals).
**Space: O(1)** — only the dummy node plus two pointer variables, regardless of list length.
