# Problem: Add Two Numbers Represented as Linked Lists

## Problem Statement

Two non-negative integers are represented as linked lists, where each node holds a single digit stored in **reverse order** (the 1's digit is the head). Add the two numbers and return the sum as a linked list in the same reversed-digit format.

## Constraints

- Each list has between `1` and `100` nodes.
- `0 <= node value <= 9` (no leading zeros in the input, except the number `0` itself).

## Examples

```
addTwoNumbers(2->4->3, 5->6->4) → 7->0->8      (342 + 465 = 807)
addTwoNumbers(0, 0)               → 0
addTwoNumbers(9->9->9, 9->9->9->9) → 8->9->9->0->1   (999 + 9999 = 10998)
```

## Approach

Because digits are already stored least-significant-first, this maps directly onto elementary-school column addition: walk both lists simultaneously, summing corresponding digits plus any carry from the previous position, emitting one result digit (`sum % 10`) per step and carrying the rest (`Math.floor(sum / 10)`) forward. Continue until both lists are exhausted **and** no carry remains, since the result may have one more digit than either input (e.g. `9999 + 1`).

## Solution

```js
class ListNode {
  constructor(value, next = null) {
    this.value = value;
    this.next = next;
  }
}

function addTwoNumbers(l1, l2) {
  const dummy = new ListNode(0);
  let tail = dummy;
  let carry = 0;

  while (l1 || l2 || carry) {
    const digit1 = l1 ? l1.value : 0;
    const digit2 = l2 ? l2.value : 0;

    const sum = digit1 + digit2 + carry;
    carry = Math.floor(sum / 10);
    tail.next = new ListNode(sum % 10);
    tail = tail.next;

    if (l1) l1 = l1.next;
    if (l2) l2 = l2.next;
  }

  return dummy.next;
}
```

## Complexity Analysis

**Time: O(max(n, m))** — where n and m are the lengths of the two input lists; the loop runs once per digit position up to the longer list's length (plus possibly one more for a final carry).
**Space: O(max(n, m))** — for the newly created result list, which is unavoidable since a new list must be returned (not counted against an "extra space" constraint, since it's the required output); no other auxiliary structures are used.
