# Insertion Sort

```js
function insertionSort(arr) {
  const a = [...arr];
  for (let i = 1; i < a.length; i++) {
    const current = a[i];
    let j = i - 1;
    while (j >= 0 && a[j] > current) {
      a[j + 1] = a[j];
      j--;
    }
    a[j + 1] = current;
  }
  return a;
}

console.log(insertionSort([9, 5, 1, 4, 3])); // [1, 3, 4, 5, 9]
console.log(insertionSort([1, 2, 3, 4, 9]));  // best case: nearly no shifting, close to O(n)
```
