# Counting Sort Implementation

```js
function countingSort(arr, maxValue = Math.max(...arr)) {
  const counts = new Array(maxValue + 1).fill(0);
  for (const num of arr) counts[num]++;

  const result = [];
  for (let value = 0; value <= maxValue; value++) {
    while (counts[value]-- > 0) result.push(value);
  }
  return result;
}

console.log(countingSort([4, 2, 2, 8, 3, 3, 1])); // [1, 2, 2, 3, 3, 4, 8]
// Only appropriate when the value range is small relative to n -- see theory/05 for why
```
