# `Array.sort()` Default Comparator Trap — and the Fix

```js
const scores = [100, 25, 3, 40];
console.log(scores.sort());
// [100, 25, 3, 40] -- WRONG! sorted as strings: "100" < "25" < "3" < "40" lexicographically

console.log(scores.sort((a, b) => a - b));
// [3, 25, 40, 100] -- correct ascending numeric order

console.log(scores.sort((a, b) => b - a));
// [100, 40, 25, 3] -- descending

// Sorting objects always needs an explicit comparator -- there is no sensible default
const people = [{ name: 'Bob', age: 25 }, { name: 'Amy', age: 30 }, { name: 'Cid', age: 20 }];
console.log(people.sort((a, b) => a.age - b.age).map(p => p.name)); // ['Cid', 'Bob', 'Amy']
```
