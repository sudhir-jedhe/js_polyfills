Diagrams and visual aids for sorting algorithms (partitioning walkthroughs, merge trees, heap structures) will be added here.
