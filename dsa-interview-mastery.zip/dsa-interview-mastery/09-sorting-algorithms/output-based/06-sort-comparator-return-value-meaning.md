# Output: Comparator Return Value — What Does the Sign Mean?

```js
const nums = [3, 1, 4, 1, 5];

console.log(nums.slice().sort((a, b) => a - b));       // ?
console.log(nums.slice().sort((a, b) => 1));            // ? -- always returns a positive number
console.log(nums.slice().sort((a, b) => 0));             // ? -- always returns zero
```

**Answer:** `[1, 1, 3, 4, 5]`, then an array that **may not be sorted at all** (implementation-defined, but for this particular case likely reverses to something like `[5, 1, 4, 1, 3]` or similar, depending on the engine's merge pattern), then the **original, unchanged order** `[3, 1, 4, 1, 5]`.

**Why:** A comparator must return: a **negative** number if `a` should sort before `b`, a **positive** number if `a` should sort after `b`, and `0` if their relative order doesn't matter (they're "equal" for sorting purposes). `(a, b) => 1` claims *every* pair has `a` after `b`, which is a self-contradictory/invalid comparator (it can't be consistently true for all pairs) — the actual output becomes implementation-defined garble, since the sorting algorithm's internal comparisons no longer form a valid total order. `(a, b) => 0` claims every pair is "equal," so a stable sort (which `Array.sort` is guaranteed to be) makes no swaps at all — the array comes back in its **original order**, unchanged. The concrete lesson: the comparator isn't just "truthy means swap" — it must return a value whose **sign** consistently encodes relative order across all pairs, or the sort's output is not well-defined.
