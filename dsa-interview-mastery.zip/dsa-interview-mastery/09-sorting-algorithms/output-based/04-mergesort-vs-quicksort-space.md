# What's the Complexity? — Merge Sort Space Usage

```js
function mergeSort(arr) {
  if (arr.length <= 1) return arr;
  const mid = Math.floor(arr.length / 2);
  const left = mergeSort(arr.slice(0, mid));   // slice() copies -- allocates a new array
  const right = mergeSort(arr.slice(mid));
  return merge(left, right);                    // merge() also allocates a new result array
}
```

**Question:** What is the auxiliary (extra, beyond the input) space complexity of this merge sort implementation?

**Answer:** **O(n)** total auxiliary space (though this particular implementation, using `.slice()` at every recursive call plus a new array in every `merge`, has a higher constant factor than a tightly-written version — but the asymptotic bound stays O(n), not O(n log n), for the standard textbook analysis).

**Why:** At any given moment, the total number of elements held across all the temporary `left`/`right`/`result` arrays active in the call stack sums to O(n) — despite looking like it might multiply out with the recursion depth, the temporary arrays at each level of recursion don't all coexist simultaneously *and* even where they do, their total size per level is bounded by n. This is the standard result: merge sort takes O(n) auxiliary space, in contrast to quicksort's O(log n) (just the recursion call stack, no auxiliary array — quicksort partitions in-place) and heap sort's O(1). Space is exactly the trade-off merge sort makes for its unconditional O(n log n) time guarantee and stability — see `theory/02-merge-sort.md`.
