# Output: Stability — Does Relative Order Survive?

```js
const items = [
  { name: 'a', priority: 1 },
  { name: 'b', priority: 2 },
  { name: 'c', priority: 1 },
  { name: 'd', priority: 2 },
];

const sorted = items.sort((a, b) => a.priority - b.priority);
console.log(sorted.map(i => i.name));
```

**Answer:** `['a', 'c', 'b', 'd']`

**Why:** `Array.prototype.sort()` in JavaScript has been spec-required to be **stable** since ES2019, and every modern engine honors this. Items `a` and `c` tie at `priority: 1` — since the sort is stable, they keep their original relative order (`a` before `c`, exactly as in the input array). Same for `b` and `d` at `priority: 2`. If you were hand-implementing this comparison in a language/engine with an *unstable* sort (or using an unstable algorithm like naive quicksort or selection sort yourself), the output order among tied elements would be unspecified — could just as easily come out as `['c', 'a', 'd', 'b']` depending on implementation details. This is exactly why the stability question matters practically: "sort orders by status, keep same-status orders in their original submission order" only works correctly with a stable sort.
