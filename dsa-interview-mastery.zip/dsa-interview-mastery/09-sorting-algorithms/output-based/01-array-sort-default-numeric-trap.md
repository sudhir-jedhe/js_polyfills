# Output: Default `.sort()` on Numbers

```js
const arr = [5, 30, 1, 4, 21, 100];
console.log(arr.sort());
```

**Answer:** `[1, 100, 21, 30, 4, 5]`

**Why:** With no comparator, `.sort()` converts every element to a string via `String(x)` and compares them lexicographically (character by character, by UTF-16 code unit) — not numerically. `'1'` sorts before `'100'` and `'21'` because comparing strings character-by-character, `'1'` is the shortest match and ties are broken by length only after all compared characters match, so `'1' < '100' < '21' < '30' < '4' < '5'` alphabetically. The fix is always the same: pass an explicit comparator, `arr.sort((a, b) => a - b)`, which would correctly produce `[1, 4, 5, 21, 30, 100]`.
