# What's the Complexity? — Insertion Sort on Nearly-Sorted Data

```js
function insertionSort(arr) {
  const a = [...arr];
  let totalShifts = 0;
  for (let i = 1; i < a.length; i++) {
    const current = a[i];
    let j = i - 1;
    while (j >= 0 && a[j] > current) {
      a[j + 1] = a[j];
      j--;
      totalShifts++;
    }
    a[j + 1] = current;
  }
  console.log('total shifts:', totalShifts);
  return a;
}

insertionSort([1, 2, 3, 4, 5, 6, 7, 100, 8]); // one element (100) out of place, rest already sorted
```

**Question:** What's the time complexity of this call, and roughly how many shifts print?

**Answer:** **O(n)** for this near-best-case input (not O(n²)), and `totalShifts` prints `1`.

**Why:** Insertion sort's inner `while` loop only runs when the current element is smaller than its immediate predecessor. For a nearly-sorted array, almost every element is already `>=` its predecessor, so the inner loop exits after zero or one comparison for most positions — the only real work happens when `100` (out of place) needs exactly one shift to let `8` move past it into position. This is the concrete mechanism behind insertion sort's O(n) best case: unlike selection sort (which always does a full O(n) scan per outer iteration regardless of input order), insertion sort's cost is **data-dependent** — proportional to how far each element is from its final sorted position, which is why it's the practical choice for sorting data that's already mostly ordered (e.g. re-sorting a log after appending a few late-arriving entries).
