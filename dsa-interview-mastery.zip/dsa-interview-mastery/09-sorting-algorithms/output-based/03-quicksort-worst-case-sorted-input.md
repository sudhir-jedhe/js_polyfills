# What's the Complexity? — Quicksort on Already-Sorted Input with a Fixed Pivot

```js
function quickSort(arr, low = 0, high = arr.length - 1) {
  if (low < high) {
    const pivotIndex = partition(arr, low, high);
    quickSort(arr, low, pivotIndex - 1);
    quickSort(arr, pivotIndex + 1, high);
  }
  return arr;
}
function partition(arr, low, high) {
  const pivot = arr[high]; // ALWAYS the last element -- no randomization
  let i = low - 1;
  for (let j = low; j < high; j++) {
    if (arr[j] <= pivot) { i++; [arr[i], arr[j]] = [arr[j], arr[i]]; }
  }
  [arr[i + 1], arr[high]] = [arr[high], arr[i + 1]];
  return i + 1;
}

const sorted = [1, 2, 3, 4, 5, 6, 7, 8];
quickSort(sorted);
// what is the TIME complexity of this call, given the input is already sorted?
```

**Answer:** **O(n²)**, not O(n log n).

**Why:** With a fixed "always pick the last element" pivot strategy and an already-sorted input, every partition call picks the *largest* remaining element as the pivot — so partitioning always produces a split of size `n-1` and `0` (everything else ends up ≤ pivot, nothing ends up greater). This is the maximally unbalanced split. The recursion depth becomes `n` (one level removed per call, instead of halving), and each level still does O(n) work for partitioning, giving `O(n) + O(n-1) + O(n-2) + ... + O(1) = O(n²)`. This is precisely why production quicksort implementations randomize the pivot (or use median-of-three) — it doesn't change the theoretical worst case, but it makes triggering it by accident (or via ordinary sorted input, which is common in practice) essentially impossible, since the adversarial input would need to specifically target the random choice made at runtime.
