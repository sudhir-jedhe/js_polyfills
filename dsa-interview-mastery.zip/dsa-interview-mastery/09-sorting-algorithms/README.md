# Sorting Algorithms

Sorting is one of the oldest and most thoroughly studied problems in computer science, and interviewers use it to probe several skills at once: can you implement a non-trivial recursive algorithm correctly under pressure (merge/quick sort), can you reason precisely about worst-case vs average-case complexity (quicksort's O(n²) trap), do you understand stability and when it actually matters, and do you know JavaScript's own `Array.sort()` well enough to avoid its most common silent bug (the default lexicographic comparator on numbers). This topic covers the full landscape: the simple O(n²) sorts and when they're still the right call, the three "big" O(n log n) comparison sorts (merge, quick, heap) with a precise worst-case analysis for each, the non-comparison sorts (counting, radix) that escape the O(n log n) floor entirely, and exactly how JS's built-in sort behaves.

## Folder structure

- **`theory/`** — bubble/selection/insertion sort, merge sort, quick sort (with a precise worst-case derivation), heap sort, counting sort & radix sort, and stability plus `Array.sort()`'s actual behavior and default-comparator trap.
- **`snippets/`** — 7 focused, runnable implementations: all three simple sorts, merge sort, randomized quicksort, counting sort, and the `.sort()` comparator trap/fix side by side.
- **`output-based/`** — 6 "predict the output / what's the complexity?" questions covering the numeric-sort trap, stability, quicksort's worst case, merge sort's space cost, insertion sort's best case, and comparator contract violations.
- **`scenarios/`** — 5 real-world situations: sorting a nearly-sorted log stream, external sorting for data that doesn't fit in memory, counting sort for a known small range, multi-key stable sorting, and choosing a sort under tight memory constraints.
- **`interview-qa/`** — 15 Q&A pairs across 3 themed files: comparison-sort fundamentals, quicksort/merge sort/heap sort specifics, and non-comparison sorts plus JS's `Array.sort()`.
- **`problems/`** — 6 hands-on coding challenges: implement merge sort, implement quicksort, sort colors (Dutch flag), kth largest element (quickselect), merge intervals, and sort by frequency.
- **`assets/`** — placeholder for diagrams (see `assets/README.md`).

## What's covered

- Bubble, selection, and insertion sort — their real O(n) best cases and where they're still practically useful (small arrays, nearly-sorted data, minimal-write scenarios)
- Merge sort's guaranteed O(n log n) in every case, its O(n) space cost, and why the `<=` comparison is what makes it stable
- Quicksort's pivot selection strategies and a precise derivation of exactly when and why its worst case is O(n²)
- Heap sort's O(n log n) worst-case guarantee with O(1) space, and why building a heap is O(n) not O(n log n)
- Counting sort and radix sort — how they escape the O(n log n) comparison-sort lower bound, and the range constraints that limit them
- A full stability comparison table across every algorithm covered
- JS's `Array.prototype.sort()`: its guaranteed stability since ES2019, its Timsort-like hybrid implementation, and the default string-coercion comparator trap on numbers
