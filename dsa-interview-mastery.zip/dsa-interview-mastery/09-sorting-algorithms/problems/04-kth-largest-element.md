# Problem: Kth Largest Element in an Array

## Problem Statement

Given an unsorted array of integers and an integer `k`, find the `k`-th largest element — not the `k`-th *distinct* element, duplicates count individually.

## Constraints

- `1 <= k <= nums.length <= 10^5`
- `-10^4 <= nums[i] <= 10^4`

## Examples

```
Input: nums = [3, 2, 1, 5, 6, 4], k = 2
Output: 5             // sorted descending: 6, 5, 4, 3, 2, 1 -- 2nd largest is 5

Input: nums = [3, 2, 3, 1, 2, 4, 5, 5, 6], k = 4
Output: 4
```

## Approach

The naive approach — full sort, then index `n - k` — is O(n log n) and always does more work than necessary (fully ordering the entire array to answer a single positional question). The better approach is **quickselect**, a quicksort-partition-based algorithm that only recurses into the *one* side of the partition that could contain the answer, giving expected O(n) time (this is the canonical follow-up interviewers want after you produce the O(n log n) sort-based answer).

## Solution

```js
function findKthLargest(nums, k) {
  const targetIndex = nums.length - k; // k-th largest == index (n-k) in ascending sorted order
  return quickSelect(nums, 0, nums.length - 1, targetIndex);
}

function quickSelect(arr, low, high, targetIndex) {
  if (low === high) return arr[low];

  const pivotIndex = partition(arr, low, high);
  if (pivotIndex === targetIndex) return arr[pivotIndex];
  if (pivotIndex < targetIndex) return quickSelect(arr, pivotIndex + 1, high, targetIndex);
  return quickSelect(arr, low, pivotIndex - 1, targetIndex);
}

function partition(arr, low, high) {
  const randomIndex = low + Math.floor(Math.random() * (high - low + 1));
  [arr[randomIndex], arr[high]] = [arr[high], arr[randomIndex]];

  const pivot = arr[high];
  let i = low - 1;
  for (let j = low; j < high; j++) {
    if (arr[j] <= pivot) {
      i++;
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
  }
  [arr[i + 1], arr[high]] = [arr[high], arr[i + 1]];
  return i + 1;
}

module.exports = { findKthLargest };

// --- verification ---
console.log(findKthLargest([3, 2, 1, 5, 6, 4], 2)); // 5
console.log(findKthLargest([3, 2, 3, 1, 2, 4, 5, 5, 6], 4)); // 4
```

## Complexity

- **Time:** O(n) expected (quickselect only recurses into one side each time, so work halves on average each round: n + n/2 + n/4 + ... = O(n)). **Worst case O(n²)** with an unlucky/adversarial pivot sequence, same underlying risk as quicksort, mitigated the same way (randomized pivot).
- **Space:** O(log n) expected (recursion depth), O(n) worst case.

**Alternative:** a min-heap of size k gives a guaranteed O(n log k) worst case with no risk of O(n²) — worth mentioning as the safer alternative if the interviewer pushes on quickselect's worst case (see the heaps topic for the heap-based "top-K" pattern).
