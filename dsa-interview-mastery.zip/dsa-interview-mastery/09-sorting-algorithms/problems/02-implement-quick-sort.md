# Problem: Implement Quick Sort

## Problem Statement

Implement quicksort from scratch, sorting an array of numbers **in place**. Include a strategy to avoid the O(n²) worst case being trivially triggered by sorted or reverse-sorted input.

## Requirements

- Must sort in place (O(log n) auxiliary space for recursion, not O(n)).
- Must mitigate the worst case for common "already sorted" inputs via pivot randomization.
- State the worst-case time complexity even with randomization, and explain why it can still theoretically occur.

## Approach

Use Lomuto partitioning: pick a pivot, swap it to the end, then walk through the array moving every element `<= pivot` to the front, finally placing the pivot in its correct final position. Randomize which element is chosen as the pivot before partitioning to avoid the worst case being triggered "for free" by sorted input.

## Solution

```js
function quickSort(arr, low = 0, high = arr.length - 1) {
  if (low < high) {
    const pivotIndex = partition(arr, low, high);
    quickSort(arr, low, pivotIndex - 1);
    quickSort(arr, pivotIndex + 1, high);
  }
  return arr;
}

function partition(arr, low, high) {
  const randomIndex = low + Math.floor(Math.random() * (high - low + 1));
  [arr[randomIndex], arr[high]] = [arr[high], arr[randomIndex]]; // randomize pivot

  const pivot = arr[high];
  let i = low - 1;
  for (let j = low; j < high; j++) {
    if (arr[j] <= pivot) {
      i++;
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
  }
  [arr[i + 1], arr[high]] = [arr[high], arr[i + 1]];
  return i + 1;
}

module.exports = { quickSort };

// --- verification ---
console.log(quickSort([5, 2, 8, 1, 9, 3]));         // [1, 2, 3, 5, 8, 9]
console.log(quickSort([1, 2, 3, 4, 5]));             // already sorted -- randomized pivot avoids worst case in practice
console.log(quickSort([5, 4, 3, 2, 1]));             // reverse sorted -- same
console.log(quickSort([]));                           // []
console.log(quickSort([7]));                          // [7]
```

## Complexity

- **Time:** O(n log n) average and expected case (with randomized pivot). **Worst case is still O(n²)** — randomization doesn't change the theoretical worst case, it only makes that worst case exceedingly unlikely to occur on any given input, since it would require the random choices themselves to consistently produce the worst pivot, rather than the input's fixed order alone determining it.
- **Space:** O(log n) average (recursion depth when splits are roughly balanced), O(n) worst case (recursion depth when splits are maximally unbalanced).

**Not stable** — the swaps during partitioning can reorder equal elements; explicitly worth naming if asked, since it's the most common quicksort follow-up after worst-case analysis.
