# Problem: Sort an Array by Decreasing Frequency

## Problem Statement

Given an array of integers, sort it so that elements appear in order of **decreasing frequency** (the most frequent value's occurrences come first). If two values have the same frequency, order between them doesn't matter, but each value's own occurrences should stay grouped together.

## Constraints

- `1 <= nums.length <= 10^5`
- `-10^4 <= nums[i] <= 10^4`

## Examples

```
Input: [1, 1, 2, 2, 2, 3]
Output: [2, 2, 2, 1, 1, 3]     // 2 appears 3x, 1 appears 2x, 3 appears 1x

Input: [2, 3, 1, 3, 2]
Output: [3, 3, 2, 2, 1]         // or [2, 2, 3, 3, 1] -- either tie order is valid
```

## Approach

This combines hashing (from the hashing topic — counting frequencies) with sorting: first build a frequency map in O(n), then sort the **distinct values** by their frequency (descending) — sorting only u distinct values instead of all n elements — and finally expand each value out by its count. This is meaningfully cheaper than sorting all n raw elements directly whenever there are many duplicates (u << n).

## Solution

```js
function frequencySort(nums) {
  const freq = new Map();
  for (const num of nums) freq.set(num, (freq.get(num) ?? 0) + 1);

  const distinctValues = [...freq.keys()];
  distinctValues.sort((a, b) => freq.get(b) - freq.get(a)); // descending by frequency

  const result = [];
  for (const value of distinctValues) {
    for (let i = 0; i < freq.get(value); i++) result.push(value);
  }
  return result;
}

module.exports = { frequencySort };

// --- verification ---
console.log(frequencySort([1, 1, 2, 2, 2, 3])); // [2, 2, 2, 1, 1, 3]
console.log(frequencySort([2, 3, 1, 3, 2]));     // [3, 3, 2, 2, 1] or [2, 2, 3, 3, 1] (tie order unspecified)
```

## Complexity

- **Time:** O(n + u log u) — O(n) to build the frequency map and to expand the final result, O(u log u) to sort the distinct values (u ≤ n). When there are many duplicates, u is much smaller than n, making this cheaper than a direct O(n log n) sort of the raw array.
- **Space:** O(u) for the frequency map and the distinct-values array, plus O(n) for the output.

**Cross-reference:** this is a direct composition of two topics — hashing solves "count occurrences," sorting solves "order by that count" — the same two-structure pattern seen in the hashing topic's "top-K word frequency" scenario, just applied to a full re-ordering rather than a top-N selection.
