# Problem: Implement Merge Sort

## Problem Statement

Implement merge sort from scratch: a function that sorts an array of numbers in ascending order, guaranteeing O(n log n) time in every case and stability (equal elements keep their original relative order).

## Requirements

- Must not use the built-in `Array.prototype.sort()`.
- Must be stable.
- Must guarantee O(n log n) regardless of input order (no degraded worst case).

## Approach

Recursively split the array in half until each piece has 0 or 1 elements (trivially sorted), then merge sorted pairs back together, always taking from the left side first on ties to preserve stability.

## Solution

```js
function mergeSort(arr) {
  if (arr.length <= 1) return arr;

  const mid = Math.floor(arr.length / 2);
  const left = mergeSort(arr.slice(0, mid));
  const right = mergeSort(arr.slice(mid));

  return merge(left, right);
}

function merge(left, right) {
  const result = [];
  let i = 0, j = 0;

  while (i < left.length && j < right.length) {
    if (left[i] <= right[j]) { // <= (not <) preserves stability -- left wins ties
      result.push(left[i]);
      i++;
    } else {
      result.push(right[j]);
      j++;
    }
  }
  while (i < left.length) result.push(left[i++]);
  while (j < right.length) result.push(right[j++]);
  return result;
}

module.exports = { mergeSort };

// --- verification ---
console.log(mergeSort([38, 27, 43, 3, 9, 82, 10])); // [3, 9, 10, 27, 38, 43, 82]
console.log(mergeSort([]));    // []
console.log(mergeSort([5]));   // [5]
console.log(mergeSort([2, 2, 1, 1])); // [1, 1, 2, 2]

// stability check with tagged objects
const items = [{v:1,tag:'a'},{v:2,tag:'b'},{v:1,tag:'c'}];
console.log(mergeSort(items).map(x => x.tag)); // ['a','c','b'] -- ties (v:1) keep original order (a before c)
```

## Complexity

- **Time:** O(n log n) — every case, no exceptions. `log n` levels of recursion, O(n) merge work per level.
- **Space:** O(n) — auxiliary arrays created by `.slice()` and `merge`'s `result` array.

The two details an interviewer will specifically probe: (1) using `<=` rather than `<` in `merge` for stability, and (2) being able to explain why the recursion always produces `log n` levels regardless of input values (the split point is always the midpoint, not data-dependent).
