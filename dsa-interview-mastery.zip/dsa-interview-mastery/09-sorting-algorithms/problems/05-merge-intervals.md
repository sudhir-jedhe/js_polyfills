# Problem: Merge Intervals

## Problem Statement

Given an array of intervals `[start, end]`, merge all overlapping intervals and return an array of the non-overlapping intervals that cover all the input intervals.

## Constraints

- `1 <= intervals.length <= 10^4`
- `intervals[i].length === 2`
- `0 <= start <= end <= 10^5`

## Examples

```
Input: [[1,3],[2,6],[8,10],[15,18]]
Output: [[1,6],[8,10],[15,18]]    // [1,3] and [2,6] overlap -> merged into [1,6]

Input: [[1,4],[4,5]]
Output: [[1,5]]                    // touching intervals (end == next start) count as overlapping
```

## Approach

Sorting is the key unlock here: once intervals are sorted by **start** value, any overlap can only happen between an interval and its immediate neighbor in the sorted order — you never need to compare non-adjacent intervals. This turns an otherwise O(n²) all-pairs overlap check into a single O(n) linear scan, at the cost of the initial O(n log n) sort.

## Solution

```js
function mergeIntervals(intervals) {
  if (intervals.length <= 1) return intervals;

  const sorted = [...intervals].sort((a, b) => a[0] - b[0]); // sort by start -- the essential first step
  const merged = [sorted[0]];

  for (let i = 1; i < sorted.length; i++) {
    const [start, end] = sorted[i];
    const lastMerged = merged[merged.length - 1];

    if (start <= lastMerged[1]) {
      // overlaps (or touches) the last merged interval -- extend its end if needed
      lastMerged[1] = Math.max(lastMerged[1], end);
    } else {
      merged.push([start, end]); // no overlap -- starts a new merged interval
    }
  }
  return merged;
}

module.exports = { mergeIntervals };

// --- verification ---
console.log(mergeIntervals([[1,3],[2,6],[8,10],[15,18]])); // [[1,6],[8,10],[15,18]]
console.log(mergeIntervals([[1,4],[4,5]]));                 // [[1,5]]
console.log(mergeIntervals([[1,4]]));                        // [[1,4]]
```

## Complexity

- **Time:** O(n log n) — dominated by the initial sort; the merge scan itself is O(n).
- **Space:** O(n) — for the sorted copy and the output (or O(log n) if only counting the sort's internal space, ignoring output).

This is a strong example of sorting as a *pre-processing enabler*: the problem isn't "sort this array," but sorting transforms an otherwise all-pairs comparison problem into one that only needs adjacent-element comparisons — recognizing that transformation is the actual interview signal being tested.
