# Problem: Sort Colors (Dutch National Flag)

## Problem Statement

Given an array containing only the values `0`, `1`, and `2` (representing red, white, and blue), sort it in place in a single pass, without using a general-purpose sort or counting sort's two-pass approach.

## Constraints

- `1 <= nums.length <= 300`
- `nums[i]` is `0`, `1`, or `2`.
- Must sort in place, in one pass, using O(1) extra space.

## Examples

```
Input: [2, 0, 2, 1, 1, 0]
Output: [0, 0, 1, 1, 2, 2]

Input: [2, 0, 1]
Output: [0, 1, 2]
```

## Approach

This is the classic **Dutch National Flag** problem (Dijkstra). Maintain three pointers: `low` (boundary of the 0-region), `mid` (current element being examined), and `high` (boundary of the 2-region). Walk `mid` through the array once: if it points to a `0`, swap it to the `low` region and advance both `low` and `mid`; if `2`, swap it to the `high` region and shrink `high` (but do **not** advance `mid`, since the swapped-in element from the high end hasn't been examined yet); if `1`, it's already in the correct middle zone, just advance `mid`.

## Solution

```js
function sortColors(nums) {
  let low = 0, mid = 0, high = nums.length - 1;

  while (mid <= high) {
    if (nums[mid] === 0) {
      [nums[low], nums[mid]] = [nums[mid], nums[low]];
      low++;
      mid++; // safe to advance: swapped-in element from `low` was already examined (it was 0 or 1)
    } else if (nums[mid] === 2) {
      [nums[mid], nums[high]] = [nums[high], nums[mid]];
      high--; // do NOT advance mid here -- the newly swapped-in element hasn't been checked yet
    } else {
      mid++; // it's a 1, already correctly placed in the middle region
    }
  }
  return nums;
}

module.exports = { sortColors };

// --- verification ---
console.log(sortColors([2, 0, 2, 1, 1, 0])); // [0, 0, 1, 1, 2, 2]
console.log(sortColors([2, 0, 1]));           // [0, 1, 2]
console.log(sortColors([0]));                 // [0]
console.log(sortColors([1, 1, 1]));           // [1, 1, 1]
```

## Complexity

- **Time:** O(n) — single pass, `mid` only ever moves forward or stays (on a `2` swap); the total number of pointer movements is bounded by n.
- **Space:** O(1) — three pointers, in-place swaps, no auxiliary array.

This is a specialized case of counting sort's underlying idea (only 3 distinct values) done in a single in-place pass instead of counting sort's separate count-then-rebuild phases — worth explicitly connecting to counting sort if asked about the relationship between the two.
