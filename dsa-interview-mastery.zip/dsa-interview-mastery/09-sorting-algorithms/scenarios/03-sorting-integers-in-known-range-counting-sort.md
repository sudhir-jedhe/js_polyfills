# Scenario: Sorting Exam Scores by Percentile Bucket

**Scenario:** You need to sort one million exam scores, each an integer from 0 to 100, to compute percentile rankings. A generic `Array.sort()` call would work, but a colleague suggests it's needlessly slow for this specific case. Are they right, and what would you do instead?

**Approach:**

They're right — this is a textbook fit for **counting sort**, because the value range (0-100, so k=101) is tiny and fixed relative to n (one million). Counting sort runs in O(n + k) instead of a comparison sort's O(n log n), and for n = 1,000,000 with k = 101, that's a meaningful practical difference (roughly n + k vs n log n ≈ 20n).

```js
function sortScores(scores) {
  const counts = new Array(101).fill(0); // scores are guaranteed 0-100
  for (const score of scores) counts[score]++;

  const sorted = [];
  for (let score = 0; score <= 100; score++) {
    while (counts[score]-- > 0) sorted.push(score);
  }
  return sorted;
}
```

This also directly answers the percentile question with almost no extra work — `counts[score]` and a running prefix sum over `counts` give you the exact count of scores at or below any threshold in O(1) after the O(n + k) counting pass, without needing the fully sorted array at all in some cases.

The scenario-level lesson: a comparison sort (`Array.sort`) is the safe general-purpose default, but recognizing "the values live in a small, known, fixed range" as a structural property of the *data* — not just the algorithm — is what unlocks a non-comparison sort that beats the theoretical O(n log n) floor that applies to comparison-based approaches only.
