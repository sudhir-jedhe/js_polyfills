# Scenario: Sorting on a Memory-Constrained Embedded Device

**Scenario:** You're writing firmware for an embedded sensor device with very limited RAM. You need to sort a buffer of a few hundred integer readings, and you can't afford to allocate any auxiliary array proportional to the input size — extra allocations risk running out of memory entirely. Which sort would you pick, and which would you rule out immediately?

**Approach:**

Rule out **merge sort** first — its O(n) auxiliary space for the merge step is exactly the constraint you can't afford, regardless of its attractive guaranteed O(n log n) time and stability.

That leaves the in-place options: quicksort (O(log n) space for the recursion stack — technically not O(1), but much smaller than O(n)), heap sort (true O(1) auxiliary space if `siftDown` is written iteratively rather than recursively), and the simple O(n²) sorts (bubble/selection/insertion, all O(1) space).

For "a few hundred" elements specifically:
- If worst-case time matters and O(n²) is unacceptable even for a few hundred elements (say, this runs frequently or under real-time constraints): **heap sort** — guaranteed O(n log n) worst case, true O(1) space, no risk of quicksort's pathological O(n²) case triggering on already-sorted sensor data (which is a realistic scenario if readings arrive roughly in order).
- If a few hundred elements sorting occasionally, and O(n²) is genuinely fine at that small scale (a few hundred² is still only ~100,000 operations, likely fast enough): **insertion sort** — simplest to implement correctly in constrained firmware, O(1) space, and if readings tend to arrive nearly-sorted (common for time-series sensor data), it approaches O(n) in practice.

The reasoning that matters here: "limited memory" should immediately narrow the candidate list to in-place algorithms, ruling out merge sort's O(n) requirement outright regardless of its other advantages — a demonstration that the "best" sort is always a function of the actual constraints (time budget, memory budget, stability requirement, data characteristics), not a single universal answer.
