# Scenario: Sorting a Dataset That Doesn't Fit in Memory

**Scenario:** You need to sort a 500GB file of records, but the machine only has 16GB of RAM. Quicksort and heap sort both assume random access to the full array in memory. What approach actually works here, and why does merge sort's structure make it the natural fit?

**Approach:**

This is the classic **external sorting** problem, and it's solved with an approach directly derived from merge sort's divide-and-conquer structure — specifically, its **merge step only ever needs sequential access to two already-sorted streams**, never random access to the whole dataset at once:

1. **Split phase:** read the 500GB file in chunks that *do* fit in memory (e.g. 4GB at a time), sort each chunk in-memory with any standard in-memory sort (quicksort, or `Array.sort`), and write each sorted chunk back to disk as a separate "run."
2. **Merge phase:** repeatedly merge sorted runs pairwise (or k-way merge several at once), the same way merge sort's `merge()` combines two sorted halves — except each "half" is a disk file, read incrementally rather than loaded entirely into memory, and the merged output is streamed back to disk.

```js
// Conceptual sketch of the merge step, generalized to disk-backed streams instead of in-memory arrays:
function mergeStreams(readStreamA, readStreamB, writeStream) {
  let a = readStreamA.next();
  let b = readStreamB.next();
  while (a !== null && b !== null) {
    if (a <= b) { writeStream.write(a); a = readStreamA.next(); }
    else { writeStream.write(b); b = readStreamB.next(); }
  }
  writeStream.writeAll(a !== null ? readStreamA.drain(a) : readStreamB.drain(b));
}
```

Merge sort is the right *conceptual* answer here — not because you'd literally recurse on 500GB in memory, but because its core insight (merging two sorted sequences only ever needs to look at the *current front* of each sequence, never the whole thing at once) generalizes directly from "two sorted arrays in RAM" to "two sorted files on disk," which is exactly what external merge sort is. Quicksort and heap sort don't generalize this way — both rely on random-access indexing into a single array (`arr[i]`, swap `arr[i]` and `arr[j]`), which disk-backed sequential streams don't support efficiently.
