# Scenario: Multi-Key Sort — Sort by Department, Then by Name Within Department

**Scenario:** You have a list of employee records and need to sort them primarily by department (alphabetically), and *within* each department, by name (alphabetically). Your first instinct is to write a single comparator that compares department first, then falls back to name. A colleague suggests instead sorting by name first, then sorting again by department. Which approach is correct, and does the second one actually work?

**Approach:**

Both work, but for different reasons — and the second one **only** works because `Array.prototype.sort()` is guaranteed stable.

**Approach A — single compound comparator (always correct, algorithm-agnostic):**

```js
employees.sort((a, b) => {
  if (a.department !== b.department) return a.department.localeCompare(b.department);
  return a.name.localeCompare(b.name);
});
```

**Approach B — sort by secondary key first, then primary key, relying on stability:**

```js
employees.sort((a, b) => a.name.localeCompare(b.name));        // sort by name first
employees.sort((a, b) => a.department.localeCompare(b.department)); // then by department
// Within each department group, employees stay in name-sorted order --
// but ONLY because the second sort is stable and doesn't disturb ties.
```

Approach B is a real, commonly-used technique (multi-pass stable sorting, least-significant-key first — the same principle radix sort is built on), but it is **only correct if the underlying sort is stable**. If you swapped in an unstable sort (e.g. a hand-rolled quicksort) for the second pass, employees within the same department could end up in an arbitrary order relative to their name-sorted positions, silently breaking the multi-key ordering. Since `Array.prototype.sort()` has been spec-guaranteed stable since ES2019, Approach B is safe to rely on in modern JS — but the single compound comparator (Approach A) is more explicit, easier to reason about at a glance, and doesn't depend on a reader knowing that the two-pass trick relies on stability, so it's usually the better choice to actually write in an interview or in production code.
