# Scenario: Sorting a Nearly-Sorted Log Stream

**Scenario:** You maintain a rolling buffer of the last 10,000 log entries, already sorted by timestamp. Every second, a handful (typically 1-5) of new entries arrive slightly out of order (network delay) and need to be merged back into sorted position. Re-running a full O(n log n) sort every second on all 10,000 entries feels wasteful. What would you do instead?

**Approach:**

The key observation: the buffer is *already sorted*, and only a tiny number of new elements are out of place. This is exactly the situation where **insertion sort's O(n) best case** applies — inserting a handful of new elements into an already-sorted array by shifting only the elements that are actually out of order costs close to O(1) per new element (bounded by how far out of order each one is), not O(n log n) for the whole buffer.

```js
function insertSorted(sortedArr, newEntry, compare) {
  let i = sortedArr.length - 1;
  sortedArr.push(newEntry); // temporarily append
  while (i >= 0 && compare(sortedArr[i], newEntry) > 0) {
    sortedArr[i + 1] = sortedArr[i]; // shift larger elements right
    i--;
  }
  sortedArr[i + 1] = newEntry;
  return sortedArr;
}

// For a handful of new entries per tick:
for (const entry of newEntries) {
  insertSorted(logBuffer, entry, (a, b) => a.timestamp - b.timestamp);
}
```

Running a general-purpose O(n log n) sort (merge sort, or `Array.sort`) on the *entire* buffer every tick would waste enormous effort re-verifying the order of 9,995+ entries that were never touched. Recognizing "already sorted, only a few new elements" as the signal for **insertion-style incremental insertion** — rather than reaching for the "better" asymptotic algorithm reflexively — is exactly the kind of judgment interviewers probe for beyond "what's the fastest sort in general."
