# Merge Sort

Merge sort is a **divide-and-conquer**, comparison-based sort that guarantees O(n log n) time in every case — best, average, and worst — at the cost of O(n) extra space. It recursively splits the array in half until each piece has one element (trivially sorted), then merges pairs of sorted pieces back together in sorted order.

```js
function mergeSort(arr) {
  if (arr.length <= 1) return arr; // base case: 0 or 1 elements is already "sorted"

  const mid = Math.floor(arr.length / 2);
  const left = mergeSort(arr.slice(0, mid));
  const right = mergeSort(arr.slice(mid));

  return merge(left, right);
}

function merge(left, right) {
  const result = [];
  let i = 0, j = 0;

  while (i < left.length && j < right.length) {
    if (left[i] <= right[j]) { // <= (not <) is what makes this merge STABLE
      result.push(left[i]);
      i++;
    } else {
      result.push(right[j]);
      j++;
    }
  }
  // append whichever side has leftovers
  while (i < left.length) result.push(left[i++]);
  while (j < right.length) result.push(right[j++]);
  return result;
}

console.log(mergeSort([5, 2, 8, 1, 9, 3])); // [1, 2, 3, 5, 8, 9]
```

## Why it's always O(n log n)

- The array is halved at every level of recursion: `log n` levels total.
- Each level does O(n) work across all the merges at that level combined (every element gets touched exactly once per level during merging).
- `O(n)` work × `O(log n)` levels = **O(n log n)**, and critically this holds for *every* input — there's no "already sorted" best case shortcut and no "reverse sorted" worst case blowup, unlike quicksort. The split point is always the midpoint, regardless of data values.

## Why it's stable

The `<=` comparison in `merge` is the load-bearing detail: when `left[i]` and `right[j]` are equal, the element from the **left** half is taken first. Since the left half's elements were always positioned before the right half's in the original array, this preserves their original relative order — the definition of a stable sort. Changing that `<=` to `<` would still produce a correctly *sorted* array, but would no longer be guaranteed stable (equal elements could end up swapped relative to their original order).

## The cost: O(n) auxiliary space

Unlike quick sort or heap sort, standard merge sort is **not in-place** — the `merge` step needs a separate array to write merged results into (you can't merge two sorted halves of the same array back into itself in-place without extra bookkeeping). This O(n) space requirement is the main practical downside, and is exactly why merge sort is the algorithm interviewers expect you to name when the question shifts to "what if the data doesn't fit in memory?" — see `scenarios/02-sorting-huge-dataset-external-not-fits-memory.md` for the external-merge-sort answer.

## Complexity summary

| Case | Time | Space |
|---|---|---|
| Best | O(n log n) | O(n) |
| Average | O(n log n) | O(n) |
| Worst | O(n log n) | O(n) |

Merge sort's headline selling point: **guaranteed** O(n log n) with no pathological worst case, plus stability — the two things quick sort can't promise simultaneously.
