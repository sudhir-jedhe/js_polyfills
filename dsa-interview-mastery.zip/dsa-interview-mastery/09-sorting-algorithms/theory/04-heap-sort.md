# Heap Sort

Heap sort is a comparison-based sort that uses a **binary heap** (see the heaps/priority-queues topic for the full heap data structure) as an intermediate structure to repeatedly extract the maximum element and place it at the end of the array, shrinking the "unsorted" region by one each time.

```js
function heapSort(arr) {
  const a = [...arr];
  const n = a.length;

  // Step 1: build a max-heap in place -- O(n)
  for (let i = Math.floor(n / 2) - 1; i >= 0; i--) {
    siftDown(a, n, i);
  }

  // Step 2: repeatedly move the max (root) to the end, shrink heap, re-heapify -- O(n log n)
  for (let end = n - 1; end > 0; end--) {
    [a[0], a[end]] = [a[end], a[0]]; // move current max to its final sorted position
    siftDown(a, end, 0);             // restore heap property on the shrunk heap
  }
  return a;
}

function siftDown(a, heapSize, i) {
  let largest = i;
  const left = 2 * i + 1;
  const right = 2 * i + 2;
  if (left < heapSize && a[left] > a[largest]) largest = left;
  if (right < heapSize && a[right] > a[largest]) largest = right;
  if (largest !== i) {
    [a[i], a[largest]] = [a[largest], a[i]];
    siftDown(a, heapSize, largest); // continue sifting down the displaced element
  }
}

console.log(heapSort([5, 2, 8, 1, 9, 3])); // [1, 2, 3, 5, 8, 9]
```

## Why it's O(n log n) in every case

- **Building the initial heap is O(n)**, not O(n log n) — a subtlety often mis-stated. Although each `siftDown` call is O(log n), most nodes in a heap are near the bottom and need very little sifting; the sum across all nodes works out to O(n) total (a standard but non-obvious amortized analysis).
- **Extracting all n elements** each costs O(log n) (one `siftDown` per extraction to restore the heap property), for O(n log n) total.
- No input order (sorted, reverse-sorted, random) changes this — heap sort has **no pathological worst case** like quicksort does, making its worst-case guarantee identical to its average case: O(n log n).

## In-place, but not stable

Heap sort sorts within the original array — O(1) auxiliary space (excluding recursion stack for `siftDown`, which can also be written iteratively for true O(1) space) — making it the only one of the three "big" comparison sorts (merge/quick/heap) that is simultaneously in-place AND has a guaranteed O(n log n) worst case. The trade-off: it is **not stable** — the heap extraction process reorders equal elements relative to each other with no simple fix, and it has noticeably worse real-world cache locality than quicksort (heap operations jump around the array via parent/child index arithmetic rather than scanning contiguous ranges), which is part of why quicksort is still usually preferred in practice despite the worse worst-case guarantee.

## Complexity summary

| Case | Time | Space |
|---|---|---|
| Best | O(n log n) | O(1) |
| Average | O(n log n) | O(1) |
| Worst | O(n log n) | O(1) |

## When to actually reach for it

Heap sort is the answer whenever a problem needs: guaranteed O(n log n) worst case (no quicksort-style pathological input risk) **and** strictly bounded O(1) extra memory (ruling out merge sort). It's less commonly used as a general-purpose sort in practice (quicksort variants and Timsort dominate real implementations) but the *underlying heap/priority-queue mechanism* — repeatedly extracting the min/max — is exactly the tool for "top K elements," "k-th largest," and priority-scheduling problems; see the heaps topic (`07-heaps-priority-queues`) for that side of it.
