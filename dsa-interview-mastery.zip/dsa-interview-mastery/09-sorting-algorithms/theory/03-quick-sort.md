# Quick Sort

Quick sort is a **divide-and-conquer**, in-place, comparison-based sort. It picks a **pivot**, partitions the array so everything less than the pivot ends up left of it and everything greater ends up right of it (the pivot itself lands in its final sorted position after partitioning), then recursively sorts each side.

```js
function quickSort(arr, low = 0, high = arr.length - 1) {
  if (low < high) {
    const pivotIndex = partition(arr, low, high);
    quickSort(arr, low, pivotIndex - 1);
    quickSort(arr, pivotIndex + 1, high);
  }
  return arr;
}

function partition(arr, low, high) {
  const pivot = arr[high]; // Lomuto partition scheme: last element as pivot
  let i = low - 1; // boundary of "elements known to be <= pivot"
  for (let j = low; j < high; j++) {
    if (arr[j] <= pivot) {
      i++;
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
  }
  [arr[i + 1], arr[high]] = [arr[high], arr[i + 1]]; // place pivot in its final sorted position
  return i + 1;
}

console.log(quickSort([5, 2, 8, 1, 9, 3])); // [1, 2, 3, 5, 8, 9], sorted in place
```

## Pivot selection strategies

| Strategy | Behavior | Worst-case trigger |
|---|---|---|
| Always first element | Simple | Already-sorted (or reverse-sorted) input |
| Always last element (shown above) | Simple, common textbook choice | Already-sorted (or reverse-sorted) input |
| Random element | Swap a random element to the pivot slot first | No fixed input pattern triggers worst case — expected O(n log n) regardless of input order |
| Median-of-three (first, middle, last) | Estimate a better pivot without full sorting | Much harder (but not impossible) to construct an adversarial worst case |

**Why pivot choice matters so much:** a good pivot splits the array roughly in half each time (giving the `O(n log n)` recursion depth of `log n`). A bad pivot — consistently the smallest or largest element — produces one side of size 0 and the other of size `n-1`, degrading the recursion to `n` levels deep instead of `log n`.

## Worst-case analysis — precisely

With a fixed pivot choice (e.g. always the last element) and an **already-sorted** or **reverse-sorted** input, every partition step produces the most unbalanced possible split: one subarray of size `n-1`, the other of size `0`. This gives a recurrence of `T(n) = T(n-1) + O(n)`, which sums to **O(n²)** — not `O(n log n)`. This is the single most commonly tested quicksort fact in interviews: quicksort's average case is O(n log n), but its **worst case is O(n²)**, and that worst case is realistically triggerable by sorted/reverse-sorted input if the pivot strategy is naive. Randomized pivot selection (or median-of-three) doesn't eliminate the O(n²) worst case in theory — an adversary could still construct a pathological input for any deterministic strategy — but it makes the worst case exceedingly unlikely to occur "by accident" on real, unadversarial data, and immune to being deliberately triggered by simply feeding in sorted data.

## In-place, but not stable

Quick sort sorts within the original array (O(log n) space for the recursion call stack, not O(n) for a copy — a key advantage over merge sort), but the swapping during partitioning can reorder equal elements relative to each other, so **standard quicksort is not stable**. A stable variant exists but requires extra space, defeating much of the in-place advantage — this is the classic trade-off: quicksort is fast and low-memory, but you can't have both stability and full in-place-ness at once.

## Complexity summary

| Case | Time | Space |
|---|---|---|
| Best | O(n log n) | O(log n) — recursion stack |
| Average | O(n log n) | O(log n) |
| Worst | **O(n²)** (bad pivot + adversarial/sorted input) | O(n) — unbalanced recursion depth |
