# Counting Sort and Radix Sort — Non-Comparison Sorts

Every sort covered so far (bubble, selection, insertion, merge, quick, heap) is a **comparison sort** — it decides order purely by comparing pairs of elements (`<`, `>`), and it's a proven theoretical result that no comparison sort can beat **O(n log n)** in the worst case (there's a decision-tree argument behind this bound). Counting sort and radix sort sidestep the limit entirely by never comparing elements — they exploit structural knowledge about the values themselves.

## Counting Sort

Works when input is integers within a **known, reasonably small range** `[0, k]`. Counts occurrences of each distinct value, then reconstructs the sorted output directly from those counts — no comparisons at all.

```js
function countingSort(arr, maxValue) {
  const counts = new Array(maxValue + 1).fill(0);
  for (const num of arr) counts[num]++;             // O(n): tally occurrences

  const result = [];
  for (let value = 0; value <= maxValue; value++) {
    while (counts[value] > 0) {                      // O(n + k): rebuild sorted output
      result.push(value);
      counts[value]--;
    }
  }
  return result;
}

console.log(countingSort([4, 2, 2, 8, 3, 3, 1], 8)); // [1, 2, 2, 3, 3, 4, 8]
```

- **Time:** O(n + k), where k is the range of input values. If k is O(n) or smaller, this beats O(n log n) outright.
- **Space:** O(n + k) — the counts array plus output.
- **Stable variant exists** (using a running prefix-sum of counts to place each element directly into its final index, walking the input in order) — the simple version above is not stable as written, since it reconstructs purely from counts and loses original relative order/associated data.
- **Falls apart when k >> n** — e.g. sorting 100 numbers where values range up to 10 billion would allocate a 10-billion-length array. Counting sort's efficiency is entirely dependent on the range being small relative to n.

## Radix Sort

Sorts integers (or fixed-length strings) digit-by-digit, from least-significant to most-significant, using counting sort (or a similar stable bucket method) as a subroutine for each digit position.

```js
function radixSort(arr) {
  const result = [...arr];
  const maxNum = Math.max(...result);
  for (let exp = 1; Math.floor(maxNum / exp) > 0; exp *= 10) {
    countingSortByDigit(result, exp); // stable pass on this digit position
  }
  return result;
}

function countingSortByDigit(arr, exp) {
  const output = new Array(arr.length);
  const counts = new Array(10).fill(0); // digits 0-9
  for (const num of arr) counts[Math.floor(num / exp) % 10]++;
  for (let i = 1; i < 10; i++) counts[i] += counts[i - 1]; // prefix sums -> final positions
  for (let i = arr.length - 1; i >= 0; i--) {               // iterate backward to keep it stable
    const digit = Math.floor(arr[i] / exp) % 10;
    output[--counts[digit]] = arr[i];
  }
  for (let i = 0; i < arr.length; i++) arr[i] = output[i];
}

console.log(radixSort([170, 45, 75, 90, 802, 24, 2, 66])); // [2, 24, 45, 66, 75, 90, 170, 802]
```

- **Time:** O(d * (n + b)), where d is the number of digits in the largest number and b is the base (10 for decimal). For fixed-width integers (e.g. 32-bit), d is a constant, giving effectively **O(n)**.
- **Space:** O(n + b).
- **Must use a stable sort for each digit pass** — if the per-digit sort weren't stable, sorting by the next digit would scramble the correct relative order already established by previous, lower-significance digit passes. This is the whole reason radix sort processes least-significant digit first.

## When these actually apply

| Situation | Use |
|---|---|
| Sorting small non-negative integers with a known small max value (e.g. exam scores 0-100, ages) | Counting sort |
| Sorting large integers or fixed-length strings where digit/character count is small relative to n | Radix sort |
| Sorting arbitrary comparable objects, floats, or unbounded-range values | Neither applies — use a comparison sort |
| Values need a custom/complex comparator (e.g. multi-key business logic) | Comparison sort — counting/radix require values to map cleanly onto discrete buckets/digits |

The interview-ready framing: comparison sorts have a hard O(n log n) floor; counting and radix sort escape it by exploiting structure in the data (small range, fixed digit width) that a general-purpose comparator can't exploit — but that structure is a *requirement*, not a bonus, so naming when it does and doesn't apply is the actual skill being tested.
