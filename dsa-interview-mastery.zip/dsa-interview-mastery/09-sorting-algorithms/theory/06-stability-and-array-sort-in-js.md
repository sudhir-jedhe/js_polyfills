# Stability, and JavaScript's `Array.prototype.sort()`

## What "stable" means, precisely

A sort is **stable** if elements that compare as equal retain their original relative order in the output. This matters whenever you sort by one key but care about a previously-established order for ties — e.g. sorting a list of orders by `status`, where orders with the same status should stay in their original (say, chronological) order.

```js
const orders = [
  { id: 1, status: 'shipped' },
  { id: 2, status: 'pending' },
  { id: 3, status: 'shipped' },
  { id: 4, status: 'pending' },
];
// A stable sort by status preserves id order within each status group:
// pending: [2, 4], shipped: [1, 3] -- NOT [4, 2] or [3, 1]
```

## Stability comparison table

| Algorithm | Stable? | Notes |
|---|---|---|
| Bubble sort | Yes | Only swaps strictly-greater adjacent pairs |
| Insertion sort | Yes | Only shifts strictly-greater elements |
| Merge sort | Yes | As long as the merge step uses `<=` (take left on ties) |
| Quick sort | No (standard in-place version) | Partitioning swaps can reorder equal elements; a stable version exists but needs O(n) extra space |
| Heap sort | No | Heap extraction reorders equal elements with no simple fix |
| Selection sort | No (naive swap-based) | Swapping the found minimum into place can jump it past an equal element |
| Counting sort | Yes (with the prefix-sum/backward-iteration variant) | The naive count-and-rebuild version is not stable |
| Radix sort | Yes | Requires a stable sort for each digit pass — this is a hard requirement, not incidental |

## JS's `Array.prototype.sort()` — what algorithm does it actually use?

As of the ES2019 spec, `Array.prototype.sort()` is **required to be stable** — before that, stability was implementation-defined, and older V8 versions used an unstable quicksort variant for arrays above a size threshold. Modern JS engines (V8 since Chrome 70/Node 11, and all current major engines) implement `sort` with a **Timsort-like hybrid**: insertion sort for small sub-arrays (a handful of elements) merged together with merge sort's approach for larger runs — Timsort itself specifically also detects and exploits already-sorted "runs" in the data. The practical takeaway: you can now rely on `Array.prototype.sort()` being stable and roughly O(n log n), without needing to know or care about the exact hybrid algorithm.

## The default comparator trap — numbers sort as strings

This is the single most common `Array.sort()` interview gotcha:

```js
const nums = [10, 1, 21, 2];
console.log(nums.sort());
// [1, 10, 2, 21]  <-- NOT [1, 2, 10, 21]!
```

**Why:** without a comparator function, `.sort()` converts every element to a **string** and sorts by UTF-16 code unit order (lexicographic/dictionary order), not numeric order. `"10"` sorts before `"2"` because `'1' < '2'` as characters — the comparison never looks at the numbers' actual magnitude. This bites on any array of numbers, and equally on any array of objects being sorted "manually" without an explicit comparator.

## The fix — always pass a comparator for numeric (or any non-default) sorting

```js
const nums = [10, 1, 21, 2];
console.log(nums.sort((a, b) => a - b)); // [1, 2, 10, 21] -- correct ascending numeric order

// Comparator contract: return negative if a should come before b,
//                       positive if a should come after b,
//                       0 if their relative order doesn't matter.
console.log(nums.sort((a, b) => b - a)); // [21, 10, 2, 1] -- descending

const words = ['banana', 'Apple', 'cherry'];
console.log(words.sort()); // ['Apple', 'banana', 'cherry'] -- default IS correct here (strings), but note the case-sensitivity: uppercase sorts before lowercase in UTF-16
```

## The interview-ready rule

**Always pass an explicit comparator when sorting anything other than an array of plain strings you want in default lexicographic order.** For numbers, that's `(a, b) => a - b` (ascending) — never rely on the default. This single fact is one of the most-tested "gotcha" details across every JS-adjacent interview, precisely because the bug is silent: the array *does* get sorted, just not the way anyone intended, and it's easy to miss in a quick visual check of small test data (e.g. `[1, 2, 3]` sorts "correctly" under lexicographic order too, hiding the bug until a two-digit number shows up).
