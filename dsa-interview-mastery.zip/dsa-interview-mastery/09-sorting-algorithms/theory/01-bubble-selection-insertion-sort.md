# Bubble, Selection, and Insertion Sort

These three are the "simple" O(n²) comparison sorts — rarely optimal for large inputs, but foundational, and each still has real niche use cases worth naming precisely in an interview.

## Bubble Sort

Repeatedly steps through the array, swapping adjacent elements that are out of order, so larger elements "bubble" toward the end each pass.

```js
function bubbleSort(arr) {
  const a = [...arr];
  for (let i = 0; i < a.length - 1; i++) {
    let swapped = false;
    for (let j = 0; j < a.length - 1 - i; j++) { // shrinks each pass -- the tail is already sorted
      if (a[j] > a[j + 1]) {
        [a[j], a[j + 1]] = [a[j + 1], a[j]];
        swapped = true;
      }
    }
    if (!swapped) break; // early exit: no swaps this pass means the array is already sorted
  }
  return a;
}
```

- Worst/average case: O(n²) comparisons and swaps.
- Best case (already sorted), **with** the early-exit flag: O(n) — a single pass detects no swaps and stops.
- Stable (equal elements never swap past each other, since swaps only happen on strict `>`).
- In-place: O(1) extra space (ignoring the defensive copy above).

## Selection Sort

Repeatedly finds the minimum of the unsorted remainder and swaps it into place at the front.

```js
function selectionSort(arr) {
  const a = [...arr];
  for (let i = 0; i < a.length - 1; i++) {
    let minIndex = i;
    for (let j = i + 1; j < a.length; j++) {
      if (a[j] < a[minIndex]) minIndex = j;
    }
    if (minIndex !== i) [a[i], a[minIndex]] = [a[minIndex], a[i]];
  }
  return a;
}
```

- Always O(n²) comparisons, **regardless of input order** — it always scans the entire unsorted remainder to find the minimum, so there's no early-exit best case like bubble sort has.
- Exactly O(n) swaps (at most one per outer iteration) — the fewest swaps of any of these three, which matters when writes are expensive (e.g. flash memory).
- **Not stable** in the naive swap-based form above: swapping a found minimum into place can jump it past an equal element, changing their relative order.

## Insertion Sort

Builds the sorted portion one element at a time, shifting larger elements right to make room for each new element in its correct position — the way most people sort a hand of playing cards.

```js
function insertionSort(arr) {
  const a = [...arr];
  for (let i = 1; i < a.length; i++) {
    const current = a[i];
    let j = i - 1;
    while (j >= 0 && a[j] > current) { // shift elements right until the correct slot is found
      a[j + 1] = a[j];
      j--;
    }
    a[j + 1] = current;
  }
  return a;
}
```

- Worst/average case: O(n²).
- **Best case (already sorted or nearly sorted): O(n)** — the inner `while` loop barely runs, since each element is already ≥ its predecessor.
- Stable (the `>` comparison, not `>=`, means equal elements are never shifted past each other).
- In-place: O(1) extra space.

## Why these are still actually useful

- **Small arrays:** the constant-factor overhead of a recursive divide-and-conquer sort (merge sort, quick sort) outweighs its better asymptotic complexity for tiny n — real-world sort implementations (including JS engines' `Array.sort`, Python's Timsort) switch to insertion sort for small sub-arrays (commonly under ~10-20 elements) as an optimization.
- **Nearly-sorted data:** insertion sort's O(n) best case makes it the right choice for data that's already mostly in order (e.g. appending a few new records to an already-sorted log and re-sorting), where a full O(n log n) sort would do unnecessary work.
- **Online/streaming sort:** insertion sort can sort data as it arrives, one element at a time, without needing the whole dataset upfront — useful for maintaining a sorted structure incrementally.
- **Minimal writes:** selection sort's guaranteed O(n) swaps (not comparisons — total data movement) matters when writes are far more expensive than comparisons, e.g. sorting data on flash storage with limited write endurance.

## Comparison

| Algorithm | Best case | Average/Worst case | Stable? | In-place? | Notable trait |
|---|---|---|---|---|---|
| Bubble sort | O(n) with early exit | O(n²) | Yes | Yes | Simplest to explain; rarely used in practice |
| Selection sort | O(n²) — no early exit possible | O(n²) | No (naive swap version) | Yes | Minimizes number of swaps (O(n)) |
| Insertion sort | O(n) (nearly sorted) | O(n²) | Yes | Yes | Best of the three for nearly-sorted/small/streaming data |
