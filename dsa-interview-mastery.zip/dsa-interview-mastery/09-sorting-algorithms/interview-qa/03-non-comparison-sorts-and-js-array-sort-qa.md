# Interview Q&A — Non-Comparison Sorts and JS's `Array.sort()`

**Q: How does counting sort beat the O(n log n) comparison-sort lower bound?**
It doesn't compare elements to each other at all — it counts occurrences of each distinct value directly (an O(n) pass) and reconstructs sorted output from those counts (an O(n + k) pass, where k is the value range). Since it never performs pairwise comparisons, the O(n log n) lower bound (which is specifically a bound on comparison-based algorithms) doesn't apply to it.

**Q: What's the catch that limits counting sort's applicability?**
It requires the input to be integers (or discretely bucketable values) within a known range that's small relative to n. If the range k is much larger than n, the O(n + k) time and space cost becomes dominated by k and can be far worse than a comparison sort — e.g. sorting 100 values that range up to 10 billion would try to allocate a 10-billion-element counts array.

**Q: How does radix sort extend counting sort to larger values?**
It sorts digit-by-digit (least significant digit first), using a stable counting-sort-like pass for each digit position. Processing least-significant-digit first, combined with a stable per-digit sort, is what preserves the correct ordering established by previous (lower-significance) passes as later, higher-significance digits are processed.

**Q: Is `Array.prototype.sort()` guaranteed to be stable in JavaScript?**
Yes, as of the ES2019 specification — before that, stability was implementation-defined and some engines used an unstable algorithm for larger arrays. Every current major JS engine (V8/Chrome/Node, SpiderMonkey/Firefox, JavaScriptCore/Safari) implements a stable sort today, commonly a Timsort-like hybrid of insertion sort (for small runs) and merge sort.

**Q: What happens if you call `.sort()` on an array of numbers with no comparator, and why?**
Every element is coerced to a string via `String(x)` and compared lexicographically (UTF-16 code unit order), not numerically — so `[10, 2, 1]` sorts to `[1, 10, 2]`, not `[1, 2, 10]`. The fix is to always pass an explicit comparator for numeric sorting: `(a, b) => a - b` for ascending order.

**Q: What are the rules a valid comparator function must follow?**
Return a negative number if `a` should sort before `b`, a positive number if `a` should sort after `b`, and `0` if their order doesn't matter for sorting purposes. The comparator must be consistent across all pairs (transitive, well-defined) — a comparator that always returns the same non-zero sign regardless of the actual values produces an invalid, implementation-defined result rather than a genuinely reordered or reversed array.
