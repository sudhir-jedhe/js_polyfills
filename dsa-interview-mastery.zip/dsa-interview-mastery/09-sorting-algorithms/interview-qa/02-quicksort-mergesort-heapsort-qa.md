# Interview Q&A — Quicksort, Merge Sort, Heap Sort

**Q: What is quicksort's worst-case time complexity, and exactly when does it occur?**
O(n²). It occurs when every partition step produces a maximally unbalanced split (size n-1 and 0) — which happens with a naive fixed pivot choice (e.g. always the last or first element) on already-sorted or reverse-sorted input, since the pivot ends up being the largest or smallest remaining element every single time.

**Q: How do real quicksort implementations mitigate the worst case?**
By randomizing pivot selection (swap a random element into the pivot slot before partitioning) or using median-of-three (estimate a better pivot from the first, middle, and last elements). Neither eliminates the theoretical O(n²) worst case entirely — an adversary could still construct a pathological input for any fixed strategy — but both make the worst case exceptionally unlikely on ordinary or even sorted input, since it can no longer be triggered "for free" just by input order.

**Q: Why is merge sort's time complexity O(n log n) in every case, with no worst-case blowup like quicksort?**
Because merge sort always splits the array at the exact midpoint, regardless of the data's values — the split point is purely positional (index-based), not value-based like quicksort's pivot-based partitioning. This guarantees log n levels of recursion every time, with O(n) work per level, for O(n log n) unconditionally.

**Q: Why is building a heap O(n) rather than O(n log n), even though each individual sift-down is O(log n)?**
Because most nodes in a heap are near the bottom of the tree and need very little sifting — only a small number of nodes near the root require the full O(log n) sift-down. Summing sift-down cost across all nodes (weighted by how many nodes are at each height) works out to O(n) total, not n × O(log n) = O(n log n). This is a standard but frequently mis-stated result.

**Q: Which of quicksort, merge sort, and heap sort would you pick if you needed guaranteed O(n log n) worst-case time AND O(1) auxiliary space?**
Heap sort — it's the only one of the three that offers both simultaneously. Quicksort risks O(n²) worst case; merge sort needs O(n) auxiliary space. The trade-off heap sort makes for this guarantee is that it's not stable and tends to have worse real-world cache performance than quicksort due to its non-sequential (parent/child index-jumping) memory access pattern.
