# Interview Q&A — Comparison Sorts Fundamentals

**Q: What's the theoretical lower bound for any comparison-based sort, and why?**
O(n log n) in the worst case. This comes from a decision-tree argument: a comparison sort must distinguish between all n! possible orderings of the input using a sequence of binary (yes/no) comparisons, and a binary decision tree that distinguishes n! outcomes needs at least log₂(n!) levels, which is Θ(n log n) by Stirling's approximation. No comparison sort — no matter how cleverly written — can beat this in the worst case.

**Q: What does "stable" mean for a sort, and name two stable and two unstable common algorithms.**
Stable means elements that compare as equal retain their original relative order in the sorted output. Merge sort and insertion sort are stable (their comparison/merge logic never reorders equal elements). Quicksort (standard in-place partitioning) and heap sort (heap extraction) are not stable — both can reorder equal elements as a side effect of swapping.

**Q: What does "in-place" mean, and which of merge/quick/heap sort qualifies?**
In-place means the algorithm sorts using O(1) (or sometimes O(log n), a looser but common definition covering recursion-stack space) extra memory beyond the input array, rather than allocating a new structure proportional to n. Quicksort (O(log n) stack) and heap sort (O(1)) both qualify; merge sort does not — its merge step requires O(n) auxiliary space.

**Q: When are the simple O(n²) sorts (bubble, selection, insertion) still the right choice?**
For small arrays (low constant-factor overhead beats better asymptotic complexity — real sort implementations switch to insertion sort under a size threshold), for nearly-sorted data (insertion sort's O(n) best case), and for insertion sort specifically, for online/streaming scenarios where data arrives incrementally and needs to stay sorted at every step.

**Q: Why can't you achieve both "in-place" and "stable" with quicksort simultaneously?**
Quicksort's in-place partitioning works by swapping elements across the array based on comparisons to the pivot — those swaps are exactly what can move an element past another equal element, breaking stability. A stable version of quicksort exists, but it requires auxiliary O(n) space to track original positions/do the partitioning without disruptive swaps, which defeats the in-place property that makes quicksort attractive in the first place.
