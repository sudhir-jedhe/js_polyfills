# Dynamic Programming

Dynamic programming is what you get when you take a recursive solution and eliminate the redundant work it does — it applies exactly when a problem has both optimal substructure (the optimal answer is built from optimal answers to subproblems) and overlapping subproblems (a naive recursive solution ends up solving the exact same subproblem many times over). This is consistently the highest-signal topic in DSA interviews, not because the individual problems are exotic, but because most candidates can write brute-force recursion and can recite "memoization vs. tabulation" as two separate facts — what actually separates strong answers is recognizing a *new* problem's DP shape under pressure, deriving its recurrence out loud, and fluently converting between top-down and bottom-up implementations of the exact same idea. This topic treats memoization and tabulation as one mechanical transformation of each other (not two disconnected techniques), builds up from 1D to 2D DP to the knapsack pattern, and closes with a concrete decision framework for recognizing DP problems plus the standard rolling-array technique for cutting a solution's space usage.

## Folder structure

- **`theory/`** — what makes a problem DP (optimal substructure + overlapping subproblems), memoization vs. tabulation with Fibonacci solved both ways and every piece mapped between them, 1D DP (climbing stairs, house robber), 2D DP (unique paths, LCS, edit distance), the 0/1 knapsack pattern, and a practical decision framework for recognizing DP problems plus space optimization via rolling arrays.
- **`snippets/`** — 7 focused, runnable code examples: Fibonacci memoized, Fibonacci tabulated, climbing stairs both ways, house robber, unique paths, 0/1 knapsack, and a space-optimized rolling-variable Fibonacci.
- **`output-based/`** — 7 "trace through this" questions: naive Fibonacci's exponential call count, memoized Fibonacci's linear call count (a direct before/after comparison), a climbing-stairs table fill trace, a house-robber array trace, a unique-paths 2D table trace, an LCS table-fill-and-backtrace trace, and a knapsack table fill trace.
- **`scenarios/`** — 5 real-world engineering scenarios: memoizing a repeated recursive pricing computation (and the cache-scoping tradeoff), why greedy fails at weighted job scheduling where DP succeeds, budget allocation as knapsack (with a prerequisites extension), diffing two documents with edit distance and backtrace reconstruction, and a diagnostic guide for "recursion times out — is DP actually the fix?"
- **`interview-qa/`** — 15 Q&A pairs across 3 themed files: DP fundamentals, memoization vs. tabulation, and classic DP patterns.
- **`problems/`** — 7 hands-on coding challenges: climbing stairs, house robber, unique paths, longest common subsequence, edit distance, 0/1 knapsack, and coin change — each with a full JavaScript solution and Big-O analysis.
- **`assets/`** — placeholder for diagrams (recursion trees, DP tables, memoization vs. tabulation comparisons).

## What's covered

- The two-question test for whether a problem is DP-shaped, and clear counterexamples (merge sort, longest-path-in-a-graph) for when it isn't
- Memoization and tabulation as the same recurrence computed in two directions, with an explicit piece-by-piece mapping between them (cache ↔ table, base case ↔ seeded entries, recursive call ↔ array read, call stack ↔ loop)
- 1D DP's counting-vs-optimization distinction (sum vs. max/min at each step), 2D DP's up/left/diagonal cell-dependency template, and the 0/1 vs. unbounded knapsack distinction (previous row vs. same row/pass)
- A concrete, repeatable framework for recognizing DP problems from verbal tells, deriving state, and choosing table dimensionality — plus diagnosing when a slow recursive solution genuinely needs DP versus a different algorithm entirely
- The rolling-array/rolling-variable space optimization, applied to both 1D (Fibonacci) and 2D (unique paths) cases, with an explicit note on when it does and doesn't apply
- Hands-on: climbing stairs, house robber, unique paths, longest common subsequence, edit distance, 0/1 knapsack, and coin change
