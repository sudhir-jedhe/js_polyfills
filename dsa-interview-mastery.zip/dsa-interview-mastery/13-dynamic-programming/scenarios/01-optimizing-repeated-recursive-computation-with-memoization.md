# Scenario: A Pricing Engine Recomputes the Same Recursive Quote Repeatedly

**Scenario:** A pricing service computes a quote recursively — the price for a bundle of `n` items depends recursively on the best price for smaller sub-bundles (accounting for combinable discounts), similar in shape to a knapsack-style recurrence. Profiling shows the service is slow, and a flame graph shows the *same* sub-bundle price being computed thousands of times per request. How do you fix it, and how do you decide between an in-request cache and something more persistent?

**Approach:** the flame graph is describing overlapping subproblems directly — the fix is memoization, but the *scope* of the cache matters:

```js
function bestPrice(bundle, cache = new Map()) {
  const key = JSON.stringify(bundle); // composite key for a whole sub-bundle
  if (cache.has(key)) return cache.get(key);

  let best = computeDirectPrice(bundle); // base case: no further discount combination
  for (const split of possibleSplits(bundle)) {
    const combined = bestPrice(split.left, cache) + bestPrice(split.right, cache);
    best = Math.min(best, combined);
  }

  cache.set(key, best);
  return best;
}
```

**Scoping the cache — the real design decision:** a `cache` created fresh per request (as a function parameter, the way `bestPrice` is written above) only eliminates *intra-request* duplication — safe by default, but doesn't help if the same sub-bundle price is requested by *different* requests. Whether to share a cache across requests (e.g. a module-level `Map`, or an external cache like Redis) depends on whether prices actually stay valid across requests — if a sub-bundle's price can change (inventory, live pricing rules), a shared cache introduces a staleness bug identical in shape to the memoization-with-impure-functions trap covered in closures/memoization content elsewhere. The safe default is per-request scoping; only widen the cache's lifetime once you've confirmed the underlying prices are stable for a known time window, and add explicit invalidation (a TTL, or an event-driven cache bust) if you do.
