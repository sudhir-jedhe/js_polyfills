# Scenario: Scheduling Weighted Jobs — Why Greedy Fails Where DP Succeeds

**Scenario:** You're given a list of jobs, each with a start time, end time, and profit. No two selected jobs can overlap. Choose a subset of non-overlapping jobs to maximize total profit. A teammate suggests a greedy approach: "just always pick the job that ends earliest, like the classic activity-selection problem." Is that correct here, and if not, why does DP succeed where greedy fails?

**Why greedy fails here:** the classic "earliest end time" greedy strategy is provably optimal for **unweighted** activity selection (maximize the *count* of non-overlapping jobs) — but the moment jobs carry different *profits*, that greedy rule breaks. A short, low-profit job ending early can greedily get selected and block out a much longer, dramatically more profitable job that would have been the better choice. Greedy algorithms are only correct when a *locally* optimal choice is provably always part of *some* globally optimal solution — weighted job scheduling doesn't have that property, because the best local choice (by end time) can conflict with the best global choice (by total profit).

**Why DP succeeds:** this problem does have optimal substructure and overlapping subproblems relative to a different ordering — sort jobs by end time, and define `dp[i]` = maximum profit achievable using only the first `i` jobs (in end-time order). At each job `i`, there's a genuine choice: skip it (carry forward `dp[i-1]`), or take it (add its profit to the best profit achievable from jobs that don't conflict with it — found via binary search for the latest job that ends before job `i` starts).

```js
function jobScheduling(jobs) { // jobs: [{start, end, profit}, ...]
  jobs.sort((a, b) => a.end - b.end);
  const n = jobs.length;
  const dp = new Array(n + 1).fill(0);

  function latestNonConflicting(i) { // binary search for the last job ending <= jobs[i].start
    let lo = 0, hi = i - 1, result = -1;
    while (lo <= hi) {
      const mid = Math.floor((lo + hi) / 2);
      if (jobs[mid].end <= jobs[i].start) { result = mid; lo = mid + 1; }
      else hi = mid - 1;
    }
    return result;
  }

  for (let i = 0; i < n; i++) {
    const skip = dp[i];                                    // dp[i] so far = best using jobs[0..i-1]
    const prev = latestNonConflicting(i);
    const take = jobs[i].profit + (prev === -1 ? 0 : dp[prev + 1]);
    dp[i + 1] = Math.max(skip, take);
  }
  return dp[n];
}
```

**Takeaway:** the presence of *weights/values* that don't correlate cleanly with the greedy ordering criterion (end time, in this case) is exactly the tell that a problem needs DP's "consider both options, keep the better one" approach instead of a single greedy rule. In an interview, explicitly naming *why* the greedy approach fails (with a concrete counterexample — a short cheap job blocking a long expensive one) is a stronger answer than just asserting "DP is needed here."
