# Scenario: Building a "Track Changes" Diff Between Two Document Versions

**Scenario:** You're building a diff view that shows how one version of a document's text changed into another — which words were inserted, deleted, or replaced, similar to Git's diff or Word's Track Changes. How does edit distance apply, and what has to change from the plain "minimum operation count" version to actually produce a displayable diff?

**Approach:** treat each version as a sequence of tokens (words, not characters, for a document-level diff) and run the edit-distance recurrence over the two token sequences — but instead of only tracking the *minimum count*, also track *which operation* was chosen at each cell, so the actual sequence of edits can be reconstructed afterward:

```js
function diffTokens(wordsA, wordsB) {
  const m = wordsA.length, n = wordsB.length;
  const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;

  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      if (wordsA[i - 1] === wordsB[j - 1]) {
        dp[i][j] = dp[i - 1][j - 1]; // unchanged word — no edit
      } else {
        dp[i][j] = 1 + Math.min(dp[i - 1][j - 1], dp[i - 1][j], dp[i][j - 1]);
      }
    }
  }

  // backtrace from dp[m][n] to reconstruct the actual edit sequence (insert/delete/replace/keep)
  const edits = [];
  let i = m, j = n;
  while (i > 0 || j > 0) {
    if (i > 0 && j > 0 && wordsA[i - 1] === wordsB[j - 1]) {
      edits.unshift({ type: 'keep', word: wordsA[i - 1] });
      i--; j--;
    } else if (i > 0 && j > 0 && dp[i][j] === dp[i - 1][j - 1] + 1) {
      edits.unshift({ type: 'replace', from: wordsA[i - 1], to: wordsB[j - 1] });
      i--; j--;
    } else if (i > 0 && dp[i][j] === dp[i - 1][j] + 1) {
      edits.unshift({ type: 'delete', word: wordsA[i - 1] });
      i--;
    } else {
      edits.unshift({ type: 'insert', word: wordsB[j - 1] });
      j--;
    }
  }
  return edits;
}
```

**The key shift from "just the count" to "a usable diff":** the plain edit-distance recurrence only needs the *minimum number* — but a diff UI needs the actual sequence of operations, which requires the same backtrace idea used for LCS reconstruction (see `../output-based/06-lcs-table-backtrace-for-string.md`): walk backward from `dp[m][n]`, at each cell inferring which operation *must* have produced the current value by comparing it against the three cells it could have come from, and prepend that operation to the result.

**Interview framing:** this scenario is a good test of whether "edit distance" is understood as a *reconstructable* DP table, not just a single number — a common follow-up after solving the base edit-distance problem is exactly "now show me the actual edits," which requires the backtrace technique, not a redesign of the recurrence itself.
