# Scenario: Allocating a Fixed Marketing Budget Across Campaigns

**Scenario:** Marketing has a fixed budget and a list of candidate campaigns, each with a cost and a projected return. Each campaign can either be funded in full or not at all (no partial funding). Choose which campaigns to fund to maximize total projected return without exceeding the budget. What's the approach, and how would you extend it if some campaigns had prerequisites (campaign B can only be funded if campaign A is also funded)?

**Approach — this is 0/1 knapsack, directly:** budget is the capacity, each campaign is an item with a cost (weight) and a projected return (value), and "fund in full or not at all" is exactly the 0/1 constraint:

```js
function allocateBudget(campaigns, budget) {
  const n = campaigns.length;
  const dp = Array.from({ length: n + 1 }, () => new Array(budget + 1).fill(0));

  for (let i = 1; i <= n; i++) {
    const { cost, projectedReturn } = campaigns[i - 1];
    for (let b = 0; b <= budget; b++) {
      dp[i][b] = dp[i - 1][b]; // don't fund this campaign
      if (cost <= b) {
        dp[i][b] = Math.max(dp[i][b], dp[i - 1][b - cost] + projectedReturn); // fund it
      }
    }
  }
  return dp[n][budget];
}
```

**Extending for prerequisites:** a hard dependency ("B requires A") breaks the simple per-item independence the basic recurrence assumes — you can no longer decide campaign B's inclusion without knowing campaign A's. The clean fix is to change what an "item" represents: group dependent campaigns into a small number of valid *bundles* (e.g. "neither A nor B," "A alone," "A and B together" — never "B alone," since that violates the prerequisite), each with its own combined cost and return, and run the same knapsack recurrence over bundles instead of individual campaigns. For a handful of pairwise dependencies this stays tractable; for a dense dependency graph, this becomes a genuinely harder constrained-optimization problem, worth flagging explicitly rather than forcing a knapsack fit that no longer holds.

**Interview framing:** recognizing "fixed capacity + subset of cost/value items" as knapsack-shaped, even when the surface language is "budget" and "campaigns" rather than "weight" and "value," is the core skill being tested — followed by knowing where the basic 0/1 knapsack recurrence's assumptions (item independence) start to break down.
