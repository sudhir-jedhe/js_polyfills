# Scenario: A Recursive Solution Works but Times Out — Is DP the Fix?

**Scenario:** You've written a clean recursive solution to a problem. It's correct on small test cases but times out on larger ones during an interview or in a submission judge. How do you diagnose whether DP (memoization/tabulation) will actually fix it, versus needing a different algorithmic approach entirely?

**Diagnostic steps:**

1. **Print or count the actual function calls on a mid-sized input.** If the count is wildly larger than the number of *distinct* argument combinations the function could ever be called with, that's overlapping subproblems, confirmed empirically — DP will help, likely dramatically (see the 25-calls-vs-11-calls Fibonacci comparison in `../output-based/01-naive-fibonacci-recursion-tree-call-count.md` and `02-memoized-fibonacci-call-count-trace.md` for exactly this kind of before/after).

2. **Check whether the "state" (the function's arguments that actually affect the answer) is small and reusable.** If a subproblem is uniquely identified by, say, two integers each bounded by the input size, that's a small, cacheable, 2D state space — a strong DP candidate. If the state includes something like "the exact set of elements used so far" (as in many NP-hard-shaped problems, e.g. traveling salesman on many cities), the state space itself is exponential, and no amount of caching turns an exponential-sized problem into a polynomial one — DP alone won't save you; you'd need approximation, pruning (branch and bound), or accepting exponential time for small inputs only.

3. **If the state is small but recursion is still slow after memoizing, check the *work done per subproblem*.** Memoization only removes *redundant* recomputation — if each individual subproblem itself does expensive work (e.g. an O(n) scan inside a memoized function that's called O(n) times), the total is still O(n²), and the fix is optimizing that per-call work (e.g. with a prefix sum, a hashmap, or a smarter recurrence), not further caching.

## Quick self-check table

| Symptom | Diagnosis | Fix |
|---|---|---|
| Exponential call count, small distinct-state space | Overlapping subproblems | Memoize or tabulate |
| Call count is already ≈ number of distinct states | No redundant recomputation | DP won't help — look elsewhere (better algorithm, or the per-call work itself) |
| State space itself is exponential (e.g. subsets, permutations of large n) | Problem may be inherently exponential | DP won't reduce complexity class — consider approximation, pruning, or smaller-input assumptions |
| Memoized version still slow | Redundant recomputation is gone, but per-subproblem work is expensive | Optimize per-call work (better data structure, tighter recurrence) |

**Interview framing:** explicitly walking through "is there overlap? is the state space actually small?" out loud — rather than reflexively slapping a `Map` cache onto any slow recursive function — is what shows real understanding versus pattern-matching "recursion is slow, therefore add memoization" without checking whether memoization is the applicable fix.
