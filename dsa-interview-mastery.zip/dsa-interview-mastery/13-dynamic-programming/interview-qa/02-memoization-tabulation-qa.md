# Interview Q&A — Memoization vs. Tabulation

**Q: What's the mechanical difference between converting a naive recursive function into a memoized one, versus a tabulated one?**
Memoization keeps the exact same recursive structure and adds two things: a cache check at the top (return early on a hit) and a cache write right before returning (on a miss) — the recursion itself, and its call order, stay unchanged. Tabulation replaces the recursion entirely with a loop that fills an array from the base cases upward, in an explicitly chosen order, reading previously-computed entries instead of making recursive calls.

**Q: Do memoization and tabulation have the same time and space complexity?**
Generally yes, for problems where every subproblem needs to be solved anyway — both compute each distinct subproblem exactly once. The constant factor typically favors tabulation (plain array indexing beats function-call and hashmap-lookup overhead), and tabulation avoids the call-stack space and stack-overflow risk that memoization's recursion carries. One asymmetry: memoization may skip subproblems the recursion never actually visits, while tabulation (in its simplest form) computes every table entry unconditionally — for problems where large parts of the table genuinely aren't needed for the final answer, memoization can do strictly less work.

**Q: Why is tabulation generally safer against stack overflow than memoization?**
Tabulation is a loop, not recursion — it uses O(1) call-stack frames regardless of the table's size, since there's no function call per subproblem. Memoization is still ordinary recursion under the hood (just with a cache added), so it inherits the same call-stack depth risk as any other recursive function — a memoized solution to a problem with, say, 100,000 sequential states can still overflow the stack in JavaScript, even though the *time* complexity is fine.

**Q: If you have a working memoized (top-down) solution, how do you convert it to tabulated (bottom-up)?**
Identify every distinct argument combination the recursion depends on — that becomes your table's dimensions. Seed the table's base cases directly (mirroring the function's base-case `if` checks). Then write a loop (or nested loops, for 2D+ state) that visits every table entry in an order that guarantees each entry's dependencies are already filled before it's computed — usually the natural increasing-index order, though for some problems (e.g. state depending on values "ahead" rather than "behind") the fill direction has to be chosen deliberately.

**Q: When would you prefer memoization over tabulation even knowing they're asymptotically equivalent?**
When only a small, hard-to-predict subset of the full state space is actually needed to answer the query (memoization naturally computes only what recursion demands, while naive tabulation fills the whole table regardless), or when the natural fill order for tabulation isn't obvious (irregular/graph-shaped subproblem dependencies), in which case matching the problem's own recursive structure via memoization is often easier to get correct on the first attempt.
