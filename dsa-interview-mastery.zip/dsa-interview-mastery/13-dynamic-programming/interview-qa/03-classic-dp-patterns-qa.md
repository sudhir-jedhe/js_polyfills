# Interview Q&A — Classic DP Patterns

**Q: What's the key structural difference between a "counting" 1D DP recurrence (like climbing stairs) and an "optimization" 1D DP recurrence (like house robber)?**
Counting recurrences typically *sum* the contributions of multiple valid options, since every option is a legitimately different path/way that should all be counted (`dp[i] = dp[i-1] + dp[i-2]`). Optimization recurrences typically take the *max* (or *min*) of a small set of explicit choices, since only one choice can actually be taken and the goal is finding the best one (`dp[i] = max(dp[i-1], dp[i-2] + value[i])`).

**Q: In 2D grid DP (like unique paths), why does each cell only need to look at the cell above it and the cell to its left?**
Because the movement rule (only right or down) means any cell can only have been arrived at from exactly those two neighbors — there's no other way to reach `(i, j)` given the constraints. This is a direct consequence of the problem's structure, not a general DP rule; a different movement rule (e.g. allowing diagonal moves) would require reading a different, larger set of neighboring cells.

**Q: What distinguishes 0/1 knapsack from unbounded knapsack (like coin change) at the code level?**
0/1 knapsack's "take this item" branch reads from the *previous row* of the table (`dp[i-1][w - weight]`), guaranteeing each item is considered at most once. Unbounded knapsack's "take this item" branch reads from the *same row/pass* (`dp[w - weight]`, without decrementing the item index), which allows the same item to be selected again in that same computation — modeling unlimited supply.

**Q: What does the LCS and edit-distance table backtrace technique let you do beyond just getting the final number?**
It lets you reconstruct the *actual sequence of decisions* that produced the optimal value — the specific common subsequence itself (for LCS), or the specific sequence of insert/delete/replace operations (for edit distance) — by walking backward from the final cell to the origin, at each step inferring which choice must have been made by comparing the current cell's value against the cells it could have come from. This is a common, natural follow-up question after solving the base "what's the optimal value" version of either problem.

**Q: Why is edit distance's per-cell recurrence a `1 + min(...)` rather than a plain `min(...)`?**
Every branch of the mismatch case (replace, delete, insert) represents performing exactly one additional edit operation on top of whatever the referenced neighboring cell already required — so the `+1` accounts for that operation's cost, while `min(...)` picks whichever of the three operations leads to the cheapest overall path. When the characters already match, no operation is needed at all, so that case skips the `+1` entirely and just carries forward the diagonal cell's value unchanged.
