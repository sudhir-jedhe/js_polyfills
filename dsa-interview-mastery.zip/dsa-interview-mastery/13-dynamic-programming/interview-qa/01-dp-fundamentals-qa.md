# Interview Q&A — DP Fundamentals

**Q: What two properties must a problem have for dynamic programming to apply?**
Optimal substructure (the optimal solution to the whole problem can be built from optimal solutions to its subproblems) and overlapping subproblems (a naive recursive solution ends up solving the exact same subproblem multiple times from different call paths). Both are required — optimal substructure without overlap means plain recursion or divide-and-conquer is already efficient (nothing to cache); overlap without optimal substructure means DP's core assumption (locally optimal pieces combine into a globally optimal whole) doesn't hold.

**Q: Why doesn't merge sort benefit from memoization even though it's recursive?**
Merge sort's subproblems (the left half and right half of the array) are always genuinely disjoint — no recursive call is ever repeated with the same arguments from a different path. Without overlapping subproblems, there's nothing for a cache to save; every subproblem is computed exactly once regardless.

**Q: Give an example of a problem with optimal substructure but NOT overlapping subproblems, and one with neither.**
Merge sort has optimal substructure (a sorted array is built from two sorted halves) but no overlap, as above. "Find the longest simple path in a general graph" has neither cleanly — it's NP-hard, and doesn't have optimal substructure in the useful sense, since the locally-longest path to an intermediate node might not extend to the globally longest path at all (it could dead-end).

**Q: What is "state" in the context of DP, and why does identifying it correctly matter?**
State is the minimal set of variables that fully and uniquely describes a subproblem — e.g. "position in an array" for 1D DP, or "index in string A, index in string B" for two-string 2D DP. Getting the state definition right determines the DP table's dimensionality and correctness: too little state (missing a variable the answer actually depends on) produces a table that silently gives wrong answers because different subproblems collide into the same cell; too much state works correctly but wastes time and space on distinctions that don't actually matter.

**Q: How do you compute the time complexity of a DP solution in general?**
Multiply the number of distinct states (the size of the DP table) by the work done to fill each state. For example, 0/1 knapsack has `O(n · capacity)` states, and each state does `O(1)` work (a constant number of array lookups and comparisons), giving `O(n · capacity)` total time — even though this can be exponential relative to the *input size* in bits (this is why knapsack is called "pseudo-polynomial," not truly polynomial, a distinction worth knowing for a strong answer).
