# Problem: Unique Paths

## Problem Statement

A robot is located at the top-left corner of an `m x n` grid. The robot can only move either down or right at any point in time. The robot is trying to reach the bottom-right corner. How many possible unique paths are there?

## Constraints

- `1 <= m, n <= 100`
- The answer is guaranteed to fit in a 32-bit integer.

## Examples

```
Input: m = 3, n = 7
Output: 28

Input: m = 3, n = 2
Output: 3
```

## Approach

Any cell `(i, j)` can only be reached from directly above `(i-1, j)` or directly to the left `(i, j-1)`, since those are the only two moves allowed. So the number of paths to `(i, j)` is the sum of the paths to those two cells. The first row and first column are base cases: exactly one path reaches any cell along either edge (a straight line of moves in one direction).

## Solution

```js
function uniquePaths(m, n) {
  let prevRow = new Array(n).fill(1); // row 0: exactly 1 path to every cell (straight line right)

  for (let i = 1; i < m; i++) {
    const currentRow = new Array(n).fill(1); // column 0 of every row: exactly 1 path (straight line down)
    for (let j = 1; j < n; j++) {
      currentRow[j] = currentRow[j - 1] + prevRow[j]; // from the left (this row) + from above (prev row)
    }
    prevRow = currentRow;
  }
  return prevRow[n - 1];
}

module.exports = { uniquePaths };

// --- verification ---
console.log(uniquePaths(3, 7)); // 28
console.log(uniquePaths(3, 2)); // 3
console.log(uniquePaths(1, 1)); // 1 — already at the destination
```

## Complexity

- **Time:** O(m · n) — every cell is computed once.
- **Space:** O(n) — only the previous row is kept (a rolling-array space optimization down from the naive O(m·n) full 2D table — see `../theory/06-recognizing-dp-problems-decision-framework-and-space-optimization.md`).
