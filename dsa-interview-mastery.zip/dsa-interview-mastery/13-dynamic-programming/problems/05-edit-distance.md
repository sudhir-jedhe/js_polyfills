# Problem: Edit Distance

## Problem Statement

Given two strings `word1` and `word2`, return the minimum number of operations required to convert `word1` into `word2`. You have three operations permitted on a word: insert a character, delete a character, or replace a character.

## Constraints

- `0 <= word1.length, word2.length <= 500`
- Both strings consist of lowercase English letters.

## Examples

```
Input: word1 = "horse", word2 = "ros"
Output: 3   (horse -> rorse [replace h->r] -> rose [delete r] -> ros [delete e])

Input: word1 = "intention", word2 = "execution"
Output: 5
```

## Approach

`dp[i][j]` = minimum operations to convert the first `i` characters of `word1` into the first `j` characters of `word2`. If the current characters already match, no operation is needed at that position — carry forward the diagonal (`dp[i-1][j-1]`). If they don't match, one operation is required, whichever is cheapest: replace (`dp[i-1][j-1]`, fixing both characters at once), delete from `word1` (`dp[i-1][j]`), or insert into `word1` to match `word2` (`dp[i][j-1]`) — take `1 + min` of those three.

## Solution

```js
function minDistance(word1, word2) {
  const m = word1.length, n = word2.length;
  const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));

  for (let i = 0; i <= m; i++) dp[i][0] = i; // convert word1[0..i-1] to "" -> i deletions
  for (let j = 0; j <= n; j++) dp[0][j] = j; // convert "" to word2[0..j-1] -> j insertions

  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      if (word1[i - 1] === word2[j - 1]) {
        dp[i][j] = dp[i - 1][j - 1];
      } else {
        dp[i][j] = 1 + Math.min(
          dp[i - 1][j - 1], // replace
          dp[i - 1][j],     // delete
          dp[i][j - 1]      // insert
        );
      }
    }
  }
  return dp[m][n];
}

module.exports = { minDistance };

// --- verification ---
console.log(minDistance('horse', 'ros'));        // 3
console.log(minDistance('intention', 'execution')); // 5
console.log(minDistance('', 'abc'));              // 3 — three insertions
```

## Complexity

- **Time:** O(m · n) — every cell filled once in O(1).
- **Space:** O(m · n) for the full table; reducible to O(min(m, n)) with a rolling-row optimization if only the count (not the reconstructed edit sequence) is needed.
