# Problem: Longest Common Subsequence

## Problem Statement

Given two strings `text1` and `text2`, return the length of their longest common subsequence. A subsequence is a sequence derived from the original string by deleting some (or no) characters without changing the order of the remaining characters. If there's no common subsequence, return `0`.

## Constraints

- `1 <= text1.length, text2.length <= 1000`
- Both strings consist of lowercase English characters.

## Examples

```
Input: text1 = "abcde", text2 = "ace"
Output: 3   ("ace" is a subsequence of both)

Input: text1 = "abc", text2 = "abc"
Output: 3

Input: text1 = "abc", text2 = "def"
Output: 0
```

## Approach

`dp[i][j]` = LCS length using the first `i` characters of `text1` and the first `j` characters of `text2`. If those two characters (`text1[i-1]` and `text2[j-1]`) match, they can both be part of the LCS — extend the diagonal (`dp[i-1][j-1]`) by 1. If they don't match, the LCS can't include *both* of these specific characters, so take the best of excluding one or the other: `max(dp[i-1][j], dp[i][j-1])`.

## Solution

```js
function longestCommonSubsequence(text1, text2) {
  const m = text1.length, n = text2.length;
  const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));

  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      if (text1[i - 1] === text2[j - 1]) {
        dp[i][j] = dp[i - 1][j - 1] + 1;
      } else {
        dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1]);
      }
    }
  }
  return dp[m][n];
}

module.exports = { longestCommonSubsequence };

// --- verification ---
console.log(longestCommonSubsequence('abcde', 'ace')); // 3
console.log(longestCommonSubsequence('abc', 'abc'));    // 3
console.log(longestCommonSubsequence('abc', 'def'));    // 0
```

## Complexity

- **Time:** O(m · n) — every cell of the table is filled once, in O(1).
- **Space:** O(m · n) for the full table; can be reduced to O(min(m, n)) with a rolling-row optimization if only the length (not the actual subsequence) is needed, since each row only depends on the row directly above it.
