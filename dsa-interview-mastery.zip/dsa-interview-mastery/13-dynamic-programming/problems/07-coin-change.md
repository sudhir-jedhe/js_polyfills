# Problem: Coin Change

## Problem Statement

Given an array of coin `denominations` and a target `amount`, return the fewest number of coins needed to make up that amount. Each denomination has an unlimited supply. If the amount cannot be made up by any combination of the coins, return `-1`.

## Constraints

- `1 <= denominations.length <= 12`
- `1 <= denominations[i] <= 2^31 - 1`
- `0 <= amount <= 10^4`

## Examples

```
Input: denominations = [1,2,5], amount = 11
Output: 3   (5 + 5 + 1)

Input: denominations = [2], amount = 3
Output: -1  (odd amount, only even denomination available)

Input: denominations = [1], amount = 0
Output: 0
```

## Approach

This is the **unbounded** knapsack variant (each coin denomination can be reused without limit), which is why the recurrence differs from 0/1 knapsack in one key way: `dp[w]` = fewest coins to make amount `w`. For each amount from `1` to the target, try every denomination that fits, and take `1 + dp[w - coin]` — reading from the *same* pass (not a "previous item" row), which is exactly what permits reusing a coin denomination multiple times within the final answer.

## Solution

```js
function coinChange(denominations, amount) {
  const dp = new Array(amount + 1).fill(Infinity);
  dp[0] = 0; // 0 coins needed to make amount 0

  for (let w = 1; w <= amount; w++) {
    for (const coin of denominations) {
      if (coin <= w && dp[w - coin] + 1 < dp[w]) {
        dp[w] = dp[w - coin] + 1; // reusing dp[w - coin] from the SAME array/pass allows coin reuse
      }
    }
  }
  return dp[amount] === Infinity ? -1 : dp[amount];
}

module.exports = { coinChange };

// --- verification ---
console.log(coinChange([1, 2, 5], 11)); // 3
console.log(coinChange([2], 3));         // -1
console.log(coinChange([1], 0));         // 0
console.log(coinChange([1, 3, 4], 6));   // 2 -> 3 + 3
```

## Complexity

- **Time:** O(amount · number of denominations) — for every amount from 1 to the target, every denomination is tried once.
- **Space:** O(amount) for the `dp` array — already the space-optimal 1D form, since coin change's state only needs "remaining amount," unlike 0/1 knapsack's two-dimensional "item index + capacity" state.
