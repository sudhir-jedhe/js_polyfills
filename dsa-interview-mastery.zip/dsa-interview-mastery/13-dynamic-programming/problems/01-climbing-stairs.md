# Problem: Climbing Stairs

## Problem Statement

You're climbing a staircase with `n` steps. Each move, you can climb either 1 or 2 steps. In how many distinct ways can you climb to the top?

## Constraints

- `1 <= n <= 45`

## Examples

```
Input: n = 2
Output: 2   (1+1, or 2)

Input: n = 3
Output: 3   (1+1+1, 1+2, or 2+1)
```

## Approach

To reach step `n`, the last move taken was either a single 1-step from step `n-1`, or a single 2-step from step `n-2` — these are the only two ways to arrive, and they're mutually exclusive, so the total number of ways to reach `n` is the *sum* of the ways to reach `n-1` and the ways to reach `n-2`. This is structurally identical to the Fibonacci recurrence, just with different base cases.

## Solution

```js
function climbStairs(n) {
  if (n <= 2) return n; // 1 way to reach step 1, 2 ways to reach step 2

  let prev2 = 1; // ways to reach step 1
  let prev1 = 2; // ways to reach step 2

  for (let i = 3; i <= n; i++) {
    const current = prev1 + prev2;
    prev2 = prev1;
    prev1 = current;
  }
  return prev1;
}

module.exports = { climbStairs };

// --- verification ---
console.log(climbStairs(2));  // 2
console.log(climbStairs(3));  // 3
console.log(climbStairs(5));  // 8
console.log(climbStairs(10)); // 89
```

## Complexity

- **Time:** O(n) — one pass computing each value once.
- **Space:** O(1) — only two rolling variables are kept (the space-optimized, rolling-array form of the full `dp` array version); see `../theory/06-recognizing-dp-problems-decision-framework-and-space-optimization.md` for the general technique this applies.
