# Problem: 0/1 Knapsack

## Problem Statement

Given `n` items, each with a `weight` and a `value`, and a knapsack with maximum weight capacity `W`, determine the maximum total value achievable by choosing a subset of items whose combined weight does not exceed `W`. Each item may be taken at most once (0/1 — take it fully, or not at all).

## Constraints

- `1 <= n <= 100`
- `1 <= weight[i], value[i] <= 1000`
- `1 <= W <= 1000`

## Examples

```
Input: weights = [1,3,4,5], values = [1,4,5,7], W = 7
Output: 9   (take items with weight 3 (value 4) and weight 4 (value 5): total weight 7, value 9)

Input: weights = [2,3,4,5], values = [3,4,5,6], W = 5
Output: 7   (take items with weight 2 (value 3) and weight 3 (value 4): total weight 5, value 7)
```

## Approach

`dp[i][w]` = maximum value achievable using only the first `i` items with capacity `w`. At each item, either skip it (`dp[i-1][w]`) or, if it fits, take it (`dp[i-1][w - weight] + value`) — take the better of the two. Referencing the *previous* item row (`i-1`) in both branches, never the current row, is what enforces each item being usable at most once.

## Solution

```js
function knapsack01(weights, values, capacity) {
  const n = weights.length;
  const dp = Array.from({ length: n + 1 }, () => new Array(capacity + 1).fill(0));

  for (let i = 1; i <= n; i++) {
    const weight = weights[i - 1];
    const value = values[i - 1];
    for (let w = 0; w <= capacity; w++) {
      dp[i][w] = dp[i - 1][w];
      if (weight <= w) {
        dp[i][w] = Math.max(dp[i][w], dp[i - 1][w - weight] + value);
      }
    }
  }
  return dp[n][capacity];
}

module.exports = { knapsack01 };

// --- verification ---
console.log(knapsack01([1, 3, 4, 5], [1, 4, 5, 7], 7)); // 9
console.log(knapsack01([2, 3, 4, 5], [3, 4, 5, 6], 5)); // 7
```

## Complexity

- **Time:** O(n · W) — pseudo-polynomial: polynomial in the *numeric value* of the capacity, but exponential relative to the number of bits needed to represent it, which is why knapsack is NP-hard in general despite this efficient DP solution for reasonably-sized inputs.
- **Space:** O(n · W) for the full table; reducible to O(W) with a rolling 1D array, iterating capacity `w` in *decreasing* order within each item's pass — decreasing order is required specifically to avoid reusing the same item twice within one item's own update pass.
