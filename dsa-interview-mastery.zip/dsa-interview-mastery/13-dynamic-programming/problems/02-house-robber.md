# Problem: House Robber

## Problem Statement

You are a professional robber planning to rob houses along a street, represented as an array `nums` where `nums[i]` is the amount of money in house `i`. Adjacent houses have connected security systems — robbing two adjacent houses on the same night triggers an alarm. Determine the maximum amount of money you can rob without robbing two adjacent houses.

## Constraints

- `1 <= nums.length <= 100`
- `0 <= nums[i] <= 400`

## Examples

```
Input: nums = [1,2,3,1]
Output: 4   (rob house 0 and house 2: 1 + 3 = 4)

Input: nums = [2,7,9,3,1]
Output: 12  (rob houses 0, 2, 4: 2 + 9 + 1 = 12)
```

## Approach

At each house `i`, there's a genuine binary choice: skip it (carrying forward the best result achievable using houses up to `i-1`), or rob it (adding its value to the best result achievable using houses up to `i-2`, since house `i-1` is now off-limits). Take whichever option yields more.

## Solution

```js
function rob(nums) {
  if (nums.length === 0) return 0;
  if (nums.length === 1) return nums[0];

  let prev2 = nums[0];                    // best using just house 0
  let prev1 = Math.max(nums[0], nums[1]); // best using houses 0-1

  for (let i = 2; i < nums.length; i++) {
    const current = Math.max(prev1, prev2 + nums[i]);
    prev2 = prev1;
    prev1 = current;
  }
  return prev1;
}

module.exports = { rob };

// --- verification ---
console.log(rob([1, 2, 3, 1]));    // 4
console.log(rob([2, 7, 9, 3, 1])); // 12
console.log(rob([5]));              // 5
console.log(rob([]));               // 0
```

## Complexity

- **Time:** O(n) — one pass through the houses.
- **Space:** O(1) — rolling `prev1`/`prev2` variables instead of a full `dp` array, since each state only ever depends on the two immediately preceding values.
