# Space-Optimized Fibonacci — Rolling Variables Instead of a Full Array

```js
function fibSpaceOptimized(n) {
  if (n <= 1) return n;

  let prev2 = 0; // fib(i - 2)
  let prev1 = 1; // fib(i - 1)

  for (let i = 2; i <= n; i++) {
    const current = prev1 + prev2;
    prev2 = prev1;
    prev1 = current;
  }
  return prev1;
}

console.log(fibSpaceOptimized(30)); // 832040 — identical result to the full-array tabulated version
```

Since `fib(i)` only ever depends on the two immediately preceding values, the entire `table` array from the tabulated version is unnecessary — two rolling scalars carry exactly the state the recurrence needs. Time stays O(n); space drops from O(n) to O(1). This is the 1D case of the "rolling array" technique — see `../theory/06-recognizing-dp-problems-decision-framework-and-space-optimization.md` for the 2D (rolling row) version applied to unique paths.
