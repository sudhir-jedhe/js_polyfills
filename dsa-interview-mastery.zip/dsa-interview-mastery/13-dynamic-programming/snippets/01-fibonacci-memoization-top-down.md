# Fibonacci — Memoization (Top-Down)

```js
function fibMemo(n, cache = new Map()) {
  if (n <= 1) return n;
  if (cache.has(n)) return cache.get(n);

  const result = fibMemo(n - 1, cache) + fibMemo(n - 2, cache);
  cache.set(n, result);
  return result;
}

console.log(fibMemo(30)); // 832040 — instant; naive recursion would take noticeably longer
```

O(n) time, O(n) space (cache + call stack). See `02-fibonacci-tabulation-bottom-up.md` for the same recurrence computed without recursion, and `../theory/02-memoization-vs-tabulation-same-problem-both-ways.md` for the full piece-by-piece mapping between the two.
