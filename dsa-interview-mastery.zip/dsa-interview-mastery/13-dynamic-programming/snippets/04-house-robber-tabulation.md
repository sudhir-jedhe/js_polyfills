# House Robber — Tabulation

```js
function rob(nums) {
  if (nums.length === 0) return 0;
  if (nums.length === 1) return nums[0];

  const dp = new Array(nums.length);
  dp[0] = nums[0];
  dp[1] = Math.max(nums[0], nums[1]);

  for (let i = 2; i < nums.length; i++) {
    dp[i] = Math.max(dp[i - 1], dp[i - 2] + nums[i]);
  }
  return dp[nums.length - 1];
}

console.log(rob([1, 2, 3, 1])); // 4 -> rob house 0 (1) + house 2 (3)
console.log(rob([2, 7, 9, 3, 1])); // 12 -> rob houses 0, 2, 4 (2+9+1)
```

Unlike Fibonacci/climbing-stairs (a sum of both prior options), this recurrence takes a `max` — a genuine choice exists at each house (rob it or skip it), which is the hallmark of an optimization-style 1D DP problem rather than a counting one.
