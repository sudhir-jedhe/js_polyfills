# Fibonacci — Tabulation (Bottom-Up)

```js
function fibTab(n) {
  if (n <= 1) return n;

  const table = new Array(n + 1);
  table[0] = 0;
  table[1] = 1;
  for (let i = 2; i <= n; i++) {
    table[i] = table[i - 1] + table[i - 2];
  }
  return table[n];
}

console.log(fibTab(30)); // 832040 — same answer as the memoized version
```

Same O(n) time, O(n) space as memoization, but with no recursion (no call stack risk) and no cache-lookup overhead — a plain loop reading array entries computed earlier in the same pass. See `07-space-optimized-rolling-array-fibonacci.md` for cutting the space to O(1).
