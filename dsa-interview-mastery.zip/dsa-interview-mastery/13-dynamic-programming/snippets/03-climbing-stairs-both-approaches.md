# Climbing Stairs — Memoized and Tabulated

```js
// Top-down
function climbStairsMemo(n, cache = new Map()) {
  if (n <= 2) return n;
  if (cache.has(n)) return cache.get(n);
  const result = climbStairsMemo(n - 1, cache) + climbStairsMemo(n - 2, cache);
  cache.set(n, result);
  return result;
}

// Bottom-up
function climbStairsTab(n) {
  if (n <= 2) return n;
  const dp = new Array(n + 1);
  dp[1] = 1;
  dp[2] = 2;
  for (let i = 3; i <= n; i++) dp[i] = dp[i - 1] + dp[i - 2];
  return dp[n];
}

console.log(climbStairsMemo(10)); // 89
console.log(climbStairsTab(10));  // 89
```

Structurally identical to Fibonacci with different base cases (`dp[1]=1, dp[2]=2` instead of `dp[0]=0, dp[1]=1`) — a good example of recognizing that two differently-worded problems share the same underlying recurrence.
