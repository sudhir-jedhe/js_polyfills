# 0/1 Knapsack — Tabulation

```js
function knapsack01(weights, values, capacity) {
  const n = weights.length;
  const dp = Array.from({ length: n + 1 }, () => new Array(capacity + 1).fill(0));

  for (let i = 1; i <= n; i++) {
    for (let w = 0; w <= capacity; w++) {
      dp[i][w] = dp[i - 1][w]; // skip item i
      if (weights[i - 1] <= w) {
        dp[i][w] = Math.max(dp[i][w], dp[i - 1][w - weights[i - 1]] + values[i - 1]); // take item i
      }
    }
  }
  return dp[n][capacity];
}

console.log(knapsack01([2, 3, 4, 5], [3, 4, 5, 6], 5)); // 7 -> items weight 2 (3) + weight 3 (4)
```

`dp[i][w]` = best value using only the first `i` items with capacity `w`. Referencing `dp[i - 1][...]` in both branches (never `dp[i][...]`) is what guarantees each item is used at most once — see `../theory/05-knapsack-pattern-0-1-knapsack.md` for the contrast with the unbounded (reuse-allowed) variant.
