# Unique Paths — 2D Tabulation

```js
function uniquePaths(m, n) {
  const dp = Array.from({ length: m }, () => new Array(n).fill(1)); // top row & left col = 1

  for (let i = 1; i < m; i++) {
    for (let j = 1; j < n; j++) {
      dp[i][j] = dp[i - 1][j] + dp[i][j - 1];
    }
  }
  return dp[m - 1][n - 1];
}

console.log(uniquePaths(3, 7)); // 28
console.log(uniquePaths(3, 2)); // 3
```

Each cell sums the cell above it and the cell to its left — the two, and only two, cells a rightward/downward move could have arrived from. O(m·n) time and space; see `../theory/06-recognizing-dp-problems-decision-framework-and-space-optimization.md` for collapsing this to O(n) space using a rolling row.
