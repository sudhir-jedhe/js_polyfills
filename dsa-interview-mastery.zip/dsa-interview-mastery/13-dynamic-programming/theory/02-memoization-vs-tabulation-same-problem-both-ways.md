# Memoization (Top-Down) vs. Tabulation (Bottom-Up): The Same Problem, Both Ways

Both memoization and tabulation solve exactly the same recurrence, produce exactly the same answer, and have the same asymptotic time and space complexity in almost every case. They're not two different algorithms — they're two different *directions* of computing the same recursion tree. Understanding one as a direct transformation of the other is what makes DP click, instead of feeling like two disconnected tricks to memorize.

We'll solve Fibonacci — `fib(n) = fib(n-1) + fib(n-2)`, with `fib(0) = 0` and `fib(1) = 1` — three times: naive, then memoized (top-down), then tabulated (bottom-up), so the transformation at each step is visible.

## Step 0: naive recursion (the baseline, with the problem)

```js
function fibNaive(n) {
  if (n <= 1) return n;
  return fibNaive(n - 1) + fibNaive(n - 2);
}
```

This directly encodes the recurrence but recomputes every subproblem exponentially many times (see `01-optimal-substructure-and-overlapping-subproblems.md`) — O(2^n) time.

## Step 1: memoization (top-down) — add a cache to the recursion you already have

The transformation from naive recursion to memoization is mechanical: keep the exact same recursive structure, and add a cache check at the top of the function (return early on a hit) plus a cache write right before every return (on a miss).

```js
function fibMemo(n, cache = new Map()) {
  if (n <= 1) return n;                     // base case — unchanged from naive version
  if (cache.has(n)) return cache.get(n);     // NEW: cache check — skip recomputation

  const result = fibMemo(n - 1, cache) + fibMemo(n - 2, cache); // same recursive call shape
  cache.set(n, result);                       // NEW: cache write before returning
  return result;
}
```

**"Top-down"** describes the direction of computation: the call starts at the top (`fib(n)`, the value we actually want) and works its way *down* toward the base cases through recursive calls, computing whatever subproblems the recursion happens to need, in whatever order the call structure naturally visits them.

## Step 2: tabulation (bottom-up) — invert the direction, replace recursion with a loop

Tabulation asks the same question — "what's `fib(k)` for every `k` needed?" — but computes answers starting from the base cases and building *up* toward `n`, using an explicit array (the "table") instead of the call stack, and a loop instead of recursive calls.

```js
function fibTab(n) {
  if (n <= 1) return n;

  const table = new Array(n + 1);
  table[0] = 0;                               // base case
  table[1] = 1;                               // base case

  for (let i = 2; i <= n; i++) {
    table[i] = table[i - 1] + table[i - 2];    // same recurrence, computed forward
  }
  return table[n];
}
```

**"Bottom-up"** describes the direction: start at the bottom (the base cases, `table[0]` and `table[1]`) and iteratively fill upward until reaching `table[n]`. There's no recursion at all — just a loop reading previously-filled entries.

## Mapping every piece, memoization → tabulation

| Memoization (top-down) piece | Tabulation (bottom-up) equivalent |
|---|---|
| `cache` (a `Map`, filled lazily, possibly sparse) | `table` (an array, filled completely and in order) |
| Base case `if (n <= 1) return n` | Table seeded directly: `table[0] = 0; table[1] = 1;` |
| Recursive calls `fibMemo(n-1)`, `fibMemo(n-2)` | Array reads `table[i-1]`, `table[i-2]` |
| Call stack (implicit order, driven by recursion) | `for` loop (explicit order, driven by the loop counter) |
| Cache check (`if (cache.has(n))`) | Not needed — every table entry is computed exactly once, in a fixed order, before it's read |
| Cache write (`cache.set(n, result)`) | Array assignment (`table[i] = ...`) |

Every recursive call in the top-down version corresponds to exactly one loop iteration in the bottom-up version — they visit the same set of subproblems, just in different orders (top-down: whatever order recursive calls happen to demand; bottom-up: strictly increasing index order, guaranteed by the loop).

## Why they have the same complexity

Both compute each of the `n` distinct subproblems (`fib(0)` through `fib(n)`) exactly once, doing O(1) work per subproblem beyond the recursive/loop lookups — O(n) time, O(n) space for either version. The constant-factor difference: tabulation avoids function-call overhead and cache-lookup overhead entirely (plain array indexing is faster than `Map` operations), which is why bottom-up is typically somewhat faster in practice despite matching Big-O.

## When to prefer one over the other

| | Memoization (top-down) | Tabulation (bottom-up) |
|---|---|---|
| Computes every subproblem from 0 to n? | Only the ones actually needed by the recursion (can be fewer, if some are skippable) | Always all of them, in order |
| Risk of stack overflow on deep recursion | Yes — one stack frame per recursive call | No — it's a plain loop, O(1) stack frames |
| Code often closer to the natural recurrence | Yes — usually a near-direct translation of the recursive definition | Requires figuring out a valid *fill order* up front |
| Easier for irregular/graph-shaped subproblem structure | Often yes — recursion naturally follows whatever structure the problem has | Can be awkward if the right fill order isn't a simple increasing loop |
| Space optimization (rolling variables instead of a full array) | Harder to see/apply directly | Very natural — see `06-recognizing-dp-problems-decision-framework-and-space-optimization.md` |

**Practical interview default:** many candidates find it easier to *derive* the recurrence by thinking recursively first (top-down, matching how the problem is naturally described), get a memoized version working, and then — if bottom-up or space-optimized is asked for as a follow-up — mechanically invert it into tabulation using the mapping table above. Both are fully correct, complete answers; knowing the translation between them, not just one direction, is what interviewers are actually checking for.
