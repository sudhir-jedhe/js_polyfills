# 2D DP: Grids, Longest Common Subsequence, and Edit Distance

2D DP problems need *two* indices to describe a subproblem's state — usually either a position in a grid `(row, col)`, or a pair of positions, one in each of two input strings/arrays. The table becomes a 2D array `dp[i][j]`, and each cell typically depends on one to three neighboring cells (left, up, and/or diagonal).

## Unique paths (grid DP)

**Problem shape:** starting at the top-left of an `m x n` grid, moving only right or down, how many distinct paths reach the bottom-right?

**Recurrence:** the number of ways to reach cell `(i, j)` is the sum of the ways to reach the cell directly above it and the cell directly to its left — since those are the only two cells a move could have come from.

```js
function uniquePaths(m, n) {
  const dp = Array.from({ length: m }, () => new Array(n).fill(1)); // first row/col: only 1 way (straight line)

  for (let i = 1; i < m; i++) {
    for (let j = 1; j < n; j++) {
      dp[i][j] = dp[i - 1][j] + dp[i][j - 1]; // from above + from the left
    }
  }
  return dp[m - 1][n - 1];
}
console.log(uniquePaths(3, 2)); // 3
```

The first row and first column are seeded to `1` directly (there's exactly one way to reach any cell along the top edge or left edge: a straight line of moves), which serves as the base case for the 2D recurrence.

## Longest Common Subsequence (LCS)

**Problem shape:** given two strings, find the length of their longest subsequence common to both (subsequence = characters in order, not necessarily contiguous).

**Recurrence:** `dp[i][j]` = LCS length using the first `i` characters of string A and the first `j` characters of string B. If the characters at the current position match, extend the diagonal's LCS by 1; if they don't, take the better of "skip this character of A" or "skip this character of B."

```js
function longestCommonSubsequence(textA, textB) {
  const m = textA.length, n = textB.length;
  const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));

  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      if (textA[i - 1] === textB[j - 1]) {
        dp[i][j] = dp[i - 1][j - 1] + 1;               // characters match — extend the diagonal
      } else {
        dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1]); // no match — best of skipping either character
      }
    }
  }
  return dp[m][n];
}
console.log(longestCommonSubsequence('abcde', 'ace')); // 3 -> "ace"
```

Note the off-by-one convention: `dp[i][j]` refers to the first `i` characters of A (i.e. `textA[0..i-1]`), so `textA[i-1]` is the *i*-th character. This mirrors the prefix-sum offset-by-one convention from the two-pointers/prefix-sum topic, and for the same reason — it cleanly handles the "zero characters considered so far" base case without special-casing.

## Edit Distance (Levenshtein distance)

**Problem shape:** minimum number of insert/delete/replace operations to turn string A into string B.

**Recurrence:** `dp[i][j]` = min operations to convert the first `i` characters of A into the first `j` characters of B. Matching characters cost nothing extra (diagonal carries forward); a mismatch costs 1 operation, taking the best of the three possible edits.

```js
function minDistance(word1, word2) {
  const m = word1.length, n = word2.length;
  const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));

  for (let i = 0; i <= m; i++) dp[i][0] = i; // deleting all i characters of word1
  for (let j = 0; j <= n; j++) dp[0][j] = j; // inserting all j characters of word2

  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      if (word1[i - 1] === word2[j - 1]) {
        dp[i][j] = dp[i - 1][j - 1];         // characters match — no operation needed
      } else {
        dp[i][j] = 1 + Math.min(
          dp[i - 1][j - 1], // replace
          dp[i - 1][j],     // delete from word1
          dp[i][j - 1]      // insert into word1
        );
      }
    }
  }
  return dp[m][n];
}
console.log(minDistance('horse', 'ros')); // 3
```

## Common thread across all three

Every 2D DP recurrence here reads from at most 3 neighboring cells — `dp[i-1][j]` (up), `dp[i][j-1]` (left), and `dp[i-1][j-1]` (diagonal) — combined with either a sum (unique paths, a counting problem), a max (LCS, an optimization/length problem), or a min-plus-one (edit distance, a cost-minimization problem). This "read from up/left/diagonal, fill row by row" shape is worth recognizing as its own template — a large fraction of 2D DP interview problems (unique paths with obstacles, minimum path sum, LCS, edit distance) are variations on exactly this cell-dependency pattern.
