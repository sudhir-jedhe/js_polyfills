# The Knapsack Pattern: 0/1 Knapsack

The 0/1 knapsack problem is one of the most important DP templates because so many other problems — including ones that don't look like "packing a bag" at all — reduce to it: subset sum, partition equal subset sum, target sum, and any "choose a subset of items under a capacity constraint to maximize value" problem.

## Problem shape

Given `n` items, each with a `weight` and a `value`, and a knapsack with capacity `W`, choose a subset of items (each either fully taken or fully left — hence "0/1," as opposed to fractional knapsack) to maximize total value without exceeding total weight `W`.

## Why this needs 2D state

The decision at item `i` — take it or not — depends on how much capacity remains, so the subproblem needs **both** "which items have been considered so far" and "how much capacity is left" to be well-defined. That's two dimensions: `dp[i][w]` = the maximum value achievable using only the first `i` items, with capacity `w`.

## Recurrence

For each item `i` and each capacity `w`, there are two options: skip item `i` (carry forward the best value using the first `i-1` items at the same capacity), or take item `i` (only possible if it fits — `weight[i] <= w` — in which case add its value to the best value achievable with the *remaining* capacity, using only the first `i-1` items). Take whichever option is better.

```js
function knapsack01(weights, values, capacity) {
  const n = weights.length;
  const dp = Array.from({ length: n + 1 }, () => new Array(capacity + 1).fill(0));

  for (let i = 1; i <= n; i++) {
    const weight = weights[i - 1];
    const value = values[i - 1];

    for (let w = 0; w <= capacity; w++) {
      dp[i][w] = dp[i - 1][w]; // option 1: skip item i — carry forward

      if (weight <= w) {
        dp[i][w] = Math.max(
          dp[i][w],
          dp[i - 1][w - weight] + value // option 2: take item i
        );
      }
    }
  }
  return dp[n][capacity];
}

console.log(knapsack01([1, 3, 4, 5], [1, 4, 5, 7], 7)); // 9 -> items weight 3 (value 4) + weight 4 (value 5)
```

## Why `dp[i-1][...]`, not `dp[i][...]`, in the "take" branch

The critical detail that makes this *0/1* (each item usable at most once) rather than *unbounded* (each item reusable any number of times) knapsack is referencing `dp[i-1][w - weight]` — the best value using the *previous* items only — rather than `dp[i][w - weight]`, which would allow item `i` to be "taken again" from a state that had already included it. Referencing row `i-1` guarantees item `i` is considered exactly once per state. (The unbounded/coin-change variant, covered in `../problems/07-coin-change.md`, deliberately reuses `dp[w]` from the *same* row/pass instead, which is exactly what allows unlimited reuse of each item.)

## Comparison: 0/1 vs. unbounded knapsack

| | 0/1 Knapsack | Unbounded Knapsack (e.g. Coin Change) |
|---|---|---|
| Can an item be used more than once? | No — each item taken or not, at most once | Yes — unlimited supply of each item/denomination |
| Recurrence take-branch references | `dp[i-1][w - weight]` (previous row) | `dp[w - weight]` (same row/pass, allows reuse) |
| Classic examples | Subset sum, partition equal subset sum, target sum | Coin change (min coins / number of ways), rod cutting |

## Recognizing knapsack-shaped problems

The tell is a **capacity-like constraint** (a total weight, budget, target sum) combined with a **set of discrete items each with a cost and a value**, where you're choosing a subset. Once you spot that shape, the two-dimensional `dp[item index][remaining capacity]` state — and the skip-vs-take recurrence — applies directly, even when the problem is phrased as "can a subset sum to exactly X" (subset sum: same recurrence, but tracking a boolean "reachable" instead of a maximized value) rather than literally packing physical items.
