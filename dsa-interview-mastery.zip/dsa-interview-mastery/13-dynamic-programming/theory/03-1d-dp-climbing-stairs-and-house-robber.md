# 1D DP: Climbing Stairs and House Robber

1D DP problems are ones where the state that matters can be captured by a single index — usually "position in an array" or "step number" — and the table is a simple 1D array `dp[i]`, where each entry depends on one or two *previous* entries.

## Climbing stairs

**Problem shape:** you can climb 1 or 2 steps at a time; how many distinct ways are there to reach step `n`?

**Recurrence:** to reach step `i`, your *last* move was either a 1-step from `i-1`, or a 2-step from `i-2` — so the number of ways to reach `i` is the sum of the ways to reach each of those:

```js
function climbStairs(n) {
  if (n <= 2) return n; // 1 way to reach step 1, 2 ways to reach step 2 (1+1, or 2)

  const dp = new Array(n + 1);
  dp[1] = 1;
  dp[2] = 2;
  for (let i = 3; i <= n; i++) {
    dp[i] = dp[i - 1] + dp[i - 2]; // structurally identical to fib(i) = fib(i-1) + fib(i-2)
  }
  return dp[n];
}
```

Climbing stairs is, structurally, exactly Fibonacci with different base cases — recognizing that equivalence is a very common "aha" moment, and a strong interview signal when named explicitly.

## House robber

**Problem shape:** given an array of house values, rob houses to maximize total value, but you can't rob two *adjacent* houses. What's the max total?

**Recurrence:** at each house `i`, you face a genuine choice — rob it (and add its value to the best result from `i-2`, since `i-1` is now off-limits) or skip it (keeping the best result from `i-1`, unchanged):

```js
function rob(nums) {
  if (nums.length === 0) return 0;
  if (nums.length === 1) return nums[0];

  const dp = new Array(nums.length);
  dp[0] = nums[0];
  dp[1] = Math.max(nums[0], nums[1]);

  for (let i = 2; i < nums.length; i++) {
    dp[i] = Math.max(
      dp[i - 1],              // skip house i — carry forward the best so far
      dp[i - 2] + nums[i]     // rob house i — add its value to the best excluding i-1
    );
  }
  return dp[nums.length - 1];
}
```

`dp[i]` means "the maximum value obtainable from the first `i+1` houses" — not "whether house `i` specifically is robbed." This distinction matters: `dp[i]` already accounts for the optimal decision at every earlier house, so the final answer is simply `dp[n-1]`, without needing to track which houses were actually chosen (unless the problem asks you to reconstruct the actual set, which requires walking back through the table afterward).

## Comparing the two recurrences

| | Climbing Stairs | House Robber |
|---|---|---|
| Recurrence | `dp[i] = dp[i-1] + dp[i-2]` | `dp[i] = max(dp[i-1], dp[i-2] + nums[i])` |
| What each `dp[i]` means | Total *count* of ways to reach step `i` | Best *value* achievable using the first `i+1` houses |
| Combine sub-answers by | Summing (every path counts) | Taking a max (choosing the better of two options) |
| Real decision at step `i`? | No — both a 1-step and 2-step arrival are always valid, both get counted | Yes — genuinely choose to rob or skip |

This contrast is the most useful thing to internalize about 1D DP: **counting problems tend to sum sub-results together**, while **optimization problems (max/min) tend to take the best of a small set of explicit choices** at each step. Spotting which shape a new problem has is most of the work of writing its recurrence.

## General 1D DP template

```js
function solve1D(input) {
  const n = input.length;
  const dp = new Array(n);
  dp[0] = /* base case */;
  // possibly dp[1] = /* second base case, if the recurrence looks back 2 steps */;

  for (let i = 1 /* or 2 */; i < n; i++) {
    dp[i] = /* combine dp[i-1] (and maybe dp[i-2]) with input[i] */;
  }
  return dp[n - 1];
}
```
