# What Makes a Problem a DP Problem: Optimal Substructure + Overlapping Subproblems

Dynamic programming isn't a separate algorithm so much as an optimization applied to plain recursion: it's what you get when you take a recursive solution and eliminate the redundant, repeated work it does. A problem is a good candidate for DP exactly when it has **both** of these two properties — missing either one means DP either doesn't apply or doesn't help.

## Optimal substructure

A problem has optimal substructure when its optimal solution can be constructed from the optimal solutions of its subproblems. In other words: solve the smaller pieces optimally, and combining those optimal pieces gives you the optimal answer to the whole problem — no need to reconsider "was that piece really the best choice" once it's solved.

```js
// Climbing stairs: the optimal (only) way to count paths to step n
// is built from the optimal counts for step n-1 and step n-2.
// ways(n) = ways(n-1) + ways(n-2)
```

Not every problem has this property. For example, "find the longest path in a graph" does *not* have optimal substructure in the same clean way shortest-path does, because the longest path to an intermediate node might force you into a dead end that prevents reaching the final destination at all — the locally optimal subpath isn't necessarily part of the globally optimal one. This is why DP solves shortest-path-style problems cleanly but not longest-simple-path problems.

## Overlapping subproblems

A problem has overlapping subproblems when a naive recursive solution ends up solving the *exact same* subproblem multiple times, independently, from different call paths. This is the property that makes caching worthwhile — if every subproblem were only ever computed once anyway (as in, say, merge sort's divide step), there'd be nothing to save by caching.

```js
// fib(5) calls fib(3) via TWO different paths:
//   fib(5) -> fib(4) -> fib(3)
//   fib(5) -> fib(3)          (directly)
// Both branches recompute fib(3), fib(2), fib(1), fib(0) independently — pure waste.
```

Contrast this with a divide-and-conquer algorithm like merge sort: `mergeSort(arr)` splits into two genuinely *disjoint* halves and never revisits the same sub-array from two different call paths — there's nothing to memoize, because nothing repeats.

## The two-question test

When facing a new problem in an interview, ask:

1. **Can I express the answer to the whole problem in terms of the answer to smaller versions of the same problem?** (Optimal substructure — if no, DP doesn't apply; think greedy, graph algorithms, or something else.)
2. **Does a direct recursive implementation of that recurrence end up solving the same smaller version more than once?** (Overlapping subproblems — if no, plain recursion or divide-and-conquer is already efficient; memoizing wouldn't change the complexity, since nothing is repeated to save.)

| Property present? | What it means |
|---|---|
| Both optimal substructure and overlapping subproblems | Classic DP problem — memoize or tabulate |
| Optimal substructure only, no overlap | Plain recursion / divide-and-conquer is already efficient (e.g. merge sort, binary search) |
| No optimal substructure | DP doesn't apply at all — greedy, exhaustive search, or a different technique needed |

## Worked example: Fibonacci passes both tests

- **Optimal substructure:** `fib(n) = fib(n-1) + fib(n-2)` — the answer for `n` is built directly from the answers for `n-1` and `n-2`.
- **Overlapping subproblems:** as shown above, `fib(3)` gets computed independently many times within a single call to `fib(5)` or larger.

Both properties hold, so caching each `fib(k)` the first time it's computed (memoization) turns an O(2^n) naive recursion into O(n) — see `02-memoization-vs-tabulation-same-problem-both-ways.md` for the full top-down and bottom-up implementations of exactly this.
