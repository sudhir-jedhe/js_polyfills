# Recognizing DP Problems in an Interview, and Space-Optimizing the Solution

Most candidates who "know DP" still struggle to recognize a fresh problem as a DP problem under interview pressure. This file gives a concrete, repeatable process for that recognition step, plus the standard technique (rolling array / rolling variables) for cutting a DP solution's space usage once it's working.

## A practical decision framework

**Step 1 — Look for the verbal tells.** Certain phrasings correlate strongly with DP:
- "Maximum / minimum ... " (cost, value, path sum, number of operations)
- "Number of distinct ways to ..." (counting problems)
- "Longest / shortest ... subsequence / substring / subarray / path"
- "Can you reach / achieve exactly ..." (feasibility, often subset-sum-shaped)

**Step 2 — Try to write a brute-force recursive solution first**, even a bad one. Ask: at each step, what choice(s) am I making, and what smaller version of the problem does each choice lead to? If you can write `solve(state)` in terms of `solve(smaller state)`, you likely have optimal substructure.

**Step 3 — Check for overlapping subproblems.** Would that brute-force recursion call `solve()` with the *same arguments* more than once from different paths? If yes — memoize or tabulate it. If every call has genuinely distinct arguments (like merge sort's disjoint halves), plain recursion is already efficient; DP wouldn't change the complexity.

**Step 4 — Identify the "state"** — the minimum set of variables that fully describes a subproblem. This determines your DP table's dimensionality:
- One index changing (position in an array, step count) → 1D DP, `dp[i]`.
- Two independent indices changing (two strings' positions, or item-index + remaining-capacity) → 2D DP, `dp[i][j]`.
- More dimensions (e.g. item index + capacity + a third constraint) → 3D+ DP, rarer but the same principle.

**Step 5 — Write the recurrence**, expressing `dp[state]` in terms of `dp[smaller states]`. This is usually the hardest step and the one worth talking through out loud — interviewers care more about *how* you derive the recurrence than about arriving at it instantly.

**Step 6 — Decide base cases**, then implement top-down (memoized) or bottom-up (tabulated) — see `02-memoization-vs-tabulation-same-problem-both-ways.md` for converting between them.

## Quick-reference: state shape to problem family

| Signal in the problem | Likely DP shape |
|---|---|
| One sequence, decisions build up over one index | 1D DP (climbing stairs, house robber, max subarray) |
| Two sequences being compared/aligned | 2D DP over both lengths (LCS, edit distance) |
| Grid with movement constraints | 2D DP over `(row, col)` (unique paths, min path sum) |
| Items with a capacity/budget constraint, choose a subset | Knapsack-shaped 2D DP over `(item index, capacity)` |
| "Number of ways to partition / sum to exactly X" | Often a knapsack variant (subset sum boolean, or counting variant) |

## Space optimization: the rolling array technique

Once a tabulated solution works, check whether `dp[i]` (or `dp[i][...]`) only ever depends on a **fixed, small number of previous rows/entries** — not on arbitrarily far-back history. If so, you don't need to keep the *entire* table around; only the most recent row(s) matter, and older ones can be discarded.

**1D example — Fibonacci needs only the last two values, not a full array:**

```js
function fibSpaceOptimized(n) {
  if (n <= 1) return n;
  let prev2 = 0, prev1 = 1; // fib(0), fib(1)
  for (let i = 2; i <= n; i++) {
    const current = prev1 + prev2;
    prev2 = prev1;
    prev1 = current;
  }
  return prev1;
}
// Time: O(n) — unchanged. Space: O(1) — down from O(n) for the full dp array.
```

**2D example — unique paths only needs the previous row, not the whole grid:**

```js
function uniquePathsSpaceOptimized(m, n) {
  let prevRow = new Array(n).fill(1);
  for (let i = 1; i < m; i++) {
    const currentRow = new Array(n).fill(1);
    for (let j = 1; j < n; j++) {
      currentRow[j] = currentRow[j - 1] + prevRow[j]; // "from the left" (same row) + "from above" (prev row)
    }
    prevRow = currentRow;
  }
  return prevRow[n - 1];
}
// Time: O(m*n) — unchanged. Space: O(n) — down from O(m*n) for the full 2D table.
```

This is the exact same recurrence as the full 2D version in `04-2d-dp-grids-lcs-edit-distance.md`, just with the table's second-to-last dimension collapsed to "only ever keep what's still needed."

## When rolling arrays don't apply

If a recurrence needs to look back further than a constant number of previous states (e.g. `dp[i]` depends on `dp[i-1]` *and* `dp[0]` for some accumulated global value), or if the *entire* filled table needs to be reconstructed afterward (e.g. to recover the actual chosen items, not just the optimal value), you generally can't collapse the table down — keep the full array in those cases, and only optimize space when the dependency pattern genuinely allows it. Always verify this dependency pattern explicitly before discarding rows; collapsing too aggressively is a common source of subtle bugs.

## Interview framing

A strong answer sequence: derive the recurrence and get a correct (even if not space-optimal) tabulated solution working first, state its time and space complexity, and *then* proactively mention the rolling-array optimization as a follow-up — "this only reads the previous row, so I can reduce space from O(m·n) to O(n) if that matters here." Volunteering this without being asked is a strong, low-risk signal of DP fluency.
