# What Does This Output? — 0/1 Knapsack Table Fill Trace

```js
function knapsack01(weights, values, capacity) {
  const n = weights.length;
  const dp = Array.from({ length: n + 1 }, () => new Array(capacity + 1).fill(0));
  for (let i = 1; i <= n; i++) {
    for (let w = 0; w <= capacity; w++) {
      dp[i][w] = dp[i - 1][w];
      if (weights[i - 1] <= w) {
        dp[i][w] = Math.max(dp[i][w], dp[i - 1][w - weights[i - 1]] + values[i - 1]);
      }
    }
  }
  console.log(dp.map(row => row.join(' ')).join('\n'));
  return dp[n][capacity];
}
console.log('result:', knapsack01([1, 2], [6, 10], 3));
```

**Answer:**
```
0 0 0 0
0 6 6 6
0 6 10 16
result: 16
```

**Why:** row 0 (no items considered yet) is all zeros — no value achievable with zero items regardless of capacity. Row 1 (item 1: weight 1, value 6): for every capacity `w >= 1`, taking item 1 (`dp[0][w-1] + 6`) beats skipping it (`dp[0][w] = 0`), so the row becomes `[0, 6, 6, 6]` — the value can't exceed 6 since there's only one item available. Row 2 (item 2: weight 2, value 10): at `w=1`, item 2 doesn't fit (`weight 2 > 1`), so `dp[2][1] = dp[1][1] = 6` (unchanged, skip). At `w=2`, taking item 2 alone (`dp[1][0] + 10 = 0 + 10 = 10`) beats carrying forward item-1-only's `dp[1][2] = 6`, so `dp[2][2] = 10`. At `w=3`, taking item 2 *and* whatever fits in the remaining capacity 1 (`dp[1][1] + 10 = 6 + 10 = 16`) beats both skipping item 2 (`dp[1][3] = 6`) and taking item 2 alone (`10`) — `dp[2][3] = 16`, meaning both items fit (`weight 1 + 2 = 3 <= 3`) for a combined value of `6 + 10 = 16`. The final answer, `dp[2][3] = 16`, confirms taking both items is optimal here.
