# What Does This Output? — Naive Fibonacci's Exponential Recursion Tree

```js
let calls = 0;
function fib(n) {
  calls++;
  if (n <= 1) return n;
  return fib(n - 1) + fib(n - 2);
}
console.log(fib(6), calls);
```

**Answer:** `8 25`

**Why:** `fib(6)` correctly evaluates to `8` (the 6th Fibonacci number), but getting there costs 25 total function calls — far more than the 6 distinct values (`fib(0)` through `fib(6)`) actually involved. The recursion tree branches in two at every node until it hits a base case, and because `fib(6)` calls `fib(5)` and `fib(4)`, `fib(5)` calls `fib(4)` and `fib(3)`, and so on, the *same* values get recomputed from scratch many times over — `fib(2)`, for instance, is computed independently multiple times across different branches of the tree. In general, naive `fib(n)`'s total call count is `2·fib(n+1) - 1`, which grows exponentially with `n` — this call-count blowup, purely from redundant recomputation of identical subproblems, is exactly the "overlapping subproblems" property that makes Fibonacci (and problems shaped like it) prime candidates for memoization. Compare against `02-memoized-fibonacci-call-count-trace.md`, where the identical recurrence, computed with a cache, needs only 11 calls for the same `n = 6`.
