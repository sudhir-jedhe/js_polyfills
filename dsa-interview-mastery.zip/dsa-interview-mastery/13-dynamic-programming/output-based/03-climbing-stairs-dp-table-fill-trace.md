# What Does This Output? — Climbing Stairs DP Table Fill

```js
function climbStairs(n) {
  const dp = new Array(n + 1);
  dp[1] = 1;
  dp[2] = 2;
  for (let i = 3; i <= n; i++) {
    dp[i] = dp[i - 1] + dp[i - 2];
    console.log(`dp[${i}] = dp[${i-1}](${dp[i-1]}) + dp[${i-2}](${dp[i-2]}) = ${dp[i]}`);
  }
  return dp[n];
}
console.log('result:', climbStairs(5));
```

**Answer:**
```
dp[3] = dp[2](2) + dp[1](1) = 3
dp[4] = dp[3](3) + dp[2](2) = 5
dp[5] = dp[4](5) + dp[3](3) = 8
result: 8
```

**Why:** the table is seeded with the two base cases (`dp[1] = 1`: one way to climb 1 stair — a single 1-step; `dp[2] = 2`: two ways to climb 2 stairs — two 1-steps, or one 2-step). From `i = 3` onward, each entry is built purely from the two entries directly before it, reading left to right through the array exactly once. `dp[5] = 8` means there are 8 distinct ways to climb a 5-step staircase taking 1 or 2 steps at a time. Note this table-fill order is only possible in the tabulated (bottom-up) version — the memoized (top-down) version computes the *same* values but in whatever order the recursive calls happen to demand them, typically starting from `dp[5]` and working its way down to the base cases before any addition actually happens.
