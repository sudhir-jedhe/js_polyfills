# What Does This Output? — Memoized Fibonacci's Call Count

```js
let calls = 0;
function fibMemo(n, cache = new Map()) {
  calls++;
  if (n <= 1) return n;
  if (cache.has(n)) return cache.get(n);
  const result = fibMemo(n - 1, cache) + fibMemo(n - 2, cache);
  cache.set(n, result);
  return result;
}
console.log(fibMemo(6), calls);
```

**Answer:** `8 11`

**Why:** trace the call order: `fibMemo(6)` calls `fibMemo(5)`, which calls `fibMemo(4)`, which calls `fibMemo(3)`, which calls `fibMemo(2)`, which calls `fibMemo(1)` (base case, returns `1`) and `fibMemo(0)` (base case, returns `0`) — `fibMemo(2)` computes `1`, caches it. Back in `fibMemo(3)`, its second call `fibMemo(1)` is another base case (base cases aren't cached, since they return before the cache check) — `fibMemo(3)` computes `1 + 1 = 2`, caches it. Back in `fibMemo(4)`, its second call `fibMemo(2)` **hits the cache** — no further recursion, straight to `return cache.get(2)`. `fibMemo(4)` computes `3`, caches it. Back in `fibMemo(5)`, its second call `fibMemo(3)` also **hits the cache**. `fibMemo(5)` computes `5`, caches it. Finally, `fibMemo(6)`'s second call `fibMemo(4)` **hits the cache** too. Counting every call in this trace gives exactly 11 — matching the general formula `2n - 1` for memoized `fib(n)` with `n = 6`. This is the concrete payoff of memoization: the same recurrence, the same final answer (`8`), but 11 calls instead of 25 — and the gap widens dramatically as `n` grows, since naive recursion's call count grows exponentially while memoization's grows linearly.
