# What Does This Output? — LCS Table Fill and Backtrace

```js
function lcsWithString(textA, textB) {
  const m = textA.length, n = textB.length;
  const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));

  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      dp[i][j] = textA[i - 1] === textB[j - 1]
        ? dp[i - 1][j - 1] + 1
        : Math.max(dp[i - 1][j], dp[i][j - 1]);
    }
  }

  // backtrace from dp[m][n] to reconstruct the actual subsequence
  let i = m, j = n, result = '';
  while (i > 0 && j > 0) {
    if (textA[i - 1] === textB[j - 1]) {
      result = textA[i - 1] + result;
      i--; j--;
    } else if (dp[i - 1][j] >= dp[i][j - 1]) {
      i--;
    } else {
      j--;
    }
  }
  return { length: dp[m][n], subsequence: result };
}
console.log(lcsWithString('ABC', 'AC'));
```

**Answer:** `{ length: 2, subsequence: 'AC' }`

**Why:** the filled table is:
```
      ''  A  C
  ''   0  0  0
  A    0  1  1
  B    0  1  1
  C    0  1  2
```
`dp[3][2] = 2` (bottom-right corner) confirms the LCS length. The backtrace walks from that corner toward `[0][0]`: at `(3,2)`, `textA[2]='C'` matches `textB[1]='C'`, so `'C'` is prepended to the result and both pointers move diagonally to `(2,1)`. At `(2,1)`, `textA[1]='B'` doesn't match `textB[0]='A'`; comparing `dp[1][1]=1` (moving up) against `dp[2][0]=0` (moving left), moving up is at least as good, so `i` decrements to `(1,1)`. At `(1,1)`, `textA[0]='A'` matches `textB[0]='A'`, so `'A'` is prepended, landing at `(0,0)` where the loop stops (`i === 0`). Reading the prepended characters in the order they were added gives `"AC"` — the backtrace always follows the *same* choices the forward fill made, just in reverse, which is why it reliably reconstructs one valid longest common subsequence (not necessarily the only one, if ties existed along the way).
