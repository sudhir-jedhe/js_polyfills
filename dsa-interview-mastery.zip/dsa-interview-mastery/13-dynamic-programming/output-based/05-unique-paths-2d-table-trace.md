# What Does This Output? — Unique Paths 2D Table Trace

```js
function uniquePaths(m, n) {
  const dp = Array.from({ length: m }, () => new Array(n).fill(1));
  for (let i = 1; i < m; i++) {
    for (let j = 1; j < n; j++) {
      dp[i][j] = dp[i - 1][j] + dp[i][j - 1];
    }
  }
  console.log(dp.map(row => row.join(' ')).join('\n'));
  return dp[m - 1][n - 1];
}
console.log('result:', uniquePaths(3, 3));
```

**Answer:**
```
1 1 1
1 2 3
1 3 6
result: 6
```

**Why:** the first row and first column are seeded to `1` (there's exactly one straight-line path to any cell along the top or left edge of the grid). Every other cell sums the cell above it and the cell to its left: `dp[1][1] = dp[0][1](1) + dp[1][0](1) = 2`; `dp[1][2] = dp[0][2](1) + dp[1][1](2) = 3`; `dp[2][1] = dp[1][1](2) + dp[2][0](1) = 3`; `dp[2][2] = dp[1][2](3) + dp[2][1](3) = 6`. The bottom-right cell, `dp[2][2] = 6`, is the total number of distinct paths from the top-left to the bottom-right of a 3×3 grid — matching the closed-form combinatorial answer `C(m+n-2, m-1) = C(4, 2) = 6`.
