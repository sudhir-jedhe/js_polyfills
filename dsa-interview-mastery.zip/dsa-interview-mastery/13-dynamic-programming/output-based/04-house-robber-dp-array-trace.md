# What Does This Output? — House Robber DP Array Trace

```js
function rob(nums) {
  const dp = new Array(nums.length);
  dp[0] = nums[0];
  dp[1] = Math.max(nums[0], nums[1]);
  for (let i = 2; i < nums.length; i++) {
    dp[i] = Math.max(dp[i - 1], dp[i - 2] + nums[i]);
  }
  console.log(dp);
  return dp[nums.length - 1];
}
console.log('result:', rob([2, 7, 9, 3, 1]));
```

**Answer:**
```
[ 2, 7, 11, 11, 12 ]
result: 12
```

**Why:** `dp[0] = 2` (only one house available, rob it). `dp[1] = max(2, 7) = 7` (between the first two houses, robbing just house 1, value 7, beats robbing just house 0). `dp[2] = max(dp[1]=7, dp[0]+9=2+9=11) = 11` — robbing house 2 (value 9) *plus* the best result excluding house 1 (`dp[0] = 2`) beats skipping house 2 entirely. `dp[3] = max(dp[2]=11, dp[1]+3=7+3=10) = 11` — here skipping house 3 (staying at 11) beats robbing it (which would only reach 10), so `dp[3]` stays equal to `dp[2]`. `dp[4] = max(dp[3]=11, dp[2]+1=11+1=12) = 12` — robbing house 4 (value 1) added to `dp[2]` (11) narrowly beats skipping it. Final answer `12` corresponds to robbing houses 0, 2, and 4 (values `2 + 9 + 1 = 12`), no two of which are adjacent. Note that `dp[3]` staying equal to `dp[2]` doesn't mean "house 3 was robbed" — it's important to remember `dp[i]` tracks the *best achievable value*, not which specific houses were chosen.
