# DSA Interview Mastery

Same deep structure as the companion repos: every topic is a folder of folders (`theory/`, `snippets/`,
`output-based/`, `scenarios/`, `interview-qa/`, `problems/`, `assets/`) instead of flat files. All code is
JavaScript. `problems/` gets extra weight here (5-7 LeetCode-style challenges per topic, each with a full
solution and Big-O analysis) since DSA interviews are problem-heavy.

## Topics

| # | Topic | Folder |
|---|---|---|
| 01 | Big O & Complexity Analysis | [`01-big-o-complexity-analysis`](./01-big-o-complexity-analysis) |
| 02 | Arrays & Strings | [`02-arrays-strings`](./02-arrays-strings) |
| 03 | Linked Lists | [`03-linked-lists`](./03-linked-lists) |
| 04 | Stacks & Queues | [`04-stacks-queues`](./04-stacks-queues) |
| 05 | Trees & BST | [`05-trees-bst`](./05-trees-bst) |
| 06 | Graphs | [`06-graphs`](./06-graphs) |
| 07 | Heaps & Priority Queues | [`07-heaps-priority-queues`](./07-heaps-priority-queues) |
| 08 | Hashing, HashMaps & Sets | [`08-hashing-hashmaps-sets`](./08-hashing-hashmaps-sets) |
| 09 | Sorting Algorithms | [`09-sorting-algorithms`](./09-sorting-algorithms) |
| 10 | Searching Algorithms | [`10-searching-algorithms`](./10-searching-algorithms) |
| 11 | Recursion & Backtracking | [`11-recursion-backtracking`](./11-recursion-backtracking) |
| 12 | Two Pointers, Sliding Window & Prefix Sum | [`12-two-pointers-sliding-window-prefix-sum`](./12-two-pointers-sliding-window-prefix-sum) |
| 13 | Dynamic Programming | [`13-dynamic-programming`](./13-dynamic-programming) |

See [`STUDY-PLAN.md`](./STUDY-PLAN.md) for a suggested order and [`SOURCE-MAP.md`](./SOURCE-MAP.md) for where
this maps to your existing `js_polyfills/Algorithm` and `js_polyfills/Data Structure` notes — including a
full `dsa-with-javascript-course-master/` mini-course you already had.

## How to use this repo

1. **Learning a topic for the first time** — read `theory/`, then run the code in `snippets/` yourself.
2. **Weekly review** — skim `interview-qa/` across all topics.
3. **The night before an interview** — do `output-based/` and `scenarios/` only, plus a few `problems/`.
4. **Adding new material** — drop a new numbered file in the matching subfolder.
