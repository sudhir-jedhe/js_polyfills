# Scenario: Finding a Timestamp in a Huge Sorted Log File

**Scenario:** You have an in-memory array of 10 million log entries, sorted by timestamp, and need to find the index of the first entry at or after a given timestamp — this lookup happens frequently (e.g. every incoming query in a monitoring dashboard). A colleague's implementation uses `array.findIndex(entry => entry.timestamp >= target)`. Is that a problem, and what would you change?

**Approach:**

`findIndex` is a **linear scan** — O(n) — and on 10 million entries, done frequently, that's a real, measurable cost. Since the array is already sorted by exactly the field being searched, this is the textbook case for binary search: O(log n) instead of O(n). For 10 million entries, that's roughly 24 comparisons instead of up to 10 million.

```js
// O(n) -- scans from the start every time
function findFirstAtOrAfterSlow(entries, targetTimestamp) {
  return entries.findIndex((e) => e.timestamp >= targetTimestamp);
}

// O(log n) -- binary search for the first-occurrence-style boundary
function findFirstAtOrAfterFast(entries, targetTimestamp) {
  let left = 0, right = entries.length; // exclusive right bound -- entries.length means "not found, insert at end"
  while (left < right) {
    const mid = left + Math.floor((right - left) / 2);
    if (entries[mid].timestamp >= targetTimestamp) right = mid; // this could be the answer -- keep searching left
    else left = mid + 1;                                          // definitely too early -- search right
  }
  return left; // first index where timestamp >= target (or entries.length if none qualify)
}
```

The key recognition: "find the boundary where a monotonic condition (`timestamp >= target`) first becomes true in sorted data" is precisely the first-occurrence binary search pattern (see `theory/06-first-last-occurrence-and-ternary-search.md`), not a simple exact-match search — but it's still binary search, still O(log n), and still a drop-in replacement for the O(n) `findIndex` call. This is also a good moment to double-check the sortedness assumption holds in practice (are log entries *guaranteed* strictly ordered by timestamp, or can out-of-order arrivals sneak in?) before swapping to binary search — the whole approach silently breaks (see `output-based/03-binary-search-on-unsorted-array.md`) if that assumption is ever violated.
