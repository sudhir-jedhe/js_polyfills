# Scenario: Finding the First Bad Version

**Scenario:** You maintain a product with versions `1` through `n`, released in order. At some unknown version, a bug was introduced, and every version after that is also bad (once broken, always broken, until a fix ships — assume no fix for this scenario). You have an API `isBadVersion(version)` that's expensive to call (e.g. it runs a test suite). Find the **first** bad version while minimizing calls to `isBadVersion`.

**Approach:**

This is binary search on the answer space (see `theory/04-binary-search-on-answer-space.md`), even though there's no literal array — the "sortedness" comes from the guarantee that `isBadVersion` is monotonic: `false, false, ..., false, true, true, ..., true`. That monotonicity is exactly what binary search needs.

```js
function firstBadVersion(n, isBadVersion) {
  let left = 1, right = n;
  while (left < right) {
    const mid = left + Math.floor((right - left) / 2);
    if (isBadVersion(mid)) {
      right = mid; // mid is bad -- the first bad version is mid or earlier; keep it in range
    } else {
      left = mid + 1; // mid is good -- first bad version must be later
    }
  }
  return left; // left === right: the first bad version
}

// Example: versions 1-4 good, 5-10 bad -- first bad version is 5
const isBadVersion = (v) => v >= 5;
console.log(firstBadVersion(10, isBadVersion)); // 5, found in ~4 calls instead of up to 10
```

The business value here is concrete: if `isBadVersion` is expensive (a real test suite run, a deployment rollback check, a bisection over git commits — this is literally what `git bisect` does), reducing calls from O(n) to O(log n) is the entire point, not just an asymptotic nicety. For n = 1,000,000 versions, that's the difference between roughly 20 expensive calls and up to a million. Recognizing "monotonic true/false condition over a range" as the signal for binary-search-on-answer-space, even with zero literal array in sight, is the transferable skill this scenario tests.
