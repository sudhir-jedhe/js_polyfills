# Scenario: Searching a Circular Buffer of Sorted Config Snapshots

**Scenario:** A system keeps the last N configuration snapshots in a fixed-size circular buffer, sorted by version number, but because it's circular, the buffer's "start" isn't always index 0 — the underlying array looks like a sorted sequence that's been rotated by however many writes have happened since it last wrapped around (e.g. `[cfg_v104, cfg_v105, cfg_v101, cfg_v102, cfg_v103]`). You need to find a specific config version by binary search, without physically re-sorting or copying the buffer (it's large and this runs on a hot path). What's the approach?

**Approach:**

This is a direct real-world instance of the rotated-sorted-array search problem — the circular buffer's physical layout *is* a rotated sorted array, with the "rotation point" being wherever the buffer last wrapped. Rather than physically shifting the array to un-rotate it (an O(n) operation you specifically want to avoid on a hot path), apply the rotated-array binary search directly against the buffer as-is.

```js
function findConfigVersion(buffer, targetVersion) {
  let left = 0, right = buffer.length - 1;
  while (left <= right) {
    const mid = left + Math.floor((right - left) / 2);
    if (buffer[mid].version === targetVersion) return buffer[mid];

    if (buffer[left].version <= buffer[mid].version) { // left half sorted
      if (buffer[left].version <= targetVersion && targetVersion < buffer[mid].version) {
        right = mid - 1;
      } else {
        left = mid + 1;
      }
    } else { // right half sorted
      if (buffer[mid].version < targetVersion && targetVersion <= buffer[right].version) {
        left = mid + 1;
      } else {
        right = mid - 1;
      }
    }
  }
  return null;
}
```

The engineering payoff: O(log n) lookup directly on the buffer's natural physical layout, with **zero** copying or shifting — versus a naive approach that either re-sorts on every access (expensive, and pointless work since the data was already sorted before the rotation) or does a full O(n) linear scan to avoid dealing with the rotation logic. Recognizing that a circular/ring buffer with monotonically increasing entries **is** a rotated sorted array in disguise is the transferable insight — this exact structure shows up in ring buffers, wrap-around log files, and cyclic version histories generally.
