# Scenario: Autocomplete Range Lookup

**Scenario:** You have a sorted array of 200,000 product names and need to power an autocomplete feature: given a typed prefix like `"lap"`, return *all* products whose name starts with that prefix, as fast as possible, without scanning the whole array.

**Approach:**

Because the array is sorted alphabetically, every product matching a given prefix occupies a single **contiguous range** — this is exactly the first/last-occurrence binary search pattern (see `theory/06-first-last-occurrence-and-ternary-search.md`), just applied to a prefix-match condition instead of exact equality. Find the first index where the name is `>= prefix` (using the prefix as a lower bound), and the first index where the name is `>= prefix + '￿'` (a sentinel that sorts after any string starting with the prefix but before any string that doesn't) — everything between those two boundaries matches.

```js
function lowerBound(arr, target) { // first index with arr[index] >= target
  let left = 0, right = arr.length;
  while (left < right) {
    const mid = left + Math.floor((right - left) / 2);
    if (arr[mid] >= target) right = mid;
    else left = mid + 1;
  }
  return left;
}

function autocompleteRange(sortedNames, prefix) {
  const start = lowerBound(sortedNames, prefix);
  const end = lowerBound(sortedNames, prefix + '￿'); // '￿' sorts after any realistic suffix
  return sortedNames.slice(start, end);
}

const names = ['keyboard', 'laptop', 'laptop stand', 'lapel mic', 'monitor'].sort();
console.log(autocompleteRange(names, 'lap')); // ['laptop', 'laptop stand'] -- note: alphabetically 'lapel mic' also matches 'lap' prefix and would be included given correct sort order
```

Two O(log n) binary searches (finding each boundary) plus an O(k) slice (where k is the number of matches actually returned) beats an O(n) linear scan through all 200,000 names on every keystroke by a wide margin — and this composes naturally with the general "find first/last occurrence" pattern rather than needing a bespoke algorithm. The scenario-level lesson: prefix range queries on sorted string data reduce to *two* boundary binary searches, not one exact-match search — recognizing that a range query decomposes into "find the start boundary" + "find the end boundary" is the transferable pattern.
