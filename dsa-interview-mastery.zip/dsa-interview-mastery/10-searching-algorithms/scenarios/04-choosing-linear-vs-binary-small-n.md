# Scenario: Is Binary Search Even Worth It Here?

**Scenario:** You're reviewing a PR that replaces a simple `array.includes(x)` check with a hand-rolled binary search, for an array that's always sorted and never has more than about 8 elements (a small, fixed configuration list checked on every request). Is this a worthwhile optimization?

**Approach:**

Almost certainly not — and pushing back on it is the right call. For n = 8, `log2(8) = 3`, so binary search does at most 3 comparisons versus `includes`'s worst case of 8 — a real difference in comparison *count*, but at this scale the constant-factor overhead of binary search (extra variables, more complex branching, function call overhead if extracted into its own function) very likely costs more in practice than the 5 extra comparisons it saves, especially since `.includes()` is a highly optimized native engine method while a hand-rolled binary search is interpreted/JIT-compiled application code.

```js
// For n = 8, this is very likely simpler AND fast enough:
const isValidConfig = validConfigs.includes(config);

// The binary search version adds real code complexity (and off-by-one risk!)
// for a save that's unlikely to be measurable at this scale:
function binarySearchTiny(arr, target) {
  let left = 0, right = arr.length - 1;
  while (left <= right) {
    const mid = left + Math.floor((right - left) / 2);
    if (arr[mid] === target) return true;
    if (arr[mid] < target) left = mid + 1;
    else right = mid - 1;
  }
  return false;
}
```

The broader lesson, and the actual review comment worth making: Big-O describes **asymptotic** behavior as n grows toward infinity — it says almost nothing about which approach is faster for a *fixed, small* n, where constant factors dominate. Binary search becomes clearly worth it once n is large enough that O(log n) vs O(n) represents a meaningful real difference in comparisons (hundreds or thousands of elements, not single digits), or when the search runs so frequently that even small per-call savings compound significantly. For a fixed 8-element list checked per-request, prefer the simpler, more readable, and just-as-fast-in-practice `includes()` call — and flag the PR for adding unnecessary complexity and off-by-one risk without a measurable benefit.
