Diagrams and visual aids for searching algorithms (binary search trees of comparisons, rotated array boundary tracing) will be added here.
