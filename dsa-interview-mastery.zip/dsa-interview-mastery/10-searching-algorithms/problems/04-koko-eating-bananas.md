# Problem: Koko Eating Bananas

## Problem Statement

Koko has `piles.length` piles of bananas, `piles[i]` bananas in the `i`-th pile. She has `h` hours before the guards return. Each hour she chooses one pile and eats up to `speed` bananas from it — if the pile has fewer than `speed` bananas, she eats them all and doesn't start another pile that hour. Find the **minimum integer** eating speed that lets her eat all the bananas within `h` hours.

## Constraints

- `1 <= piles.length <= 10^4`
- `piles.length <= h <= 10^9`
- `1 <= piles[i] <= 10^9`

## Examples

```
Input: piles = [3,6,7,11], h = 8
Output: 4

Input: piles = [30,11,23,4,20], h = 5
Output: 30

Input: piles = [30,11,23,4,20], h = 6
Output: 23
```

## Approach

This is binary search on the answer space (see `theory/04-binary-search-on-answer-space.md`): the candidate answers are eating speeds from `1` to `max(piles)`, and the feasibility predicate `hoursNeeded(speed) <= h` is monotonic — a faster speed never needs more hours. Binary search that range for the boundary where the predicate first becomes true.

## Solution

```js
function minEatingSpeed(piles, h) {
  function hoursNeeded(speed) {
    let hours = 0;
    for (const pile of piles) hours += Math.ceil(pile / speed);
    return hours;
  }

  let left = 1;
  let right = Math.max(...piles);

  while (left < right) {
    const mid = left + Math.floor((right - left) / 2);
    if (hoursNeeded(mid) <= h) {
      right = mid; // this speed works -- but a slower speed might also work; keep searching left
    } else {
      left = mid + 1; // too slow -- need a faster speed
    }
  }
  return left; // left === right: minimum feasible speed
}

module.exports = { minEatingSpeed };

// --- verification ---
console.log(minEatingSpeed([3,6,7,11], 8));       // 4
console.log(minEatingSpeed([30,11,23,4,20], 5));  // 30
console.log(minEatingSpeed([30,11,23,4,20], 6));  // 23
```

## Complexity

- **Time:** O(n log m) — where n is the number of piles and m is the maximum pile size; O(log m) binary search iterations, each doing an O(n) `hoursNeeded` computation.
- **Space:** O(1) — aside from the input.

A brute-force approach (try every speed from 1 upward, linearly, until one works) would be O(n * m) in the worst case — for large pile sizes, that's meaningfully worse than the O(n log m) binary-search-on-answer-space approach.
