# Problem: Find Peak Element

## Problem Statement

A peak element is one strictly greater than its neighbors. Given an array of integers `nums` where `nums[i] !== nums[i+1]` for all valid `i`, find the index of **any** peak element. Treat elements outside the array's bounds as `-infinity` (so the first or last element can be a peak if it's greater than its one real neighbor). Must run in O(log n).

## Constraints

- `1 <= nums.length <= 1000`
- `-2^31 <= nums[i] <= 2^31 - 1`
- `nums[i] !== nums[i+1]` for all adjacent pairs.
- Must run in O(log n) — a linear scan for a local maximum does not satisfy the intended solution.

## Examples

```
Input: nums = [1,2,3,1]
Output: 2               // nums[2] = 3 is greater than both neighbors

Input: nums = [1,2,1,3,5,6,4]
Output: 1 or 5           // either 2 (index 1) or 6 (index 5) is a valid answer
```

## Approach

Binary search works here because of a key monotonic-like property: if `nums[mid] < nums[mid+1]`, there is guaranteed to be a peak somewhere to the right (the sequence is "climbing," and since it's bounded by `-infinity` at the edges, it must eventually turn downward or hit the boundary, producing a peak). Symmetrically, if `nums[mid] > nums[mid+1]`, a peak is guaranteed to exist at `mid` or somewhere to its left. This lets you discard half the array at each step, exactly like standard binary search, without the array needing to be sorted at all.

## Solution

```js
function findPeakElement(nums) {
  let left = 0, right = nums.length - 1;

  while (left < right) {
    const mid = left + Math.floor((right - left) / 2);
    if (nums[mid] < nums[mid + 1]) {
      left = mid + 1; // climbing upward -- a peak must exist to the right
    } else {
      right = mid; // descending (or at a peak) -- a peak exists at mid or to its left
    }
  }
  return left; // left === right: a valid peak index
}

module.exports = { findPeakElement };

// --- verification ---
console.log(findPeakElement([1,2,3,1]));       // 2
console.log(findPeakElement([1,2,1,3,5,6,4])); // 1 or 5 -- both are valid peaks (index 1 -> value 2, index 5 -> value 6)
console.log(findPeakElement([1]));              // 0
console.log(findPeakElement([1,2]));            // 1
console.log(findPeakElement([2,1]));            // 0
```

## Complexity

- **Time:** O(log n) — one comparison per iteration, halving the search space each time.
- **Space:** O(1) — iterative.

This is a good example of binary search's core requirement being **not** "the array is sorted" but more precisely "there's a way to determine, from a local comparison, which half of the remaining space is guaranteed to contain a valid answer" — sortedness is just the most common way that guarantee arises, not the only one (see also binary search on the answer space, `theory/04`).
