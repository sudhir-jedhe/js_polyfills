# Problem: Binary Search

## Problem Statement

Given a sorted (ascending) array of distinct integers and a target value, return the index of the target if it exists, or `-1` if it doesn't. Implement it in O(log n) time.

## Constraints

- `1 <= nums.length <= 10^4`
- `-10^4 <= nums[i], target <= 10^4`
- All values in `nums` are unique and sorted in ascending order.
- Must run in O(log n).

## Examples

```
Input: nums = [-1, 0, 3, 5, 9, 12], target = 9
Output: 4

Input: nums = [-1, 0, 3, 5, 9, 12], target = 2
Output: -1
```

## Approach

Standard iterative binary search with inclusive bounds: maintain `left`/`right` pointers spanning the current candidate range, compare the midpoint to the target, and discard whichever half cannot contain it.

## Solution

```js
function search(nums, target) {
  let left = 0, right = nums.length - 1; // inclusive bounds: valid range is [left, right]

  while (left <= right) { // <= is required to check the last remaining single-element range
    const mid = left + Math.floor((right - left) / 2);
    if (nums[mid] === target) return mid;
    if (nums[mid] < target) left = mid + 1;
    else right = mid - 1;
  }
  return -1;
}

module.exports = { search };

// --- verification ---
console.log(search([-1, 0, 3, 5, 9, 12], 9));  // 4
console.log(search([-1, 0, 3, 5, 9, 12], 2));  // -1
console.log(search([5], 5));                    // 0 -- single-element array, the classic off-by-one test case
console.log(search([5], -5));                   // -1
console.log(search([], 1));                     // -1 -- empty array
```

## Complexity

- **Time:** O(log n) — the search space halves every iteration.
- **Space:** O(1) — iterative, only a few index variables.

The single-element-array test case (`search([5], 5)`) is the exact case that exposes the `left < right` vs `left <= right` off-by-one bug (see `theory/03-binary-search-off-by-one-bugs.md`) — always verify against it explicitly.
