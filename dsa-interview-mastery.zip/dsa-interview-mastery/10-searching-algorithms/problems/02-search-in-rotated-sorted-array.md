# Problem: Search in Rotated Sorted Array

## Problem Statement

An array of distinct integers, originally sorted in ascending order, has been rotated at an unknown pivot (e.g. `[0,1,2,4,5,6,7]` becomes `[4,5,6,7,0,1,2]`). Given the rotated array and a target, return its index, or `-1` if not present, in O(log n) time.

## Constraints

- `1 <= nums.length <= 5000`
- All values in `nums` are **unique**.
- `nums` is guaranteed to be a rotated version of some ascending-sorted array.
- Must run in O(log n).

## Examples

```
Input: nums = [4,5,6,7,0,1,2], target = 0
Output: 4

Input: nums = [4,5,6,7,0,1,2], target = 3
Output: -1

Input: nums = [1], target = 0
Output: -1
```

## Approach

At every step of the binary search, at least one of the two halves (split at the midpoint) is guaranteed to be properly sorted — determine which one by comparing `arr[left]` to `arr[mid]`, then check whether the target falls within that sorted half's known value range. If it does, search there; otherwise, the target must be in the other (still-rotated) half.

## Solution

```js
function search(nums, target) {
  let left = 0, right = nums.length - 1;

  while (left <= right) {
    const mid = left + Math.floor((right - left) / 2);
    if (nums[mid] === target) return mid;

    if (nums[left] <= nums[mid]) {
      // left half [left..mid] is properly sorted
      if (nums[left] <= target && target < nums[mid]) {
        right = mid - 1;
      } else {
        left = mid + 1;
      }
    } else {
      // right half [mid..right] is properly sorted instead
      if (nums[mid] < target && target <= nums[right]) {
        left = mid + 1;
      } else {
        right = mid - 1;
      }
    }
  }
  return -1;
}

module.exports = { search };

// --- verification ---
console.log(search([4,5,6,7,0,1,2], 0)); // 4
console.log(search([4,5,6,7,0,1,2], 3)); // -1
console.log(search([1], 0));              // -1
console.log(search([1], 1));              // 0
console.log(search([5,1,3], 5));          // 0
```

## Complexity

- **Time:** O(log n) — still one binary-search-style halving per step, just with an extra O(1) check to determine which half is sorted.
- **Space:** O(1) — iterative.

This problem is guaranteed to have distinct values in this variant, which is what keeps the "which half is sorted" determination unambiguous — the version with duplicates (see `theory/05-searching-in-a-rotated-sorted-array.md`) needs an extra defensive step and can degrade to O(n) worst case.
