# Problem: Search a 2D Matrix

## Problem Statement

Given an `m x n` matrix where each row is sorted in ascending order, and the first integer of each row is greater than the last integer of the previous row (meaning the whole matrix, read row by row, is a single ascending sequence), determine if a target value exists in the matrix. Must run in O(log(m * n)).

## Constraints

- `1 <= m, n <= 100`
- `-10^4 <= matrix[i][j], target <= 10^4`
- Each row sorted ascending; matrix is effectively one long sorted sequence when read row-major.

## Examples

```
Input: matrix = [[1,3,5,7],[10,11,16,20],[23,30,34,60]], target = 3
Output: true

Input: matrix = [[1,3,5,7],[10,11,16,20],[23,30,34,60]], target = 13
Output: false
```

## Approach

Since the matrix is effectively one sorted 1D array of `m * n` elements laid out row-major, treat it exactly like a standard binary search over a virtual flat array — convert a flat index `mid` to its `(row, col)` coordinates with integer division and modulo, instead of physically flattening the matrix (which would cost O(m*n) space and time).

## Solution

```js
function searchMatrix(matrix, target) {
  if (matrix.length === 0 || matrix[0].length === 0) return false;

  const rows = matrix.length;
  const cols = matrix[0].length;
  let left = 0, right = rows * cols - 1;

  while (left <= right) {
    const mid = left + Math.floor((right - left) / 2);
    const row = Math.floor(mid / cols);
    const col = mid % cols;
    const value = matrix[row][col];

    if (value === target) return true;
    if (value < target) left = mid + 1;
    else right = mid - 1;
  }
  return false;
}

module.exports = { searchMatrix };

// --- verification ---
const matrix = [[1,3,5,7],[10,11,16,20],[23,30,34,60]];
console.log(searchMatrix(matrix, 3));  // true
console.log(searchMatrix(matrix, 13)); // false
console.log(searchMatrix(matrix, 1));  // true -- first element
console.log(searchMatrix(matrix, 60)); // true -- last element
console.log(searchMatrix([[]], 1));    // false -- empty row edge case
```

## Complexity

- **Time:** O(log(m * n)) — a single binary search over the conceptual flattened length, matching the problem's requirement exactly.
- **Space:** O(1) — no actual flattening occurs; `row`/`col` are computed arithmetically from the flat index on the fly.

The core technique — mapping a flat index to 2D coordinates via `Math.floor(mid / cols)` and `mid % cols` — is a reusable trick any time a genuinely 1D binary search needs to operate over data that's stored in a 2D (or higher-dimensional) but conceptually linear structure.
