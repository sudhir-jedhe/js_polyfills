# Problem: Find First and Last Position of Element in Sorted Array

## Problem Statement

Given a sorted array of integers (possibly with duplicates) and a target value, return `[firstIndex, lastIndex]` — the first and last position of the target. If the target isn't present, return `[-1, -1]`. Must run in O(log n).

## Constraints

- `0 <= nums.length <= 10^5`
- Array is sorted in non-decreasing order, may contain duplicates.
- Must run in O(log n) — a linear scan does not satisfy the intended solution.

## Examples

```
Input: nums = [5,7,7,8,8,10], target = 8
Output: [3, 4]

Input: nums = [5,7,7,8,8,10], target = 6
Output: [-1, -1]

Input: nums = [], target = 0
Output: [-1, -1]
```

## Approach

Run two independent modified binary searches: one biased to find the leftmost (first) occurrence, one biased to find the rightmost (last) occurrence. Each, on finding a match, doesn't return immediately — it records the match and keeps narrowing in the direction that could reveal an even earlier (or later) match.

## Solution

```js
function searchRange(nums, target) {
  return [findBoundary(nums, target, true), findBoundary(nums, target, false)];
}

function findBoundary(nums, target, findFirst) {
  let left = 0, right = nums.length - 1, result = -1;

  while (left <= right) {
    const mid = left + Math.floor((right - left) / 2);
    if (nums[mid] === target) {
      result = mid;
      if (findFirst) right = mid - 1; // keep searching left for an earlier match
      else left = mid + 1;             // keep searching right for a later match
    } else if (nums[mid] < target) {
      left = mid + 1;
    } else {
      right = mid - 1;
    }
  }
  return result;
}

module.exports = { searchRange };

// --- verification ---
console.log(searchRange([5,7,7,8,8,10], 8)); // [3, 4]
console.log(searchRange([5,7,7,8,8,10], 6)); // [-1, -1]
console.log(searchRange([], 0));              // [-1, -1]
console.log(searchRange([1], 1));             // [0, 0]
```

## Complexity

- **Time:** O(log n) — two independent binary searches, each O(log n).
- **Space:** O(1) — iterative, no auxiliary structures.

The critical detail: `right = mid - 1` (not returning immediately) after finding a match while searching for "first" — treating a found match as "not good enough yet, keep looking left" is what turns a plain O(log n) exact-match search into a boundary search while preserving the O(log n) guarantee.
