# Searching Algorithms

Searching sounds simple — "find the element" — but binary search is one of the most consistently mis-implemented algorithms in real interviews precisely because it *looks* trivial while hiding several sharp off-by-one edges (loop condition, midpoint rounding, boundary updates) that silently produce infinite loops or wrong answers rather than obvious crashes. This topic covers linear and binary search (iterative and recursive) with a precise catalog of the classic off-by-one bugs, the more advanced "binary search on the answer space" pattern, searching a rotated sorted array, finding first/last occurrence with duplicates, and a brief look at ternary search.

## Folder structure

- **`theory/`** — linear search, binary search (iterative and recursive), the off-by-one bugs precisely cataloged, binary search on the answer space, searching a rotated sorted array, and first/last occurrence plus ternary search.
- **`snippets/`** — 7 focused, runnable examples: linear search, both binary search forms, first/last occurrence, rotated-array search, and ternary search.
- **`output-based/`** — 6 "predict the output / does it terminate?" questions covering infinite loops from bad rounding, mismatched bound conventions, unsorted-data failures, duplicate-value ambiguity, rotated-array tracing, and answer-space monotonicity.
- **`scenarios/`** — 5 real-world situations: searching a huge sorted log file, finding the first bad version (binary search on answer space), searching a rotated circular buffer, judging whether binary search is even worth it at small n, and autocomplete range lookups.
- **`interview-qa/`** — 15 Q&A pairs across 3 themed files: linear vs binary search, binary search boundary conditions, and advanced search patterns.
- **`problems/`** — 6 hands-on coding challenges: basic binary search, search in a rotated sorted array, find first and last position, Koko eating bananas (binary search on answer space), find peak element, and search a 2D matrix.
- **`assets/`** — placeholder for diagrams (see `assets/README.md`).

## What's covered

- Linear search and exactly when it's still the right choice over binary search
- Binary search, iterative and recursive, with the inclusive-bounds convention explained precisely
- The three classic off-by-one bugs: `left < right` losing the last element, mismatched rounding direction causing infinite loops, and mixing inclusive/exclusive bound conventions
- Binary search on the answer space — using a monotonic feasibility predicate to binary search over candidate answers, not array indices
- Searching a rotated sorted array by determining which half is properly sorted at each step, and the duplicate-value edge case that degrades it to O(n)
- Finding the first and last occurrence of a value among duplicates, and where ternary search actually applies (unimodal function optimization, not array search)
