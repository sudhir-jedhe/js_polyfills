# Interview Q&A — Binary Search Boundary Conditions

**Q: What's the difference between the inclusive and exclusive binary search conventions, and why does mixing them cause bugs?**
Inclusive: `right = arr.length - 1`, loop while `left <= right`, narrow with `right = mid - 1`. Exclusive: `right = arr.length`, loop while `left < right`, narrow with `right = mid`. Both are internally consistent and correct on their own. Mixing pieces — e.g. an exclusive initial `right` with an inclusive-style `<=` loop condition — can read one past the array's valid range (`arr[arr.length]`, which is `undefined` in JS) and, depending on the exact logic, either return a wrong answer or infinite-loop, since the bound may stop shrinking.

**Q: Why does `while (left < right)` instead of `while (left <= right)` sometimes cause a search to miss the last valid element?**
With inclusive bounds, a search space containing exactly one remaining candidate has `left === right` — that element still needs to be checked. `left < right` exits the loop before that check happens, incorrectly treating a single-element search space as empty.

**Q: What causes a binary search to infinite-loop, and what's the general fix?**
It happens when the narrowing logic (`left = mid` or `right = mid`, without a `+1`/`-1`) is paired with the wrong rounding direction for `mid`, such that in a 2-element window `mid` recomputes to the exact same value as before, and the boundary variable never actually advances. The general fix: whenever narrowing uses `left = mid` (no `+1`), round `mid` up (`Math.ceil`); whenever narrowing uses `right = mid` (no `-1`), round `mid` down (`Math.floor`) — mismatching these is the root cause almost every time.

**Q: What's the standard debugging habit for verifying a binary search implementation is correct?**
Manually trace the smallest non-trivial cases: an array of length 1, a target equal to the first element, a target equal to the last element, and a target that doesn't exist in the array at all (confirm it terminates and correctly returns "not found" rather than looping forever or reading out of bounds).

**Q: Why is `left + Math.floor((right - left) / 2)` preferred over `Math.floor((left + right) / 2)` for computing the midpoint?**
The first form avoids `left + right` overflowing in languages with fixed-width integer types once both bounds are large (a documented historical bug in real binary search implementations, including early Java). JavaScript numbers are IEEE-754 doubles and don't overflow the same way at typical array sizes, so this specific issue is mostly a non-concern in JS — but writing it this way is still good general practice and a detail some interviewers explicitly ask about.
