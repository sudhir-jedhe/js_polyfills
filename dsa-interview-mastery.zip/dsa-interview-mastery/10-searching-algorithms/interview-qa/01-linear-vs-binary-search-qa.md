# Interview Q&A — Linear vs Binary Search

**Q: What's the fundamental precondition binary search requires that linear search doesn't?**
Binary search requires the data to be sorted (or to have a known monotonic structure over the search range) so that comparing against the midpoint reliably tells you which half to discard. Linear search makes no assumption about ordering at all — it works correctly on any collection, sorted or not.

**Q: Why is binary search O(log n) while linear search is O(n)?**
Binary search discards half the remaining search space with every comparison, so the number of comparisons needed to narrow down to one element is the number of times n can be halved before reaching 1 — that's log₂(n). Linear search, with no way to skip elements, may need to examine every one of the n elements in the worst case.

**Q: Give a concrete case where linear search is still the right choice even though binary search is asymptotically faster.**
Unsorted data where sorting first (O(n log n)) just to enable one or a few binary searches costs more overall than a single O(n) linear scan; very small collections where constant-factor overhead dominates; data structures without O(1) random access (like a linked list), where binary search's "jump to the midpoint" assumption doesn't hold cheaply; or searching by a field that isn't the sort key.

**Q: What's the best-case time complexity for each, and when does it occur?**
Linear search: O(1), if the target happens to be the very first element checked. Binary search: O(1), if the target happens to be exactly the first midpoint checked (the middle of the whole array).

**Q: Does binary search need extra space beyond the array itself?**
The iterative version needs only O(1) extra space (a few index variables). The recursive version needs O(log n) extra space for the call stack, since the recursion depth is bounded by the number of halvings, log n.
