# Interview Q&A — Advanced Search Patterns

**Q: What does "binary search on the answer space" mean, and when do you recognize it applies?**
It means applying binary search over a range of *candidate answers* rather than array indices, using a monotonic feasibility predicate (`canAchieve(candidate)`) in place of an array-value comparison. It applies whenever fixing a candidate answer and checking its feasibility produces a result that changes monotonically as the candidate increases (or decreases) — common phrasing tells include "minimize the maximum," "maximize the minimum," or "find the smallest/largest value such that condition Y holds."

**Q: How do you search for an exact value in a rotated sorted array in O(log n)?**
At each step, compare `arr[left]` to `arr[mid]` to determine which half of the current range is properly sorted (a rotated array still guarantees at least one half of any split is fully sorted). Then check whether the target falls within that sorted half's known value range — if so, recurse/iterate into it; if not, the target must be in the other, still-rotated half.

**Q: What breaks the rotated-array search approach, and how is it typically handled?**
Duplicate values can make `arr[left] === arr[mid] === arr[right]`, which gives no information about which half is sorted. The standard fix is to defensively shrink the search space by one element (`left++`) when this ambiguity occurs and re-evaluate — this keeps the algorithm correct but degrades the worst-case time to O(n) when duplicates are adversarially placed.

**Q: How do you find the first or last occurrence of a value in a sorted array with duplicates, and why can't plain binary search do this directly?**
Plain binary search returns as soon as it finds any matching element — with duplicates, that could be any one of several equal elements, with no guarantee of which. Finding a specific boundary requires continuing the search after a match instead of returning immediately: on a match, record it as the current best answer and keep narrowing toward the target boundary (searching left for "first," right for "last") as if that match weren't sufficient yet.

**Q: What is ternary search actually used for, and why isn't it typically used to replace binary search on sorted arrays?**
Ternary search finds the extremum (max or min) of a unimodal function — one that strictly increases then strictly decreases (or vice versa) — by splitting the range into three parts using two midpoints per iteration. For a plain sorted-array exact-match search, it does more comparisons per iteration than binary search for the same logarithmic reduction in search space, making it strictly less efficient there — its real use case is continuous/discrete function optimization, not array search.
