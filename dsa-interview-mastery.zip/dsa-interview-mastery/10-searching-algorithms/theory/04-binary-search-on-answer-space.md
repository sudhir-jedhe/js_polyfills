# Binary Search on the Answer Space

A more advanced pattern: binary search doesn't require an actual sorted **array** to search — it only requires a **monotonic predicate** over a range of candidate answers (a function that's `false` for a while, then flips to `true` and stays `true`, or vice versa — the answer space itself is "sorted" by that predicate even though no literal array of sorted values exists). This pattern shows up constantly in "minimize the maximum" / "maximize the minimum" style optimization problems.

## The general shape

1. Identify the range of *possible answers* (not array indices) — e.g. "minimum possible speed" from 1 to `max(pile sizes)`.
2. Write a predicate `canAchieve(candidateAnswer)` that's monotonic — true for all values on one side of the true answer, false on the other.
3. Binary search over the answer range itself, using the predicate exactly like an array comparison, to find the boundary where the predicate flips.

## Worked example: Koko Eating Bananas (minimize eating speed)

Koko has piles of bananas and `h` hours to eat them all; each hour she picks one pile and eats up to `speed` bananas from it (a pile with fewer than `speed` bananas is finished that hour, and she moves on). Find the **minimum** integer eating speed that lets her finish within `h` hours.

```js
function minEatingSpeed(piles, h) {
  function hoursNeeded(speed) {
    return piles.reduce((total, pile) => total + Math.ceil(pile / speed), 0);
  }

  let left = 1;                       // slowest possible speed
  let right = Math.max(...piles);     // fastest speed that could ever matter (finishes every pile in 1 hour)

  while (left < right) {
    const mid = left + Math.floor((right - left) / 2);
    if (hoursNeeded(mid) <= h) {
      right = mid; // this speed works -- but maybe a slower speed also works; keep searching left
    } else {
      left = mid + 1; // too slow, need to search faster speeds
    }
  }
  return left; // left === right: the minimum speed where hoursNeeded(speed) <= h
}

console.log(minEatingSpeed([3, 6, 7, 11], 8)); // 4
```

## Why this is a valid binary search

The predicate `hoursNeeded(speed) <= h` is **monotonic** in `speed`: increasing speed can only decrease (or keep equal) the hours needed — it's never the case that a faster speed requires *more* hours. That monotonicity is the exact property binary search relies on (the same property "the array is sorted" provides in the classic case) — it guarantees that once the predicate flips from false to true as speed increases, it never flips back, so discarding half the candidate range at each step is always safe.

## Recognizing the pattern in a new problem

Ask: "if I fix a candidate answer and check whether it's *feasible*, does feasibility change monotonically as the candidate answer increases (or decreases)?" If yes — even though there's no literal sorted array in sight — binary search on the answer space applies. Common tells: "minimize the maximum X," "maximize the minimum X," "find the smallest/largest value such that condition Y holds." Examples beyond Koko: minimizing the largest shipment weight to ship all packages within D days, finding the smallest divisor so a division sum stays under a threshold, finding the maximum distance between placed items ("aggressive cows" style problems).

## Complexity

Binary search on the answer space costs O(log(range) × cost of the predicate check) — for Koko, that's O(log(max pile) × n) since `hoursNeeded` itself is O(n). This is frequently far better than checking every possible speed linearly (O(max pile × n)).
