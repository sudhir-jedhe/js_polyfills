# Binary Search — The Off-By-One Bugs, Precisely

Binary search is famously easy to get *approximately* right and subtly wrong — Jon Bentley's classic observation is that most professional programmers' first attempt at binary search contains a bug. Here are the concrete failure modes, each with the broken code and the fix.

## Bug 1: `left < right` instead of `left <= right` (loses the last element)

```js
// BROKEN
function binarySearchBuggy(arr, target) {
  let left = 0, right = arr.length - 1;
  while (left < right) { // BUG: should be <=
    const mid = left + Math.floor((right - left) / 2);
    if (arr[mid] === target) return mid;
    if (arr[mid] < target) left = mid + 1;
    else right = mid - 1;
  }
  return -1;
}
console.log(binarySearchBuggy([5], 5)); // -1  <-- WRONG, should be 0!
```

With inclusive bounds `[left, right]`, a single remaining candidate has `left === right`. The loop condition `left < right` exits *before* that final candidate is ever checked, silently failing to find a target that's the very last element being narrowed down to. **Fix:** use `left <= right`.

## Bug 2: Infinite loop from a non-shrinking search space (wrong mid rounding + wrong bound update)

```js
// BROKEN -- can infinite loop
function findFirstBuggy(arr, target) {
  let left = 0, right = arr.length - 1;
  while (left < right) {
    const mid = Math.ceil((left + right) / 2); // rounds UP
    if (arr[mid] > target) right = mid - 1;
    else left = mid; // BUG: when mid rounds down and left = mid, this can stall
  }
  return arr[left] === target ? left : -1;
}
```

When searching for the **first occurrence** with a half-open-style narrowing (`left = mid` rather than `left = mid + 1`), if `mid` rounds **down** (`Math.floor`) and the condition sets `left = mid`, then for a 2-element space `[left, left+1]`, `mid` computes to `left` again — `left` never advances, looping forever. **Fix:** when using `left = mid` (not `mid + 1`), you must round `mid` **up** (`Math.ceil`) so it can never equal `left` again in a 2-element window; symmetrically, when using `right = mid` (not `mid - 1`), round `mid` **down**. Mixing the wrong rounding direction with the wrong bound-update style is the single most common source of binary-search infinite loops.

## Bug 3: `right = arr.length` (exclusive) mixed with inclusive-style logic

```js
// BROKEN -- mixes exclusive right bound with inclusive-style comparisons
function binarySearchMixed(arr, target) {
  let left = 0, right = arr.length; // exclusive bound: valid space is [left, right)
  while (left <= right) { // BUG: should be < to match the exclusive bound
    const mid = left + Math.floor((right - left) / 2);
    if (arr[mid] === target) return mid; // can read arr[arr.length] -- undefined, comparison always fails oddly
    if (arr[mid] < target) left = mid + 1;
    else right = mid;
  }
  return -1;
}
```

There are two internally-consistent conventions for the search space: **inclusive** `[left, right]` (use `right = arr.length - 1`, loop `while (left <= right)`, narrow with `right = mid - 1`) or **half-open/exclusive** `[left, right)` (use `right = arr.length`, loop `while (left < right)`, narrow with `right = mid`). The bug above mixes them — an exclusive `right` initial value with an inclusive-style `<=` loop condition — which can read past the array's end (`arr[arr.length]` is `undefined`) and produce wrong results. **Fix:** pick one convention and apply it consistently throughout; don't mix `arr.length` (exclusive-style) with `<=` (inclusive-style) or `arr.length - 1` (inclusive-style) with `<` alone without also adjusting the narrowing logic.

## Quick-reference: the two valid conventions

| Convention | Initial `right` | Loop condition | Narrow when too high | Narrow when too low |
|---|---|---|---|---|
| Inclusive `[left, right]` | `arr.length - 1` | `left <= right` | `right = mid - 1` | `left = mid + 1` |
| Exclusive `[left, right)` | `arr.length` | `left < right` | `right = mid` | `left = mid + 1` |

Both are correct if applied consistently. The inclusive convention is the more common textbook default and is what's used throughout the rest of this topic's snippets and problems, but recognizing *both* patterns — and never mixing their pieces — is the actual skill being tested when an interviewer probes binary search boundary conditions.

## The debugging habit that catches all three

Trace through the smallest non-trivial cases by hand before considering the implementation done: an array of length 1 (does it find the only element?), a target equal to the first element, a target equal to the last element, and a target that doesn't exist at all (does the loop terminate, and does it return -1 rather than looping forever or throwing on an out-of-bounds read). Every one of the three bugs above is caught by at least one of these four cases.
