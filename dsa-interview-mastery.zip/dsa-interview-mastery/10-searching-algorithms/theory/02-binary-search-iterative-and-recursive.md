# Binary Search — Iterative and Recursive

Binary search finds a target in a **sorted** array in O(log n) time by repeatedly halving the search space: compare the target to the middle element, and discard the half that can't contain it.

## Iterative implementation

```js
function binarySearch(arr, target) {
  let left = 0;
  let right = arr.length - 1; // inclusive bound -- valid search space is [left, right]

  while (left <= right) { // <= is essential: a search space of exactly one element (left === right) is still valid
    const mid = left + Math.floor((right - left) / 2); // avoids overflow vs (left + right) / 2 in languages with fixed-width ints
    if (arr[mid] === target) return mid;
    if (arr[mid] < target) left = mid + 1;  // target is in the right half
    else right = mid - 1;                    // target is in the left half
  }
  return -1; // search space exhausted, not found
}

console.log(binarySearch([1, 3, 5, 7, 9, 11], 7)); // 3
console.log(binarySearch([1, 3, 5, 7, 9, 11], 4)); // -1
```

## Recursive implementation

```js
function binarySearchRecursive(arr, target, left = 0, right = arr.length - 1) {
  if (left > right) return -1; // base case: search space empty, not found

  const mid = left + Math.floor((right - left) / 2);
  if (arr[mid] === target) return mid;
  if (arr[mid] < target) return binarySearchRecursive(arr, target, mid + 1, right);
  return binarySearchRecursive(arr, target, left, mid - 1);
}

console.log(binarySearchRecursive([1, 3, 5, 7, 9, 11], 9)); // 4
```

## Why `left <= right`, not `left < right`

This is the first of several off-by-one details covered fully in `03-binary-search-off-by-one-bugs.md`, but it's worth stating plainly here: with inclusive bounds `[left, right]`, a search space containing exactly **one** candidate element has `left === right` — that element must still be checked. Using `left < right` as the loop condition would skip checking it and incorrectly return "not found" one comparison too early.

## Why `mid = left + Math.floor((right - left) / 2)` instead of `Math.floor((left + right) / 2)`

Both are mathematically equivalent for the values involved, but `left + (right - left) / 2` avoids `left + right` overflowing in languages with fixed-width integers (a famous historical bug in Java's `Arrays.binarySearch`, and in C/C++ implementations) once `left` and `right` are both large. JavaScript numbers don't overflow the same way (they're IEEE-754 doubles, safe up to 2^53), so this specific overflow isn't a practical JS concern — but writing it this way is still good habit-forming practice that translates directly to other languages, and interviewers sometimes ask about it explicitly.

## Iterative vs recursive — the trade-off

| Aspect | Iterative | Recursive |
|---|---|---|
| Space | O(1) | O(log n) — call stack depth |
| Readability | Slightly more verbose (manual loop/bounds) | Often reads closer to the "halve the space" definition |
| Risk of stack overflow | None | Possible on very large n in languages/engines without tail-call optimization (JS engines generally don't reliably optimize tail calls) |

For production code, iterative is generally preferred in JS specifically because of the stack-overflow risk on deep recursion without guaranteed tail-call optimization — but both are expected to be correct and fast to write in an interview.

## Complexity

| Case | Time | Space (iterative / recursive) |
|---|---|---|
| Best | O(1) | O(1) / O(1) |
| Average | O(log n) | O(1) / O(log n) |
| Worst | O(log n) | O(1) / O(log n) |
