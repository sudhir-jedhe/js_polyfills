# Searching in a Rotated Sorted Array

A sorted array that's been "rotated" at an unknown pivot (e.g. `[4, 5, 6, 7, 0, 1, 2]` — originally `[0,1,2,4,5,6,7]` rotated left by 4) is no longer globally sorted, so naive binary search doesn't directly apply. But it retains a crucial property: **at least one half of any sub-range, split at the midpoint, is always properly sorted.** That's enough to keep binary search's O(log n) guarantee intact.

## The core insight

At every step, compare `arr[mid]` against `arr[left]` (or `arr[right]`) to determine *which half is the properly-sorted one* — then check whether the target falls inside that sorted half's range. If it does, recurse/iterate into that half; if not, the target must be in the other (still-rotated) half.

```js
function searchRotated(arr, target) {
  let left = 0, right = arr.length - 1;

  while (left <= right) {
    const mid = left + Math.floor((right - left) / 2);
    if (arr[mid] === target) return mid;

    if (arr[left] <= arr[mid]) {
      // left half [left..mid] is properly sorted
      if (arr[left] <= target && target < arr[mid]) {
        right = mid - 1; // target is within the sorted left half's range
      } else {
        left = mid + 1;  // target must be in the right (rotated) half
      }
    } else {
      // right half [mid..right] is properly sorted instead
      if (arr[mid] < target && target <= arr[right]) {
        left = mid + 1;  // target is within the sorted right half's range
      } else {
        right = mid - 1; // target must be in the left (rotated) half
      }
    }
  }
  return -1;
}

console.log(searchRotated([4, 5, 6, 7, 0, 1, 2], 0)); // 4
console.log(searchRotated([4, 5, 6, 7, 0, 1, 2], 3)); // -1
console.log(searchRotated([1], 0));                    // -1
```

## Why `arr[left] <= arr[mid]` determines which half is sorted

If `arr[left] <= arr[mid]`, there's no rotation point between `left` and `mid` — that half must be in ascending order (a rotation point is the one place where a larger value is immediately followed by a smaller one; if that drop happened within `[left, mid]`, then `arr[left]` would have to be greater than `arr[mid]`, contradicting the assumption). Otherwise, the rotation point must live in `[left, mid]`, which means the *other* half, `[mid, right]`, is guaranteed sorted instead.

## Handling duplicates (the harder variant)

If the array can contain duplicate values, `arr[left] === arr[mid] === arr[right]` can make it impossible to determine which half is sorted using this comparison alone (e.g. `[1,1,1,0,1,1,1]` — comparing endpoints gives no information about where the rotation point is). The standard fix: when `arr[left] === arr[mid]`, just shrink the search space defensively (`left++`) and re-evaluate — this degrades worst-case time to **O(n)** in the all-duplicates case, since you might have to shrink one element at a time, but keeps the algorithm correct.

## Complexity

| Case | Time |
|---|---|
| No duplicates | O(log n) — always |
| With duplicates, worst case (many repeated boundary values) | O(n) |

Space: O(1) iterative.

This problem is a good test of whether someone actually understands binary search's underlying invariant (some property that lets you safely discard half the space) rather than having memorized the "compare to middle" mechanics for a plain sorted array — the invariant here is "which half is properly sorted," not "is the target bigger or smaller than the middle."
