# Linear Search

Linear search checks every element in sequence until it finds a match (or exhausts the collection). It's the baseline every other search algorithm is compared against — O(n) time, no preconditions on the data.

```js
function linearSearch(arr, target) {
  for (let i = 0; i < arr.length; i++) {
    if (arr[i] === target) return i; // found -- return its index
  }
  return -1; // not found
}

console.log(linearSearch([5, 3, 8, 1, 9], 8)); // 2
console.log(linearSearch([5, 3, 8, 1, 9], 4)); // -1
```

## Why it's still relevant

- **No ordering requirement** — works on any collection, sorted or not. Binary search *requires* sorted data; if the data isn't sorted and sorting it just to search once isn't worth the O(n log n) cost, linear search is the pragmatic choice.
- **Small n** — for a handful of elements, the constant-factor simplicity of linear search often beats the overhead of more "sophisticated" approaches.
- **Unindexable/streaming data** — searching a linked list or a stream where random access (`arr[mid]`) isn't O(1) rules out binary search's core assumption; linear search doesn't need random access at all, just sequential iteration.
- **Search key isn't the sort key** — if data is sorted by one field but you're searching by another, binary search on the wrong key doesn't work; you're back to O(n) linear search (or need a separate index).

## Complexity

| Case | Time |
|---|---|
| Best (target is first element) | O(1) |
| Average | O(n) |
| Worst (target is last, or absent) | O(n) |

Space: O(1) — no auxiliary structure needed.

## The precondition binary search needs that linear search doesn't

This is the single most important thing to internalize before moving to binary search: **linear search makes no assumptions about the data's order.** Binary search's entire O(log n) advantage comes from being able to discard half the remaining search space at each step — which is only valid if the data is sorted (or otherwise has a known monotonic structure). Searching unsorted data with binary search produces incorrect results, silently, because the "discard half" logic assumes an ordering property that isn't actually there.
