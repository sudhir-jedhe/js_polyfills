# Finding First/Last Occurrence, and Ternary Search (Brief)

## Finding the first and last occurrence of a target in a sorted array with duplicates

Standard binary search stops as soon as it finds *any* match — with duplicates present, that could be any one of several equal elements, not necessarily the first or last. Finding a specific boundary (first or last occurrence) requires a modified binary search that **keeps searching** even after finding a match, narrowing toward the boundary instead of returning immediately.

```js
function findFirst(arr, target) {
  let left = 0, right = arr.length - 1, result = -1;
  while (left <= right) {
    const mid = left + Math.floor((right - left) / 2);
    if (arr[mid] === target) {
      result = mid;
      right = mid - 1; // keep searching LEFT for an even earlier occurrence
    } else if (arr[mid] < target) {
      left = mid + 1;
    } else {
      right = mid - 1;
    }
  }
  return result;
}

function findLast(arr, target) {
  let left = 0, right = arr.length - 1, result = -1;
  while (left <= right) {
    const mid = left + Math.floor((right - left) / 2);
    if (arr[mid] === target) {
      result = mid;
      left = mid + 1; // keep searching RIGHT for an even later occurrence
    } else if (arr[mid] < target) {
      left = mid + 1;
    } else {
      right = mid - 1;
    }
  }
  return result;
}

const arr = [5, 7, 7, 7, 7, 8, 10];
console.log(findFirst(arr, 7)); // 1
console.log(findLast(arr, 7));  // 4
```

**The core trick:** on a match, don't return immediately — record it as the current best answer, then keep narrowing in the direction that could reveal an even earlier (or later) match, exactly as if the found element were *not* actually a match at all for the purposes of continuing to search. This still runs in O(log n): you're not scanning outward from the match linearly, you're binary-searching for the boundary itself.

## Ternary search (brief)

Ternary search is a variant that splits the search space into **three** parts instead of two, using two midpoints (`mid1`, `mid2`) instead of one. It's used specifically for finding the extremum (min or max) of a **unimodal function** (one that strictly increases then strictly decreases, or vice versa) over a continuous or discrete range — it is *not* a general-purpose replacement for binary search on sorted arrays.

```js
function ternarySearchMax(f, left, right, epsilon = 1e-9) {
  while (right - left > epsilon) {
    const mid1 = left + (right - left) / 3;
    const mid2 = right - (right - left) / 3;
    if (f(mid1) < f(mid2)) left = mid1;  // max can't be in [left, mid1)
    else right = mid2;                    // max can't be in (mid2, right]
  }
  return (left + right) / 2;
}
```

**Why it's rarely the right tool for interview array-search problems:** for a plain sorted array, ternary search does **more** comparisons per iteration (2 instead of 1) for the same logarithmic base reduction, making it strictly slower in practice than binary search for that use case — it only earns its keep on unimodal *function optimization* problems (find the peak of a hill-shaped function), not on searching sorted data for a value. It's included here mainly so it's recognizable by name and correctly distinguished from binary search's use case, not as a technique to reach for by default.

## Quick comparison

| Technique | Splits per step | Use case |
|---|---|---|
| Binary search | 2 | Sorted array / monotonic predicate — find exact value or boundary |
| Binary search (first/last occurrence variant) | 2 | Sorted array with duplicates — find a specific boundary among equal elements |
| Ternary search | 3 | Unimodal function — find a maximum or minimum, not an exact match |
