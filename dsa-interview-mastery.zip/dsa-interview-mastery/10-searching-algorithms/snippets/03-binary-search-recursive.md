# Binary Search — Recursive

```js
function binarySearchRecursive(arr, target, left = 0, right = arr.length - 1) {
  if (left > right) return -1;
  const mid = left + Math.floor((right - left) / 2);
  if (arr[mid] === target) return mid;
  return arr[mid] < target
    ? binarySearchRecursive(arr, target, mid + 1, right)
    : binarySearchRecursive(arr, target, left, mid - 1);
}

console.log(binarySearchRecursive([2, 4, 6, 8, 10, 12], 10)); // 4
console.log(binarySearchRecursive([2, 4, 6, 8, 10, 12], 5));  // -1
```
