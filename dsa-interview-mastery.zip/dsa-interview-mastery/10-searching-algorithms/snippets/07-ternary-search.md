# Ternary Search — Finding the Peak of a Unimodal Function

```js
function ternarySearchMax(f, left, right, iterations = 100) {
  for (let i = 0; i < iterations; i++) {
    const mid1 = left + (right - left) / 3;
    const mid2 = right - (right - left) / 3;
    if (f(mid1) < f(mid2)) left = mid1;
    else right = mid2;
  }
  return (left + right) / 2;
}

// f(x) = -(x-3)^2 + 9  -- a downward parabola peaking at x = 3
const peak = ternarySearchMax((x) => -(x - 3) ** 2 + 9, -10, 10);
console.log(peak.toFixed(2)); // ~3.00
```
