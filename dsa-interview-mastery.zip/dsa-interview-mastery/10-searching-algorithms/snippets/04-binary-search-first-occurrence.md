# Binary Search — First Occurrence (with Duplicates)

```js
function findFirst(arr, target) {
  let left = 0, right = arr.length - 1, result = -1;
  while (left <= right) {
    const mid = left + Math.floor((right - left) / 2);
    if (arr[mid] === target) {
      result = mid;
      right = mid - 1; // keep looking left for an earlier match
    } else if (arr[mid] < target) {
      left = mid + 1;
    } else {
      right = mid - 1;
    }
  }
  return result;
}

console.log(findFirst([1, 2, 2, 2, 3, 4], 2)); // 1
console.log(findFirst([1, 2, 2, 2, 3, 4], 5)); // -1
```
