# Binary Search — Rotated Sorted Array (No Duplicates)

```js
function searchRotated(arr, target) {
  let left = 0, right = arr.length - 1;
  while (left <= right) {
    const mid = left + Math.floor((right - left) / 2);
    if (arr[mid] === target) return mid;

    if (arr[left] <= arr[mid]) { // left half is properly sorted
      if (arr[left] <= target && target < arr[mid]) right = mid - 1;
      else left = mid + 1;
    } else { // right half is properly sorted instead
      if (arr[mid] < target && target <= arr[right]) left = mid + 1;
      else right = mid - 1;
    }
  }
  return -1;
}

console.log(searchRotated([4, 5, 6, 7, 0, 1, 2], 6)); // 2
console.log(searchRotated([6, 7, 0, 1, 2, 4, 5], 0)); // 2
```
