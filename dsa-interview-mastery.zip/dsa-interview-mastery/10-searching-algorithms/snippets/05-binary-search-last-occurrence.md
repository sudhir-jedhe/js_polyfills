# Binary Search — Last Occurrence (with Duplicates)

```js
function findLast(arr, target) {
  let left = 0, right = arr.length - 1, result = -1;
  while (left <= right) {
    const mid = left + Math.floor((right - left) / 2);
    if (arr[mid] === target) {
      result = mid;
      left = mid + 1; // keep looking right for a later match
    } else if (arr[mid] < target) {
      left = mid + 1;
    } else {
      right = mid - 1;
    }
  }
  return result;
}

console.log(findLast([1, 2, 2, 2, 3, 4], 2)); // 3
console.log(findLast([1, 2, 2, 2, 3, 4], 1)); // 0
```
