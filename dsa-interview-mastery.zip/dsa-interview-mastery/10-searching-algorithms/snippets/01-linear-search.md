# Linear Search

```js
function linearSearch(arr, target) {
  for (let i = 0; i < arr.length; i++) {
    if (arr[i] === target) return i;
  }
  return -1;
}

console.log(linearSearch(['a', 'b', 'c', 'd'], 'c')); // 2
console.log(linearSearch(['a', 'b', 'c', 'd'], 'z')); // -1
```
