# Output: Inclusive vs Exclusive Right Bound, Mismatched

```js
function search(arr, target) {
  let left = 0, right = arr.length; // exclusive bound: intended valid range is [left, right)
  while (left <= right) {           // BUG: should be left < right to match an exclusive bound
    const mid = left + Math.floor((right - left) / 2);
    if (arr[mid] === target) return mid;
    if (arr[mid] < target) left = mid + 1;
    else right = mid;
  }
  return -1;
}

console.log(search([1, 2, 3, 4], 100)); // target not present
```

**Answer:** This call **infinite-loops** and never returns (or returns after exhausting call-stack/time budget in a real runtime — conceptually, it never terminates on its own).

**Why:** Trace it: `left=0, right=4, mid=2`, `arr[2]=3 < 100` → `left=3`. Next: `left=3, right=4, mid=3`, `arr[3]=4 < 100` → `left=4`. Next: `left=4, right=4, mid=4`, `arr[4]` is **`undefined`** (one past the last valid index) — `undefined === 100` is `false`, and `undefined < 100` is also `false` (comparisons against `undefined` coerce to `NaN`, and any comparison with `NaN` is `false`), so the code falls into the `else` branch: `right = mid = 4`. But `right` was already `4` — nothing changed. The loop condition `left <= right` (`4 <= 4`) is still true, so it runs again, recomputes the exact same `mid = 4`, takes the same branch, and repeats forever.

This is exactly the "mixed convention" bug from `theory/03-binary-search-off-by-one-bugs.md`: `right` was initialized as an **exclusive** bound (`arr.length`, meaning valid indices are `< right`), but the loop condition (`left <= right`) and narrowing logic assume an **inclusive** bound. The fix is to pick one convention consistently — either `right = arr.length - 1` with `left <= right`, or `right = arr.length` with `left < right` — and never mix pieces of both.
