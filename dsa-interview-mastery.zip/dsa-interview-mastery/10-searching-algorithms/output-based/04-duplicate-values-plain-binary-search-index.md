# Output: Which Index Does Plain Binary Search Return With Duplicates?

```js
function binarySearch(arr, target) {
  let left = 0, right = arr.length - 1;
  while (left <= right) {
    const mid = left + Math.floor((right - left) / 2);
    if (arr[mid] === target) return mid;
    if (arr[mid] < target) left = mid + 1;
    else right = mid - 1;
  }
  return -1;
}

const arr = [2, 4, 4, 4, 4, 4, 7, 9];
console.log(binarySearch(arr, 4));
```

**Answer:** `3` — but this is **not guaranteed to be the first or last occurrence**; it's simply whichever index the halving happens to land on first.

**Why:** Standard binary search returns as soon as it finds *any* element equal to the target — it has no concept of "first" or "last" among duplicates, it just stops at whatever index its midpoint calculations happen to hit. Tracing it: `left=0, right=7, mid=3`, `arr[3]=4===target` → returns immediately. If the duplicates were positioned differently, or the array length were different (shifting where the midpoints fall), plain binary search could just as easily return index 1, 2, 4, or 5 — all equally "correct" in the sense of pointing at *a* 4, but unpredictable as to *which* one. This is exactly why "find the first occurrence" or "find the last occurrence" requires the modified binary search shown in `theory/06-first-last-occurrence-and-ternary-search.md` — plain binary search cannot be relied on to consistently return a specific boundary index among duplicate values, only some arbitrary matching index.
