# Output: Does This Binary Search Terminate?

```js
function findBoundary(arr, predicate) {
  let left = 0, right = arr.length - 1;
  while (left < right) {
    const mid = Math.floor((left + right) / 2); // rounds DOWN
    if (predicate(arr[mid])) {
      right = mid;
    } else {
      left = mid; // narrowing WITHOUT +1
    }
  }
  return left;
}

// Find the first element >= 5 in [1, 3, 5, 7, 9]
console.log(findBoundary([1, 3, 5, 7, 9], (x) => x >= 5));
```

**Answer:** This call **infinite-loops** and never returns.

**Why:** Consider the search space narrowing to two elements, e.g. `left = 0, right = 1`. `mid = Math.floor((0+1)/2) = 0`, which equals `left`. If the predicate is false at `arr[0]` (so we take the `else` branch), `left = mid` sets `left = 0` — completely unchanged. The loop condition `left < right` (`0 < 1`) is still true, so the loop runs again, computes the exact same `mid`, takes the same branch, and repeats forever. This is the classic **rounding-direction bug**: when the narrowing logic uses `left = mid` (not `mid + 1`), `mid` must round **up** (`Math.ceil`) so that in a 2-element window it lands on the *upper* index, guaranteeing `left` actually advances. The fix here is changing `const mid = Math.floor(...)` to `const mid = Math.ceil((left + right) / 2)`. See `theory/03-binary-search-off-by-one-bugs.md` for the full breakdown of this exact failure mode.
