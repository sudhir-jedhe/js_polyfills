# Output: Binary Search on Unsorted Data

```js
function binarySearch(arr, target) {
  let left = 0, right = arr.length - 1;
  while (left <= right) {
    const mid = left + Math.floor((right - left) / 2);
    if (arr[mid] === target) return mid;
    if (arr[mid] < target) left = mid + 1;
    else right = mid - 1;
  }
  return -1;
}

const unsorted = [8, 1, 23, 4, 15, 6, 3];
console.log(binarySearch(unsorted, 23)); // 23 IS present, at index 2
```

**Answer:** `-1` — even though `23` is clearly present in the array, at index 2.

**Why:** Binary search's correctness depends entirely on the invariant "if `arr[mid] < target`, the target (if present) must be to the right; if `arr[mid] > target`, it must be to the left" — a guarantee that only holds on sorted data. Tracing it: `left=0, right=6, mid=3`, `arr[3]=4 < 23` → search moves right, `left=4`. Next: `left=4, right=6, mid=5`, `arr[5]=6 < 23` → `left=6`. Next: `left=6, right=6, mid=6`, `arr[6]=3 < 23` → `left=7`. Now `left (7) > right (6)`, loop ends, returns `-1` — despite `23` sitting at index 2, which the algorithm discarded on its very first comparison and never looked at again. On unsorted data, a single comparison against `arr[mid]` tells you nothing reliable about which half contains the target, so the "discard half the search space" logic can (and here, does) throw away the half that actually contains it. **Always verify the sortedness precondition before reaching for binary search** — it doesn't fail loudly, it just returns a wrong answer.
