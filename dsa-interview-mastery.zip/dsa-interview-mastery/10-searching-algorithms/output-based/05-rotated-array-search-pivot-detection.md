# Output: Rotated Array Search — Tracing the Sorted-Half Detection

```js
function searchRotated(arr, target) {
  let left = 0, right = arr.length - 1;
  while (left <= right) {
    const mid = left + Math.floor((right - left) / 2);
    console.log(`left=${left} mid=${mid} right=${right} arr[mid]=${arr[mid]}`);
    if (arr[mid] === target) return mid;
    if (arr[left] <= arr[mid]) {
      if (arr[left] <= target && target < arr[mid]) right = mid - 1;
      else left = mid + 1;
    } else {
      if (arr[mid] < target && target <= arr[right]) left = mid + 1;
      else right = mid - 1;
    }
  }
  return -1;
}

searchRotated([6, 7, 8, 1, 2, 3, 4, 5], 2);
```

**Answer:** The trace prints, then returns index `4`:
```
left=0 mid=3 right=7 arr[mid]=1
left=4 mid=5 right=7 arr[mid]=3
left=4 mid=4 right=4 arr[mid]=2
```

**Why:** Step 1: `mid=3`, `arr[mid]=1`. Check `arr[left]=6 <= arr[mid]=1`? False — so the **right** half `[3..7]` must be the sorted one instead (values `1,2,3,4,5`). Is `arr[mid]=1 < target=2 <= arr[right]=5`? Yes — target is within that sorted right half's range, so `left = mid + 1 = 4`. Step 2: `left=4, right=7, mid=5`, `arr[mid]=3`. Check `arr[left]=2 <= arr[mid]=3`? True — left half `[4..5]` is sorted. Is `arr[left]=2 <= target=2 < arr[mid]=3`? Yes — target is in that range, so `right = mid - 1 = 4`. Step 3: `left=4, right=4, mid=4`, `arr[mid]=2 === target` → return `4`. This traces exactly the mechanism from `theory/05-searching-in-a-rotated-sorted-array.md`: at every step, one half is guaranteed properly sorted (determined by comparing `arr[left]` to `arr[mid]`), and the target's presence in that half's known range is what decides which half to keep searching.
