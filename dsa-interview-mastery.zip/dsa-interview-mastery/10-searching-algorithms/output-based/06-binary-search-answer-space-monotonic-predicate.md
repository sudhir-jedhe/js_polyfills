# Output: Binary Search on Answer Space — Why This Predicate Choice Matters

```js
function canFinish(piles, speed, h) {
  const hours = piles.reduce((sum, p) => sum + Math.ceil(p / speed), 0);
  return hours <= h;
}

function minSpeed(piles, h) {
  let left = 1, right = Math.max(...piles);
  while (left < right) {
    const mid = left + Math.floor((right - left) / 2);
    if (canFinish(piles, mid, h)) right = mid;
    else left = mid + 1;
  }
  return left;
}

console.log(minSpeed([30, 11, 23, 4, 20], 5));
```

**Question:** Why is it valid to binary search over `speed` here, given there's no actual sorted array of speeds anywhere in the code?

**Answer:** `5` is the printed result. The validity comes from `canFinish`'s **monotonicity** in `speed`, not from any literal array being sorted.

**Why:** `canFinish(piles, speed, h)` is `false` for every speed below some threshold and `true` for every speed at or above it — because increasing `speed` can only decrease (never increase) the number of hours needed (`Math.ceil(p / speed)` is non-increasing as `speed` grows). That monotonic true/false structure across the range `[1, max(piles)]` is functionally identical to a sorted boolean array like `[false, false, false, true, true, true]` — binary search's halving logic works identically whether it's discarding half of a literal sorted array or half of a conceptual range of candidate answers filtered by a monotonic predicate. The `right = mid` (not `mid - 1`) narrowing when the predicate is true, paired with `left = mid + 1` when false, converges `left` and `right` onto the exact boundary index where the predicate first becomes true — the minimum feasible speed. This is the general template for every "binary search on the answer space" problem: identify a monotonic feasibility predicate, then binary search the boundary exactly as if it were an array.
