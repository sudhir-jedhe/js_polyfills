# Snippet: A Minimal Toast Queue Manager (Singleton Store)

```js
// toast-store.js — module-level singleton, importable from anywhere
let listeners = [];
let state = { visible: [], queue: [] };
const MAX_VISIBLE = 3;

function emit() {
  listeners.forEach((listener) => listener(state));
}

function show(message, options = {}) {
  const toast = { id: crypto.randomUUID(), message, duration: 4000, ...options };
  if (state.visible.length < MAX_VISIBLE) {
    state = { ...state, visible: [...state.visible, toast] };
  } else {
    state = { ...state, queue: [...state.queue, toast] };
  }
  emit();
  return toast.id;
}

function dismiss(id) {
  const visible = state.visible.filter((t) => t.id !== id);
  const [next, ...restQueue] = state.queue;
  state = { visible: next ? [...visible, next] : visible, queue: restQueue };
  emit();
}

export const toast = { show, dismiss };

export function subscribe(listener) {
  listeners.push(listener);
  return () => { listeners = listeners.filter((l) => l !== listener); };
}
```

```jsx
// ToastContainer.jsx — mounted once, near the app root
function ToastContainer() {
  const [state, setState] = useState({ visible: [], queue: [] });
  useEffect(() => subscribe(setState), []);

  return (
    <div className="toast-container" aria-live="polite">
      {state.visible.map((t) => (
        <div key={t.id} className={`toast toast--${t.type ?? 'info'}`}>
          {t.message}
          <button onClick={() => toast.dismiss(t.id)} aria-label="Dismiss">×</button>
        </div>
      ))}
    </div>
  );
}
```

```js
// used from anywhere, no context or props needed
import { toast } from './toast-store';
toast.show('Saved successfully', { type: 'success' });
```
