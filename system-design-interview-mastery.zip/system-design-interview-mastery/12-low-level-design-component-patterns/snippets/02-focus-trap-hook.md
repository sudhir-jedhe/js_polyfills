# Snippet: A Reusable Focus Trap Hook

```jsx
function useFocusTrap(containerRef, isActive) {
  const previouslyFocused = useRef(null);

  useEffect(() => {
    if (!isActive || !containerRef.current) return;

    previouslyFocused.current = document.activeElement;

    const focusableSelector =
      'a[href], button:not([disabled]), textarea, input, select, [tabindex]:not([tabindex="-1"])';
    const getFocusable = () => Array.from(containerRef.current.querySelectorAll(focusableSelector));

    const first = getFocusable()[0];
    (first ?? containerRef.current).focus();

    function handleKeyDown(e) {
      if (e.key === 'Escape') {
        containerRef.current.dispatchEvent(new CustomEvent('trap-escape', { bubbles: true }));
        return;
      }
      if (e.key !== 'Tab') return;

      const focusable = getFocusable();
      if (focusable.length === 0) return;
      const firstEl = focusable[0];
      const lastEl = focusable[focusable.length - 1];

      if (e.shiftKey && document.activeElement === firstEl) {
        e.preventDefault();
        lastEl.focus();
      } else if (!e.shiftKey && document.activeElement === lastEl) {
        e.preventDefault();
        firstEl.focus();
      }
    }

    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      previouslyFocused.current?.focus(); // restore focus to the trigger on close
    };
  }, [isActive, containerRef]);
}
```

```jsx
function Modal({ open, onClose, children }) {
  const containerRef = useRef(null);
  useFocusTrap(containerRef, open);

  if (!open) return null;
  return createPortal(
    <div className="overlay">
      <div ref={containerRef} role="dialog" aria-modal="true" tabIndex={-1} className="modal">
        {children}
      </div>
    </div>,
    document.body
  );
}
```
