# Snippet: Debounced, Cancellable Autocomplete Hook

```jsx
function useDebouncedValue(value, delayMs) {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const id = setTimeout(() => setDebounced(value), delayMs);
    return () => clearTimeout(id);
  }, [value, delayMs]);
  return debounced;
}

function useAutocomplete(rawQuery, { delayMs = 250, minLength = 2 } = {}) {
  const debouncedQuery = useDebouncedValue(rawQuery, delayMs);
  const [state, setState] = useState({ status: 'idle', results: [] });
  const latestRequestId = useRef(0);

  useEffect(() => {
    if (debouncedQuery.length < minLength) {
      setState({ status: 'idle', results: [] });
      return;
    }

    const requestId = ++latestRequestId.current;
    const controller = new AbortController();
    setState((s) => ({ ...s, status: 'loading' }));

    fetch(`/api/search?q=${encodeURIComponent(debouncedQuery)}`, { signal: controller.signal })
      .then((res) => res.json())
      .then((results) => {
        if (requestId !== latestRequestId.current) return; // stale response, ignore
        setState({ status: results.length ? 'success' : 'empty', results });
      })
      .catch((err) => {
        if (err.name === 'AbortError') return;
        if (requestId !== latestRequestId.current) return;
        setState({ status: 'error', results: [] });
      });

    return () => controller.abort();
  }, [debouncedQuery, minLength]);

  return state; // { status: 'idle'|'loading'|'success'|'empty'|'error', results }
}
```

```jsx
function SearchBox() {
  const [query, setQuery] = useState('');
  const { status, results } = useAutocomplete(query);

  return (
    <div>
      <input value={query} onChange={(e) => setQuery(e.target.value)} />
      {status === 'loading' && <Spinner />}
      {status === 'empty' && <div>No results</div>}
      {status === 'success' && <ul>{results.map((r) => <li key={r.id}>{r.label}</li>)}</ul>}
    </div>
  );
}
```
