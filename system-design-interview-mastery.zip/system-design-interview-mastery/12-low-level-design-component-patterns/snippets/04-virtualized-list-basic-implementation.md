# Snippet: A Basic Fixed-Height Virtualized List

```jsx
function VirtualList({ items, itemHeight = 40, height = 400, overscan = 3, renderItem }) {
  const [scrollTop, setScrollTop] = useState(0);
  const containerRef = useRef(null);

  const totalHeight = items.length * itemHeight;
  const startIndex = Math.max(0, Math.floor(scrollTop / itemHeight) - overscan);
  const endIndex = Math.min(
    items.length - 1,
    Math.ceil((scrollTop + height) / itemHeight) + overscan
  );
  const visible = items.slice(startIndex, endIndex + 1);

  return (
    <div
      ref={containerRef}
      onScroll={(e) => setScrollTop(e.currentTarget.scrollTop)}
      style={{ height, overflowY: 'auto', position: 'relative' }}
    >
      <div style={{ height: totalHeight, position: 'relative' }}>
        {visible.map((item, i) => {
          const index = startIndex + i;
          return (
            <div
              key={item.id} // stable identity key, NOT the recycled index
              style={{ position: 'absolute', top: index * itemHeight, height: itemHeight, width: '100%' }}
            >
              {renderItem(item, index)}
            </div>
          );
        })}
      </div>
    </div>
  );
}
```

```jsx
// usage — renders only ~14 DOM nodes at a time (400/40 visible + 2*3 overscan) out of 50,000 items
<VirtualList
  items={rows}
  itemHeight={40}
  height={400}
  renderItem={(row) => <div className="row">{row.label}</div>}
/>
```
