# Snippet: Portal-Based Modal With Z-Index Stacking

```jsx
const modalStack = []; // shared module-level stack of open modal ids

function useModalStack(id, isOpen) {
  const [zIndex, setZIndex] = useState(null);

  useEffect(() => {
    if (!isOpen) return;
    modalStack.push(id);
    setZIndex(1000 + modalStack.length * 10);
    return () => {
      const idx = modalStack.indexOf(id);
      if (idx !== -1) modalStack.splice(idx, 1);
    };
  }, [isOpen, id]);

  const isTopmost = modalStack[modalStack.length - 1] === id;
  return { zIndex, isTopmost };
}

function Modal({ id, open, onClose, children }) {
  const containerRef = useRef(null);
  const { zIndex, isTopmost } = useModalStack(id, open);
  useFocusTrap(containerRef, open && isTopmost); // only the topmost modal traps focus/Escape

  useEffect(() => {
    if (!open) return;
    document.body.dataset.modalOpenCount = String(
      Number(document.body.dataset.modalOpenCount || 0) + 1
    );
    document.body.style.overflow = 'hidden'; // lock scroll
    return () => {
      const count = Number(document.body.dataset.modalOpenCount || 1) - 1;
      document.body.dataset.modalOpenCount = String(count);
      if (count <= 0) document.body.style.overflow = ''; // only unlock when the LAST modal closes
    };
  }, [open]);

  if (!open) return null;

  return createPortal(
    <div className="overlay" style={{ zIndex }} onClick={onClose}>
      <div ref={containerRef} role="dialog" aria-modal="true" onClick={(e) => e.stopPropagation()}>
        {children}
      </div>
    </div>,
    document.getElementById('modal-root')
  );
}
```

Opening a confirmation `<Modal id="confirm">` from inside `<Modal id="edit">` naturally stacks above it (higher `zIndex`), and closing the confirmation modal correctly leaves the edit modal's scroll lock intact via the reference-counted `data-modal-open-count`.
