# Snippet: A Minimal Schema-Driven Form Renderer

```jsx
const registry = {
  text: ({ label, value, onChange }) => (
    <label>{label}<input value={value ?? ''} onChange={(e) => onChange(e.target.value)} /></label>
  ),
  select: ({ label, options, value, onChange }) => (
    <label>{label}
      <select value={value ?? ''} onChange={(e) => onChange(e.target.value)}>
        <option value="" disabled>Choose...</option>
        {options.map((opt) => <option key={opt} value={opt}>{opt}</option>)}
      </select>
    </label>
  ),
  checkbox: ({ label, value, onChange }) => (
    <label>
      <input type="checkbox" checked={!!value} onChange={(e) => onChange(e.target.checked)} />
      {label}
    </label>
  ),
};

function isVisible(field, values) {
  if (!field.visibleWhen) return true;
  return values[field.visibleWhen.field] === field.visibleWhen.equals;
}

function SchemaForm({ schema, values, onChange }) {
  return (
    <form>
      {schema.fields
        .filter((field) => isVisible(field, values))
        .map((field) => {
          const Field = registry[field.type];
          if (!Field) return <div key={field.name}>Unknown field type: {field.type}</div>;
          return (
            <Field
              key={field.name}
              {...field}
              value={values[field.name]}
              onChange={(v) => onChange(field.name, v)}
            />
          );
        })}
    </form>
  );
}
```

```jsx
const schema = {
  fields: [
    { type: 'select', name: 'country', label: 'Country', options: ['US', 'UK'] },
    { type: 'text', name: 'zip', label: 'ZIP Code', visibleWhen: { field: 'country', equals: 'US' } },
    { type: 'checkbox', name: 'subscribe', label: 'Email me updates' },
  ],
};

function App() {
  const [values, setValues] = useState({});
  return <SchemaForm schema={schema} values={values} onChange={(k, v) => setValues((s) => ({ ...s, [k]: v }))} />;
}
```
