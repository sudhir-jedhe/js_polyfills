# Low-Level Design: Component Patterns

Component-level low-level design (LLD) interviews ask you to design the *API and internal architecture* of a specific UI component or system — a toast notifier, a modal system, a virtualized list, an autocomplete — the way a backend LLD interview asks you to design a rate limiter or a parking-lot class hierarchy. The bar is the same: a clean public API surface, a justified internal architecture, and explicit handling of the hard edge cases (race conditions, focus management, nested instances, stale async responses) that separate "it renders" from "it's actually correct." This topic covers the handful of components that show up again and again in frontend LLD interviews, plus the general vocabulary (controlled vs. uncontrolled, headless vs. styled, composition vs. configuration) that lets you reason about any component you haven't seen before.

## Folder structure

- **`theory/`** — component API design principles (controlled/uncontrolled, imperative/declarative, headless/styled, composition), then dedicated architecture deep-dives for toast systems, modal/dialog systems, virtualized list windowing math, autocomplete/typeahead, schema-driven UI, and multi-step forms.
- **`snippets/`** — 6 runnable examples: a toast queue manager, a focus-trap hook, a portal-based stacking modal, a fixed-height virtualized list, a debounced/cancellable autocomplete hook, and a schema-driven form renderer.
- **`output-based/`** — 5 "what happens?" deep dives: a toast timer that doesn't pause on hover, `aria-modal` without a real focus trap, index-based keys corrupting virtualized row state, out-of-order autocomplete responses, and stale cached step-validity in a wizard.
- **`scenarios/`** — 6 real-world design/fix situations: taming a high-frequency toast stream, nested-modal focus bugs, virtualizing variable-height rows, an autocomplete flooding a backend, extending a schema-driven form with conditional logic, and persisting a checkout wizard across refresh.
- **`interview-qa/`** — 4 themed files: toast/modal design, virtualization/performance, autocomplete/async UI, and schema-driven/form architecture.
- **`problems/`** — 4 full component-design challenges: design a toast notification system, a modal/dialog system, a virtualized list component, and an autocomplete/typeahead component — each with a complete solution and design rationale.
- **`assets/`** — placeholder for diagrams (see `assets/README.md`).

## What's covered

- The vocabulary every component API decision falls along: controlled vs. uncontrolled, imperative vs. declarative, headless vs. styled, composition vs. configuration
- Toast systems: singleton store architecture (no prop-drilling), queueing under burst load, pausable auto-dismiss timers, accessibility (`aria-live`)
- Modal/dialog systems: portal rendering and React's synthetic event bubbling through the logical tree, real keyboard focus trapping (vs. `aria-modal` alone), z-index and scroll-lock coordination across nested/stacked modals
- Virtualized lists: the exact fixed-height windowing arithmetic, overscan tradeoffs, why item keys must be stable identity not index, and the harder variable-height measure-and-cache approach
- Autocomplete/typeahead: debouncing vs. cancellation as two distinct problems, `AbortController` + sequence-token guards against stale responses, the ARIA combobox pattern, and explicit loading/empty/error states
- Schema-driven UI systems: the schema → registry → renderer architecture, safely expressing conditional logic as data (not embedded code), and the registry as an escape hatch for genuinely custom cases
- Multi-step forms: centralized shared state vs. per-step local state, deriving (never caching) step validity, and safe persistence across refresh
