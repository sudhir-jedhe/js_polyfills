# Output: Toast Auto-Dismiss Timer Doesn't Pause on Hover

```jsx
function Toast({ id, message, duration, onDismiss }) {
  useEffect(() => {
    const timerId = setTimeout(() => onDismiss(id), duration);
    return () => clearTimeout(timerId);
  }, [id, duration, onDismiss]);

  return (
    <div className="toast" onMouseEnter={() => {/* nothing here */}}>
      {message}
    </div>
  );
}
```

**Scenario:** A toast shows "Undo delete" with a 4-second auto-dismiss. QA reports that hovering over the toast to click "Undo" sometimes doesn't help — the toast disappears mid-hover before they can click, especially if they pause reading the message first.

**Question:** Why does the toast still disappear at the original 4-second mark even while the user is actively hovering it, and what specifically is missing?

**Answer:** The `setTimeout` is set once on mount and runs to completion regardless of any subsequent hover — there's no `onMouseEnter`/`onMouseLeave` logic that actually pauses or clears the timer; the empty handler is a no-op. The timer has no concept of "the user is currently engaged with this," so 4 seconds after mount, `onDismiss` fires unconditionally, even mid-hover, even mid-read.

**Fix — track elapsed time and pause/resume instead of a single fire-and-forget timeout:**

```jsx
function Toast({ id, message, duration, onDismiss }) {
  const remaining = useRef(duration);
  const startedAt = useRef(Date.now());
  const timerId = useRef(null);

  const start = () => {
    startedAt.current = Date.now();
    timerId.current = setTimeout(() => onDismiss(id), remaining.current);
  };
  const pause = () => {
    clearTimeout(timerId.current);
    remaining.current -= Date.now() - startedAt.current;
  };

  useEffect(() => { start(); return () => clearTimeout(timerId.current); }, []);

  return (
    <div className="toast" onMouseEnter={pause} onMouseLeave={start} onFocus={pause} onBlur={start}>
      {message}
    </div>
  );
}
```

**Broader lesson:** an auto-dismiss timer is stateful UX, not a fire-and-forget side effect — any interaction the user can have with the toast while it's visible (hover, focus on an action button) needs to be able to pause the countdown, or the auto-dismiss feature actively works against the toast's own purpose (giving the user a chance to act on it).
