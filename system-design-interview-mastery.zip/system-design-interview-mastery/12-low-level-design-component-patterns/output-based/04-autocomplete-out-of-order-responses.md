# Output: Autocomplete Shows Results for an Old Query

```jsx
function useAutocomplete(query) {
  const [results, setResults] = useState([]);
  useEffect(() => {
    if (!query) return;
    fetch(`/api/search?q=${query}`)
      .then((res) => res.json())
      .then(setResults); // no guard against staleness
  }, [query]);
  return results;
}
```

**Scenario:** A user quickly types "cat" then immediately deletes it and types "dog". The request for "cat" hits a slower backend shard and takes 800ms; the request for "dog" hits a fast shard and returns in 120ms. The dropdown briefly shows dog results correctly — then, ~700ms later, flickers to show cat results instead, even though the input now reads "dog".

**Question:** Why does the earlier, already-superseded request's response overwrite the later, correct one?

**Answer:** Both requests are in flight concurrently (nothing cancels the "cat" request when "dog" is typed), and each `.then(setResults)` runs independently whenever its own network response arrives — completely unordered with respect to when the *requests* were made. Because "cat"'s response happens to arrive **after** "dog"'s (slower shard), it's the last `setResults` call to run, and it wins, regardless of the fact that it's answering a query the user no longer has typed.

**Fix — a sequence-token guard (or `AbortController`, or both) that only accepts the response belonging to the most recently issued request:**

```jsx
function useAutocomplete(query) {
  const [results, setResults] = useState([]);
  const latestId = useRef(0);

  useEffect(() => {
    if (!query) return;
    const requestId = ++latestId.current;
    fetch(`/api/search?q=${query}`)
      .then((res) => res.json())
      .then((data) => {
        if (requestId === latestId.current) setResults(data); // ignore if a newer request has since started
      });
  }, [query]);

  return results;
}
```

With the guard, the "cat" response arrives, checks `requestId (1) === latestId.current (2)` → false → discarded. The "dog" results (already showing) stay showing.

**Broader lesson:** debouncing reduces *how many* requests fire, but does nothing about the *order responses arrive in* — those are two separate problems, and an autocomplete implementation needs an explicit answer to both, not just a debounce delay.
