# Output: Multi-Step Form Lets an Invalid Later Step Through After Editing an Earlier One

```jsx
function useWizard(steps) {
  const [step, setStep] = useState(0);
  const [values, setValues] = useState({});
  const [validSteps, setValidSteps] = useState({}); // { [stepIndex]: true } — cached, set once on first pass

  function goNext() {
    const errors = steps[step].validate(values);
    if (Object.keys(errors).length === 0) {
      setValidSteps((v) => ({ ...v, [step]: true })); // cached forever, never re-checked
      setStep((s) => s + 1);
    }
  }

  function jumpTo(target) {
    // allow jumping to any step that's ever been validated before
    if (validSteps[target] || target < step) setStep(target);
  }

  return { step, values, setValues, goNext, jumpTo };
}
```

**Scenario:** Step 1 asks for a subscription `plan` ("Free" or "Pro"). Step 3 asks for payment details, only meaningful if `plan === 'Pro'`. A user selects "Pro" on step 1, fills out step 3's payment fields (now marked `validSteps[3] = true`), then navigates back to step 1 and changes their selection to "Free". They then jump forward directly to the final review step.

**Question:** What does the review step show, and why does the system let this state exist at all?

**Answer:** The review step shows a "Free" plan **with payment details still attached and marked as validated** — a nonsensical combination the validation logic should have caught. The bug is that `validSteps[target]` is a **cached flag set once**, at the moment the user first passed that step's validation, and it's never invalidated when an *earlier* step's data changes afterward, even though step 3's actual required fields (and their meaning) depend on step 1's `plan` value. The wizard's `jumpTo` trusts the stale cached flag instead of re-deriving validity from current `values`.

**Fix — always derive step validity from current values, never trust a cached "was valid at some point" flag:**

```jsx
function useWizard(steps) {
  const [step, setStep] = useState(0);
  const [values, setValues] = useState({});

  function isStepValid(index) {
    return Object.keys(steps[index].validate(values)).length === 0;
  }

  function goNext() {
    if (isStepValid(step)) setStep((s) => s + 1);
  }

  function jumpTo(target) {
    // every step strictly before the target must ALSO still be valid under current values
    const allPriorStepsStillValid = Array.from({ length: target }, (_, i) => i).every(isStepValid);
    if (allPriorStepsStillValid) setStep(target);
  }

  return { step, values, setValues, goNext, jumpTo };
}
```

Now, after changing `plan` to "Free," step 3's validator (which presumably requires payment fields *only* `visibleWhen plan === 'Pro'`, and should be considered vacuously valid — or explicitly cleared — when not applicable) is re-evaluated fresh against the current `values` every time, rather than trusting a flag set under now-outdated conditions.

**Broader lesson:** any "has this step been completed" state in a multi-step flow is a *derived* value (a function of current form data), not independent state to cache and forget — caching it decouples it from the very data whose validity it's supposed to represent, and backward navigation is exactly the interaction that exposes the staleness.
