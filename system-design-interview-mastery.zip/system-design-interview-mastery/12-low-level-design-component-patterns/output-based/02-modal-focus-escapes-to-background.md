# Output: Tab Key Escapes the Modal to Background Content

```jsx
function Modal({ open, children }) {
  if (!open) return null;
  return createPortal(
    <div className="overlay">
      <div className="modal" role="dialog" aria-modal="true">
        {children}
      </div>
    </div>,
    document.getElementById('modal-root')
  );
}
```

**Scenario:** A modal renders fine visually, with `role="dialog"` and `aria-modal="true"` correctly set. A keyboard-only user reports that after tabbing through all the buttons inside the modal, the next Tab press moves focus to a link in the page's header behind the overlay — which is invisible under the overlay, but still receiving focus.

**Question:** Why does `aria-modal="true"` alone not prevent this, and what's actually missing?

**Answer:** `aria-modal="true"` is purely a **semantic hint for assistive technology** — it tells a screen reader "treat everything outside this dialog as inert for its virtual cursor navigation." It does not affect actual keyboard `Tab` order or `focus()` behavior at all; the browser has no built-in mechanism that makes `aria-modal` trap real keyboard focus. Without separate, explicit JavaScript that intercepts `Tab`/`Shift+Tab` and redirects focus back into the modal's last/first focusable element, the DOM's natural tab order continues right past the modal's boundary into whatever's next in the document — in this case, the header link, which is still technically focusable even though it's visually hidden under the overlay.

**Fix — an actual focus trap (see `snippets/02-focus-trap-hook.md`):**

```jsx
function Modal({ open, children }) {
  const containerRef = useRef(null);
  useFocusTrap(containerRef, open); // intercepts Tab/Shift+Tab and cycles within containerRef

  if (!open) return null;
  return createPortal(
    <div className="overlay">
      <div ref={containerRef} className="modal" role="dialog" aria-modal="true" tabIndex={-1}>
        {children}
      </div>
    </div>,
    document.getElementById('modal-root')
  );
}
```

**Broader lesson:** ARIA attributes describe intent to assistive technology; they never implement behavior. `aria-modal="true"` without a real focus trap is a common accessibility-audit failure — it passes a screen-reader-only spot check while still failing keyboard-only users, which is exactly this bug's symptom.
