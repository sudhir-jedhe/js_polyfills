# Output: Virtualized List Using Array Index as Key

```jsx
function VirtualList({ items, itemHeight, startIndex, endIndex }) {
  const visible = items.slice(startIndex, endIndex + 1);
  return visible.map((item, i) => (
    <Row key={i} style={{ top: (startIndex + i) * itemHeight }} item={item} />
  ));
}

function Row({ item, style }) {
  const [expanded, setExpanded] = useState(false);
  return (
    <div style={style} onClick={() => setExpanded((e) => !e)}>
      {item.title} {expanded && <p>{item.details}</p>}
    </div>
  );
}
```

**Scenario:** A virtualized list of 5,000 expandable FAQ items. A user scrolls down, expands item #47 to read its details, then keeps scrolling. As they scroll, other rows sometimes appear already expanded — rows they never clicked.

**Question:** Why does expanding one row cause seemingly unrelated rows to appear expanded later?

**Answer:** `key={i}` uses the **local slice index** (0, 1, 2, ... within the currently-rendered window), not the item's actual stable identity. As the user scrolls, `startIndex`/`endIndex` shift, so the *same key* (say, `key={2}`) gets reused for a *different* underlying item on each render — React, matching by key, reuses the existing `Row` component instance (and its `expanded` local state) for whatever new item now happens to occupy that slice position, instead of unmounting/remounting. The `expanded` state genuinely belongs to "the 3rd position in the current window," not to any particular FAQ item — so scrolling drags that `true` expanded state onto whatever unrelated item next lands in that slot.

**Fix — key by stable item identity, not position:**

```jsx
function VirtualList({ items, itemHeight, startIndex, endIndex }) {
  const visible = items.slice(startIndex, endIndex + 1);
  return visible.map((item, i) => (
    <Row key={item.id} style={{ top: (startIndex + i) * itemHeight }} item={item} />
  ));
}
```

With `key={item.id}`, React correctly recognizes "this is a genuinely different item" whenever the underlying data at a given screen position changes, and mounts a fresh `Row` (with fresh `expanded = false` state) rather than incorrectly reusing a component instance and its stale local state.

**Broader lesson:** virtualization physically recycles *screen positions*, but React's reconciliation recycles *component instances by key* — if those two recycling mechanisms are keyed on different things (position vs. identity), any row-local state silently "sticks" to the wrong data as the user scrolls. This is one of the most common real bugs in hand-rolled virtualized lists.
