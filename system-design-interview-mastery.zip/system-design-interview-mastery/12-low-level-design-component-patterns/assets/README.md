Diagrams and reference images for component-level low-level design (e.g. a modal focus-trap flow diagram, a virtualization windowing illustration) will be added here.
