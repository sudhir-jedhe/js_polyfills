# Problem: Design a Virtualized List Component

## Problem Statement

Design a reusable `VirtualList` component that renders only the visible (plus overscan) subset of a large array, supporting:

- Fixed-height rows as the common case, with correct windowing math.
- A pluggable API that could later extend to variable-height rows without a full rewrite of the consumer-facing API.
- Smooth scrolling with no visible blank flashes on fast scroll.
- Programmatic "scroll to index" support (e.g., for jumping to a search result).

## Constraints

- Must render a bounded number of DOM nodes regardless of total item count (10 items or 100,000 — DOM node count for the visible window should be roughly constant).
- `scrollToIndex` must work even for an index currently outside the rendered window.
- Item identity (`key`) must be stable across scroll-driven re-renders.

## Solution

```jsx
function VirtualList({ items, itemHeight, height, overscan = 3, renderItem, listRef }) {
  const [scrollTop, setScrollTop] = useState(0);
  const containerRef = useRef(null);

  useImperativeHandle(listRef, () => ({
    scrollToIndex(index) {
      const target = index * itemHeight;
      containerRef.current?.scrollTo({ top: target, behavior: 'smooth' });
    },
  }));

  const totalHeight = items.length * itemHeight;
  const startIndex = Math.max(0, Math.floor(scrollTop / itemHeight) - overscan);
  const endIndex = Math.min(items.length - 1, Math.ceil((scrollTop + height) / itemHeight) + overscan);
  const visible = items.slice(startIndex, endIndex + 1);

  return (
    <div
      ref={containerRef}
      onScroll={(e) => setScrollTop(e.currentTarget.scrollTop)}
      style={{ height, overflowY: 'auto' }}
    >
      <div style={{ height: totalHeight, position: 'relative' }}>
        {visible.map((item, i) => {
          const index = startIndex + i;
          return (
            <div
              key={item.id}
              style={{ position: 'absolute', top: index * itemHeight, height: itemHeight, width: '100%' }}
            >
              {renderItem(item, index)}
            </div>
          );
        })}
      </div>
    </div>
  );
}
```

```jsx
// usage with imperative scrollToIndex
function SearchableList({ items }) {
  const listRef = useRef(null);
  return (
    <>
      <button onClick={() => listRef.current.scrollToIndex(4200)}>Jump to #4200</button>
      <VirtualList
        listRef={listRef}
        items={items}
        itemHeight={40}
        height={500}
        renderItem={(item) => <Row item={item} />}
      />
    </>
  );
}
```

## Extending toward variable-height rows (API stays stable)

```jsx
function VirtualList({ items, itemHeight, height, overscan, renderItem, listRef }) {
  // itemHeight can be either a number (fixed) or a function (index) => number (variable, estimated)
  const heightCache = useMemo(() => new RowHeightCache(items.length, itemHeight), [items.length]);
  // internal windowing logic swaps from arithmetic to heightCache.findStartIndex(scrollTop) —
  // the component's external prop surface (items, height, renderItem, listRef.scrollToIndex) is unchanged
}
```

## Why this design

- **`key={item.id}`, never index** — since virtualization physically recycles DOM nodes across different underlying items as the window shifts, keying by anything other than stable item identity causes local component state to incorrectly persist onto the wrong item (see `output-based/03`).
- **`scrollToIndex` computes a target offset and calls `scrollTo` directly on the container**, rather than depending on the item being currently rendered — this works for any index, in or out of the current window, because the outer spacer's height (`totalHeight`) already reflects the full scrollable range regardless of what's rendered.
- **The `itemHeight`-as-number-or-function design decision is called out explicitly** as the seam that lets the same public API extend to variable-height rows later (see `theory/04` and `scenarios/03`) without breaking existing consumers — a component interface decision made deliberately with the harder future case in mind, rather than needing a breaking API change later.
- **Overscan is a prop, not hardcoded**, since the right value is a latency/memory tradeoff that depends on typical scroll velocity and row render cost for a given use case — exposing it lets consumers tune it rather than the library guessing one universal default.
