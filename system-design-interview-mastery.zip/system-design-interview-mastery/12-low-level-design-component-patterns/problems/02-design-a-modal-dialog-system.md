# Problem: Design a Modal / Dialog System

## Problem Statement

Design the API and internal architecture for a reusable modal/dialog system supporting:

- Portal rendering (never clipped/mispositioned by an ancestor's CSS).
- Full keyboard focus trapping while open, with correct focus restoration on close.
- Correct behavior when multiple modals are opened on top of each other (nested confirmation dialogs).
- Scroll-locking the background page, correctly reference-counted across multiple open modals.
- `Escape`-to-close and click-outside-to-close, both configurable/overridable per instance.

## Constraints

- Must satisfy WAI-ARIA dialog pattern requirements (`role="dialog"`, `aria-modal="true"`, correct focus management).
- A confirmation modal opened from inside another modal must stack visually above it, and `Escape` must close only the topmost.
- Closing the last open modal must restore both scroll and focus correctly.

## Solution

```js
// modal-stack.js — shared coordination across all Modal instances
const stack = [];

export function pushModal(id) {
  stack.push(id);
}
export function popModal(id) {
  const idx = stack.indexOf(id);
  if (idx !== -1) stack.splice(idx, 1);
}
export function isTopmost(id) {
  return stack[stack.length - 1] === id;
}
export function stackSize() {
  return stack.length;
}
```

```jsx
// useFocusTrap.js
function useFocusTrap(containerRef, isActive, { onEscape, onClickOutside } = {}) {
  const previouslyFocused = useRef(null);

  useEffect(() => {
    if (!isActive || !containerRef.current) return;
    previouslyFocused.current = document.activeElement;

    const getFocusable = () =>
      Array.from(containerRef.current.querySelectorAll(
        'a[href], button:not([disabled]), textarea, input, select, [tabindex]:not([tabindex="-1"])'
      ));
    (getFocusable()[0] ?? containerRef.current).focus();

    function handleKeyDown(e) {
      if (e.key === 'Escape') { onEscape?.(); return; }
      if (e.key !== 'Tab') return;
      const focusable = getFocusable();
      if (!focusable.length) return;
      const [first, last] = [focusable[0], focusable[focusable.length - 1]];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }

    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      previouslyFocused.current?.focus();
    };
  }, [isActive, containerRef, onEscape]);
}
```

```jsx
// Modal.jsx
let scrollLockCount = 0;

function useScrollLock(isOpen) {
  useEffect(() => {
    if (!isOpen) return;
    scrollLockCount += 1;
    document.body.style.overflow = 'hidden';
    return () => {
      scrollLockCount -= 1;
      if (scrollLockCount <= 0) document.body.style.overflow = '';
    };
  }, [isOpen]);
}

function Modal({ id, open, onClose, closeOnEscape = true, closeOnOverlayClick = true, children }) {
  const containerRef = useRef(null);

  useEffect(() => {
    if (!open) return;
    pushModal(id);
    return () => popModal(id);
  }, [open, id]);

  const topmost = open && isTopmost(id);
  useFocusTrap(containerRef, topmost, { onEscape: closeOnEscape ? onClose : undefined });
  useScrollLock(open);

  if (!open) return null;

  const zIndex = 1000 + stackSize() * 10;

  return createPortal(
    <div
      className="modal-overlay"
      style={{ zIndex }}
      onClick={closeOnOverlayClick && topmost ? onClose : undefined}
    >
      <div
        ref={containerRef}
        role="dialog"
        aria-modal="true"
        tabIndex={-1}
        className="modal-content"
        onClick={(e) => e.stopPropagation()}
      >
        {children}
      </div>
    </div>,
    document.getElementById('modal-root')
  );
}
```

```jsx
// usage
<Modal id="edit-profile" open={editOpen} onClose={() => setEditOpen(false)}>
  <h2>Edit Profile</h2>
  <button onClick={() => setConfirmOpen(true)}>Delete Account</button>
</Modal>

<Modal id="confirm-delete" open={confirmOpen} onClose={() => setConfirmOpen(false)}>
  <p>Are you sure?</p>
  <button onClick={handleDelete}>Confirm</button>
</Modal>
```

## Why this design

- **A shared `modal-stack` module, not per-instance state**, is what makes nested modals behave correctly: z-index is derived from stack position, and only the topmost instance's focus trap/`Escape` handler is actually active (`topmost` gates `useFocusTrap`'s `isActive`) — a covered modal's trap effect simply doesn't run its listener setup, so it can't compete with the modal above it.
- **Scroll lock uses a module-level counter**, incremented/decremented per open/close, released only at zero — this is what makes closing an inner confirmation modal correctly leave the outer modal's scroll lock intact, rather than naively toggling a boolean that the second modal's cleanup would incorrectly clear.
- **`closeOnEscape`/`closeOnOverlayClick` are per-instance configurable**, since some dialogs (e.g., a destructive confirmation, or a form with unsaved changes) deliberately want to disable click-outside dismissal to prevent accidental data loss.
- **Focus restoration** happens in the trap's cleanup, restoring to whatever had focus *before this specific modal* opened — because the trap only activates while topmost, this naturally handles the nested case correctly: closing the confirmation restores focus to whatever the edit modal had focused, and only when the edit modal itself later closes does focus return further, to the original page trigger.
