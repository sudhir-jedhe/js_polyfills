# Problem: Design a Toast Notification System

## Problem Statement

Design the API and internal architecture for a toast notification system usable from anywhere in a large application (deep in API interceptors, form handlers, anywhere) without prop-drilling or requiring a React context provider wrap at every call site. It must support:

- Multiple toast types (`success`, `error`, `info`, `warning`).
- A maximum of 3 visible toasts at once, with excess queued and shown as earlier ones dismiss.
- Auto-dismiss after a configurable duration, which pauses while the user hovers or focuses the toast.
- An optional action button (e.g., "Undo").
- Programmatic dismissal (`toast.dismiss(id)`) and dismiss-all.
- Screen-reader announcement of new toasts without stealing keyboard focus.

## Constraints

- No React Context required at call sites — `toast.show(...)` must be importable and callable from plain (non-component) JS modules too (e.g., an Axios interceptor).
- The visible-toast cap and queueing must not drop any queued toast — everything shown eventually, in order, unless explicitly dismissed.
- Must not leak timers on unmount (dismissing a toast externally while its auto-dismiss timer is still pending must clean up correctly).

## Solution

```js
// toast-store.js
let listeners = [];
let state = { visible: [], queue: [] };
const MAX_VISIBLE = 3;
const DEFAULT_DURATION = 4000;

function emit() { listeners.forEach((l) => l(state)); }

function show(message, options = {}) {
  const toast = {
    id: crypto.randomUUID(),
    message,
    type: options.type ?? 'info',
    duration: options.duration ?? DEFAULT_DURATION,
    action: options.action ?? null,
  };
  if (state.visible.length < MAX_VISIBLE) {
    state = { ...state, visible: [...state.visible, toast] };
  } else {
    state = { ...state, queue: [...state.queue, toast] };
  }
  emit();
  return toast.id;
}

function dismiss(id) {
  const wasVisible = state.visible.some((t) => t.id === id);
  const visible = state.visible.filter((t) => t.id !== id);
  const queue = state.queue.filter((t) => t.id !== id); // also allow dismissing a still-queued toast
  if (wasVisible && visible.length < MAX_VISIBLE) {
    const [next, ...restQueue] = queue;
    state = { visible: next ? [...visible, next] : visible, queue: restQueue };
  } else {
    state = { visible, queue };
  }
  emit();
}

function dismissAll() {
  state = { visible: [], queue: [] };
  emit();
}

export const toast = { show, dismiss, dismissAll };
export function subscribeToToasts(listener) {
  listeners.push(listener);
  return () => { listeners = listeners.filter((l) => l !== listener); };
}
```

```jsx
// ToastItem.jsx — owns its own pausable auto-dismiss timer
function ToastItem({ id, message, type, duration, action }) {
  const remaining = useRef(duration);
  const startedAt = useRef(Date.now());
  const timerId = useRef(null);

  const start = useCallback(() => {
    startedAt.current = Date.now();
    timerId.current = setTimeout(() => toast.dismiss(id), remaining.current);
  }, [id]);

  const pause = useCallback(() => {
    clearTimeout(timerId.current);
    remaining.current -= Date.now() - startedAt.current;
  }, []);

  useEffect(() => {
    start();
    return () => clearTimeout(timerId.current); // cleanup on unmount, including external dismiss
  }, [start]);

  return (
    <div className={`toast toast--${type}`} onMouseEnter={pause} onMouseLeave={start} onFocus={pause} onBlur={start}>
      <span>{message}</span>
      {action && <button onClick={() => { action.onClick(); toast.dismiss(id); }}>{action.label}</button>}
      <button aria-label="Dismiss" onClick={() => toast.dismiss(id)}>×</button>
    </div>
  );
}

// ToastContainer.jsx — mounted once near the app root
function ToastContainer() {
  const [state, setState] = useState({ visible: [], queue: [] });
  useEffect(() => subscribeToToasts(setState), []);

  return (
    <div className="toast-container" aria-live="polite" aria-atomic="false">
      {state.visible.map((t) => <ToastItem key={t.id} {...t} />)}
    </div>
  );
}
```

## Why this design

- **Module-level singleton store**, not a React Context — satisfies "no provider required at call sites" by construction, since `toast.show()` is just a plain function import, usable from any JS module regardless of whether it's inside the React tree.
- **`ToastItem` owns its own timer**, not the container — this keeps pause/resume logic local to each toast (each one independently pauses only when *it specifically* is hovered/focused) and means the cleanup effect correctly clears its own timer whether the toast unmounts via its own timeout, via a dismiss button click, or via an external `toast.dismiss(id)` call triggering a re-render that removes it from `state.visible`.
- **`dismiss()` handles both visible and still-queued toasts** — a toast the user dismisses without ever seeing (e.g., "Undo delete" clicked from a different UI affordance before the toast even became visible) is correctly removed from the queue too, not just the visible list.
- **`aria-live="polite"`** on the container announces new toasts to screen readers without moving focus, satisfying the requirement that toasts never steal keyboard focus from what the user was doing.
