# Problem: Design an Autocomplete / Typeahead Component

## Problem Statement

Design the API and internal architecture for a reusable autocomplete component supporting:

- Debounced, cancellable search requests with correct handling of out-of-order responses.
- Full keyboard navigation (`ArrowUp`/`ArrowDown`/`Enter`/`Escape`) following the ARIA combobox pattern.
- Distinct `idle`/`loading`/`success`/`empty`/`error` states.
- Both a "fetch results from a URL" mode and a "filter a provided in-memory list" mode (some consumers have small enough datasets to not need a network round trip at all).

## Constraints

- Must not fire a request for every keystroke.
- Must never display results for a query the user has since changed away from.
- `activeIndex` must never point outside the current result set after it changes size.
- Must be usable as a controlled component (`value`/`onChange` for the input, so a parent form library can own the actual field state).

## Solution

```jsx
function useDebouncedValue(value, delayMs) {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const id = setTimeout(() => setDebounced(value), delayMs);
    return () => clearTimeout(id);
  }, [value, delayMs]);
  return debounced;
}

function useAutocompleteData({ query, fetchResults, minLength = 2, delayMs = 250 }) {
  const debouncedQuery = useDebouncedValue(query, delayMs);
  const [state, setState] = useState({ status: 'idle', results: [] });
  const latestId = useRef(0);

  useEffect(() => {
    if (debouncedQuery.length < minLength) {
      setState({ status: 'idle', results: [] });
      return;
    }
    const requestId = ++latestId.current;
    const controller = new AbortController();
    setState((s) => ({ ...s, status: 'loading' }));

    fetchResults(debouncedQuery, controller.signal)
      .then((results) => {
        if (requestId !== latestId.current) return;
        setState({ status: results.length ? 'success' : 'empty', results });
      })
      .catch((err) => {
        if (err.name === 'AbortError' || requestId !== latestId.current) return;
        setState({ status: 'error', results: [] });
      });

    return () => controller.abort();
  }, [debouncedQuery, minLength, fetchResults]);

  return state;
}

function useComboboxKeyboardNav(resultsLength, { onSelect, onClose }) {
  const [activeIndex, setActiveIndex] = useState(-1);
  useEffect(() => { setActiveIndex(-1); }, [resultsLength]);

  function onKeyDown(e) {
    switch (e.key) {
      case 'ArrowDown': e.preventDefault(); setActiveIndex((i) => Math.min(i + 1, resultsLength - 1)); break;
      case 'ArrowUp': e.preventDefault(); setActiveIndex((i) => Math.max(i - 1, 0)); break;
      case 'Enter': if (activeIndex >= 0) onSelect(activeIndex); break;
      case 'Escape': setActiveIndex(-1); onClose?.(); break;
    }
  }
  return { activeIndex, onKeyDown };
}

function Autocomplete({ value, onChange, fetchResults, onSelectResult, getLabel = (r) => r.label }) {
  const { status, results } = useAutocompleteData({ query: value, fetchResults });
  const listboxId = useId();
  const { activeIndex, onKeyDown } = useComboboxKeyboardNav(results.length, {
    onSelect: (i) => onSelectResult(results[i]),
  });

  return (
    <div role="combobox" aria-expanded={results.length > 0} aria-owns={listboxId} aria-haspopup="listbox">
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={onKeyDown}
        aria-autocomplete="list"
        aria-controls={listboxId}
        aria-activedescendant={activeIndex >= 0 ? `${listboxId}-opt-${activeIndex}` : undefined}
      />
      {status === 'loading' && <Spinner />}
      {status === 'empty' && <div role="status">No results</div>}
      {status === 'error' && <div role="alert">Search failed. Try again.</div>}
      {status === 'success' && (
        <ul id={listboxId} role="listbox">
          {results.map((r, i) => (
            <li
              key={r.id}
              id={`${listboxId}-opt-${i}`}
              role="option"
              aria-selected={i === activeIndex}
              onClick={() => onSelectResult(r)}
            >
              {getLabel(r)}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
```

```jsx
// "filter an in-memory list" mode reuses the exact same component by passing a synchronous-looking
// fetchResults that never actually hits the network — no separate code path needed
function inMemoryFetcher(list) {
  return async (query) => list.filter((item) => item.label.toLowerCase().includes(query.toLowerCase()));
}

<Autocomplete
  value={query}
  onChange={setQuery}
  fetchResults={inMemoryFetcher(countries)}
  onSelectResult={(r) => setSelectedCountry(r)}
/>
```

## Why this design

- **`fetchResults` is a single injected async function**, letting both the "hit a network endpoint" and "filter an in-memory array" use cases share the exact same component and hook logic — the component doesn't know or care whether the "async" work is a real network round trip or a synchronous filter wrapped in a resolved Promise; both get the same debounce/cancellation/state-machine treatment uniformly, satisfying the dual-mode requirement without a second code path.
- **The sequence-token guard (`requestId !== latestId.current`) is checked in both the success and error branches**, not just success — an error response for a superseded request must also be discarded, or a fast-typing user could see a stale error message flash for a query they've already moved past.
- **`value`/`onChange` are plain controlled props**, not internal state, so the component composes cleanly with an external form library that needs to own the actual field value (satisfying the "usable as a controlled component" constraint) — the component only owns its *derived* async/UI state (`status`, `results`, `activeIndex`), never the source-of-truth text value itself.
