# Scenario: Nested Modals Break Focus Management

**Scenario:** An "Edit Profile" modal has a "Delete Account" button that opens a confirmation modal on top of it. Both modals use the same `Modal` component with its own independent focus trap. Users report that after canceling the confirmation modal, keyboard focus lands somewhere unpredictable in the edit modal — sometimes the first field, sometimes nowhere obvious — and pressing `Escape` while the confirmation is open sometimes closes *both* modals at once instead of just the confirmation.

**Diagnosis:** Each `Modal` instance runs its own independent focus trap and its own independent `Escape` keydown listener, both attached at mount with no awareness of each other. Two bugs stack:

1. **Escape closing both**: both modals' `keydown` listeners are active simultaneously (both attached to `document`, neither aware the other exists), so a single `Escape` press bubbles/fires both handlers, triggering both `onClose` calls in the same tick.
2. **Unpredictable focus restoration**: the edit modal's focus trap saved "previously focused element" at *its own* mount time (a button on the page behind everything) — but when the confirmation modal closes, it restores focus to *its own* saved previously-focused element (a button inside the edit modal), which conflicts with the edit modal's trap simultaneously trying to re-establish its own focus cycle, since both traps' cleanup/setup logic run in the same synchronous batch with no defined ordering between them.

**Fix — a shared modal stack, where only the topmost modal's trap and `Escape` handler are active (see `snippets/03-portal-based-modal-with-stacking.md` for the full pattern):**

```js
const modalStack = [];

function useModalStack(id, isOpen) {
  useEffect(() => {
    if (!isOpen) return;
    modalStack.push(id);
    return () => {
      const idx = modalStack.indexOf(id);
      if (idx !== -1) modalStack.splice(idx, 1);
    };
  }, [isOpen, id]);

  return modalStack[modalStack.length - 1] === id; // isTopmost
}
```

```jsx
function Modal({ id, open, onClose, children }) {
  const containerRef = useRef(null);
  const isTopmost = useModalStack(id, open);
  useFocusTrap(containerRef, open && isTopmost); // only topmost modal installs its Escape/Tab handlers
  // ...
}
```

With this, opening the confirmation modal automatically **suspends** (not removes) the edit modal's trap — its listeners simply don't fire while it isn't topmost, so `Escape` only ever reaches the confirmation modal's handler. When the confirmation modal unmounts, the stack's new top is the edit modal, whose trap re-activates from wherever it originally was — no competing simultaneous restore, because only one trap is ever "live" (attached and listening) at a time.

**Broader lesson:** any global keyboard/focus behavior (Escape-to-close, Tab-trapping) implemented per-instance without coordination breaks the moment instances can nest — the fix is always some form of shared stack/registry that establishes an explicit "who's currently in control" ordering, rather than each instance independently assuming it's the only one that exists.
