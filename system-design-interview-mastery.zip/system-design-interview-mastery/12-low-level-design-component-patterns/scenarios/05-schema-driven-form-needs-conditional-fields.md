# Scenario: A Schema-Driven Form Needs Deeply Conditional Fields

**Scenario:** An internal admin tool's forms are generated from a JSON schema stored in the database, editable by ops without a deploy. A new requirement: a "Shipping Method" field should show different sub-fields depending on a combination of conditions — "Express" shows a "priority level" dropdown *only* if the destination country is in a specific list *and* the order total exceeds a threshold. The existing schema only supports simple `visibleWhen: { field, equals }` single-condition visibility (see `theory/06-schema-driven-ui-systems.md`), which can't express this.

**Requirements clarification:**
- The condition logic must remain data (storable in the DB, editable by ops), not arbitrary code — the whole point of the schema-driven system is that non-engineers can safely modify it without a deploy or a code review for correctness/security.
- Must support AND/OR combinations and comparisons beyond simple equality (`in`, `greaterThan`).
- Must not become a full programming language embedded in JSON — that reintroduces the security/complexity problem the schema system was built to avoid.

**Design — extend `visibleWhen` to a small, closed expression tree instead of a single condition:**

```json
{
  "type": "select",
  "name": "priorityLevel",
  "label": "Priority Level",
  "visibleWhen": {
    "op": "and",
    "conditions": [
      { "field": "shippingMethod", "op": "equals", "value": "express" },
      { "field": "destinationCountry", "op": "in", "value": ["US", "CA", "UK"] },
      { "field": "orderTotal", "op": "greaterThan", "value": 500 }
    ]
  }
}
```

```js
const operators = {
  equals: (a, b) => a === b,
  in: (a, b) => Array.isArray(b) && b.includes(a),
  greaterThan: (a, b) => Number(a) > Number(b),
  lessThan: (a, b) => Number(a) < Number(b),
};

function evaluate(node, values) {
  if (node.op === 'and') return node.conditions.every((c) => evaluate(c, values));
  if (node.op === 'or') return node.conditions.some((c) => evaluate(c, values));
  const compare = operators[node.op];
  if (!compare) {
    console.warn(`Unknown operator: ${node.op}`);
    return false; // fail closed — an unrecognized condition should hide the field, not show it unpredictably
  }
  return compare(values[node.field], node.value);
}
```

**Why this design and not a full expression language:** a fixed, closed set of operators (`equals`, `in`, `greaterThan`, `lessThan`, plus `and`/`or` combinators) is expressive enough for the vast majority of real conditional-field requirements while remaining trivially safe to store as data and validate against a strict schema (a JSON-schema-of-schemas can enforce that `op` is one of a known enum, `field` references a real field name, etc.) — there's no `eval`, no way to express arbitrary computation, and no way for a malformed or malicious schema entry to do anything worse than fail closed (hide a field) rather than execute unintended code.

**Escape hatch for the genuinely complex 5%:** for logic this system truly can't express (e.g., "priority level's default value depends on a live inventory API call"), the registry pattern's existing extensibility point applies — register a fully custom component (`type: 'custom-priority-selector'`) written in real code for that one specific field, rather than trying to stretch the declarative expression language to cover every conceivable case. This keeps the schema declarative-by-default with code as a scoped, deliberate exception, rather than eroding the whole system's safety property to chase 100% expressiveness.
