# Scenario: Autocomplete Is Flooding the Backend With Requests

**Scenario:** A product search autocomplete fires a request on every `onChange` with no debouncing. The backend team reports the search endpoint is their highest-QPS endpoint by a wide margin, mostly from requests for search terms the user typed for a few hundred milliseconds before typing the next character — i.e., requests whose responses are functionally never seen because the user already moved on.

**Requirements clarification:**
- Reduce request volume without making the UI feel laggy relative to typing speed.
- Handle the case where a fast typist's requests can still arrive out of order.
- Backend wants to know the worst-case request rate per user session for capacity planning.

**Design — layered mitigation, not a single fix:**

1. **Debounce at 250ms** — delays firing until the user pauses, which for typical typing speed (roughly 200-300ms between keystrokes for average typists, faster for fast typists) collapses many keystrokes into a single request in the common case, without feeling laggy since 250ms is under the threshold most users perceive as "slow":

```js
const debouncedQuery = useDebouncedValue(rawQuery, 250);
```

2. **Minimum query length gate** — don't fire for 1-character queries at all (`minLength: 2`), since single-character searches are both low-signal (huge unfiltered result sets) and disproportionately expensive on the backend (broad prefix scans) relative to their usefulness.

3. **Cancel superseded requests with `AbortController`** — this doesn't reduce the *count* of requests sent from the client's perspective as much as debouncing does, but it reduces **backend work actually completed**, since an aborted fetch (if the client disconnects fast enough, and depending on backend framework support for detecting client aborts) can let the server bail out of an in-progress expensive query rather than compute a result nobody will see.

4. **Client-side response caching for repeated queries** (e.g., user types "lap", deletes to "la", retypes "lap") — a simple `Map<query, results>` cache with a short TTL avoids re-hitting the network for a query already answered recently:

```js
const cache = new Map();
async function search(query) {
  if (cache.has(query)) return cache.get(query);
  const results = await fetchResults(query);
  cache.set(query, results);
  setTimeout(() => cache.delete(query), 60_000); // short TTL — search results can go stale
  return results;
}
```

5. **Worst-case rate for capacity planning**: with a 250ms debounce and no cache hit, worst case is one request every 250ms per actively-typing user — this is the number to hand backend for capacity planning (`1000ms / 250ms = 4 req/s/user` sustained ceiling during active typing, in practice far lower once the cache and min-length gate are factored in for realistic typing patterns).

**Result:** debouncing addresses the bulk of the waste (collapsing keystroke-level requests into pause-level requests), the length gate removes the cheapest-to-avoid, worst-signal requests entirely, cancellation reduces wasted backend compute for the requests that do fire but get superseded, and the cache absorbs backtrack/retype patterns — each layer addressing a distinct part of the request-volume problem rather than one mechanism trying to do everything.
