# Scenario: Design a Toast System for High-Frequency Events

**Scenario:** A collaborative document editor shows a toast every time a teammate makes a change ("Alice edited paragraph 2"). During an active co-editing session with 4 people, this can fire 10+ toasts per minute. Users complain the screen is constantly cluttered with a stack of near-identical toasts, several of which they never even get to read before the next one pushes them out.

**Requirements clarification:**
- Toasts must still surface important one-off events (errors, "document saved") distinctly from this high-frequency ambient activity feed.
- The UI must never let toast volume overwhelm the screen, regardless of how many events fire.
- Users shouldn't lose the *information* even if they don't see every individual toast.

**Design:**

1. **Separate the high-frequency "activity" stream from the low-frequency "notification" stream entirely** — they have different UX needs and shouldn't share one queue/cap. Ambient collaborator-activity events get a dedicated, compact, always-visible **activity indicator** (e.g., "3 recent changes" with an expandable log) rather than individual toasts — this is the core design correction: not every event should be a transient toast at all.

2. **For genuinely toast-worthy events** (save confirmation, connection lost, a conflict that needs the user's attention), keep the existing capped-queue toast system (max 3 visible, rest queued — see `theory/02-toast-notification-system-architecture.md`), but add **coalescing** for same-type events that occur faster than the user can read them:

```js
function show(message, options = {}) {
  const { coalesceKey } = options;
  if (coalesceKey) {
    const existing = state.visible.find((t) => t.coalesceKey === coalesceKey);
    if (existing) {
      // update the existing toast's count/message instead of pushing a new one
      state = {
        ...state,
        visible: state.visible.map((t) =>
          t.id === existing.id ? { ...t, count: (t.count ?? 1) + 1, message: buildCoalescedMessage(t, message) } : t
        ),
      };
      emit();
      return existing.id;
    }
  }
  // ...existing push-to-visible-or-queue logic
}
```

```js
toast.show('Alice edited paragraph 2', { coalesceKey: 'collab-activity' });
// second rapid call updates the SAME toast: "Alice and 2 others made changes" instead of stacking a new one
```

3. **Rate-limit coalesced toasts to a minimum visible duration** (e.g., don't let a coalesced toast update its text more than once every 500ms) so rapid bursts render as a smoothly-updating counter rather than visibly flickering text on every event.

**Result:** individual save/error events still get their own clear, capped toast queue; ambient collaborator activity moves out of the toast system entirely into a dedicated low-attention UI; and any remaining same-type rapid-fire toasts coalesce into one updating toast instead of stacking. The key insight worth stating explicitly in an interview: a toast system's queue cap and coalescing logic are damage control — the *real* fix for a "too many toasts" complaint is usually recognizing that not every event belongs in the toast system at all.
