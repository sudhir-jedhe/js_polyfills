# Scenario: Virtualize a 10,000-Row Table With Variable Row Heights

**Scenario:** A support-ticket table with 10,000 rows renders fully in the DOM today, causing multi-second scroll jank and a large initial render cost. Rows have variable height — a ticket with a long description or multiple tags wraps to 2-3 lines, while most rows are single-line. Product wants this fast without regressing the ability for rows to wrap naturally (no forced truncation).

**Why fixed-height virtualization doesn't directly apply:** the simple `scrollTop / itemHeight` math (see `theory/04-virtualized-list-windowing-math.md`) assumes every row has identical height, letting you compute the visible index range with pure arithmetic. Variable heights break that assumption — you can't know a row's height without having rendered (or otherwise measured) it, which creates a chicken-and-egg problem: you need heights to know what's visible, but you only want to render what's visible.

**Design — measure-and-cache with a cumulative offset array:**

1. **Start with an estimated height** per row (e.g., the single-line height, `48px`) for anything not yet measured — this gives an immediately-correct-enough total scroll height so the scrollbar doesn't jump around wildly on first render.
2. **Render the estimated visible range**, then **measure actual rendered row heights** via `ResizeObserver` (handles dynamic content like async-loaded tags) or a ref callback on mount.
3. **Maintain a cumulative offset array** (`offsets[i]` = sum of all row heights before row `i`) updated incrementally as real measurements replace estimates — this is what lets you binary-search "which index is at `scrollTop`" in O(log n) instead of re-summing from scratch on every scroll event.

```js
class RowHeightCache {
  constructor(count, estimatedHeight) {
    this.heights = new Array(count).fill(estimatedHeight);
    this.offsets = this._computeOffsets();
  }
  _computeOffsets() {
    const offsets = [0];
    for (let i = 0; i < this.heights.length; i++) {
      offsets.push(offsets[i] + this.heights[i]);
    }
    return offsets;
  }
  setMeasured(index, height) {
    if (this.heights[index] === height) return;
    this.heights[index] = height;
    this.offsets = this._computeOffsets(); // could be optimized to a partial recompute for large lists
  }
  totalHeight() {
    return this.offsets[this.offsets.length - 1];
  }
  findStartIndex(scrollTop) {
    let lo = 0, hi = this.offsets.length - 1;
    while (lo < hi) {
      const mid = (lo + hi) >> 1;
      if (this.offsets[mid] < scrollTop) lo = mid + 1; else hi = mid;
    }
    return Math.max(0, lo - 1);
  }
}
```

4. **Accept a self-correcting scrollbar**: as the user scrolls into previously-unmeasured territory, the total height (and therefore scrollbar size/position) shifts slightly as estimates get replaced by real measurements — a small, standard tradeoff of measure-and-cache virtualization, and worth calling out explicitly as an accepted limitation rather than something to eliminate entirely (eliminating it requires knowing every row's real height upfront, defeating the point of not rendering everything).

**Full recompute cost caveat**: naively recomputing the entire `offsets` array on every single measured row (as shown above) is O(n) per row, which is fine for occasional corrections but too slow if most of 10,000 rows are unmeasured on first load — production implementations (e.g., `react-virtual`/TanStack Virtual) use a Fenwick tree / binary-indexed tree or a lazily-recomputed "dirty from index X onward" strategy to keep updates closer to O(log n) instead.

**Result:** initial render cost drops from "lay out 10,000 rows" to "lay out ~20-30 visible + overscan rows," rows still wrap naturally with real measured heights, and the scrollbar converges to accurate as the user scrolls, at the cost of some implementation complexity beyond the fixed-height case — which is exactly the tradeoff worth naming explicitly when a table has genuinely variable content instead of reaching for a fixed-height library out of habit.
