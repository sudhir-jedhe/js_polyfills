# Scenario: A Checkout Wizard Loses Progress on Accidental Refresh

**Scenario:** A 5-step checkout flow (cart review → shipping → payment → review → confirm) has no persistence — an accidental refresh, a browser crash, or a user closing the tab to check something else and coming back loses all progress, forcing a restart. Analytics show this correlates with a measurable share of abandoned checkouts. Product wants progress preserved across a refresh/reopen within the same browser session, without persisting sensitive payment details insecurely.

**Requirements clarification:**
- Must survive a page refresh and a closed-then-reopened tab (same session).
- Must NOT persist raw payment card details anywhere in browser storage, even temporarily — a compliance/security hard constraint (PCI-DSS scope reasons), not just a nice-to-have.
- Should expire/clear after a reasonable inactivity window (an abandoned draft checkout shouldn't resurrect itself weeks later with stale pricing).
- Must handle the case where cart contents changed server-side (price change, item went out of stock) since the draft was saved.

**Design:**

1. **Persist a field-level allowlist, not the whole state blob** — an explicit list of which fields are safe to write to `sessionStorage`, so a future engineer adding a new field to the wizard's state doesn't accidentally leak something sensitive by a blanket "persist everything" approach:

```js
const PERSISTABLE_FIELDS = ['step', 'shippingAddress', 'selectedShippingMethod', 'cartSnapshot'];
// deliberately excludes: cardNumber, cvv, and any other payment step 3 fields

function persistState(state) {
  const toPersist = Object.fromEntries(
    Object.entries(state).filter(([key]) => PERSISTABLE_FIELDS.includes(key))
  );
  sessionStorage.setItem('checkout-draft', JSON.stringify({ ...toPersist, savedAt: Date.now() }));
}
```

2. **`sessionStorage`, not `localStorage`** — scoped to the tab's session by design, which naturally satisfies "don't resurrect a stale draft weeks later" for the common case (closing the browser clears it), while still surviving an in-session refresh.

3. **Expiry check on rehydrate**, as a second layer beyond session scoping (covers a tab left open/backgrounded for a long time):

```js
function loadDraft() {
  const raw = sessionStorage.getItem('checkout-draft');
  if (!raw) return null;
  const draft = JSON.parse(raw);
  const ONE_HOUR = 60 * 60 * 1000;
  if (Date.now() - draft.savedAt > ONE_HOUR) {
    sessionStorage.removeItem('checkout-draft');
    return null;
  }
  return draft;
}
```

4. **Re-validate the cart snapshot against live server state on rehydrate**, rather than trusting the persisted `cartSnapshot` blindly — prices and stock can change between save and resume:

```js
async function rehydrateAndReconcile(draft) {
  const liveCart = await fetchCart(draft.cartSnapshot.cartId);
  const priceChanged = liveCart.total !== draft.cartSnapshot.total;
  const stockIssues = liveCart.items.filter((i) => i.available < i.quantity);
  if (priceChanged || stockIssues.length > 0) {
    return { ...draft, needsReview: true, liveCart }; // jump back to review step 1, flagged, instead of resuming silently at step 4
  }
  return draft;
}
```

5. **On reaching the resumed draft's step, since payment details were never persisted, step 3 always starts empty** even if the user had previously reached step 4 — this is a deliberate, disclosed tradeoff (a small re-entry of payment info) traded for never storing sensitive data client-side, and worth stating explicitly as the reasoning rather than treating it as an oversight.

**Result:** a refresh or accidental tab close during shipping/review steps resumes seamlessly; a resumed draft with stale pricing/stock is caught and surfaced rather than silently completing checkout against outdated numbers; and payment details are never at risk of being found in browser storage, satisfying the compliance constraint without weakening the actual UX improvement for the 4 non-payment steps.
