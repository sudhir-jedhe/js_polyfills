# Interview Q&A — Toast and Modal Component Design

**Q: Why can't a toast system be built from a component owned by whatever renders `<ToastContainer />`?**
Toasts need to be triggered imperatively from anywhere in the app — deep in an API error interceptor, a form handler several components removed from the container. Prop-drilling a setter function through the whole tree to reach every possible trigger site doesn't scale. The standard architecture is a module-level singleton store (simple pub-sub or an external store) that any code can call into directly, with the container subscribing to it and rendering whatever's currently in the store.

**Q: Why does a naive `setTimeout`-based toast auto-dismiss break the moment a user hovers over the toast?**
A single fire-and-forget `setTimeout` counts down to completion regardless of user interaction — hovering doesn't pause it unless you explicitly wire `onMouseEnter`/`onMouseLeave` to clear the timer and track *remaining* time (elapsed subtracted from original duration), then restart it on mouse-leave. Without that, a toast can dismiss itself out from under a user actively reading it or about to click an action button.

**Q: Why does a modal need to be rendered via a portal instead of directly in the component tree where it's triggered?**
`position: fixed`/z-index can be broken by ancestor elements with `transform`, `overflow: hidden`, or their own stacking contexts — a modal rendered deep inside such an ancestor can be visually clipped or mispositioned. Portaling renders the modal's DOM as a direct child of `document.body` (or a dedicated root node), sidestepping any ancestor's layout/stacking interference, while React's synthetic event system still bubbles the portaled content through its *logical* React tree, not the physical DOM tree.

**Q: Does `aria-modal="true"` trap keyboard focus inside a dialog?**
No — it's purely a semantic hint for assistive technology, telling a screen reader to treat content outside the dialog as inert. It has no effect on actual `Tab` key behavior; real focus trapping requires explicit JavaScript that intercepts `Tab`/`Shift+Tab` and redirects focus to stay within the dialog's focusable elements.

**Q: How should z-index and scroll-locking work when multiple modals can stack (a confirmation dialog opened from within another modal)?**
Z-index should be derived from each modal's position in a shared, module-level stack (each newly-opened modal gets pushed and assigned a higher z-index than whatever's already open), rather than a single hardcoded constant that breaks with more than one modal. Scroll-locking (`document.body.style.overflow = 'hidden'`) needs to be reference-counted across that same stack — only released when the *last* open modal closes, not the first one to unmount, otherwise closing an inner modal prematurely re-enables background scroll while an outer modal is still open.

**Q: When two modals are open simultaneously, which one's focus trap and `Escape` handler should be active?**
Only the topmost (most recently opened) modal's — determined by the same shared stack used for z-index. Lower modals' traps and `Escape` listeners should be suspended while covered, otherwise both fire simultaneously on a single `Escape` press (closing both at once) and their focus-restoration logic can fight each other on close.
