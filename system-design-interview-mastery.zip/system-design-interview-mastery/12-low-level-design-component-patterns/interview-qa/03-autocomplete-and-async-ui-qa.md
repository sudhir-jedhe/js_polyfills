# Interview Q&A — Autocomplete and Async UI

**Q: Why is debouncing alone insufficient to prevent an autocomplete from showing stale results?**
Debouncing reduces how many requests fire, but does nothing about the *order in which responses arrive*. Even with debouncing, two requests can still be close enough in time (or reordered by network conditions — a fast connection answering a later request before a slower one answers an earlier request) that a stale response arrives and overwrites a newer, already-displayed result if nothing checks whether it's still the most recent request.

**Q: What are the two standard mechanisms for handling out-of-order autocomplete responses, and why use both?**
`AbortController`, which actually cancels the superseded request (saving real network/server work), and a sequence-token/request-id guard, which defends even against responses that can't be or weren't successfully aborted (some environments don't propagate abort signals cleanly through every layer, or the request was already too far along server-side to meaningfully cancel). Production code typically uses both — `AbortController` for efficiency, the sequence-token check as a correctness guarantee that doesn't depend on the cancellation actually working.

**Q: How should `activeIndex` (the currently keyboard-highlighted option) behave when the result set changes between keystrokes?**
It must reset (typically to -1, "nothing highlighted") whenever the options array changes shape/length — otherwise, arrowing to index 4 in a 6-item list and then having that list narrow to 2 items on the next keystroke leaves `activeIndex` pointing past the end of the new list, breaking `Enter`-to-select or causing it to select the wrong (or nonexistent) item.

**Q: What ARIA pattern applies to an autocomplete/combobox, and why does `aria-activedescendant` matter specifically?**
The ARIA combobox pattern: the input gets `role="combobox"`, `aria-expanded`, and `aria-controls` pointing at the listbox's id. `aria-activedescendant` points at the id of the currently keyboard-highlighted option and updates as the user arrows through results — this lets a screen reader announce which option is highlighted without moving actual DOM focus away from the text input, which is essential since focus has to stay in the input for typing to keep working while navigating suggestions with arrow keys.

**Q: Why should "loading," "empty," and "error" be modeled as distinct explicit states rather than derived from a single results array?**
Collapsing them into "does the array have items" loses information the UI needs to render correctly — a naive boolean check can't distinguish "no query typed yet" from "request in flight" from "request succeeded with zero matches" from "request failed," leading to bugs like a spinner that never clears after a failed request, or an "empty" message flashing between keystrokes before the debounced request has even fired.
