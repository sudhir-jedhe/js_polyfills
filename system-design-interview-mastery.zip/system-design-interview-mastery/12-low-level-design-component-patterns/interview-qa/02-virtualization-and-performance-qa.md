# Interview Q&A — Virtualization and Performance

**Q: Explain the core math behind fixed-height list virtualization.**
Given `scrollTop`, `itemHeight`, and `containerHeight`, the first visible index is `Math.floor(scrollTop / itemHeight)` and the last is `Math.ceil((scrollTop + containerHeight) / itemHeight)`. Only that index range (plus a small overscan buffer on each side) is actually rendered, each positioned absolutely at `top: index * itemHeight` inside an outer wrapper whose height is set to `itemCount * itemHeight` purely so the scrollbar's size and range stay correct, even though almost none of that height contains real DOM content.

**Q: What is "overscan" and why include it?**
Rendering a few extra rows beyond the strictly-visible range on each side. Without it, fast scrolling (or keyboard navigation jumping past the visible edge) can show a flash of blank space before the next render commits, since there's a frame or two of lag between a scroll event and the newly-visible rows actually painting. It's a tradeoff — too much overscan erodes the point of virtualizing at all.

**Q: Why is using the array index as a list item's `key` a bug specifically in a virtualized list, even though it's a general React anti-pattern anywhere?**
In a virtualized list, the same screen *position* (and therefore the same local slice index within the rendered window) gets reused for different underlying data items as the user scrolls — React, matching component instances by key, reuses the same component instance (and any of its local state) for whatever data now occupies that key, rather than mounting a fresh instance. Any row-local state (an expanded/collapsed flag, a local input) then incorrectly "sticks" to the wrong item as scrolling changes which data occupies a given index. Keying by the item's own stable identity (its id) avoids this because React can then tell "this is genuinely a new/different item" correctly on every render.

**Q: How does virtualization handle rows with variable, unknown-until-rendered heights?**
Fixed-height arithmetic breaks down. The standard approach is measure-and-cache: assume an estimated height for unmeasured rows so the total scroll height is approximately right immediately, render and measure actual heights via `ResizeObserver` or ref callbacks as rows come into view, and maintain a cumulative offset (prefix-sum) array — binary-searched to find the start index for a given `scrollTop` in O(log n) — that gets corrected as real measurements replace estimates. The scrollbar self-corrects slightly as the user scrolls into previously-unmeasured territory, which is an accepted tradeoff, not a bug.

**Q: Why can't you naively recompute the full cumulative-offset array on every single row measurement in a 10,000-row variable-height list?**
That's an O(n) operation per measured row — with thousands of initially-unmeasured rows, that's O(n²) total on first load, which defeats the performance goal virtualization exists for. Production implementations use a Fenwick tree (binary indexed tree) or a "dirty from index X" lazy recomputation strategy to keep per-measurement updates closer to O(log n).

**Q: What's the tradeoff of setting overscan too high vs. too low?**
Too low: visible blank-space flashes during fast scrolling or rapid keyboard navigation, since freshly-needed rows haven't rendered yet by the time they're needed on screen. Too high: you're rendering (and keeping in the DOM, subject to layout/paint cost) meaningfully more nodes than are ever visible, eroding the performance benefit virtualization is meant to provide — it becomes a smaller-scale version of the original "render everything" problem.
