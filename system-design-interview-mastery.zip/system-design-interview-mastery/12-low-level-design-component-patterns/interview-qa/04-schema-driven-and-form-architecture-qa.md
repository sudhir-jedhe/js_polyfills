# Interview Q&A — Schema-Driven UI and Form Architecture

**Q: What is the core architectural pattern behind a schema-driven UI system?**
A renderer walks a data-described schema (JSON/JS object describing fields/layout) and, for each node, looks up its `type` in a component registry to find the actual component to render, passing schema-derived props. The registry is the extensibility point — adding a new field type is adding one registry entry, never touching the renderer's own logic, which is what keeps the system generic over an open-ended set of field types.

**Q: Why shouldn't conditional field logic in a schema be expressed as raw embedded JavaScript?**
The schema is meant to be safely storable/editable by non-engineers (or generated from a backend/CMS), and embedding arbitrary executable code turns it into an attack surface (a stored-XSS-like risk if the schema source isn't fully trusted) and a maintainability problem (can't statically validate it). The standard fix is a small, closed expression structure — a fixed set of operators (`equals`, `in`, `greaterThan`) combined via `and`/`or` — expressive enough for the common case while remaining pure data that can be validated against a strict schema.

**Q: In a multi-step form, why is per-step local component state (each step owning its own `useState`) usually the wrong architecture?**
It breaks the moment you need cross-step logic — validation or visibility on one step depending on another step's value, or a final review step summarizing all answers. The correct architecture centralizes all form data in one shared source of truth (a reducer, or a form library instance) that every step reads from and writes into; step components become thin views over a slice of that shared state, not independent state owners.

**Q: Why is caching a step's "is this step valid" flag the first time it passes validation a bug-prone pattern in a wizard?**
Because step validity is a *derived* value — a function of the current form values — not independent state. If the user navigates backward and changes an earlier answer that an already-passed later step's requirements depend on (e.g., changing a plan selection that determines whether payment fields are even relevant), the cached "valid" flag goes stale and no longer reflects reality. The fix is always re-deriving validity from current values on every check, never trusting a cached pass/fail from an earlier point in time.

**Q: What should and shouldn't be persisted when adding refresh-survival to a multi-step form (e.g., a checkout wizard)?**
An explicit allowlist of non-sensitive fields (current step, shipping address, selected options) — never sensitive data like payment card details, which should never touch browser storage even temporarily for compliance reasons. `sessionStorage` (not `localStorage`) is typically the right scope, since it naturally clears when the browser closes, combined with an explicit time-based expiry check on rehydrate to handle a tab left open/backgrounded for a long time.

**Q: When resuming a persisted multi-step form, why is it important to re-validate persisted data against live server state rather than trusting it directly?**
The underlying data (cart contents, pricing, stock availability) can change between when the draft was saved and when it's resumed — silently resuming into a later step with stale assumptions (e.g., a since-changed price or an item that went out of stock) risks completing a transaction against outdated information. A robust design reconciles the persisted draft against fresh server state on rehydrate and routes the user back to an earlier step for review if a meaningful discrepancy is detected, rather than resuming silently.
