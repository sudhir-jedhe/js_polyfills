# Virtualized List: Windowing Math

Rendering 10,000 rows in the DOM at once tanks scroll performance and memory, even if each row is simple — the browser has to lay out, paint, and keep alive far more nodes than are ever visible. Virtualization (a.k.a. windowing) renders only the rows currently in (or near) the viewport, repositioning them as the user scrolls, while a spacer element preserves the *illusion* of the full scrollable height.

## Fixed-height windowing math

The core insight: if every row has the same fixed height, you can compute exactly which row indices are visible with pure arithmetic — no need to measure anything at render time.

```js
function getVisibleRange({ scrollTop, containerHeight, itemHeight, itemCount, overscan = 3 }) {
  const startIndex = Math.max(0, Math.floor(scrollTop / itemHeight) - overscan);
  const endIndex = Math.min(
    itemCount - 1,
    Math.ceil((scrollTop + containerHeight) / itemHeight) + overscan
  );
  return { startIndex, endIndex };
}
```

- `scrollTop / itemHeight` gives the index of the first row whose top edge is at or above the viewport's top — floor it to get the first *partially* visible row.
- `(scrollTop + containerHeight) / itemHeight` gives the index at the viewport's bottom edge — ceil it for the last partially-visible row.
- **`overscan`** renders a few extra rows beyond the strict visible range on each side, so fast scrolling (or a screen reader/keyboard tabbing just past the edge) doesn't show a flash of blank space before the next render commits.

## Positioning rendered rows and faking total scroll height

```jsx
function VirtualList({ items, itemHeight, containerHeight }) {
  const [scrollTop, setScrollTop] = useState(0);
  const { startIndex, endIndex } = getVisibleRange({
    scrollTop, containerHeight, itemHeight, itemCount: items.length,
  });
  const visibleItems = items.slice(startIndex, endIndex + 1);
  const totalHeight = items.length * itemHeight; // the "fake" full-content height

  return (
    <div
      style={{ height: containerHeight, overflowY: 'auto' }}
      onScroll={(e) => setScrollTop(e.currentTarget.scrollTop)}
    >
      <div style={{ height: totalHeight, position: 'relative' }}>
        {visibleItems.map((item, i) => {
          const index = startIndex + i;
          return (
            <div
              key={item.id}
              style={{
                position: 'absolute',
                top: index * itemHeight,
                height: itemHeight,
                width: '100%',
              }}
            >
              {item.content}
            </div>
          );
        })}
      </div>
    </div>
  );
}
```

The outer scrollable `div` gets a fixed `containerHeight`; the inner `div` is given the *full* `totalHeight` (10,000 × row height) purely so the scrollbar's size/range is correct, even though almost none of that height contains real rendered content — only `endIndex - startIndex` rows actually exist in the DOM at any time, each `position: absolute`-placed at its true offset via `top: index * itemHeight`.

## Variable-height rows: the harder case

Fixed-height math breaks the moment rows have different heights (e.g., chat messages, comments with variable text length) — you can no longer compute an index from `scrollTop` with a single division. Two standard approaches:

1. **Measure and cache**: render row, measure its actual height via `ResizeObserver` or a ref callback after mount, cache it in an array/map keyed by index, and maintain a running **prefix-sum array** of cumulative heights so a binary search over that array gives you the start index for a given `scrollTop` in O(log n).
2. **Estimate then correct**: assume an average/estimated height for unmeasured rows (so total scroll height is approximately right immediately), then patch the prefix-sum array as real measurements come in, causing a small scrollbar-size correction as the user scrolls through previously-unmeasured content.

```js
// binary search over a cumulative-height prefix sum to find the start index for a scrollTop
function findStartIndex(prefixSums, scrollTop) {
  let lo = 0, hi = prefixSums.length - 1;
  while (lo < hi) {
    const mid = (lo + hi) >> 1;
    if (prefixSums[mid] < scrollTop) lo = mid + 1; else hi = mid;
  }
  return lo;
}
```

## Key interview talking points

- **Why `key` must be stable and based on item identity, not array index** — with virtualization, the *same DOM node* gets reused for different logical rows as you scroll (React recycles component instances by key), so an index-based key causes visual/state bugs (e.g., a row's local input state "sticking" to the wrong content) when the underlying data shifts.
- **`overscan` is a latency/memory tradeoff**, not free — too small causes visible blank flashes on fast scroll or keyboard nav; too large erodes the whole point of virtualizing.
- **Horizontal virtualization** and **grid virtualization** (both axes) are the same core math applied twice, independently, along each axis.
