# Schema-Driven / Config-Driven UI Systems

A schema-driven UI system renders forms, dashboards, or entire pages from a **data description** (JSON/JS object) rather than hand-written JSX per screen — the classic use case is an admin panel or form builder where product/ops teams need to add or reconfigure fields without a code deploy, or where the same form structure needs to be generated from a backend-defined schema (e.g., derived from an API's OpenAPI spec or a CMS content model).

## The core architecture: schema → component registry → renderer

```
schema (JSON) → renderer walks schema → looks up each field's `type` in a component registry → renders the matching component, passing schema-derived props
```

```js
const schema = {
  fields: [
    { type: 'text', name: 'fullName', label: 'Full Name', required: true },
    { type: 'select', name: 'country', label: 'Country', options: ['US', 'UK', 'IN'] },
    { type: 'checkbox', name: 'subscribe', label: 'Subscribe to updates' },
  ],
};

const componentRegistry = {
  text: TextField,
  select: SelectField,
  checkbox: CheckboxField,
};

function SchemaForm({ schema, values, onChange }) {
  return schema.fields.map((field) => {
    const Component = componentRegistry[field.type];
    if (!Component) {
      console.warn(`Unknown field type: ${field.type}`);
      return null; // fail gracefully — one bad field shouldn't crash the whole form
    }
    return (
      <Component
        key={field.name}
        {...field}
        value={values[field.name]}
        onChange={(v) => onChange(field.name, v)}
      />
    );
  });
}
```

The **component registry** is the extensibility point: adding a new field type means adding one entry to the registry, not touching the renderer's logic. This is the same architectural idea as a plugin system — the renderer is generic over "anything registered," never hardcoded to a fixed set of types.

## Conditional fields and cross-field logic

Real forms need fields that appear/disappear or change validation based on other fields' values (`state` field only shown if `country === 'US'`). The schema needs a declarative way to express this without embedding arbitrary code (embedding raw JS in a JSON schema is a security/maintainability red flag if the schema can come from an untrusted or non-engineering source):

```js
{
  type: 'select', name: 'state', label: 'State',
  visibleWhen: { field: 'country', equals: 'US' },
  options: US_STATES,
}
```

```js
function isVisible(field, values) {
  if (!field.visibleWhen) return true;
  const { field: dep, equals } = field.visibleWhen;
  return values[dep] === equals;
}
```

For more complex logic than simple equality (multi-condition, computed values), schemas often support a small, deliberately-restricted expression language (e.g., JSONLogic) rather than arbitrary `eval`-able code — this keeps the schema data-only and safely serializable/storable, at the cost of expressiveness for genuinely complex cases (which usually fall back to a custom field component with real code, registered normally).

## Validation from the schema

```js
{ type: 'text', name: 'email', validate: { required: true, pattern: '^[^@]+@[^@]+$', message: 'Invalid email' } }
```

A generic validation engine walks the schema the same way the renderer does, applying each field's `validate` rules against the current values — this is what lets the *same* schema drive both rendering and validation without duplicating field definitions in two places.

## Layout as data too

Beyond individual fields, layout (grouping, columns, tabs, steps) is often also schema-described:

```js
{
  type: 'section', title: 'Billing', columns: 2,
  fields: [/* ... */],
}
```

...recursively rendered the same way — a `section` type in the registry knows how to render its own `fields` array using the same `SchemaForm` renderer, making the system naturally support nesting without special-casing it.

## Tradeoffs to name explicitly in an interview

- **Pro**: non-engineers (or a backend schema) can add/reorder/reconfigure fields without a frontend deploy; one renderer serves unlimited form shapes; validation and rendering stay in sync by construction.
- **Con**: harder to express truly bespoke UI/interaction (a field whose behavior depends on a complex multi-step wizard flow strains a declarative schema) — the registry pattern's escape hatch (a fully custom registered component) is what keeps this from being a hard ceiling, but it means the system is really "declarative for the common case, code for the exceptional case," which is the honest way to frame it rather than claiming it can express literally anything.
- **Con**: type safety is weaker unless the schema itself is validated against a strict shape (e.g., a Zod/JSON-schema-validated schema-of-schemas) — a malformed schema fails at render time, not compile time, unless deliberately guarded against.
