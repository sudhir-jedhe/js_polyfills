# Component API Design Principles

"Low-level design" for frontend interviews means designing the *API surface and internal architecture* of a reusable UI component or system — not the pixels, the contract. Before designing any specific component (toast, modal, autocomplete), you need a shared vocabulary for the axes every component API decision falls along, because interviewers evaluate whether you can reason about these tradeoffs generically, not just recite one component's implementation.

## Controlled vs. uncontrolled

| | Controlled | Uncontrolled |
|---|---|---|
| Who owns state | Parent (passes `value` + `onChange`) | Component itself (internal `useState`, exposes imperative getters or refs) |
| Parent can veto/transform input | Yes — parent decides what `value` becomes next | No — component decides its own next state |
| Boilerplate for simple cases | More (parent must wire state) | Less (works with zero parent state) |
| Needed for | Form libraries, syncing multiple components to one source of truth | Simple, self-contained widgets (an uncontrolled accordion, a simple modal's open state) |

```jsx
// controlled
<Autocomplete value={query} onChange={setQuery} />

// uncontrolled, with an escape hatch for imperative access
<Autocomplete defaultValue="" ref={autocompleteRef} />
// autocompleteRef.current.clear()
```

Many production component libraries support **both**, defaulting to uncontrolled but accepting an optional `value`/`onChange` pair that, when present, takes over — this is the pattern React itself uses for `<input>`.

## Imperative vs. declarative API

Declarative: describe the desired end state via props, let the component figure out how to get there (`<Toast open={isOpen} />`). Imperative: call a method to trigger a one-off action that doesn't map cleanly to persistent state (`toast.show('Saved!')`, `modalRef.current.focus()`).

Toasts are the canonical case where declarative APIs get awkward: a toast is fundamentally an *event* ("show this now"), not a piece of state that persists and gets re-rendered from — trying to model "show a toast" as `<Toast messages={[...]} />` re-rendered from a growing array works, but a `toast.show()` imperative call (usually backed by a singleton queue manager outside the render tree) tends to map to the mental model more directly and avoids prop-drilling a dispatcher through the whole app.

## Headless vs. styled

- **Headless**: ships behavior/logic/accessibility (focus management, ARIA attributes, keyboard handling) with zero visual opinion — consumer supplies all markup/CSS (e.g., a `useCombobox()` hook that returns props to spread onto your own elements).
- **Styled**: ships a complete, opinionated visual component, usually themeable via props/CSS variables.

Headless is the right default for a **design-system-agnostic library** meant to be reused across products with different visual languages; styled is right for an **internal, single-product component** where consistency matters more than reuse flexibility. A common production pattern is a headless "engine" package plus a thin styled wrapper built on top of it for the house design system.

## Composition vs. configuration (props explosion)

```jsx
// configuration — every variation is a new prop, eventually unmanageable
<Modal showCloseButton footer={<Footer />} footerAlign="right" size="lg" closeOnOverlayClick />

// composition — consumer assembles the pieces they need
<Modal>
  <Modal.Header>Title <Modal.CloseButton /></Modal.Header>
  <Modal.Body>...</Modal.Body>
  <Modal.Footer align="right">...</Modal.Footer>
</Modal>
```

Composition (compound components) scales better as a component's feature surface grows, because new layout variations don't require new boolean props — they're just different arrangements of the same sub-components. The tradeoff is more setup code for the simple case, which is why many libraries offer a simple configured default *and* an escape hatch into composition for advanced cases.

## The core interview framing

For any component, be ready to answer: **what's the minimal prop surface for the 80% use case, what's the escape hatch for the 20% (ref-based imperative API, render props, or slot/composition), and where does internal state live vs. what's lifted to the consumer?** This is the rubric every component design in this topic gets evaluated against.
