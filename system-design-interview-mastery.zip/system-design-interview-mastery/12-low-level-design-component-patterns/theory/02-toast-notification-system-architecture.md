# Toast Notification System Architecture

A toast system looks trivial ("just render some divs") until you account for queueing under burst load, auto-dismiss timers that must pause on hover, stacking/reflow animation, and the fact that any component anywhere in the tree needs to be able to trigger one without prop-drilling a setter through the whole app.

## The core architectural decision: a singleton store outside the render tree

Toasts are triggered imperatively (`toast.success('Saved')`) from anywhere — deep in a form's submit handler, in an API error interceptor, in a click handler three components removed from where `<ToastContainer />` renders. This rules out plain component state owned by whichever component happens to render the container. The standard architecture is a **module-level store** (a simple pub-sub, or a lightweight external store like Zustand) that the container subscribes to, and a plain exported function (`toast.show(...)`) that any code can call to push into it.

```
any code, anywhere  --toast.show(msg)-->  singleton queue/store  --subscription-->  <ToastContainer /> renders current list
```

This decouples "who can trigger a toast" (everyone, no context/props needed) from "who renders it" (one container, mounted once near the root).

## Queueing and concurrency limits

Under burst conditions (e.g., 5 API calls fail simultaneously), showing 5 toasts stacked can overwhelm the UI. A production toast system typically caps **visible** toasts (e.g., max 3) and queues the rest:

```js
const MAX_VISIBLE = 3;

function reducer(state, action) {
  switch (action.type) {
    case 'ADD': {
      const toast = { id: crypto.randomUUID(), ...action.payload };
      if (state.visible.length < MAX_VISIBLE) {
        return { ...state, visible: [...state.visible, toast] };
      }
      return { ...state, queue: [...state.queue, toast] };
    }
    case 'DISMISS': {
      const visible = state.visible.filter((t) => t.id !== action.id);
      const [next, ...restQueue] = state.queue;
      return { visible: next ? [...visible, next] : visible, queue: restQueue };
    }
  }
}
```

## Auto-dismiss timing: pause on hover/focus

A naive `setTimeout(dismiss, 4000)` set at creation keeps counting down even while the user is reading it (mouse over it, about to click an action button) — a bad UX that dismisses toasts out from under an engaged user. The fix is tracking elapsed time and pausing/resuming rather than a single fire-and-forget timer:

```js
function useAutoDismiss(id, duration, onDismiss) {
  const remaining = useRef(duration);
  const startedAt = useRef(null);
  const timerId = useRef(null);

  const start = () => {
    startedAt.current = Date.now();
    timerId.current = setTimeout(onDismiss, remaining.current);
  };
  const pause = () => {
    clearTimeout(timerId.current);
    remaining.current -= Date.now() - startedAt.current;
  };

  useEffect(() => { start(); return () => clearTimeout(timerId.current); }, []);
  return { onMouseEnter: pause, onMouseLeave: start, onFocus: pause, onBlur: start };
}
```

## Stacking, position, and reflow animation

Toasts typically stack in a fixed-position container (`position: fixed`), and each one entering/leaving needs to animate the *others* shifting position — this is naturally handled with a FLIP-style animation library (or `AnimatePresence` in Framer Motion) rather than manual position math, since the number of items and their heights change dynamically.

## Accessibility

- The container needs `aria-live="polite"` (or `assertive` for critical errors) so screen readers announce new toasts without needing focus to move there.
- Toasts with an action button need to be reachable via keyboard, but the *appearance* of a toast should never steal focus from what the user was doing (this is why toasts don't use `role="alertdialog"`/focus-trap the way modals do).
- Auto-dismiss duration should respect `prefers-reduced-motion`-adjacent concerns loosely — more importantly, a toast with an actionable button should not auto-dismiss so fast a screen reader user can't reach it; some systems pause auto-dismiss entirely whenever a screen reader is detected reading it (hard to detect reliably) or simply extend duration when an action is present.

## API surface

```js
toast.show(message, { type: 'success' | 'error' | 'info', duration, action: { label, onClick } });
toast.dismiss(id);
toast.dismissAll();
```

Kept intentionally thin and imperative — the queueing, concurrency cap, and timer logic are internal implementation details the caller never needs to know about.
