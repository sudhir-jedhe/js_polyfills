# Autocomplete / Typeahead Architecture

An autocomplete component looks like "an input plus a dropdown," but a correct implementation has to solve three genuinely hard async problems simultaneously: not flooding the backend on every keystroke, correctly handling responses that arrive out of order, and layering full keyboard navigation on top of an async, changing result list — all without introducing visible lag or flicker.

## Debouncing the input

Firing a network request on every keystroke is both wasteful and, at typical typing speed, mostly requesting results for search terms the user has already moved past by the time the response arrives. Debouncing delays the request until the user pauses typing:

```js
function useDebouncedValue(value, delayMs) {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const id = setTimeout(() => setDebounced(value), delayMs);
    return () => clearTimeout(id); // cancel the pending update if value changes again before delay elapses
  }, [value, delayMs]);
  return debounced;
}
```

Typical delay: 150-300ms. Too short and you're barely debouncing at all; too long and the UI feels laggy relative to typing.

## The stale-response race condition — and why debouncing alone doesn't fix it

Even with debouncing, two requests can still be in flight close together (e.g., user types, pauses just past the debounce window, types more, pauses again) and the network itself can reorder which response arrives first — a fast connection responding to request #2 doesn't guarantee it arrives before a slower response to request #1 if #1 hit a slow server instance. Naively setting state in every `.then()` risks an **older response overwriting a newer one's results on screen**.

Two standard fixes:

**1. `AbortController` — actually cancel the stale request:**
```js
function useAutocomplete(query) {
  const [results, setResults] = useState([]);
  useEffect(() => {
    if (!query) return;
    const controller = new AbortController();
    fetch(`/api/search?q=${query}`, { signal: controller.signal })
      .then((res) => res.json())
      .then(setResults)
      .catch((err) => { if (err.name !== 'AbortError') console.error(err); });
    return () => controller.abort(); // fires when query changes again, or component unmounts
  }, [query]);
  return results;
}
```

**2. Request-id / sequence-token guard — defend even against responses that can't be aborted (e.g., a request the network already committed to, or an API without abort support):**
```js
function useAutocompleteSafe(query) {
  const [results, setResults] = useState([]);
  const latestRequestId = useRef(0);

  useEffect(() => {
    const requestId = ++latestRequestId.current;
    fetch(`/api/search?q=${query}`).then((res) => res.json()).then((data) => {
      if (requestId === latestRequestId.current) setResults(data); // ignore if a newer request has since started
    });
  }, [query]);

  return results;
}
```

Production code typically uses **both**: `AbortController` to actually save the wasted network/server work, and the sequence-token check as a belt-and-suspenders guard against any response that slips through regardless (some environments/polyfills don't propagate abort cleanly through every layer).

## Keyboard navigation over an async list

The list of options is asynchronous and can change shape between keystrokes, but keyboard nav (`ArrowDown`/`ArrowUp`/`Enter`/`Escape`) needs to feel synchronous and never point at a stale index:

```js
function useListboxKeyboardNav(optionsLength, onSelect) {
  const [activeIndex, setActiveIndex] = useState(-1);

  useEffect(() => { setActiveIndex(-1); }, [optionsLength]); // reset when the result set changes

  function onKeyDown(e) {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setActiveIndex((i) => Math.min(i + 1, optionsLength - 1));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setActiveIndex((i) => Math.max(i - 1, 0));
    } else if (e.key === 'Enter' && activeIndex >= 0) {
      onSelect(activeIndex);
    } else if (e.key === 'Escape') {
      setActiveIndex(-1);
    }
  }
  return { activeIndex, onKeyDown };
}
```

Resetting `activeIndex` whenever the option list length changes is important — without it, arrowing to index 4 and then typing a new character that narrows results to 2 items leaves `activeIndex` pointing past the end of the new (shorter) list, and `Enter` either selects nothing or throws.

## Accessibility: the ARIA combobox pattern

The input needs `role="combobox"`, `aria-expanded`, `aria-controls` (pointing at the listbox id), and `aria-activedescendant` (pointing at the currently-highlighted option's id, updated as `activeIndex` changes) — this lets a screen reader announce the highlighted option without moving actual DOM focus off the text input, which is essential since focus must stay in the input for typing to keep working while arrow-navigating the suggestions.

## Loading and empty states as first-class UI states

A robust autocomplete distinguishes at least four states, not just "has results or doesn't": **idle** (no query yet), **loading** (debounce elapsed, request in flight), **empty** (request completed, zero results), and **error** (request failed) — collapsing these into a single boolean ("is there an array to show") is a common source of confusing UX like a persistent spinner after a failed request, or an "empty" flash between keystrokes before the debounced request even fires.
