# Modal / Dialog System Architecture

A modal has three intertwined hard problems: rendering outside the normal DOM tree without breaking React's event model (portals), trapping keyboard focus inside it while it's open (accessibility requirement, not a nice-to-have), and correctly stacking when a second modal opens on top of a first.

## Portal rendering

A modal needs to render as a direct child of `<body>` (or close to it) so `position: fixed` and z-index behave predictably regardless of where in the component tree the trigger button lives — a modal rendered deep inside a `overflow: hidden` or `transform`-having ancestor can get visually clipped or mispositioned if it's not portaled out.

```jsx
function Modal({ children, onClose }) {
  return createPortal(
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        {children}
      </div>
    </div>,
    document.getElementById('modal-root')
  );
}
```

Critically, React's **synthetic event system still bubbles through the React tree, not the DOM tree** — a click inside a portaled modal still bubbles to React parent handlers of the component that *rendered* the portal, even though in the actual DOM the modal is a sibling of `<body>`'s other children. This is a frequently-tested gotcha: `event.stopPropagation()` inside the modal stops it from reaching React ancestors, but a raw `addEventListener` on `document` (bypassing React's synthetic system) would still see it, because that listener operates on the real DOM tree where the modal genuinely is a `document` descendant.

## Focus trapping

While the modal is open, `Tab`/`Shift+Tab` must cycle only through focusable elements *inside* the modal — focus must never leak to the page content behind the overlay. This is both a UX requirement and (per WAI-ARIA) a strict accessibility requirement for `role="dialog"` with `aria-modal="true"`.

```js
function trapFocus(containerEl) {
  const focusable = containerEl.querySelectorAll(
    'a[href], button:not([disabled]), textarea, input, select, [tabindex]:not([tabindex="-1"])'
  );
  const first = focusable[0];
  const last = focusable[focusable.length - 1];

  function handleKeyDown(e) {
    if (e.key !== 'Tab') return;
    if (e.shiftKey && document.activeElement === first) {
      e.preventDefault();
      last.focus();
    } else if (!e.shiftKey && document.activeElement === last) {
      e.preventDefault();
      first.focus();
    }
  }

  containerEl.addEventListener('keydown', handleKeyDown);
  return () => containerEl.removeEventListener('keydown', handleKeyDown);
}
```

Three more pieces beyond the Tab cycle itself:
- **On open**: move focus *into* the modal (typically the first focusable element, or the modal container itself if it has `tabindex="-1"`) — focus must not stay on whatever triggered the modal, or a keyboard user tabbing continues through background content invisibly.
- **On close**: restore focus to the element that had it before the modal opened (usually the trigger button) — losing this means keyboard users lose their place in the page every time they close a dialog.
- **`Escape` key** closes the modal (a near-universal expectation, and also part of the ARIA dialog pattern).

## Z-index stacking for multiple modals

A single global z-index constant breaks the moment a second modal (a confirmation dialog opened from within the first modal) needs to render above the first. The robust approach is a **stacking context registry**: each `Modal` instance registers itself in a shared stack on mount and gets an index-derived z-index, rather than every modal hardcoding the same z-index value.

```js
let openModalCount = 0;
const BASE_Z = 1000;

function useModalStackIndex() {
  const [zIndex] = useState(() => BASE_Z + openModalCount * 10);
  useEffect(() => {
    openModalCount += 1;
    return () => { openModalCount -= 1; };
  }, []);
  return zIndex;
}
```

This also matters for **focus trap scoping and `Escape` handling**: when two modals are open, `Escape` should close only the topmost one, and the focus trap of an inactive (behind) modal must not fight the active one's trap for control of `Tab`. The clean solution is a shared modal stack (array of open modal ids) where only the top entry's trap/`Escape` listener is active; lower ones are suspended while covered.

## Scroll locking

While any modal is open, the page behind it shouldn't scroll (`document.body.style.overflow = 'hidden'`), but with multiple modals stacked, this lock must be **reference-counted** — only released when the *last* modal in the stack closes, not the first one that happens to unmount, otherwise closing an inner modal would prematurely re-enable background scroll while an outer modal is still open.

## API surface

```jsx
<Modal open={isOpen} onClose={() => setIsOpen(false)} initialFocusRef={saveButtonRef}>
  <Modal.Header>Confirm</Modal.Header>
  <Modal.Body>Are you sure?</Modal.Body>
  <Modal.Footer>
    <button onClick={confirm} ref={saveButtonRef}>Yes</button>
  </Modal.Footer>
</Modal>
```

`open`/`onClose` as controlled props (parent owns whether it's open — modals are almost always controlled, unlike simpler widgets, because the trigger and the close action are usually in different places), plus an optional `initialFocusRef` escape hatch for cases where the first-focusable-element default isn't the right one (e.g., focusing "Cancel" instead of "Delete" in a destructive confirmation).
