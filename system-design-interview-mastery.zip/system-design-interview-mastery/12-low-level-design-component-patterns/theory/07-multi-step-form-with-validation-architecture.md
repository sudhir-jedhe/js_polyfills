# Multi-Step Form With Validation: Architecture

A multi-step form ("wizard") is deceptively hard to design cleanly because it has to reconcile three separate concerns that are easy to accidentally couple: **where state lives** (per-step vs. shared), **when validation runs** (per-step gate vs. final submit), and **how navigation and persistence interact** (can the user leave and come back, refresh mid-flow, jump backward and change an earlier answer that invalidates a later step).

## Where state lives: a single source of truth, not per-step local state

The tempting-but-wrong approach is letting each step component own its own local `useState` for its fields — this breaks the moment you need cross-step validation (a discount code on step 1 affecting what's shown on step 3) or a "review all answers" final step. The correct architecture centralizes all form data in one place — a reducer or a form-library instance — that every step reads from and writes into, with each step component being a "dumb" view over a slice of that shared state.

```js
const initialState = {
  step: 0,
  values: { email: '', plan: null, paymentMethod: null },
  errors: {},
  touchedSteps: new Set(),
};

function reducer(state, action) {
  switch (action.type) {
    case 'SET_FIELD':
      return { ...state, values: { ...state.values, [action.name]: action.value } };
    case 'GO_NEXT':
      return { ...state, step: state.step + 1, touchedSteps: new Set([...state.touchedSteps, state.step]) };
    case 'GO_BACK':
      return { ...state, step: Math.max(0, state.step - 1) };
    case 'SET_ERRORS':
      return { ...state, errors: action.errors };
  }
}
```

## Per-step validation gating navigation

Each step declares its own validation function; "Next" is disabled (or, better, attempts validation on click and shows errors rather than a disabled button with no explanation) until the current step's slice of `values` passes:

```js
const stepValidators = [
  (values) => (!values.email.includes('@') ? { email: 'Invalid email' } : {}),
  (values) => (!values.plan ? { plan: 'Select a plan' } : {}),
  (values) => (!values.paymentMethod ? { paymentMethod: 'Required' } : {}),
];

function handleNext() {
  const errors = stepValidators[state.step](state.values);
  if (Object.keys(errors).length > 0) {
    dispatch({ type: 'SET_ERRORS', errors });
    return;
  }
  dispatch({ type: 'GO_NEXT' });
}
```

**Design decision worth naming explicitly**: disabling the "Next" button until valid is common but has an accessibility/UX downside (a disabled button with no explanation is confusing) — many production forms instead keep it always clickable and show inline errors on attempted advance, which is what the code above does.

## Backward navigation invalidating later steps

If the user goes back to step 1 and changes an answer that step 3 depended on (e.g., changing `plan` from "Pro" to "Free" after already filling in Pro-only payment details on step 3), step 3's previously-entered data may now be invalid or irrelevant. The clean approach is **deriving step validity from current values on every render**, not caching a per-step "was valid at time of visiting" flag — so navigating forward re-validates against the *current* state rather than trusting a stale "already passed" marker:

```js
function isStepValid(stepIndex, values) {
  return Object.keys(stepValidators[stepIndex](values)).length === 0;
}
// "Next" and any "jump to step N" affordance both check isStepValid fresh each time, never a cached flag
```

## Persistence across refresh/navigation-away

Multi-step forms are often long enough that losing progress on an accidental refresh is a real cost (checkout flows, applications). The standard fix is persisting `values` (and `step`) to `sessionStorage`/`localStorage` on every change, and rehydrating on mount:

```js
useEffect(() => {
  const saved = sessionStorage.getItem('wizard-state');
  if (saved) dispatch({ type: 'HYDRATE', state: JSON.parse(saved) });
}, []);

useEffect(() => {
  sessionStorage.setItem('wizard-state', JSON.stringify(state));
}, [state]);
```

Sensitive fields (payment details, SSNs) should be explicitly excluded from persistence — a schema-level allowlist of "safe to persist" field names, rather than persisting the whole `values` object blindly, is the correct default for anything handling sensitive data.

## Submission: single atomic call, not per-step calls

Even though the UI is broken into steps, the actual backend submission is typically a single request once all steps pass — sending partial data per-step to the backend (unless there's a genuine save-draft requirement) adds server-side partial-state complexity for no UI benefit; the wizard's step boundary is a *presentation* concern, not necessarily a *persistence* boundary, and conflating them is a common design mistake worth calling out explicitly.
