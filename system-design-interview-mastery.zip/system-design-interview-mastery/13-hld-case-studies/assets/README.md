Diagrams and reference images for HLD case studies (e.g. architecture diagrams for the URL shortener, chat system, and booking flow case studies) will be added here.
