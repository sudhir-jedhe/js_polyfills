# HLD Case Studies

This topic is the capstone of the system design track: a repeatable interview framework (deeper than the introductory one in topic 01), two trade-off frameworks that recur in almost every real design decision, and six complete, full-depth high-level design case studies — the highest-value content in this entire repo. Each case study runs the full framework end to end: requirements clarification, back-of-envelope estimation with real numbers, API design, data modeling with an explicit SQL-vs-NoSQL justification, high-level architecture, a deep dive on the 1-2 genuinely hard parts, and a bottleneck/scaling analysis. Because `problems/` carries the weight of this topic, `theory/` covers the reusable framework and frameworks in real depth while `snippets/`, `output-based/`, `scenarios/`, and `interview-qa/` stay intentionally lighter — reinforcement and technique, not the main event.

## Folder structure

- **`theory/`** — the full repeatable interview checklist, capacity estimation formulas and reference numbers, API design conventions, data modeling approach, the consistency-vs-availability (CAP/PACELC) framework, the SQL-vs-NoSQL choice framework, and how to identify bottlenecks and scale them.
- **`snippets/`** — 4 reusable references: an estimation cheat sheet, a REST API design example, a justified SQL schema example, and an architecture-diagram narration template for verbal/no-whiteboard interviews.
- **`output-based/`** — 4 "given this, work it out" drills: estimating storage from given numbers, spotting a schema bottleneck, predicting what breaks at 10x traffic, and a SQL-vs-NoSQL decision walkthrough.
- **`scenarios/`** — 4 interview-dynamics situations: requirements changing mid-interview, the "jumped to a solution too fast" failure mode, a design that's functionally correct but fails its non-functional requirements, and monolith-vs-microservices judgment for a startup-scale prompt.
- **`interview-qa/`** — 3 themed files: framework and approach, estimation and tradeoffs, and common interviewer follow-up questions.
- **`problems/`** — **the core of this topic**: 6 complete high-level design case studies, each a full requirements-to-bottlenecks walkthrough with real estimation math and justified architectural decisions — a URL shortener, a rate limiter service, a real-time chat app (WhatsApp-style), a job portal, an e-commerce checkout flow, and a movie ticket booking system.
- **`assets/`** — placeholder for diagrams (see `assets/README.md`).

## What's covered

- A repeatable, time-boxed interview framework: requirements → estimation → API → data model → architecture → deep dive → bottlenecks, with explicit guidance on where interview signal actually comes from
- Back-of-envelope estimation technique with real formulas and memorizable reference numbers (latency orders of magnitude, common record sizes, QPS/storage formulas)
- The CAP/PACELC consistency-vs-availability framework applied per-feature, not as one global system-wide setting
- A SQL-vs-NoSQL decision framework applied per-entity, driven by access patterns and transaction needs rather than "NoSQL scales better"
- Six full case studies covering every major recurring HLD pattern: unique ID generation without contention (URL shortener), atomic check-and-increment at extreme QPS (rate limiter), store-and-forward delivery with a stateful connection layer at massive concurrent-connection scale (chat), search-index eventual consistency alongside a strongly-consistent apply action (job portal), multi-system saga-style coordination between payment and inventory (checkout), and all-or-nothing multi-row locking with deadlock avoidance under extreme contention (ticket booking)
