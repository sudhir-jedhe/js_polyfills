# Interview Q&A — Framework and Approach

**Q: Walk through the standard sequence for a system design interview.**
Requirements clarification (functional and non-functional) → capacity estimation → API design → data model → high-level architecture → deep dive on 1-2 components → identify bottlenecks and how to scale them. Each step feeds the next: requirements determine what to estimate, estimation justifies architectural choices, and the deep dive is where most of the actual signal comes from.

**Q: Why do interviewers deliberately give an underspecified prompt like "design Twitter"?**
To see whether the candidate proactively asks clarifying questions and scopes the problem, rather than assuming a fixed interpretation and building toward it. Asking "should I focus on the timeline/feed generation, or also cover search, DMs, and ads?" and getting explicit interviewer buy-in on scope is itself part of what's being graded — it converts an ambiguous prompt into an agreed contract for the rest of the session.

**Q: How should you budget time in a 45-minute system design interview?**
Roughly 8-10 minutes on requirements + estimation, 8-10 on API + data model, 8-10 on high-level architecture, 12-15 on a deep dive, and 5 minutes wrapping up on bottlenecks/scaling. The most common self-inflicted failure is over-investing in requirements-gathering breadth at the expense of the deep dive, which is usually where the interview is actually won or lost.

**Q: What's the difference between functional and non-functional requirements, and why does the distinction matter?**
Functional requirements describe what the system does (its features/actions); non-functional requirements describe the qualities those actions must have (latency, availability, consistency, durability, scale). The distinction matters because non-functional requirements are what actually drive most architectural decisions — two systems with identical functional requirements (e.g., "store and retrieve messages") can have completely different correct architectures depending on whether the non-functional requirement is "sub-100ms p99 latency at massive scale" or "occasional access, cost-optimized, latency not critical."

**Q: If an interviewer steers you toward a specific component mid-interview, should you keep going with your planned structure or follow their lead?**
Follow their lead — a mid-interview steer toward a specific component is a direct signal about where the interviewer wants depth, and is far more valuable than sticking rigidly to a pre-planned structure. Briefly acknowledge the pivot ("sure, let's go deeper on the caching layer") and adjust your remaining time budget accordingly, rather than trying to force in the rest of your original outline afterward.

**Q: What's a good way to handle a requirement you don't have time to design in full depth?**
Name it explicitly and state your intended approach at a high level without fully designing it: "I'd handle retries here with exponential backoff and a dead-letter queue for permanently-failing messages — I won't design the DLQ's reprocessing flow in detail unless you'd like me to." This demonstrates awareness of the requirement and a directionally correct answer without spending interview time that's better used elsewhere, and explicitly invites the interviewer to redirect if they disagree with the prioritization.
