# Interview Q&A — Estimation and Tradeoffs

**Q: Why compute peak QPS as a multiple of average QPS rather than just using average QPS to size a system?**
Traffic isn't uniform across a day — provisioning only for the average means the system falls over during actual peak usage, which is exactly when capacity matters most. A typical peak multiplier for consumer apps is 2-5x average, and stating this multiplier explicitly (and why you chose it) is part of showing real estimation technique rather than just producing a number.

**Q: What's PACELC, and how does it extend CAP theorem?**
CAP describes the tradeoff only during a network partition (choose Consistency or Availability). PACELC extends it: "if Partitioned, choose Availability or Consistency; Else (normal operation), choose Latency or Consistency." The "else" half matters constantly, not just during rare partition events — a system that enforces strong cross-region consistency on every write pays a real latency cost on every single request, partition or not, which is a tradeoff worth naming even when discussing normal-operation behavior, not just failure scenarios.

**Q: Should a system be uniformly "AP" or "CP," or does the choice vary within one system?**
It varies — the right question is "if this specific piece of data is briefly stale, what's the actual cost?", asked per feature. A social media like count tolerates staleness fine (AP); a seat reservation or a bank balance does not (CP). A strong answer walks through 2-3 specific operations in the system being designed and justifies the consistency model for each individually, rather than declaring one global policy.

**Q: What's the real difference between SQL and NoSQL that should drive the choice, beyond "NoSQL scales better"?**
"NoSQL scales better" is a half-truth — properly sharded relational databases scale to very high throughput too. The real differentiators are: whether the entity needs multi-row/multi-table ACID transactions (favors SQL), whether its schema is stable and well-understood vs. evolving/variable per record (favors SQL vs. NoSQL respectively), and whether the access pattern is a small number of well-known key/partition lookups (favors NoSQL's native partition-key model) vs. needing flexible ad-hoc queries and joins (favors SQL).

**Q: Give an example of denormalization as a deliberate tradeoff, and explain what's being traded.**
Storing an order line item's price at the moment of purchase (`price_cents_at_purchase`) rather than always joining to the live product table — trading a small amount of duplicated storage for the correctness property that an order's historical total never silently changes because a product's price changed later, and for avoiding a join on every order-history read. This is denormalization driven by a specific business-correctness requirement, not just a performance shortcut.

**Q: When should you propose sharding a database, and what determines whether it makes the situation better or worse?**
Propose it when a single primary's write throughput or total storage size becomes the actual, numerically-justified bottleneck (tie it to your capacity estimate) — not preemptively "because scale." Whether it helps or hurts hinges entirely on the partition key choice: a key that aligns with the dominant access pattern (e.g., sharding a per-user dataset by `userId`, when nearly all queries are already scoped to one user) keeps most requests single-shard; a poorly chosen key can create a new hot-shard bottleneck that's arguably worse than the original unsharded system, or force expensive cross-shard queries for what used to be a simple lookup.
