# Case Study: Design an E-Commerce Checkout Flow

## 1. Requirements Clarification

**Functional requirements:**
- User reviews cart, provides/selects shipping address, selects payment method, confirms order.
- System validates inventory availability, computes final price (items + tax + shipping), processes payment, decrements inventory, creates an order record, triggers order confirmation (email/notification).
- Handle out-of-stock items discovered at checkout time (not just at add-to-cart time).
- Handle payment failure gracefully without losing the user's cart/progress.

**Non-functional requirements:**
- **Strong consistency is required for inventory decrement and payment** — this is the case study's central hard constraint: two customers must never both successfully purchase the last unit of an item (overselling), and a payment must never be charged without a corresponding order being durably recorded (or vice versa — charged-but-no-order is a support/trust disaster).
- **Exactly-once effective semantics for the checkout action as a whole**, even though the underlying operations (payment charge, inventory decrement, order creation) span multiple systems — a network retry or a double-click must not result in double-charging or double-decrementing inventory.
- **Availability of the browsing/cart experience** should degrade gracefully even under partial backend issues — a slow payment processor shouldn't take down product browsing.
- **Moderate latency tolerance for checkout submission** (unlike a redirect or a chat message, users tolerate a checkout submission taking 1-3 seconds, since they expect "processing" — this relaxes the pure latency pressure compared to other case studies, in exchange for a much higher correctness bar).

**Explicitly out of scope:** the recommendation/pricing engine, fraud detection modeling (would name it as a step in the flow, not design the ML), the full payment gateway integration's PCI-compliance details (assume a third-party payment processor is used via a tokenized-card API, so raw card data never touches this system's own servers).

## 2. Capacity Estimation

Assumptions: 2M orders/day platform-wide, with realistic peak concentration (e.g., a sale event) at 5x average.

```
Order QPS:
  2,000,000 / 86,400 ≈ 23 QPS average
  peak (flash sale / holiday peak, higher multiplier than typical browsing traffic
    since checkout activity concentrates heavily during promotional windows) ≈ 23 × 8 ≈ 185 QPS

Each checkout involves multiple downstream calls, not just one write:
  inventory check+reserve, payment charge, order creation, notification trigger
  → effectively ~4 dependent operations per checkout, though these should NOT
    all be synchronous on the critical path (see deep dive)

Storage:
  2M orders/day × ~2KB per order (with line items) = 4 GB/day ≈ 1.46 TB/year
  Inventory table: bounded by SKU count (e.g., 5M SKUs), not order volume — small, ~a few GB
```

**Conclusion:** order volume itself (185 QPS peak) is not a raw-throughput problem the way some other case studies are — a single well-provisioned relational database can handle this write rate comfortably. The actual hard problem here is **correctness under concurrency** (never overselling inventory, never double-charging) and **graceful handling of partial failure across multiple systems** (payment succeeds but order-write fails, or vice versa) — this case study's difficulty is concurrency/correctness engineering, not raw scale, and the deep dive should reflect that.

## 3. API Design

```
POST /api/v1/checkout/reserve
Headers: Idempotency-Key: <client-uuid>
Request:  { "cartId": "cart_123" }
Response: 201 { "checkoutSessionId": "chk_456", "reservedItems": [...], "total": 8934, "expiresAt": "..." }
          409 { "unavailableItems": ["sku_789"] }   -- some items went out of stock at reserve time

POST /api/v1/checkout/{checkoutSessionId}/confirm
Headers: Idempotency-Key: <client-uuid>
Request:  { "paymentToken": "tok_abc", "shippingAddressId": "addr_1" }
Response: 200 { "orderId": "order_999", "status": "confirmed" }
          402 { "error": "payment_failed", "reason": "card_declined" }  -- reservation stays held briefly, user can retry payment
          410 { "error": "reservation_expired" }  -- user must re-initiate from cart
```

The **reserve → confirm** split (rather than one single "place order" call) is a deliberate API design decision, directly enabling the deep dive's concurrency-control mechanism — it creates an explicit checkpoint between "inventory tentatively locked" and "payment succeeded," which is what makes clean failure handling and idempotent retries possible.

## 4. Data Model

```sql
CREATE TABLE inventory (
  sku VARCHAR(50) PRIMARY KEY,
  available_quantity INT NOT NULL,
  reserved_quantity INT NOT NULL DEFAULT 0  -- separate from available; see deep dive
);

CREATE TABLE checkout_sessions (
  id VARCHAR(50) PRIMARY KEY,
  cart_id VARCHAR(50) NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'reserved', -- reserved | confirmed | expired | cancelled
  idempotency_key VARCHAR(100) UNIQUE,  -- enforces exactly-once at the DB level for the reserve call
  created_at TIMESTAMP NOT NULL DEFAULT now(),
  expires_at TIMESTAMP NOT NULL  -- reservation hold window, e.g. now() + 10 minutes
);

CREATE TABLE orders (
  id BIGINT PRIMARY KEY,
  checkout_session_id VARCHAR(50) NOT NULL UNIQUE REFERENCES checkout_sessions(id),
  user_id BIGINT NOT NULL,
  total_cents INT NOT NULL,
  payment_status VARCHAR(20) NOT NULL, -- pending | captured | failed
  status VARCHAR(20) NOT NULL DEFAULT 'confirmed',
  created_at TIMESTAMP NOT NULL DEFAULT now()
);

CREATE TABLE order_items (
  id BIGINT PRIMARY KEY,
  order_id BIGINT NOT NULL REFERENCES orders(id),
  sku VARCHAR(50) NOT NULL,
  quantity INT NOT NULL,
  price_cents_at_purchase INT NOT NULL  -- denormalized: order totals must never change if the product's price changes later
);
```

**SQL, unambiguously**, for the transactional core (`inventory`, `checkout_sessions`, `orders`, `order_items`) — this is the textbook case for relational ACID transactions: inventory decrement and order creation must commit together or not at all, and multi-row consistency (an order and its line items) matters directly to business correctness.

## 5. Deep Dive: Preventing Overselling and Handling Partial Failure Across Payment + Inventory + Order Creation

This is the case study's central hard problem, and the natural deep-dive target.

### Preventing overselling: reserve, don't decrement, at the "add to checkout" step

A naive design decrements `available_quantity` directly at reserve time with a check: `UPDATE inventory SET available_quantity = available_quantity - N WHERE sku = ? AND available_quantity >= N`. This is *correct* (the `WHERE available_quantity >= N` clause, combined with the atomicity of a single-row `UPDATE`, does prevent overselling under concurrent requests — this is a genuinely important detail: a single atomic conditional update is race-free even without an explicit lock, because the database serializes concurrent writes to the same row). But it conflates "tentatively locked for one user's in-progress checkout" with "permanently sold" — if that user abandons checkout or their payment fails, that inventory needs to come back, and a plain decrement loses the information needed to distinguish "genuinely sold" from "held, pending confirmation."

**The chosen design uses a separate `reserved_quantity` counter:**

```sql
-- At /checkout/reserve:
UPDATE inventory
SET reserved_quantity = reserved_quantity + :qty
WHERE sku = :sku AND (available_quantity - reserved_quantity) >= :qty;
-- affected_rows = 0 means insufficient available stock -> reject with 409
```

This atomic conditional update is the same core technique as the naive version (single-row atomic update with a `WHERE` guard, race-free by construction under the database's own row-level locking), but it reserves against the **effective availability** (`available - reserved`), leaving `available_quantity` itself untouched until the sale is actually confirmed.

```sql
-- At /checkout/confirm, only after payment succeeds:
UPDATE inventory
SET available_quantity = available_quantity - :qty, reserved_quantity = reserved_quantity - :qty
WHERE sku = :sku;

-- If the reservation expires or the user abandons checkout instead:
UPDATE inventory SET reserved_quantity = reserved_quantity - :qty WHERE sku = :sku;
-- (handled by a background job scanning checkout_sessions WHERE status='reserved' AND expires_at < now())
```

### Handling partial failure between payment and order creation

The confirm step must coordinate **two systems that don't share a transaction**: the internal database (order creation, inventory decrement) and an external payment processor (charging the card). A single atomic transaction spanning both is not possible (the payment processor is a separate, external system) — this is a classic distributed-transaction problem, and the standard resolution is a **saga-like ordered sequence with explicit compensation**, not a two-phase commit (which would require the payment processor to participate in a distributed transaction protocol it almost certainly doesn't support):

```
1. Charge the payment processor FIRST (using the idempotency key so a retry
   of this exact confirm call doesn't double-charge — most payment processors,
   e.g. Stripe, natively support idempotency keys on charge requests for this
   exact reason)
2. If payment fails: return 402 to the client immediately. Inventory stays
   reserved (not yet decremented) — nothing to compensate, since step 1 was
   the first side-effecting operation and it failed.
3. If payment succeeds: create the order record + decrement inventory
   (available_quantity -= qty, reserved_quantity -= qty) in a single local
   DB transaction — this part CAN be atomic, since it's all within one database.
4. If step 3 fails after step 1 succeeded (e.g., a DB outage right after a
   successful charge) -- this is the genuinely hard case: the customer has
   been charged but no order exists. Mitigate with: (a) the DB write is
   retried with backoff before giving up, since this is the rarer failure
   path and worth extra retry effort; (b) if it still fails, an async
   reconciliation job compares the payment processor's charge log against
   orders and flags/auto-creates the missing order or triggers an automatic
   refund + customer notification -- explicitly naming this as the safety-net
   for the rare partial-failure window, not something the synchronous path
   alone eliminates.
```

**Why charge before creating the order, not after:** if order-creation happened first and payment second, a payment failure after order creation would require *rolling back* a real order record (more state to unwind, more places a rollback itself can fail) — charging first means the only failure mode requiring compensation is "charged but no order," which is narrower and has a well-defined, nameable recovery path (refund via reconciliation), versus "order exists but was never really valid," which is messier to reason about and more likely to leak into places like already-triggered fulfillment notifications.

## 6. Bottlenecks and Scaling

| Bottleneck | Trigger point | Mitigation |
|---|---|---|
| Inventory row contention for viral/limited-stock items (flash sale) | Many concurrent checkout attempts for the same popular SKU | The atomic conditional `UPDATE` approach handles correctness under contention (no overselling), but very high concurrent contention on a single row still serializes those specific requests — for genuinely extreme cases (a doorbuster sale item), consider a dedicated high-throughput reservation mechanism (e.g., a Redis-based counter/queue in front of the DB, decoupling the "am I in time" check from the DB write) |
| Payment processor latency/availability as an external dependency | Any slowness or outage from the third-party payment processor | Set an explicit timeout on the payment call and treat a timeout distinctly from a definite failure (a timed-out charge might have actually succeeded on the processor's side) — never retry-and-charge-again on ambiguous timeout without first querying the processor's own idempotency-key-based charge status, to avoid a double-charge |
| Reservation-expiry cleanup job falling behind | A burst of abandoned checkouts (e.g., after a payment-page outage) | Bound the reservation hold window (e.g., 10 minutes) tightly enough that abandoned reservations don't tie up inventory for long, and make sure the cleanup job's own throughput scales with checkout volume, not a fixed cadence, so a burst of expirations doesn't create a backlog that holds inventory artificially unavailable |
| Order-write throughput at extreme scale | Far beyond 185 QPS peak, e.g., a major platform-wide sale event | Shard the `orders`/`inventory` tables by a key aligned with the dominant access pattern (e.g., by `sku` range or hash for inventory, by `user_id` for orders) only once single-primary throughput is the demonstrated bottleneck — not preemptively, given the estimation shows current peak is comfortably within a single well-provisioned primary's capacity |
