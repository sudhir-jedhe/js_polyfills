# Case Study: Design a Movie Ticket Booking System (like BookMyShow / Fandango)

## 1. Requirements Clarification

**Functional requirements:**
- Browse movies/showtimes by city/theater.
- View a specific showtime's seat map (available/booked/held).
- Select seats, hold them temporarily, complete payment, receive a confirmed booking.
- Cancel a booking (within a policy window).
- Handle the specific, well-known hard case: a **popular movie's opening show**, where many users simultaneously try to book overlapping seats.

**Non-functional requirements:**
- **The single hardest correctness requirement in this system**: two users must never both successfully book the same seat for the same showtime — a strictly stronger and more visible version of the "no overselling" requirement from the checkout-flow case study, because here the "inventory" (specific numbered seats) is discrete, visible to the user (they picked seat "H12" specifically), and a double-booking is immediately, concretely obvious to two different customers holding tickets for the same seat.
- **Low-latency seat map reads**: viewing a showtime's current seat availability must be fast and reasonably fresh — showing a seat as available when it was just taken a second ago is a minor, self-correcting UX hiccup (caught at selection time), but showing stale data for tens of seconds is a real usability problem during high-contention bookings.
- **A bounded hold window**: a user who selects seats but doesn't complete payment must not indefinitely lock those seats away from other users.
- **High read:write ratio outside of hot showtimes** (many browse, few book), but **extreme write contention concentrated on specific showtimes** at specific times (the moment a popular show's booking opens) — a very different traffic shape from a uniformly-distributed load.

**Explicitly out of scope:** dynamic/surge pricing logic, the theater/screen/showtime scheduling admin system, loyalty points.

## 2. Capacity Estimation

Assumptions: 5,000 theaters, average 8 showtimes/theater/day, average 150 seats/showtime, platform-wide 3M tickets booked/day, with extreme concentration during "booking opens" moments for high-demand releases.

```
Baseline booking QPS:
  3,000,000 / 86,400 ≈ 35 QPS average

Peak concentration (the actual hard case) — a blockbuster's booking window
  opening: assume 500,000 people attempting to book across a popular release's
  showtimes within the first 5 minutes of booking opening city-wide
  500,000 / 300 seconds ≈ 1,670 QPS sustained for that window, with instantaneous
  bursts significantly higher (assume 3-5x instantaneous spike within that window)
  → design target: ~5,000-8,000 QPS instantaneous burst capacity for seat-selection
    attempts specifically, concentrated on a small number of hot showtimes

Seat map reads (browsing before committing to book):
  assume 20x the booking QPS in read (seat-map-view) traffic during the same
  hot window → ~30,000-40,000 QPS read burst on the hottest showtimes' seat maps

Storage: trivial in raw volume (a `seats` table bounded by theater×screen×showtime
  count, not by booking volume) — this system's difficulty is entirely about
  concurrency control under contention, not data volume
```

**Conclusion:** this is the clearest example in this topic of a system where **raw data volume is a non-issue** and the entire design challenge is **correctness under extreme, concentrated write contention on a small number of hot rows** (specific seats on a specific popular showtime) at a specific moment in time (the instant booking opens) — the deep dive should be almost entirely about the seat-locking mechanism, since that's where 100% of the actual difficulty lives.

## 3. API Design

```
GET /api/v1/showtimes/{showtimeId}/seats
Response: 200 { "seats": [ { "id": "H12", "status": "available" | "held" | "booked" }, ... ] }

POST /api/v1/showtimes/{showtimeId}/hold
Headers: Idempotency-Key: <client-uuid>
Request:  { "seatIds": ["H12", "H13"] }
Response: 201 { "holdId": "hold_456", "seatIds": ["H12", "H13"], "expiresAt": "2026-08-22T18:10:00Z" }
          409 { "unavailableSeatIds": ["H13"] }  -- someone else grabbed it first

POST /api/v1/holds/{holdId}/confirm
Request:  { "paymentToken": "tok_abc" }
Response: 200 { "bookingId": "bkg_789", "status": "confirmed" }
          410 { "error": "hold_expired" }
          402 { "error": "payment_failed" }  -- seats are released back to available on failure/expiry

DELETE /api/v1/bookings/{bookingId}   -- cancellation, within policy window
```

Same **hold → confirm** two-phase pattern as the checkout-flow case study, for the same underlying reason (creating an explicit checkpoint that decouples "seat tentatively locked" from "payment succeeded," enabling clean idempotent retries and a bounded, expirable hold instead of an indefinite lock).

## 4. Data Model

```sql
CREATE TABLE showtime_seats (
  showtime_id BIGINT NOT NULL,
  seat_id VARCHAR(10) NOT NULL,  -- e.g. "H12"
  status VARCHAR(20) NOT NULL DEFAULT 'available', -- available | held | booked
  held_by_hold_id VARCHAR(50) NULL,
  hold_expires_at TIMESTAMP NULL,
  PRIMARY KEY (showtime_id, seat_id)  -- composite key: this table's entire access
                                        -- pattern is scoped to one showtime at a time
);

CREATE TABLE holds (
  id VARCHAR(50) PRIMARY KEY,
  showtime_id BIGINT NOT NULL,
  seat_ids TEXT NOT NULL,  -- JSON array
  idempotency_key VARCHAR(100) UNIQUE,
  expires_at TIMESTAMP NOT NULL
);

CREATE TABLE bookings (
  id BIGINT PRIMARY KEY,
  hold_id VARCHAR(50) NOT NULL UNIQUE REFERENCES holds(id),
  user_id BIGINT NOT NULL,
  showtime_id BIGINT NOT NULL,
  seat_ids TEXT NOT NULL,
  total_cents INT NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'confirmed',
  created_at TIMESTAMP NOT NULL DEFAULT now()
);
```

**SQL**, unambiguously — this is a textbook case for relational transactions with row-level locking, since the entire problem is coordinating exclusive access to specific rows (seats) under contention, which is precisely what a relational database's row-level locking and atomic constrained updates are built for. The `PRIMARY KEY (showtime_id, seat_id)` composite key is deliberate: it means every seat-hold operation naturally scopes its locking to exactly the rows involved (specific seats within one showtime), never contending with unrelated showtimes' seats even though they're logically in the "same table."

## 5. Deep Dive: Seat Locking Under Extreme Concurrent Contention

This is the entire point of the case study, and should get the majority of deep-dive time.

### The naive approach and why it's insufficient alone

A single atomic conditional update per seat, similar to the checkout case study's inventory pattern:
```sql
UPDATE showtime_seats
SET status = 'held', held_by_hold_id = :holdId, hold_expires_at = :expiresAt
WHERE showtime_id = :showtimeId AND seat_id = :seatId AND status = 'available';
-- affected_rows = 0 means someone else already holds/booked it
```
This is **correct** for a single seat (the atomic conditional `UPDATE` is race-free for one row, same reasoning as the checkout case study). The complication specific to this system: a hold request typically covers **multiple seats at once** (a group of 2-4 friends booking together), and those multiple updates need to succeed or fail *together* — holding seat H12 but failing to hold H13 (because someone else grabbed it a moment earlier) shouldn't leave the user with a partial, useless hold on just H12.

### All-or-nothing multi-seat hold via a single transaction

```sql
BEGIN;
UPDATE showtime_seats SET status='held', held_by_hold_id=:holdId, hold_expires_at=:exp
  WHERE showtime_id=:st AND seat_id IN ('H12','H13') AND status='available';
-- check affected_rows == 2 (the number of seats requested)
-- if affected_rows < 2: ROLLBACK (releases any partial holds acquired within this same transaction)
--   and return 409 with which specific seats were unavailable
-- if affected_rows == 2: COMMIT
```

Wrapping the multi-seat update in a single transaction is what provides the all-or-nothing property: if seat H13 was already taken (0 rows affected for it, 1 for H12), the transaction rolls back entirely, including the H12 hold that *did* succeed within this same transaction — the user never ends up with a confusing partial hold on just one of their requested seats.

### Deadlock avoidance for multi-seat holds

When two different users simultaneously try to hold overlapping *sets* of seats (e.g., user A wants H12+H13, user B wants H13+H14) — if each transaction acquires its locks in a different order (A locks H12 then tries H13; B locks H14 then tries H13, but from the opposite direction relative to some other conflicting request), a real deadlock is possible under some interleavings. **The standard, simple fix: always acquire seat locks in a consistent, deterministic order** (e.g., sort `seatIds` alphabetically/numerically before issuing the `UPDATE`, so every transaction touching seats {H12, H13} always locks H12 before H13, regardless of which user's request it is) — this eliminates the circular-wait condition that causes deadlocks, since no two transactions can ever be holding-and-waiting on each other in opposite orders.

### Bounded hold expiry, enforced two ways

A hold must not last forever if the user abandons checkout. Two complementary mechanisms, not just one:
1. **A background sweep job** scans for `status='held' AND hold_expires_at < now()` and resets those rows to `available` — the reliable, guaranteed-eventually-correct mechanism.
2. **Defensive re-validation at confirm time**: even if the sweep job hasn't yet run, the `/holds/{holdId}/confirm` handler explicitly checks `hold_expires_at > now()` before proceeding, returning `410 hold_expired` rather than trusting the row's `status` field alone — this closes the gap between "technically expired" and "the sweep job hasn't gotten to it yet," ensuring a stale hold can never be successfully confirmed into a booking even in that narrow timing window.

### Why not a distributed lock (e.g., Redis) instead of DB-row-level locking here

Worth naming as a considered alternative: a Redis-based distributed lock per seat is a viable design too, and can be faster under very extreme contention since it avoids relational transaction/lock overhead. It was not chosen as the primary mechanism here because the relational transaction approach gets the all-or-nothing multi-seat property "for free" from the database's own transactional guarantees, whereas a Redis-lock-based design would need to hand-roll that same all-or-nothing semantics (acquire N locks, roll back all of them if any fails) itself — for a system where raw data volume is trivial (per the estimation) and correctness/simplicity matters more than shaving milliseconds off lock acquisition, the relational approach is the better-justified default; a Redis-based layer would be the next lever specifically if profiling showed relational lock contention itself becoming the bottleneck (see below).

## 6. Bottlenecks and Scaling

| Bottleneck | Trigger point | Mitigation |
|---|---|---|
| Row-lock contention on a single hot showtime's seats | The exact "booking just opened for a blockbuster" scenario the estimation step sized for | Since `showtime_seats` is keyed by `(showtime_id, seat_id)`, contention is already naturally scoped to one showtime at a time — a hot showtime doesn't create contention for unrelated showtimes; if a single showtime's contention itself exceeds what row-level locking handles gracefully, a Redis-based fast-path lock layer in front of the DB (checked first, DB as the durable source of truth behind it) is the next lever |
| Seat-map read volume during the same hot window (~30-40K QPS estimated) | Many users browsing/viewing the seat map before committing to a hold | A short-TTL cache (a few seconds) in front of seat-map reads absorbs this — a several-second-stale seat map is an acceptable, self-correcting UX tradeoff (the user finds out definitively at hold-attempt time regardless), while the actual hold/confirm writes always go through the strongly-consistent path regardless of what the cached read showed |
| Sweep job falling behind during a burst of near-simultaneous hold expirations | Many holds created in the same narrow booking-opens window naturally expire around the same time too | Scale sweep-job frequency/parallelism with observed hold volume, and rely on the defensive confirm-time re-validation as the correctness backstop regardless of sweep-job timeliness — the sweep job is a cleanup optimization for making seats reusable promptly, not the sole correctness mechanism |
| Payment processor as an external dependency on the confirm path | Same class of risk as the checkout-flow case study | Same mitigation: explicit timeout handling, idempotency-key-based charge requests, and treating an ambiguous timeout as "check processor status before assuming failure" rather than blindly retrying a charge |
