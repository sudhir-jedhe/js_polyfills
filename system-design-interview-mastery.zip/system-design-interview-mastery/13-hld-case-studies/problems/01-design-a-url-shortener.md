# Case Study: Design a URL Shortener (like bit.ly / TinyURL)

## 1. Requirements Clarification

**Functional requirements:**
- Given a long URL, generate a short, unique alias (e.g., `sho.rt/abc123`).
- Accessing the short URL redirects (HTTP 302) to the original long URL.
- Optional: users can specify a custom alias.
- Optional: links can expire after a configurable time.
- Optional: basic click analytics (count, maybe referrer/geography) — scoped down to just a click counter for this design; a full analytics pipeline is explicitly out of scope.

**Non-functional requirements:**
- **Read-heavy**: redirects vastly outnumber URL creations — assume a 100:1 read:write ratio, typical for this kind of system (a link gets created once, clicked many times over its life).
- **Low redirect latency**: the redirect is the core user-facing action; target p99 under 100ms server-side.
- **High availability** for redirects specifically — a broken shortener actively breaks other people's shared links across the web, which is a worse failure mode than a slightly-delayed URL creation.
- **Uniqueness** of short codes is a hard correctness requirement — a collision silently redirecting to the wrong URL is unacceptable.
- Consistency: eventual consistency is acceptable for click counts; strong consistency (or at least no-duplicates) is required for code generation.

**Explicitly out of scope:** user accounts/auth, a full analytics dashboard, spam/malicious-URL detection (would mention it exists in a real system, not design it here).

## 2. Capacity Estimation

Assumptions: 100M new short URLs created per month; 100:1 read:write ratio; links retained for 5 years (no aggressive deletion).

```
Writes:
  100,000,000 / 30 days ≈ 3.33M URLs/day
  3,333,333 / 86,400 s ≈ 39 QPS average write
  peak write QPS ≈ 39 × 3 ≈ 120 QPS

Reads (100:1 ratio):
  39 × 100 = 3,900 QPS average read
  peak read QPS ≈ 3,900 × 3 ≈ 11,700 QPS

Storage:
  ~500 bytes per URL record (long URL + short code + metadata)
  100M/month × 500 B = 50 GB/month ≈ 600 GB/year
  5-year total ≈ 3 TB (before replication)

Short code space needed:
  100M/month × 12 × 5 years = 6 billion codes over 5 years
  Base62 (a-z, A-Z, 0-9) encoding: 62^6 ≈ 56.8 billion possible 6-character codes
  → 6 characters is sufficient with comfortable headroom (6 billion << 56.8 billion)
```

**Conclusion drawn from the numbers:** write volume (120 QPS peak) is trivial for a single database — this is emphatically a read-scaling problem, not a write-scaling problem. At 11,700 peak read QPS, a cache in front of the database is well justified and will absorb the overwhelming majority of that traffic once warm, since redirect lookups are a classic hot-key-friendly access pattern (a small fraction of URLs — the popular ones — account for a large fraction of reads).

## 3. API Design

```
POST /api/v1/urls
Request:  { "longUrl": "https://example.com/very/long/path", "customAlias": "optional", "expiresAt": "optional" }
Response: 201 { "shortUrl": "https://sho.rt/aZ3xQ1", "code": "aZ3xQ1" }
          400 invalid longUrl
          409 customAlias already taken

GET /{code}
Response: 302 redirect, Location: <longUrl>
          404 code not found or expired

GET /api/v1/urls/{code}/stats
Response: 200 { "code": "aZ3xQ1", "clicks": 4213, "createdAt": "..." }
```

## 4. Data Model

**SQL vs. NoSQL decision:** this is a simple key-value access pattern at its core (code → long URL, no relational joins, no multi-row transactions needed) — a strong candidate for a key-value/NoSQL store for the hot path, though a relational table works fine too at this scale and is simpler operationally if the team already runs one. Given the read pattern's simplicity, either works; the more interesting decision is the **cache** in front of whichever store is chosen.

```sql
CREATE TABLE urls (
  code VARCHAR(10) PRIMARY KEY,       -- the short code itself IS the primary key — no separate id needed
  long_url TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT now(),
  expires_at TIMESTAMP NULL,
  click_count BIGINT NOT NULL DEFAULT 0  -- denormalized counter, see deep dive
);
```

Using `code` directly as the primary key (rather than a separate auto-increment `id` plus a `code` column with a secondary index) avoids an extra index lookup on the hottest possible query path (`SELECT long_url FROM urls WHERE code = ?`).

## 5. High-Level Architecture

```
Client → Load Balancer → App Servers (stateless) → Cache (Redis, code → longUrl) → DB (URL records)
                                                          │
                                            cache hit ────┘ (~99% of redirect traffic, once warm)
                                            cache miss → query DB, populate cache, return
```

- **Cache-aside pattern** for redirects: check Redis first; on miss, query the DB, write through to Redis with a TTL, then respond. Given the 100:1 read:write ratio and the fact that link popularity is highly skewed (a small number of links get disproportionately clicked — classic power-law distribution), a cache absorbs the vast majority of read traffic once warm.
- **Write path** goes straight to the DB (writes are low-volume, per the estimation above) and does *not* need to go through the cache-population path synchronously — the first read after a write is a cache miss, which is fine.
- **Async click counting**: incrementing `click_count` on every redirect is a write on the hot read path — see the deep dive for why this needs to be decoupled from the synchronous redirect response.

## 6. Deep Dive: Unique Short Code Generation Without Contention

This is the most interesting part of the system, and the natural deep-dive target: **how do you generate unique short codes at 120 QPS peak without a single point of write contention, and without needing a global lock?**

**Approach considered and rejected — random generation + collision check:** generate a random 6-character Base62 string, check if it exists, retry on collision. This works at low collision rates but gets progressively worse as the code space fills up (more retries needed over the system's lifetime), and worse, it requires a synchronous existence-check read before every write, adding latency and DB load to every single URL creation.

**Chosen approach — a pre-allocated counter range, encoded to Base62:**

1. A central **counter service** (or a dedicated auto-increment sequence in the DB, or a coordination service like Zookeeper/etcd) hands out **ranges** of unique integers to each application server on startup/exhaustion, e.g., server A gets `[1,000,000 – 1,999,999]`, server B gets `[2,000,000 – 2,999,999]`.
2. Each app server locally increments through its assigned range for every URL it creates, encoding the integer to Base62 for the short code — **no coordination needed per-request**, only when a server exhausts its range (a rare event relative to per-request volume, so the coordination overhead is amortized to near-zero).
3. Because ranges are disjoint by construction, **uniqueness is guaranteed without any collision check or lock on the hot path** — this is the key property that makes this approach superior to random-generate-and-check.

```
Base62 encoding: integer 125 -> "cb" (using digits 0-9, a-z, A-Z as the 62-symbol alphabet)

function encode(n):
  chars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
  result = ""
  while n > 0:
    result = chars[n % 62] + result
    n = n // 62
  return result
```

**Tradeoff acknowledged explicitly**: pre-allocated ranges mean codes are roughly, but not strictly, chronologically ordered (server A's range and server B's range interleave in creation time but not in code value) — this is a non-issue for this system since code ordering isn't a requirement, but it's worth naming as a deliberate tradeoff versus a strictly-sequential single-counter approach, which *would* preserve ordering at the cost of reintroducing a single point of write contention (every single URL creation would need to hit one shared counter).

**Alternative valid approach worth naming**: hash the long URL (e.g., MD5/SHA, take the first 6-7 Base62-encoded characters) — simpler conceptually, but requires a collision check anyway (different long URLs can theoretically hash to overlapping prefixes) and doesn't support the "shorten the same URL twice, get two different short codes" behavior some products want; the range-based counter approach was chosen here specifically because it avoids any collision-check entirely, which is the property most worth optimizing for on the write path.

## 7. Bottlenecks and Scaling

| Bottleneck | Trigger point | Mitigation |
|---|---|---|
| Click-count increment on every redirect | Any real read volume — a synchronous `UPDATE ... SET click_count = click_count + 1` on every redirect adds write load to the hottest read path and creates row-lock contention on popular links | Decouple: fire an async event (to a queue, or simply an in-memory buffer flushed periodically) on each redirect instead of a synchronous increment; a background process batches and applies increments, trading perfect real-time accuracy for removing write contention from the critical path entirely |
| Cache cold-start after a deploy/restart | Any cache flush/restart event | Warm the cache proactively with the most-popular-N codes before routing traffic to a freshly restarted cache instance, or accept a brief elevated DB load and ensure the DB alone can handle full unwarmed traffic for a short window |
| DB as single point of failure for redirects | Any DB outage, at any scale | Since redirects are cache-hit-dominated (~99% once warm), a DB outage degrades gracefully for already-cached popular links but breaks cold (never-cached or evicted) links — worth explicitly deciding whether that's acceptable or whether a read replica failover is needed for full availability |
| Hot popular links (a viral URL) | A single link receiving disproportionate traffic | This is precisely what the cache is designed to absorb — a single hot key in Redis handles very high read QPS natively; if a single link's traffic somehow exceeded even that, client-side/CDN-edge caching of the redirect response (with a short TTL) would be the next lever |
| Counter-range coordination service availability | If the coordination service (Zookeeper/etcd) goes down | Each app server should be issued a large-enough range to keep operating for a meaningful window (hours) without needing to fetch a new range, so a brief coordination-service outage doesn't halt URL creation entirely |
