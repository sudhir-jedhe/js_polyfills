# Case Study: Design a Real-Time Chat App (like WhatsApp)

## 1. Requirements Clarification

**Functional requirements:**
- One-to-one messaging, and group messaging (cap group size at, say, 256 members — worth stating an explicit bound).
- Message delivery status: sent → delivered → read (the double/blue-tick model).
- Online/last-seen presence.
- Messages persist and are available on new device logins (message history).
- Media (images/video) sharing — scoped down to "attach a media URL to a message," not designing the media upload/transcoding pipeline itself here.

**Non-functional requirements:**
- **Low latency delivery**: a message should reach an online recipient in well under a second — this is a real-time system, not an eventually-consistent feed.
- **At-least-once delivery guarantee**: a message must never be silently lost, even if the recipient is offline when it's sent (store-and-forward).
- **Ordering**: messages within a single conversation must be delivered/displayed in a consistent order (globally-perfect ordering across the whole system isn't required, just per-conversation).
- **High availability** — a chat app being down is highly visible and immediately noticed by users.
- **Consistency model**: per the CAP/PACELC framework, this leans AP for delivery/presence (briefly stale "last seen" is fine) but needs strong guarantees specifically around "did my message get delivered" (no silent message loss).

**Explicitly out of scope:** end-to-end encryption key exchange protocol details (would name that E2E encryption is used, not design the Signal-protocol-level cryptography), voice/video calling.

## 2. Capacity Estimation

Assumptions: 500M daily active users, each sending an average of 40 messages/day.

```
Messages/day = 500,000,000 × 40 = 20,000,000,000 (20 billion messages/day)

Write QPS (message sends):
  20,000,000,000 / 86,400 ≈ 231,000 QPS average
  peak (assume 3x for evening peak usage patterns) ≈ 700,000 QPS

Each message triggers additional fan-out reads/writes: delivery receipt,
  read receipt, and for group chats, fan-out to N recipients —
  assume average group size factor of 1.5x effective fan-out across all messages
  (most messages are 1:1, some are group) → ~1M effective delivery operations/sec at peak

Storage per message: ~200 bytes (sender, recipient/group, timestamp, text, status flags)
  20B messages/day × 200 B = 4 TB/day
  Yearly: 4 TB × 365 ≈ 1.46 PB/year (before replication)
  With 3x replication: ~4.4 PB/year

Connection count: for real-time delivery, a meaningful fraction of 500M DAU
  are simultaneously connected via a persistent connection (WebSocket) at any
  given moment — assume 150M concurrent connections at peak globally
```

**Conclusion:** two very different scaling problems compound here — **extremely high message throughput** (which is a data pipeline/storage problem, similar in shape to other high-write-volume systems) and **150M concurrent persistent connections** (which is a fundamentally different problem: connection management at massive scale, not a request/response throughput problem). The architecture needs to address both explicitly and separately.

## 3. API Design

```
Client connects via a persistent WebSocket to a "connection gateway" server:
  WS /connect?token=<auth>

Sending a message (over the WebSocket, not REST — latency-critical path):
  { "type": "send_message", "conversationId": "conv_123", "clientMsgId": "uuid", "text": "..." }
  Server response: { "type": "ack", "clientMsgId": "uuid", "serverMsgId": "01HXYZ...", "status": "sent" }

Server-pushed events (over the same WebSocket):
  { "type": "message", "conversationId": "conv_123", "message": {...} }
  { "type": "delivery_receipt", "messageId": "...", "status": "delivered" }
  { "type": "read_receipt", "messageId": "...", "status": "read" }
  { "type": "presence", "userId": "...", "status": "online" | "last_seen: <ts>" }

REST fallback for history (initial sync / pagination, not the hot real-time path):
  GET /api/v1/conversations/{id}/messages?cursor=&limit=50
```

`clientMsgId` (client-generated, e.g., a UUID) enables **idempotent send** — if a client's network blips right after sending and it doesn't receive the ack, it can safely retry with the same `clientMsgId`, and the server recognizes and deduplicates the retry rather than creating a duplicate message.

## 4. Data Model

```
messages (partitioned by conversationId — matches the dominant access pattern: "get recent messages for this conversation")
  conversationId (partition key)
  messageId (sort key — time-sortable, e.g. Snowflake ID, gives newest-first ordering for free)
  senderId
  text / mediaUrl
  clientMsgId  (for idempotent-send dedup)
  sentAt

message_status (tracks per-recipient delivery/read state — separate from the message itself,
  since a group message has N independent status entries, one per recipient)
  messageId (partition key)
  recipientId (sort key)
  status: sent | delivered | read
  statusUpdatedAt

conversations
  conversationId
  type: direct | group
  memberIds: [...]
  lastMessageId  (denormalized, for the conversation-list "preview" view — avoids a join/lookup per conversation in the list UI)
```

**SQL vs. NoSQL**: NoSQL (wide-column, partitioned by `conversationId`), for the same reasoning as the notification system in the output-based section — the dominant access pattern (recent messages for one conversation) is a single-partition range query, write volume is extremely high with no multi-row transaction requirement per write, and there's no cross-conversation join in the hot path.

## 5. Deep Dive: Reliable Delivery and Connection Management at Scale

This is the natural deep-dive target: **how do you guarantee at-least-once delivery to a recipient who might be offline, while also delivering in near-real-time to a recipient who's online — at 150M concurrent connections?**

### Connection gateway layer

A dedicated fleet of **stateful WebSocket gateway servers** sits between clients and the rest of the backend. Critically, these are *not* interchangeable/stateless like a typical HTTP app server — each gateway instance holds an in-memory map of `userId → active connection` for whichever users happen to be connected to *that specific instance*. A **connection registry** (a fast shared store, e.g., Redis) maps `userId → gateway instance id`, so any backend component that needs to push a message to a specific user first looks up which gateway instance currently holds that user's connection, then routes the push there.

```
Sender's message → App/messaging service → look up recipient's gateway instance
  in the connection registry → if found, push directly to that gateway instance,
  which forwards over the open WebSocket → if not found (recipient offline),
  persist the message and skip live delivery — see store-and-forward below
```

### Store-and-forward for offline recipients

Every message is **durably persisted first** (written to the `messages` store), *before* attempting live delivery — this ordering is the core guarantee against message loss: even if live delivery fails or the recipient is offline, the message already exists durably and will be delivered on next sync.

```
1. Client sends message over WebSocket
2. Gateway forwards to messaging service
3. Messaging service writes the message to durable storage FIRST, gets a serverMsgId
4. Messaging service acks the sender (status: "sent") — sender's tick turns single-gray
5. Messaging service checks connection registry for the recipient
   - If online: push live via their gateway instance -> on delivery ack from
     recipient's client, update message_status to "delivered" (second tick)
   - If offline: nothing more happens now; message sits durably persisted
6. When the recipient's client reconnects, it performs a sync: "give me all
   messages after my last-seen messageId per conversation" — this catches up
   on everything that arrived while offline, in order, using the time-sortable
   messageId as the resumption cursor
```

This store-and-forward + resumable-sync pattern is what makes at-least-once delivery a property of the **persistence-then-push** ordering (step 3 before step 5), not of the WebSocket push itself — the WebSocket push is purely a latency optimization for the online case; correctness/durability never depends on it succeeding.

### Ordering within a conversation

Because `messageId` is a time-sortable id (Snowflake-style: timestamp bits + a per-shard sequence counter, guaranteeing monotonically increasing ids even across multiple messaging-service instances generating ids concurrently), messages within one conversation partition naturally sort correctly by id alone — no separate ordering/sequencing service is needed, and clients can safely use "highest messageId I've seen" as a resumable sync cursor.

### Presence (online/last-seen)

Presence is intentionally **not** strongly consistent — a "last seen 2 minutes ago" being a few seconds stale is an accepted, deliberate tradeoff (per the CAP/PACELC framework applied here): presence updates are pushed best-effort to a user's contacts when their connection state changes (connect/disconnect events on the gateway), without a durability or ordering guarantee anywhere near as strict as message delivery itself gets.

## 6. Bottlenecks and Scaling

| Bottleneck | Trigger point | Mitigation |
|---|---|---|
| A single gateway instance's connection capacity | Each instance can hold some bounded number of concurrent WebSocket connections (memory/file-descriptor limited, typically tens of thousands per instance) | Horizontally scale the gateway fleet; the connection registry (not the gateway instances themselves) is the source of truth for "where is this user connected," so the fleet can grow/shrink and rebalance without any single instance being special |
| Group message fan-out for very large groups | A single message in a 256-member group requiring 256 individual delivery attempts | Fan-out is done asynchronously by the messaging service (not blocking the sender's ack on all 256 deliveries completing) — the sender's message is durably persisted and acked immediately; fan-out to online members happens as a background operation per recipient |
| Connection registry (Redis) as a critical dependency | High connect/disconnect churn (mobile clients reconnecting frequently on network changes) generating high registry write volume | Partition/shard the registry by userId hash, same pattern as other high-QPS key-value workloads in this topic |
| Hot conversation (a very large or very active group) | A group with unusually high message volume relative to typical conversations | Since messages are partitioned by `conversationId`, an extremely hot conversation partition could become a localized hot-shard bottleneck — worth naming as an edge case requiring either a higher replication factor for that specific partition or, in extreme cases, further sub-partitioning within a single very large conversation |
| Message persistence write latency on the send-ack critical path | High sustained message volume (700K QPS peak) | The durable write must complete before acking the sender (correctness requirement), so this write path's latency directly becomes the sender's perceived latency — this is why the storage layer must be a low-latency, horizontally-scalable, partition-key-native store (matching the SQL vs. NoSQL reasoning in section 4), not a slower, more general-purpose relational store forced to absorb this specific access pattern |
