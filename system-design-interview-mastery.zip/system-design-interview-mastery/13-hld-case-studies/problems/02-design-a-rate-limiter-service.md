# Case Study: Design a Rate Limiter Service

## 1. Requirements Clarification

**Functional requirements:**
- Given an incoming request identified by some key (API key, user id, or IP address), decide allow/reject based on a configured limit (e.g., "100 requests per minute per API key").
- Support multiple simultaneous rate-limit rules per key (e.g., "100/min AND 5,000/day" for the same API key).
- Return a clear signal to the client on rejection (HTTP 429) with information on when to retry.
- Configurable limits per client tier (free tier: 100/min; paid tier: 10,000/min).

**Non-functional requirements:**
- **Extremely low added latency** — this sits in front of every single request to the actual service; if it adds meaningful latency, it directly hurts every request, rate-limited or not. Target: sub-millisecond decision time.
- **Accuracy under distributed load**: the limiter must run across many application server instances (not a single machine), and the count must be shared/consistent across all of them — a naive per-instance-local counter would let a client get N times the configured limit by hitting N different instances.
- **Availability**: if the rate limiter itself becomes unavailable, the system must have an explicit fail-open or fail-closed policy (a decision worth naming explicitly, not glossing over).
- **High write throughput**: every single request the system serves triggers a rate-limiter check-and-increment, so this needs to sustain the aggregate QPS of everything it protects.

**Explicitly out of scope:** designing the actual per-endpoint business logic being protected; a full policy-management UI (assume config is provided via a simple API/config store).

## 2. Capacity Estimation

Assumptions: this rate limiter sits in front of an API platform serving 50,000 requests/second in aggregate across all clients, at peak.

```
Rate limiter must handle: 50,000 checks/sec at peak (1:1 with total request volume —
  every request needs a check, not a sampled subset)

Per-check cost: reading + incrementing a counter for typically 1-3 active
  rate-limit rules per request (e.g., per-minute AND per-day limits) →
  ~50,000 × 2 ≈ 100,000 counter operations/sec at peak

Storage: for N unique keys (API keys/user ids) actively making requests within
  a rolling window, each needs a small counter record.
  Assume 1M active keys in a given time window, each counter record ~100 bytes
  (key + count + window metadata) → ~100 MB — easily fits in memory
```

**Conclusion:** the numbers point clearly toward an **in-memory, low-latency store** (Redis or similar) rather than a disk-backed database — 100,000 ops/sec with sub-millisecond latency requirements is squarely in Redis's designed operating range, and the total working-set size (~100MB-few GB even at large scale) fits comfortably in memory. This is not a "big data" storage problem; it's a "extremely high QPS, tiny records, latency-critical" problem, which is a different profile requiring a different tool than most of the other case studies in this topic.

## 3. API Design

The rate limiter is typically an internal service/library, not a public-facing API, but worth defining its contract:

```
Internal check-and-increment call (called by the API gateway / each service, in-process or via a fast RPC):

  checkLimit(key: string, rule: "per_minute" | "per_day") -> { allowed: bool, remaining: int, resetAt: timestamp }

Client-facing response headers, on every response (allowed or not):
  X-RateLimit-Limit: 100
  X-RateLimit-Remaining: 42
  X-RateLimit-Reset: 1719000060   (unix timestamp when the window resets)

On rejection:
  HTTP 429 Too Many Requests
  Retry-After: 18   (seconds until the client should retry)
```

Surfacing `remaining` and `resetAt` on *every* response (not just rejections) lets well-behaved clients self-throttle proactively before ever hitting a 429, which is worth naming as a deliberate API design choice that reduces overall rejected-request volume.

## 4. Data Model

Not a traditional relational schema — the core "data model" here is the choice of **rate-limiting algorithm**, since that determines exactly what gets stored and how.

## 5. High-Level Architecture

```
Client → API Gateway (rate limiter check happens here, at the edge) → App Servers → ...
                │
                ▼
         Redis cluster (holds counters, shared across ALL gateway instances)
```

Placing the check at the **API gateway layer** (a single choke point every request passes through) rather than scattered redundantly across individual downstream services is the key architectural decision: it means the rate-limit decision is made once, consistently, before wasted work happens downstream — an over-limit request is rejected before it ever reaches (and consumes resources in) the actual application tier.

**Redis is shared across all gateway instances** — this is what solves the distributed-consistency requirement from section 1: instead of each gateway instance tracking counts locally (which would let a client evade the limit by spreading requests across instances), all instances read/write the same centralized (but very fast) counter store.

## 6. Deep Dive: Choosing and Implementing the Rate-Limiting Algorithm

This is the natural deep-dive target — there are several genuinely different algorithms with real tradeoffs, and picking (and correctly implementing) one is where the interesting engineering is.

### Fixed window counter
Simplest: a counter per key, reset every fixed interval (e.g., every clock-aligned minute).
```
INCR key:minute_bucket
EXPIRE key:minute_bucket 60   -- only set on first increment in the window
if count > limit: reject
```
**Flaw worth naming explicitly**: allows up to **2x the limit** in a burst straddling a window boundary — a client sending the full limit at `0:59` and again at `1:01` gets 2x the intended limit through in a 2-second span, because each falls in a different fixed window. This is a real correctness gap, not a minor edge case, and interviewers specifically probe whether you catch it.

### Sliding window log
Store a timestamp for every single request in a sorted set; on each check, remove entries older than the window and count what remains.
```
ZREMRANGEBYSCORE key 0 (now - window)
ZADD key now now
count = ZCARD key
if count > limit: reject
```
Perfectly accurate — no boundary-straddling burst issue — but **storage cost scales with request volume** (one entry per request, not per key), which is expensive at high QPS and doesn't fit the "small, bounded storage" property the estimation step assumed.

### Sliding window counter (the chosen approach)
A practical compromise: keep fixed-window counters (cheap, like the first approach) but weight the *previous* window's count by how much of it still overlaps the current sliding window:
```
estimated_count = current_window_count + previous_window_count × overlap_fraction
```
Example: limit 100/min, currently 15 seconds into the new minute (`overlap_fraction = 45/60 = 0.75` of the previous window still "counts"): if the previous window had 80 requests and the current window has 20 so far, `estimated_count = 20 + 80 × 0.75 = 80` — under the limit, allowed. This approximates the sliding-log's accuracy (no hard boundary exploit) while keeping storage at O(1) per key (two counters, not one entry per request) — the right tradeoff for this system's actual constraints (extremely high QPS, tight latency budget, bounded memory).

### Token bucket (worth naming as the alternative for burst-tolerant use cases)
Each key has a bucket that refills at a steady rate up to a max capacity; each request consumes a token, rejected if the bucket is empty. Naturally allows short bursts up to the bucket size while enforcing a steady-state average rate — a better fit than the counter-based approaches when the requirement is explicitly "allow occasional bursts, but cap sustained rate," which is common for API tiers that want to tolerate a client's brief legitimate spike without over-rejecting.

**Atomicity requirement, regardless of algorithm chosen**: the check-and-increment must be a single atomic operation against Redis (a Lua script executed via `EVAL`, or Redis's native atomic commands) — doing a separate `GET` then conditional `INCR` from application code introduces a race condition where concurrent requests from the same key can both read a count just under the limit and both proceed, letting the effective limit be exceeded under concurrent load. This is a specific, testable correctness detail worth stating explicitly.

## 7. Bottlenecks and Scaling

| Bottleneck | Trigger point | Mitigation |
|---|---|---|
| Single Redis instance throughput ceiling | Very high aggregate QPS (100K+ ops/sec sustained) | Shard Redis by key (hash the rate-limit key to a shard) — since each key's counter is independent, this parallelizes cleanly with no cross-shard coordination needed |
| Redis as a single point of failure | Any Redis outage | Explicit fail-open vs. fail-closed policy: fail-open (allow all requests through when the limiter is down) protects availability of the protected service but removes protection exactly when it might be needed most (e.g., during an incident that's also causing abnormal traffic); fail-closed (reject all) protects against abuse but turns a rate-limiter outage into a full service outage — most production systems choose fail-open for general API rate limiting and fail-closed for security-critical limits (e.g., login attempt limiting), and this choice should be stated explicitly rather than left implicit |
| Hot key (one API key/IP generating disproportionate traffic, possibly an attack) | A single abusive or misconfigured client | The whole system is designed around this exact case — a single Redis key handles very high per-key operation rates natively; if a genuinely adversarial client is generating traffic at a scale that stresses the limiter itself (not just the protected service), an even earlier, cruder layer (connection-level or IP-based throttling at the network/CDN edge) is the next lever, catching abuse before it even reaches the application-level rate limiter |
| Clock skew across distributed gateway instances | Any multi-instance deployment | Since the actual counting happens centrally in Redis (not per-instance-local clocks), this is largely mitigated by the architecture itself — worth naming as a reason centralizing state in Redis is preferable to a fully decentralized token-bucket-per-instance approach, which would need clock synchronization to stay consistent |
