# Case Study: Design a Job Portal (like LinkedIn Jobs / Indeed)

## 1. Requirements Clarification

**Functional requirements:**
- Companies post job listings (title, description, location, salary range, requirements).
- Job seekers search/filter listings (by keyword, location, salary range, experience level, remote/onsite).
- Job seekers apply to listings (submit an application, optionally with a resume attachment).
- Companies view/manage applications for their postings, update application status (applied → reviewed → interview → offer/rejected).
- Job seekers see the status of their own applications.
- Notification to a job seeker when their application status changes.

**Non-functional requirements:**
- **Search-heavy read path**: job search/filter is the dominant, highest-traffic action — needs to feel instant (sub-200ms) even with complex multi-field filtering (location + salary + keyword + experience simultaneously).
- **Consistency for applications**: applying to a job and a company reading applications need reasonably fresh data (moderate freshness — a company seeing an application "a few seconds late" is a minor issue, not a correctness one), but the *application creation itself* must be reliably durable — an application that a user believes was submitted must never silently fail to be recorded.
- **Moderate write volume, high read volume**: job postings are created relatively infrequently compared to how often they're searched/browsed (asymmetric like a content-browsing system, though less extreme than a URL shortener's ratio).
- **Freshness of listings**: a closed/filled job should stop appearing in search results promptly — stale search results showing expired listings is a real user-trust problem.

**Explicitly out of scope:** a resume-parsing/matching ML recommendation engine (would name it as a natural extension, not design it here), messaging between recruiters and candidates, a full applicant-tracking-system's interview-scheduling workflow.

## 2. Capacity Estimation

Assumptions: 10M active job listings at any time, 2M new listings/month, 50M job seekers with 5M daily active searchers performing an average of 8 searches/session.

```
Search QPS:
  5,000,000 DAU × 8 searches/day = 40,000,000 searches/day
  40,000,000 / 86,400 ≈ 463 QPS average
  peak (business-hours-concentrated traffic, higher multiplier than a 24h-uniform
    consumer app since job searching skews toward daytime) ≈ 463 × 4 ≈ 1,850 QPS

Application writes:
  Assume 5% of searches result in an application: 40,000,000 × 0.05 = 2,000,000 applications/day
  2,000,000 / 86,400 ≈ 23 QPS average, peak ≈ 70-100 QPS

Job posting writes:
  2,000,000/month / 30 / 86,400 ≈ 0.77 QPS average — trivially low

Storage:
  10M active listings × ~2KB (title, description, metadata) = 20 GB (listings themselves are small)
  Applications: assuming 5-year retention, 2M/day × 365 × 5 × ~1KB (application metadata,
    resume stored separately as a blob) ≈ 3.65 TB for application records
  Resume blobs: assume 200KB average resume, most applicants reuse across multiple
    applications so store once per user, not per application — 50M users × 200KB ≈ 10 TB
```

**Conclusion:** search is clearly the dominant, latency-critical read path (1,850 QPS peak with complex multi-field filtering) — this is not well served by a simple database query against a relational table's indexes alone once you need combined free-text + multi-field filtering at this volume; it points toward a dedicated search index. Application writes (70-100 QPS peak) are comparatively low-volume but have a hard durability requirement. Job posting writes are negligible in volume.

## 3. API Design

```
GET /api/v1/jobs/search?q=frontend+engineer&location=remote&salaryMin=120000&cursor=&limit=20
Response: 200 { "jobs": [ { id, title, companyName, location, salaryRange, postedAt }, ... ], "nextCursor": "..." }

POST /api/v1/jobs/{jobId}/applications
Headers: Idempotency-Key: <client-uuid>
Request:  { "resumeId": "res_789", "coverLetter": "optional" }
Response: 201 { "applicationId": "app_456", "status": "applied" }
          409 if already applied to this job (see data model's unique constraint)

GET /api/v1/applications?userId=me
Response: 200 { "applications": [ { jobId, jobTitle, status, appliedAt }, ... ] }

PATCH /api/v1/jobs/{jobId}/applications/{applicationId}
  (company-side, updates status)
Request:  { "status": "interview" }
Response: 200 { ...updated application... }
  -> triggers an async notification to the applicant on status change
```

## 4. Data Model

**SQL vs. NoSQL, per entity:**

- **`applications`**: relational (SQL). This is the transactional core — an application must atomically reference exactly one job listing and one applicant, its status transitions matter for business logic and reporting, and the "one application per user per listing" invariant is exactly the kind of constraint a relational unique index enforces cleanly and atomically (see the schema snippet in `snippets/03-database-schema-example-sql.md` for this exact table).
- **`job_listings`**: relational as the system of record (companies need reliable CRUD, moderate write consistency for status changes like "closed"), but **also indexed into a dedicated search engine** (Elasticsearch/OpenSearch) — the relational table is the source of truth, the search index is a derived, eventually-consistent read-optimized copy purpose-built for the actual dominant access pattern (multi-field filtered full-text search).
- **`companies`**: relational — standard entity data, low write volume, benefits from referential integrity with `job_listings`.

```sql
CREATE TABLE job_listings (
  id BIGINT PRIMARY KEY,
  company_id BIGINT NOT NULL REFERENCES companies(id),
  title VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  location VARCHAR(255),
  salary_min INT, salary_max INT,
  status VARCHAR(20) NOT NULL DEFAULT 'active', -- active | closed | draft
  posted_at TIMESTAMP NOT NULL DEFAULT now(),
  closed_at TIMESTAMP NULL
);
-- applications table: see snippets/03-database-schema-example-sql.md
--   (UNIQUE (job_listing_id, applicant_id) enforced at the DB level)
```

## 5. High-Level Architecture

```
                          ┌── Search Service (Elasticsearch) ── serves the search/filter path
Client → LB → App Servers ┤
                          └── Relational DB (source of truth: listings, applications, companies)
                                     │
                                     ▼
                          Change-Data-Capture / async indexer
                          (listens for listing create/update/close events,
                           updates the Elasticsearch index accordingly)
```

Writes (job posting create/update/close) go to the relational DB as the source of truth; a **change-data-capture (CDC) pipeline** (or a simpler async event emitted on write) propagates the change into the search index asynchronously, keeping the search index eventually consistent with the source of truth — this is a deliberate, named consistency tradeoff (see the deep dive) rather than an oversight.

## 6. Deep Dive: Search Consistency and Filtering at Scale

**Why a dedicated search engine, not just relational indexes:** the dominant query combines full-text relevance ("frontend engineer" matched fuzzily against title/description) with multiple simultaneous structured filters (location, salary range, experience level, remote/onsite) and needs to rank results by relevance, not just filter them. A relational database *can* technically do filtered queries efficiently with the right composite indexes, but full-text relevance ranking combined with faceted filtering at this query complexity and volume is exactly what search engines like Elasticsearch are purpose-built for (inverted indexes for text, combined with fast faceted filtering) — reimplementing that well on top of relational indexes is a much harder, worse-performing path.

**The eventual-consistency tradeoff this introduces, named explicitly:** a job posting that's just been created or just been closed won't be reflected in search results instantly — there's a propagation delay (typically seconds, via the CDC/async-indexer pipeline) between the write to the source-of-truth DB and the search index catching up. This is judged an acceptable tradeoff for this system specifically: "a newly posted job takes a few seconds to become searchable" is a minor, invisible-to-most-users delay, whereas "a closed job that keeps showing in search for a few seconds after being closed" is worse but still tolerable, provided the *listing detail page itself* (not just search results) checks the source-of-truth DB's current `status` before allowing an application — this is the specific mechanism that prevents the eventual-consistency window from ever allowing a real correctness violation (an application to a truly-closed job): search can be briefly stale, but the actual apply action re-validates against strong-consistency source-of-truth data at the moment it matters.

```
POST /api/v1/jobs/{jobId}/applications handler:
  1. Read job_listings WHERE id = jobId (strongly consistent read against the source-of-truth DB)
  2. If status != 'active': reject with 410 "This listing is no longer accepting applications"
  3. Otherwise, proceed with the application insert (protected by the UNIQUE constraint for idempotency/dedup)
```

**Preventing duplicate applications under concurrent requests**: the `UNIQUE (job_listing_id, applicant_id)` database constraint (not an application-level "check then insert," which would race under concurrent duplicate submissions — e.g., a user double-clicking "Apply" or a client retry) is what makes "one application per user per listing" an atomic, race-free guarantee — the second concurrent insert attempt simply fails the constraint and the API returns 409, rather than relying on an application-code check-then-act sequence that has a race window.

## 7. Bottlenecks and Scaling

| Bottleneck | Trigger point | Mitigation |
|---|---|---|
| Search index query latency under high filter complexity | Very high combined filter cardinality (many simultaneous facets) at high QPS | Elasticsearch scales horizontally by sharding the index; shard count should be chosen based on total index size and query throughput, with replicas for both read-throughput and availability |
| CDC/indexing pipeline lag growing under a burst of listing writes | A large batch of listings created/updated simultaneously (e.g., a big company bulk-uploading postings) | Monitor consumer lag on the indexing pipeline explicitly (per the "what would you monitor" interview-qa guidance) and scale indexer worker concurrency independently of the write path itself, since indexing is decoupled and async by design |
| Relational DB write contention on `applications` during viral/high-traffic postings | A single very popular listing (e.g., a well-known company's opening) receiving a disproportionate application volume in a short window | Since each application insert is scoped to one row via the unique constraint and doesn't require locking other applicants' rows, this scales reasonably well without a fundamental redesign — the bigger risk is read contention on the listing's `job_listings` row (every applicant's apply-flow re-reads its status) which is a good candidate for a short-TTL cache in front of that specific read, cautious not to let the TTL exceed the acceptable staleness window for the apply-time status check |
| Resume storage growth | Linear with user base, moderate but not extreme | Object storage (S3-like), not the relational DB — resumes stored once per user (deduplicated across applications) as identified in the estimation step, not once per application |
