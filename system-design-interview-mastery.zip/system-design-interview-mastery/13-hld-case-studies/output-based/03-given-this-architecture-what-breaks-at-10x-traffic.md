# Output: Given This Architecture, What Breaks at 10x Traffic?

**Given architecture** (a simple e-commerce checkout flow at current scale — 500 orders/minute peak):

```
Client → Load Balancer → App Servers (10 instances, stateless)
                              │
                              ▼
                     Single Postgres primary
                     (handles both inventory decrement
                      AND order writes, no read replicas,
                      no caching layer)
```

**Question:** At 10x traffic (5,000 orders/minute peak), what breaks first, and in what order would you address it?

**Answer, in order of what fails first:**

1. **The single Postgres primary's write throughput** is the first and hardest ceiling. Every checkout does an inventory decrement (`UPDATE inventory SET quantity = quantity - 1 WHERE product_id = ? AND quantity > 0`) plus an order insert, both against the same primary, with no read replica offloading any read traffic either — at 5,000 orders/minute (~83 writes/sec sustained, likely 3-5x that at instantaneous peak from bursty traffic patterns like a flash sale), a single primary handling 100% of both the read and write load starts to show rising write latency and connection pool exhaustion well before raw throughput physically maxes out, because reads (product pages, cart views, inventory checks) are still competing with writes for the same primary's resources.

2. **Inventory decrement contention on popular products** compounds this specifically during flash-sale-style traffic spikes — many concurrent checkouts targeting the *same* popular product's inventory row create lock contention on that single row (`UPDATE ... WHERE product_id = ?`), serializing what should be independent-feeling user checkouts into a queue behind that one row's lock, worse than the general throughput ceiling alone would suggest.

3. **App server tier** is comparatively fine — it's already stateless and horizontally scaled (10 instances), so scaling to 30-50 instances behind the load balancer is a straightforward, low-risk lever; this tier is not the first thing to break.

**Mitigation, in priority order:**

1. **Add read replicas** and route all non-checkout reads (product browsing, cart view) off the primary — this alone reclaims significant primary capacity for the writes that actually need it, at the cost of introducing replication lag for reads (acceptable here — product browsing doesn't need strong consistency).
2. **Move the inventory hot-row contention off a naive `UPDATE ... WHERE quantity > 0`** toward a design that reduces lock hold time and contention — e.g., a pre-reservation/hold-based flow (see the movie-ticket-booking case study's seat-locking pattern) rather than a single contended row every concurrent request fights over.
3. **Only after the above**, consider write-path sharding (e.g., by product category or a hash of `product_id`) if a single primary still can't sustain throughput even with reads offloaded — this is a bigger structural change and should be the last lever pulled, not the first, since it adds meaningful complexity (cross-shard queries, rebalancing) that isn't justified until the simpler fixes are exhausted.

**Broader lesson:** "what breaks at 10x" should be answered by walking the architecture component by component and reasoning about *which specific access pattern* saturates first — here it's not "the database" generically, it's specifically write contention on a hot inventory row compounding an overall read+write throughput ceiling on an un-replicated single primary, and the fix priority should follow the same specificity (offload reads first — cheap and low-risk — before reaching for a full sharding redesign).
