# Output: Given This Schema, Identify the Bottleneck

**Given this schema for a social media "likes" feature:**

```sql
CREATE TABLE likes (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  post_id BIGINT NOT NULL,
  user_id BIGINT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT now()
);
-- to show a post's like count, the app runs:
SELECT COUNT(*) FROM likes WHERE post_id = ?;
```

**Given:** the platform has posts that can go viral, sometimes receiving 500,000+ likes within a few hours, and the like count is displayed on every single post render (a very hot read path — every feed view triggers this query for every visible post).

**Question:** What's the bottleneck here, and why does it get specifically worse for viral content rather than uniformly worse under general load?

**Answer:** `COUNT(*) FROM likes WHERE post_id = ?` is an **aggregation computed live, on every read**, over a row set whose size is unbounded and grows precisely with the post's popularity. For a normal post with a handful of likes, this is cheap. For a viral post with 500K+ rows matching that `post_id`, this same query becomes an expensive full scan of that post's row range on every single feed render — and because feed views of a viral post are themselves disproportionately frequent (that's what "viral" means), the most expensive version of this query also gets called the most often. This is a **self-reinforcing hot-key bottleneck**: popularity directly drives both query cost and query frequency at the same time, for the same row.

**Fix — maintain a denormalized, incrementally-updated counter instead of computing the aggregate live:**

```sql
ALTER TABLE posts ADD COLUMN like_count BIGINT NOT NULL DEFAULT 0;

-- on like:
UPDATE posts SET like_count = like_count + 1 WHERE id = ?;
-- reads become:
SELECT like_count FROM posts WHERE id = ?;  -- O(1) lookup, no aggregation
```

For extremely high write concurrency on a single popular post's counter (many simultaneous likes on the same row), a single `UPDATE ... SET x = x + 1` can itself become a point of write contention — the further-scaled fix is a **sharded counter** (e.g., N counter shards per post, summed/approximated on read, or an async-aggregated counter backed by a stream of like events processed by a worker that periodically flushes the total) rather than one single hot row absorbing every increment.

**Broader lesson:** any "count/aggregate on read" pattern over an unbounded, popularity-correlated row set is a latent hot-key bottleneck that's invisible at low/uniform load and becomes the dominant cost exactly when the content in question is succeeding — which is precisely the worst time for it to degrade. The fix pattern (denormalized counter maintained incrementally at write time) generalizes to comment counts, view counts, and follower counts.
