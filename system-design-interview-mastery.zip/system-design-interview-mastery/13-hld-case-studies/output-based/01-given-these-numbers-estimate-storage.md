# Output: Given These Numbers, Estimate Storage

**Given:**
- A photo-sharing app has 20M daily active users.
- Each user uploads an average of 0.2 photos/day (i.e., 1 in 5 users uploads a photo on a given day).
- Each photo is stored in 3 sizes: original (~3 MB), a display version (~300 KB), and a thumbnail (~30 KB).
- The company wants a 5-year storage projection, and stores 3 replicated copies of everything for durability.

**Question:** What's the estimated storage requirement at 1 year and at 5 years, including replication?

**Answer, worked step by step:**

```
Photos/day = 20,000,000 × 0.2 = 4,000,000 photos/day

Storage per photo (all 3 sizes) = 3 MB + 300 KB + 30 KB ≈ 3.33 MB

Raw storage/day = 4,000,000 × 3.33 MB ≈ 13.3 TB/day
Raw storage/year = 13.3 TB × 365 ≈ 4.86 PB/year

With 3x replication: 4.86 PB × 3 ≈ 14.6 PB/year (replicated)

5-year raw (assuming steady growth, no deletion):
  ≈ 4.86 PB × 5 ≈ 24.3 PB raw
  ≈ 24.3 PB × 3 ≈ 73 PB replicated
```

**Why this matters for the architecture:** at petabyte scale, this immediately rules out a simple single-node or even simple-clustered block storage approach — this is squarely in "use a distributed object store" territory (S3-like, or an internal equivalent), not a traditional filesystem or a database BLOB column. It also justifies a **tiered storage strategy** as a cost optimization worth naming explicitly: originals accessed once at upload time and rarely again are a strong candidate for a cheaper "infrequent access" storage tier after some age threshold (e.g., 90 days), while thumbnails/display versions (accessed on every view) stay in a hot tier or behind a CDN — a single "13.3 TB/day at full price forever" assumption would be a naive answer; explicitly proposing tiering based on access-frequency-over-time is the stronger one.

**Common estimation mistake to flag:** forgetting to multiply by all 3 stored sizes (only counting the original) would understate storage by roughly 10% here — small in this case, but the more general lesson is to explicitly account for every derived artifact (thumbnails, transcoded versions, cached renditions) a system generates per logical upload, since these often add up to a comparable amount of storage to the original itself.
