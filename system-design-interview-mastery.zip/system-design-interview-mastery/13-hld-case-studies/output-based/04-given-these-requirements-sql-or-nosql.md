# Output: Given These Requirements, SQL or NoSQL?

**Given:** You're designing the notification storage for a social app. Requirements:
- Each user can have thousands of notifications ("X liked your post," "Y followed you," "Z commented").
- The dominant (99% of traffic) access pattern is: "fetch the most recent 20 notifications for user X, newest first."
- Notifications are never queried by any field other than the owning user and recency — no cross-user joins, no complex filtering by notification type in the common path.
- Write volume is very high (every like/follow/comment across the whole platform generates a notification write).
- A notification, once created, is immutable except for a `read`/`unread` flag.

**Question:** SQL or NoSQL for this entity, and what specific store/schema shape follows from the requirements?

**Answer:** **NoSQL — specifically a wide-column or key-value store, partitioned by `userId`.** Walking through why, requirement by requirement:

- **No cross-entity joins needed** — the dominant query never needs to join notifications against anything else in a single request; it's a self-contained lookup by owner. This removes the primary reason to reach for a relational store.
- **Single, extremely well-known access pattern** ("recent N for this user") — this is exactly the shape NoSQL partition/sort-key designs are built for: partition key = `userId`, sort key = a time-sortable id (Snowflake/ULID) or timestamp descending, giving an O(1)-partition-lookup + range-scan query with no aggregation or join required.
- **Very high write volume, low complexity per write** — each write is a simple, single-partition insert (append a notification to the recipient's partition) with no multi-row transaction requirement, which is a cheap, horizontally-scalable write pattern for a partitioned store, whereas a single relational primary would need to absorb all of that write volume on one instance (or be manually sharded to get the same property NoSQL gives natively).
- **The `read`/`unread` flag update** is a simple single-record field update, not a multi-record transaction — doesn't require relational transaction guarantees.

**A concrete schema shape** (e.g., DynamoDB-style):
```
Partition key: userId
Sort key: notificationId (time-sortable, e.g. a Snowflake ID — descending sort gives newest-first for free)
Attributes: { type, actorId, targetId, read: bool, createdAt }
```
Query: `Query WHERE userId = X ORDER BY notificationId DESC LIMIT 20` — a single-partition range query, exactly matching the dominant access pattern, with no scatter-gather across partitions needed.

**Why not SQL here:** you *could* model this relationally (`notifications(id, user_id FK, ...)` with an index on `(user_id, created_at DESC)`), and it would technically work at moderate scale — but it forces all that very high write volume through however that table is sharded/scaled relationally, without gaining anything from SQL's actual strengths (joins, multi-row transactions), since this entity never uses either. The requirements point cleanly at a partition-key-native store because the access pattern is exactly what that class of store is optimized for, and none of the requirements ask for what SQL is specifically good at.

**What would flip the answer:** if a new requirement appeared — "notifications must support complex admin-side filtering across all users by type and date range for a moderation dashboard" — that's a different, secondary access pattern poorly served by the userId-partitioned NoSQL shape, and would justify *also* streaming notification writes into a separate analytical store (a columnar warehouse) for that use case, rather than trying to force the primary read path's store to serve both patterns well.
