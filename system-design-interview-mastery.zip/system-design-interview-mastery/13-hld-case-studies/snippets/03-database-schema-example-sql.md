# Snippet: A Justified SQL Schema Example (Job Portal)

```sql
-- companies posting jobs
CREATE TABLE companies (
  id BIGINT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT now()
);

-- job postings — the dominant read pattern is "search/filter active jobs,"
-- so denormalize company_name onto the listing to avoid a join on every search result render
CREATE TABLE job_listings (
  id BIGINT PRIMARY KEY,
  company_id BIGINT NOT NULL REFERENCES companies(id),
  company_name VARCHAR(255) NOT NULL, -- denormalized copy, reconciled async on company rename
  title VARCHAR(255) NOT NULL,
  location VARCHAR(255),
  status VARCHAR(20) NOT NULL DEFAULT 'active', -- active | closed | draft
  posted_at TIMESTAMP NOT NULL DEFAULT now(),
  INDEX idx_status_posted_at (status, posted_at DESC) -- serves the dominant "active jobs, newest first" query
);

-- applications — the transactional core: a single application must atomically
-- reference exactly one listing and one applicant, and its status transitions
-- (applied -> reviewed -> interview -> offer/rejected) must be consistent
CREATE TABLE applications (
  id BIGINT PRIMARY KEY,
  job_listing_id BIGINT NOT NULL REFERENCES job_listings(id),
  applicant_id BIGINT NOT NULL REFERENCES users(id),
  status VARCHAR(20) NOT NULL DEFAULT 'applied',
  applied_at TIMESTAMP NOT NULL DEFAULT now(),
  UNIQUE (job_listing_id, applicant_id) -- enforces "one application per user per listing" at the DB level
);
```

The `UNIQUE (job_listing_id, applicant_id)` constraint is doing real design work: rather than checking "has this user already applied?" in application code (a race condition under concurrent requests), the database itself rejects a duplicate insert atomically — this is the kind of detail worth calling out explicitly as "why," not just "what," in an interview.
