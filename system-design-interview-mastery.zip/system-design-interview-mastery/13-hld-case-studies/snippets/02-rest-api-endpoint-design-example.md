# Snippet: REST API Endpoint Design Example (Booking System)

```
POST /api/v1/reservations
Headers: Idempotency-Key: <client-uuid>
Request:
{
  "showtimeId": "st_789",
  "seatIds": ["A12", "A13"]
}
Response 201:
{
  "reservationId": "res_456",
  "status": "held",
  "expiresAt": "2026-08-22T18:15:00Z"
}
Response 409: { "error": "seat_unavailable", "seatIds": ["A13"] }


POST /api/v1/reservations/{reservationId}/confirm
Request:  { "paymentToken": "tok_abc" }
Response 200: { "reservationId": "res_456", "status": "confirmed" }
Response 410: { "error": "hold_expired" }


GET /api/v1/showtimes/{showtimeId}/seats?cursor=&limit=100
Response 200:
{
  "seats": [ { "id": "A12", "status": "available" }, ... ],
  "nextCursor": null
}
```

Notes embedded in the design itself:
- `POST /reservations` is a two-phase **hold → confirm** split specifically to create a checkpoint between "seat tentatively locked" and "payment succeeded," so a slow/abandoned payment doesn't hold a seat forever (the hold has `expiresAt`) and so a network retry of the hold request is safe via the idempotency key.
- `409` on the hold request surfaces exactly which requested seats are unavailable, letting the client offer alternatives without a second round trip.
- `410 Gone` on confirm (not `404`) is deliberate — it distinguishes "this reservation never existed" from "it existed but its hold window lapsed," which the client needs to handle differently (show "seats released, please retry" vs. a generic error).
