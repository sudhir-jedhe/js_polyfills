# Snippet: Describing a High-Level Architecture Diagram (Template)

When there's no whiteboard (a phone screen, a doc-only interview), describe the architecture as a left-to-right request flow, naming each component's specific job:

```
[Client: web / mobile]
      │  HTTPS
      ▼
[CDN]  ──── serves static assets + cached public GET responses at the edge
      │
      ▼
[Load Balancer]  ──── distributes traffic across stateless app servers, health-checks them
      │
      ▼
[Application Tier (stateless, horizontally scaled)]
      │                              │
      ▼                              ▼
[Cache (Redis)]                [Primary DB (writes)]
  serves hot reads,                   │
  reduces DB load                     ▼
      │                        [Read Replicas]
      ▼                          serve read-heavy
[on cache miss, fall              queries, offload
 through to replica/primary]      the primary
      │
      ▼
[Async Queue (Kafka/SQS)] ──── decouples slow/non-critical side effects
      │                        (emails, notifications, analytics) from
      ▼                        the synchronous request path
[Background Workers]
```

A verbal walkthrough following this: *"A client request hits the CDN first for anything cacheable at the edge; everything else goes through a load balancer to a pool of stateless app servers. Reads check the cache first, falling through to a read replica on a miss, keeping the primary reserved mostly for writes. Writes that have side effects that don't need to block the client's response — sending a confirmation email, updating analytics — get pushed onto a queue and handled asynchronously by background workers, so the client gets a fast acknowledgment without waiting on those steps."*

This narrated-flow format is the reusable template for describing architecture in any case study in `problems/` when a visual diagram isn't available.
