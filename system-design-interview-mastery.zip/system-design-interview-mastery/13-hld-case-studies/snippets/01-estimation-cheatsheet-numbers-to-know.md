# Snippet: Estimation Cheat Sheet

A compact reference to do back-of-envelope math live in an interview without fumbling for numbers.

```
Time conversions:
  1 day    ≈ 86,400 s   (round to 100,000 for quick mental math)
  1 month  ≈ 2.6M s
  1 year   ≈ 31.5M s

QPS from DAU:
  avg QPS  = (DAU × actions/user/day) / 86,400
  peak QPS = avg QPS × 3   (typical peak multiplier; use 2-5x depending on traffic shape)

Storage:
  daily storage  = writes/day × avg record size
  yearly storage = daily storage × 365
  (multiply by replication factor, e.g. x3, for raw disk provisioning)

Common record sizes:
  UUID (binary)        16 B
  UUID (string)         36 B
  Short URL record     ~500 B
  Tweet-like post       ~1 KB
  User profile row      ~1 KB
  Small JSON response   0.5–2 KB
  Compressed thumbnail  20–100 KB
  Phone photo            2–5 MB
  1 min of SD video      5–10 MB

Latency reference points:
  Same-datacenter round trip     ~0.5 ms
  SSD random read                ~0.1 ms
  Cross-continent round trip     ~100–150 ms
  1 MB over 1 Gbps network       ~10 ms
```

**Worked example — a URL shortener at 50M new URLs/month, 100:1 read:write ratio:**
```
writes/day  = 50,000,000 / 30 ≈ 1.67M
write QPS   = 1,670,000 / 86,400 ≈ 19 QPS avg → ~60-100 QPS peak
read QPS    = 19 × 100 = 1,900 QPS avg → ~5,700-9,500 QPS peak

storage/day  = 1.67M × 500 B ≈ 835 MB/day
storage/year = 835 MB × 365 ≈ 305 GB/year
```
Conclusion drawn from these numbers: write volume is trivial for a single DB primary; read volume at peak (up to ~9,500 QPS) is where a cache pays for itself — exactly the kind of connective sentence to say out loud after computing the numbers.
