# API Design in System Design Interviews

Defining the API surface early forces precision about what the system actually does before you design internals around it — and it's a fast, high-signal step that's easy to shortchange under time pressure. A few minutes here catches edge cases (idempotency, pagination, partial failure) that are cheap to name now and expensive to discover during the deep dive.

## What to define, and at what level of detail

For each core action identified in requirements gathering, define: HTTP method + path, request shape, response shape, and the key status codes. Skip auth/header boilerplate unless it's specifically relevant to the system being designed (e.g., a rate limiter's API design *is* mostly about headers).

```
POST /api/v1/urls
Request:  { "longUrl": "https://...", "customAlias": "optional", "expiresAt": "optional ISO8601" }
Response: 201 { "shortUrl": "https://sho.rt/abc123", "code": "abc123" }
          400 if longUrl is invalid
          409 if customAlias is already taken

GET /{code}
Response: 302 redirect, Location: <longUrl>
          404 if code doesn't exist or has expired
```

## Idempotency for write/mutation endpoints

Any client-retriable write (network blips are common, and clients *will* retry) needs an explicit idempotency story, or a retried request risks a duplicate side effect (double-charging a payment, double-booking a seat). The standard pattern is a client-supplied idempotency key:

```
POST /api/v1/orders
Headers: Idempotency-Key: <client-generated-uuid>
```
The server stores completed idempotency keys (with a TTL) and returns the original response for a repeated key instead of re-executing the mutation. This is worth naming explicitly for any case study involving payments, bookings, or order creation — interviewers specifically probe this.

## Pagination for list endpoints

Any endpoint that can return an unbounded list needs pagination from the start — retrofitting it after the fact is a breaking API change. Prefer **cursor-based** pagination over offset-based for anything backed by a frequently-changing dataset:

```
GET /api/v1/messages?conversationId=123&cursor=<opaque-token>&limit=50
Response: { "messages": [...], "nextCursor": "<opaque-token-or-null>" }
```

Offset-based (`?page=3&size=50`) is simpler but suffers from **page drift**: if items are inserted/deleted between page requests, the same offset can return duplicate or skipped items — a real correctness issue for a live feed, not just a cosmetic one. Cursor-based pagination (typically encoding the last-seen sort key) avoids this because it's anchored to a specific item's position, not an absolute count.

## Read vs. write endpoint asymmetry

Read-heavy systems (URL shortener, content feed) benefit from designing reads to be maximally cacheable — stable URLs, explicit cache-control semantics, denormalized response shapes that avoid needing a join at read time. Write-heavy or transactional systems (checkout, booking) benefit from designing writes to be as narrow and validated as possible, often splitting a conceptually "single" user action into an explicit multi-step API (`reserve` → `confirm`) specifically to create a checkpoint for handling partial failure and timeouts cleanly.

## Error semantics

Define what a client should do on failure, not just what status code comes back — is a `503` retriable, and if so, with what backoff? Is a `409` (conflict) something the client should resolve by re-fetching state, or is it terminal? For any endpoint that's part of a deep-dive discussion later, its failure/retry semantics are usually exactly what the interviewer wants to probe, so having them defined upfront saves re-deriving them live.

## Internal vs. external API surfaces

For systems with multiple services, distinguish the **public API** (what an end-user client calls) from **internal service-to-service APIs** (often gRPC/binary protocols for performance, versus REST/JSON for the public-facing surface) — naming this distinction, even briefly, signals awareness that a real system's API design isn't monolithic.
