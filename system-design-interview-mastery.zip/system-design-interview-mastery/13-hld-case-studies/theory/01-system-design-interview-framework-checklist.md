# The System Design Interview Framework: A Repeatable Checklist

Every high-level system design interview — "design X" for any X — can be worked through with the same repeatable sequence. Interviewers are grading your *process* as much as your final architecture; a candidate who jumps straight to "we'll use Kafka and Redis" without ever stating requirements or doing capacity math reads as someone who's memorized components, not someone who can actually reason about a system. This checklist is the backbone every case study in `problems/` follows explicitly.

## The sequence

### 1. Requirements clarification (5-10 minutes)

**Functional requirements** — what the system must *do*, scoped explicitly (interviewers deliberately give an underspecified prompt; asking clarifying questions is graded):
- Who are the users/clients (end users, other services, mobile vs. web)?
- What are the core actions (read-heavy? write-heavy? both)?
- What's explicitly *out of scope* for this session (say it out loud — "I'll assume payment processing is out of scope and focus on the booking flow")?

**Non-functional requirements** — the qualities the system must have:
- Scale: how many users, how much data, what request volume (this feeds directly into estimation)?
- Latency: what's an acceptable p99 response time for the core read/write paths?
- Availability vs. consistency: can this tolerate eventual consistency, or does it need strong consistency (this is the single most consequential early decision — see `05-consistency-vs-availability-tradeoff-framework.md`)?
- Durability: can data ever be lost, or must every write survive a crash?

A strong candidate writes these down visibly (on a whiteboard/doc) and gets interviewer buy-in before proceeding — this converts an ambiguous prompt into an agreed contract, and gives you something to point back to when scope-creep happens mid-interview.

### 2. Capacity estimation ("back-of-envelope math")

Convert the non-functional requirements into concrete numbers: requests/second (read and write, separately), storage growth per day/year, bandwidth. See `02-capacity-estimation-formulas-and-technique.md` for the actual formulas and reference numbers. This step is not decoration — the numbers you derive here directly justify later architectural choices (e.g., "at 50K writes/sec, a single Postgres primary can't take this without partitioning" is a claim capacity math backs up; without the math, it's just an assertion).

### 3. API design

Define the core endpoints/contracts at a black-box level — request/response shape, not implementation:
```
POST /api/v1/urls        { longUrl } -> { shortUrl, code }
GET  /{code}             -> 302 redirect to longUrl
```
This forces you to nail down the system's actual interface before designing internals around it, and surfaces edge cases early (idempotency, pagination, auth) that are cheap to catch now and expensive to retrofit later in the interview.

### 4. Data model

Identify the core entities, their relationships, and — critically — **justify SQL vs. NoSQL and the schema shape based on the access patterns from step 3**, not out of habit (see `06-sql-vs-nosql-choice-framework.md`). Sketch the schema/document shape for the 2-3 most important entities; don't attempt to fully normalize every entity in an interview's time budget.

### 5. High-level architecture

Draw (describe, if verbal/no whiteboard) the major components and how requests flow through them — client → load balancer → application tier → cache → database, plus any async/queue-based paths. State *why* each component exists in terms of the requirements from step 1 (a cache exists because read latency must be low and the read:write ratio is high; a queue exists because writes must be durable but processing can be async).

### 6. Deep dive on 1-2 components

The interviewer will steer this, or you should proactively pick the most interesting/riskiest part of the system (e.g., "how do we guarantee unique short codes without a single point of contention?" for a URL shortener). This is where most of the signal comes from — a candidate who's fluent for the first five steps but hand-waves the deep dive hasn't demonstrated depth.

### 7. Identify bottlenecks and scale them

Explicitly revisit the architecture: what breaks first as load grows 10x? 100x? Name the bottleneck (a single DB write node, a hot partition key, a cache stampede) and the specific mitigation (read replicas, sharding, cache warming) — see `07-identifying-bottlenecks-and-scaling-strategies.md`.

## Time budgeting in a 45-minute interview

| Phase | Rough time |
|---|---|
| Requirements + estimation | 8-10 min |
| API + data model | 8-10 min |
| High-level architecture | 8-10 min |
| Deep dive | 12-15 min |
| Bottlenecks/wrap-up | 5 min |

Running over on requirements-gathering at the expense of the deep dive is the most common self-inflicted failure mode — the checklist is a guide for breadth, but depth on 1-2 components is where the interview is actually won or lost.
