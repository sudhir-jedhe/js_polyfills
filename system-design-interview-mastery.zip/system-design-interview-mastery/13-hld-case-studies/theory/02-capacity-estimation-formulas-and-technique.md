# Capacity Estimation: Formulas and Technique

Back-of-envelope math converts a vague scale requirement ("millions of users") into concrete numbers that drive real architectural decisions. Interviewers don't expect precision — they expect you to know the right formulas, use reasonable assumptions, and arrive at an order-of-magnitude figure fast, out loud, showing your work.

## The core formulas

**Requests per second (QPS) from daily active users (DAU):**
```
QPS (average) = (DAU × actions per user per day) / 86,400 seconds
QPS (peak)    = QPS (average) × peak factor (typically 2-5x for consumer apps with daily usage patterns)
```
Example: 10M DAU, each performs 5 searches/day → `(10,000,000 × 5) / 86,400 ≈ 579 QPS average` → `~1,700-2,900 QPS peak` at a 3-5x factor.

**Storage growth:**
```
Daily storage = new records/day × average record size
Yearly storage = Daily storage × 365 (× replication factor, if counting raw disk)
```
Example: 5M new short URLs/day, each record ~500 bytes → `5,000,000 × 500 bytes = 2.5 GB/day` → `~915 GB/year` before replication.

**Bandwidth:**
```
Bandwidth = QPS × average payload size
```
Example: 2,000 QPS reads, average response 2 KB → `2,000 × 2 KB = 4 MB/s ≈ 32 Mbps`.

**Read:write ratio** — always derive this early, since it determines whether caching helps much (skewed toward reads) or whether you need to focus on write scaling instead (skewed toward writes, or 1:1). A URL shortener might be 100:1 read:write; a chat app is closer to 1:1 (every message is both a write and, shortly after, a read by recipients).

## Numbers worth memorizing (order-of-magnitude reference points)

| Quantity | Approximate value |
|---|---|
| 1 day in seconds | ~86,400 (~100K, round for quick math) |
| 1 month in seconds | ~2.6M |
| L1 cache reference | ~1 ns |
| Main memory reference | ~100 ns |
| Round trip within same datacenter | ~0.5 ms |
| SSD random read | ~100 μs (0.1 ms) |
| Round trip cross-continent (e.g., US ↔ Europe) | ~100-150 ms |
| Reading 1 MB sequentially from memory | ~10 μs |
| Reading 1 MB sequentially from SSD | ~1 ms |
| Reading 1 MB over a 1 Gbps network | ~10 ms |

These aren't meant to be quoted verbatim in an interview — they're intuition anchors for statements like "a cross-region synchronous write would add ~100-150ms to every request, which blows our latency budget, so we need async replication instead."

## Storage size estimates for common data types

| Data type | Typical size |
|---|---|
| A UUID | 16 bytes (36 bytes as a string) |
| A URL | 100-500 bytes typically, cap around 2KB |
| A tweet/short text post | ~280 bytes text + metadata, ~1KB total |
| A JSON API response (small object) | 0.5-2 KB |
| A user profile row | ~1 KB |
| A compressed thumbnail image | 20-100 KB |
| A standard photo (uncompressed-ish, e.g. from a phone) | 2-5 MB |
| A minute of standard-definition video | ~5-10 MB |

## The technique, step by step

1. **State your assumptions explicitly and round aggressively** — "let's say 10 million daily active users, each performing an average of 3 write actions and 20 read actions per day" is a fine starting assumption to state out loud; precision isn't the point, directional correctness is.
2. **Compute average QPS first, then apply a peak multiplier** — average alone understates the capacity you actually need to provision for, since traffic isn't uniform across the day; ignoring peak factor is a common and costly omission.
3. **Compute storage growth per day, then extrapolate to 1 year and 5 years** — this is what tells you whether you need to plan for sharding/archival from day one or whether a single well-provisioned database instance is fine for the foreseeable future.
4. **Sanity-check against a known reference point** — "579 QPS is well within what a single modern application server can handle; the bottleneck will be the database, not the app tier" is the kind of connective sentence that shows you're using the numbers to reason, not just producing them because the checklist says to.
5. **Let the numbers change your architecture, and say so explicitly** — "given 900GB/year and a 5-year retention requirement, we're at ~4.5TB, which is past the point I'd keep everything in a single unsharded table — I'd plan to shard by [key] from the start" is exactly the connective tissue interviewers want to hear, distinguishing estimation-as-theater from estimation-that-drives-design.
