# Consistency vs. Availability: A Practical Tradeoff Framework

CAP theorem is usually taught as an abstract trilemma; in an interview, the useful skill is applying it as a **per-feature decision framework** — most real systems aren't uniformly CP or AP, they make this call differently for different parts of the same product.

## CAP theorem, stated practically

Under a network partition (which *will* happen in any distributed system — this isn't a hypothetical), you must choose:
- **CP (Consistency + Partition tolerance)**: refuse to serve a request rather than risk returning stale/inconsistent data. The system becomes unavailable for affected requests during the partition.
- **AP (Availability + Partition tolerance)**: keep serving requests using whatever local data is available, accepting that different nodes may temporarily disagree (eventual consistency).

Partition tolerance isn't optional in a real distributed system (networks fail), so in practice CAP reduces to: **when a partition happens, do you sacrifice consistency or availability?**

## PACELC: the more useful extension

CAP only describes behavior *during* a partition. PACELC extends it: **"if Partitioned, choose Availability or Consistency; Else (normal operation), choose Latency or Consistency."** This second half matters more day-to-day, since partitions are rare but the latency/consistency tradeoff is live on every single request: a synchronous multi-region consistency check adds real latency to *every* write, partition or not.

## The practical question to ask per-feature

**"If this data is briefly stale, what's the actual cost?"** — answer that per feature, not once for the whole system:

| Feature | Cost of staleness | Right choice |
|---|---|---|
| Instagram like count | Near zero — nobody notices a like count off by a few for a few seconds | AP — eventual consistency, optimize for availability/low latency |
| A chat message's delivery order within a conversation | Moderate — confusing but not catastrophic if briefly out of order, though ordering *within one conversation* should still be enforced | Mostly AP with a per-conversation ordering guarantee, not full linearizability |
| Seat inventory in a ticket-booking flow | High — two users could both believe they got the last seat | CP for the actual reservation step (or an equivalent conflict-resolution mechanism), even though browsing seat availability can be AP |
| Bank account balance during a transfer | Very high — double-spending is a real financial/legal problem | CP — strong consistency required for the transactional write |
| A user's profile bio | Near zero | AP |

## Naming this explicitly in an interview

A strong answer doesn't say "I'll use eventual consistency" or "I'll use strong consistency" once for the whole system — it walks through 2-3 specific operations and makes the call for each, with reasoning: *"For seat availability display, I'll accept eventual consistency and a short cache TTL — showing a seat as available for a few extra seconds when it's actually just been taken is a minor UX hiccup caught at the confirmation step. But for the actual seat-lock/reservation write, I need strong consistency — I'll route that through a single-writer-per-seat mechanism (a distributed lock, or a DB-level unique constraint on `seat_id + showtime_id` with the first successful insert winning) so two users can never both successfully reserve the same seat."* This shows you understand the tradeoff is a per-operation design decision, not a single global setting.

## Common technique names to know for each side

- **Strong consistency mechanisms**: single-writer/single-leader per key, distributed locks, consensus protocols (Raft/Paxos) for leader election, database-level unique constraints/transactions, two-phase commit (rare in practice due to blocking failure modes, usually avoided in favor of sagas).
- **Eventual consistency mechanisms**: async replication, read replicas with replication lag, CRDTs for merge-without-conflict data types, "read-your-own-writes" as a common weaker consistency guarantee that's cheaper than full strong consistency but avoids the most jarring user-facing staleness (a user should always see their own just-made edit, even if other users see it with a short delay).
