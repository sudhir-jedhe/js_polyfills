# Identifying Bottlenecks and Scaling Strategies

After sketching an architecture, the strongest interview candidates proactively revisit it and ask "what breaks first as load grows?" — this is a distinct skill from designing the initial architecture, and it's frequently where a mid-level answer and a senior answer diverge most visibly.

## The standard bottleneck-identification pass

Walk through the architecture component by component and ask, for each: **at what multiple of current load does this stop working, and what's the specific failure mode?**

| Component | Typical bottleneck | Failure mode |
|---|---|---|
| Single DB primary (writes) | Write throughput ceiling of a single machine | Write latency climbs, then timeouts/rejected writes |
| DB without read replicas | All reads compete with writes on one instance | Read latency degrades under write load |
| Cache with no eviction policy tuning | Memory exhaustion, or excessive evictions of hot keys | Cache hit rate drops, load shifts back to DB, can cascade |
| A single hot partition/shard key | Uneven load distribution (e.g., a celebrity user's data, or "today's date" as a key) | One shard saturates while others are idle — the classic "hot key/hot partition" problem |
| Synchronous cross-service calls | Latency compounds linearly with each hop; one slow dependency stalls the whole chain | Cascading latency, or cascading failure if no timeout/circuit breaker |
| A single load balancer/entry point | Becomes a single point of failure and a throughput ceiling | Outage if it fails; capacity ceiling if under-provisioned |

## Core scaling techniques, matched to the bottleneck they solve

**Vertical scaling** (bigger machine) — the first, cheapest lever, but has a hard ceiling and doesn't address availability (still a single point of failure). Good as a stopgap, not a long-term strategy for anything at real scale.

**Horizontal scaling + load balancing** (more machines, stateless where possible) — solves application-tier throughput and availability, assuming the tier is designed to be stateless (session state externalized to a shared store, not kept in-process) so any instance can serve any request.

**Read replicas** — solves read-heavy bottlenecks cheaply: replicate the primary to N read-only replicas, route reads to them, keep writes on the primary. Introduces replication lag (a consistency tradeoff — see the CAP/PACELC framework) that must be explicitly acknowledged, not ignored.

**Caching** (CDN, application-level cache like Redis, or a local in-process cache) — solves read latency and reduces load on the DB, at the cost of a cache-invalidation problem ("there are only two hard things in computer science...") that needs an explicit strategy (TTL-based, write-through, or explicit invalidation on write).

**Sharding/partitioning** — solves write-throughput and total-data-size ceilings by splitting data across multiple database instances by a partition key. The partition key choice is the single highest-leverage decision here (see `04-data-modeling-and-schema-design-approach.md`) — a poorly chosen key creates a new hot-shard bottleneck instead of solving the original one.

**Asynchronous processing / queues** — solves the case where a write's *acknowledgment* to the client doesn't need to wait for all of the write's downstream effects (e.g., "order placed" can return immediately while "send confirmation email," "update analytics," "notify warehouse" happen asynchronously via a queue/event bus) — converts a slow synchronous chain into a fast synchronous ack plus a resilient async pipeline.

**Circuit breakers and timeouts** — solves cascading failure from a slow/failing downstream dependency: a circuit breaker stops calling a dependency that's failing/timing out repeatedly, failing fast instead of piling up latency and exhausting the calling service's own resources (connection pools, threads) waiting on a dependency that isn't going to respond in time.

**Rate limiting / backpressure** — solves the case where legitimate-but-excessive load (or a runaway client/bug) threatens to overwhelm a component — protects the system's own stability rather than trying to serve unlimited load at any cost.

## Presenting this in an interview

The strongest version of this step is proactive and specific, not a generic list recited at the end: *"At our current estimate of 2,000 writes/sec this single-primary Postgres setup is fine, but if this grows another 10x to 20,000 writes/sec, a single primary becomes the bottleneck — at that point I'd shard by `userId`, since our dominant write pattern is always scoped to a single user, which keeps each write on exactly one shard with no cross-shard transaction needed."* This ties the bottleneck, the trigger point (a specific multiple of current load), and the specific mitigation (with a justified partition key) together — exactly the reasoning chain interviewers are listening for.
