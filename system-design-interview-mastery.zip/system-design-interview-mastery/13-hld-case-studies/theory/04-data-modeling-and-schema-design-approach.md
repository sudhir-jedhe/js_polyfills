# Data Modeling and Schema Design Approach

Data modeling in a system design interview is not "draw an ER diagram of every entity" — it's identifying the 2-4 entities that matter most for the system's core flows, and justifying their shape based on **access patterns**, not academic normalization.

## Start from access patterns, not entities

The wrong instinct: "what are all the nouns in this system?" (User, Order, Product, Payment, Review, ...) followed by fully normalizing all of them. The right instinct: "what are the 3-5 queries this system needs to run fast and often?" and design the schema to make *those* queries cheap, even if it means deliberate denormalization elsewhere.

Example — for a chat app, the dominant access pattern is "fetch the last N messages for a conversation, ordered by time, paginated backward." That single access pattern should directly determine the primary key/partition strategy for a `messages` table (partitioned by `conversationId`, sorted by `timestamp`/message id) — designing the schema around a different, secondary access pattern (e.g., "look up all messages by a given user across all conversations") first would produce a worse shape for the actual dominant query.

## Normalize vs. denormalize: the real tradeoff

| | Normalized | Denormalized |
|---|---|---|
| Write complexity | Simple — update one place | Higher — may need to update multiple copies |
| Read complexity | May need joins across tables | Single-table read, often the whole point |
| Storage | Efficient — no duplication | More storage — data is duplicated |
| Consistency risk | Low — single source of truth | Risk of copies drifting out of sync if not updated carefully |
| Best for | Write-heavy, low read fan-out | Read-heavy, especially when reads need "the answer" fast without joins |

A concrete pattern: storing a denormalized `authorName`/`authorAvatarUrl` directly on a `Post` record (instead of only an `authorId` requiring a join at read time) trades a small write-time cost (updating it if the author changes their name) for a large read-time win (no join needed for the extremely common "render a feed of posts" query) — and the write-time cost is often mitigated by accepting eventual consistency for that denormalized copy (a background job reconciles it, rather than a synchronous update on every profile edit).

## Choosing a primary/partition key

The partition key decision is one of the highest-leverage schema decisions in a distributed data store, because it determines which requests can be served by a single partition/shard vs. requiring a scatter-gather across many. Choose it based on the dominant query's filter clause: if the dominant query is "get all orders for this user," partition by `userId`; if it's "get all events in this time window," a naive partition by exact timestamp creates a hot partition (all writes for "now" go to one partition) — better to partition by a coarser bucket (e.g., `userId` + time-bucket composite, or a hashed key) to spread write load.

## Sketching a schema for the interview

For a relational example (order system):
```sql
orders(id PK, user_id FK, status, total_cents, created_at)
order_items(id PK, order_id FK, product_id FK, quantity, price_cents_at_purchase)
```
Note `price_cents_at_purchase` — a deliberate denormalization: the price is copied onto the order line item at purchase time rather than always joining to the live `products` table, because an order's historical total must never change just because a product's price changed later. This single naming choice ("why is price duplicated here?") is exactly the kind of detail that signals real modeling experience versus a generic textbook schema.

For a document/NoSQL example (chat message):
```json
{
  "conversationId": "conv_123",
  "messageId": "01HXYZ...",  // ULID/Snowflake — sortable by time, unique
  "senderId": "user_456",
  "text": "...",
  "sentAt": 1719000000000,
  "readBy": ["user_789"]
}
```
Partitioned by `conversationId`, sorted by `messageId` (a time-sortable id like a Snowflake ID or ULID doubles as both a unique identifier and a sort key, avoiding a separate `sentAt` index for the dominant "recent messages" query).

## What to explicitly skip in an interview

Full third-normal-form modeling of every entity, exhaustive foreign key constraints, and every possible secondary index are not a good use of interview time — name that you're aware of them ("in a real system I'd also index X for the admin reporting use case, but I'll skip that here to focus on the core flow") rather than actually drawing them all out.
