# SQL vs. NoSQL: A Choice Framework

"SQL or NoSQL" is not a single global decision for a system — different entities in the same product routinely live in different stores, chosen based on that entity's specific access pattern, consistency needs, and schema volatility. A strong interview answer justifies the choice per major entity, not once for "the database."

## The actual decision axes (not "NoSQL scales better")

| Axis | Favors SQL (relational) | Favors NoSQL |
|---|---|---|
| Relationships between entities | Many-to-many, need for joins across entities (orders ↔ products ↔ users) | Data naturally denormalized/self-contained per record (a chat message, a single document) |
| Transaction requirements | Multi-row/multi-table ACID transactions needed (money movement, inventory decrement + order creation together) | Each write is naturally scoped to one record/partition |
| Schema stability | Schema is well-understood and changes rarely | Schema is evolving fast, or genuinely varies per record (different product types with different attribute sets) |
| Query flexibility needed | Ad-hoc queries, reporting, filtering on many different columns | Access patterns are known and few, each servable by a fixed key lookup |
| Write throughput at extreme scale | Vertical scaling has a ceiling; horizontal sharding is possible but more manual/complex | Built for horizontal partitioning from the ground up (most NoSQL stores are designed around a partition key from day one) |
| Read pattern | Complex joins/aggregations | Single-key or single-partition lookups, or wide-column range scans |

**The "NoSQL scales better" claim is a half-truth**: modern relational databases (properly sharded, with read replicas) scale to enormous throughput too — see companies running sharded MySQL/Postgres at massive scale. What actually differs is which sharding/partitioning strategy is *native and easy* vs. *possible but requires more manual work* — NoSQL stores are generally designed around partition keys as a first-class concept from day one, which is genuinely simpler to reason about at scale for access patterns that fit that shape.

## A worked decision, per entity, for a hypothetical e-commerce system

- **`orders` / `order_items` / `payments`**: SQL. These require multi-table transactions (an order and its line items and the resulting payment must commit together or not at all) and relational integrity (an order line item must reference a valid product). This is the textbook ACID use case.
- **`product_catalog`**: could go either way, but NoSQL (document store) is attractive if products vary widely in attribute shape (a book has an ISBN and author; a t-shirt has a size and color) — forcing that into a single rigid relational schema means either a sparse table full of nullable columns or an EAV (entity-attribute-value) anti-pattern; a document store naturally handles per-product-type variable shape.
- **`user_sessions` / `shopping_cart`**: NoSQL, specifically a key-value store (Redis) — access pattern is purely "get/set by session id," extremely high read/write volume, and the data is disposable/short-lived (doesn't need durability guarantees as strong as an order record).
- **`product_search`**: neither, really — a dedicated search index (Elasticsearch/OpenSearch) for full-text and faceted search, since neither SQL nor a basic NoSQL key-value/document store is built for relevance-ranked full-text search at scale.
- **`clickstream/analytics events`**: a wide-column or time-series store (Cassandra, or a columnar warehouse like BigQuery/Redshift for the analytical side) — write-heavy, append-only, queried by time range and aggregated, not point-looked-up by a single key.

## The interview framing that signals seniority

Rather than declaring "I'll use NoSQL because we need to scale," walk through 2-3 entities and justify each independently, explicitly naming the axis that decided it: *"Orders need multi-table transactional integrity, so that's relational. But the shopping cart is a pure key-value access pattern with no cross-entity transaction requirement and very high read/write volume relative to its low value-per-record, so I'd put that in Redis instead."* This demonstrates you're choosing based on access patterns and consistency needs, not repeating a rule of thumb.
