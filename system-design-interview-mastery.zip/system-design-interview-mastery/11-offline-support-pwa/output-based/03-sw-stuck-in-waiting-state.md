# Output: Service Worker Stuck in "Waiting" State

```js
// sw.js — no skipWaiting() anywhere
self.addEventListener('install', (event) => {
  event.waitUntil(caches.open('v5').then((c) => c.addAll(['/', '/app.js'])));
});
```

**Scenario:** A team deploys a bug fix. The build hash changes, so the browser detects a byte-diff and installs a new SW (`v5`). QA opens the site in a tab that's been open since before the deploy, refreshes it several times, and still sees the old broken behavior. Closing and reopening the browser fixes it.

**Question:** Why does refreshing not pick up the fix, and why does a full close/reopen work?

**Answer:** With no `skipWaiting()`, a newly-installed SW enters the **waiting** state and stays there as long as *any* open tab/client is still controlled by the previous SW. A same-tab refresh does not release control mid-navigation the way you'd expect — the outgoing page is controlled by the old SW right up until unload, and by default the *new* navigation in that same tab can still be served by the old SW if it's still "active" (the new one only takes over once the old one has zero controlled clients, which a single refreshing tab alone does not guarantee, since the navigation request itself can be considered a continuation).

In practice, the safe way to guarantee an update while a tab stays open is to explicitly detect the waiting SW and either prompt the user or force `skipWaiting()` from the page — refreshing alone is not a reliable signal, because the number of "controlled clients" doesn't reliably drop to zero from a single tab's reload in every browser's implementation nuance.

Closing the tab entirely (or closing all tabs of that origin) removes every client controlled by the old SW, satisfies the "waiting" state's condition, and the new SW activates the moment a fresh tab is opened.

**Fix:** register an `updatefound` listener, detect `installed` + `navigator.serviceWorker.controller` present (meaning this is an update, not first install), and either call `skipWaiting()` proactively or show a "refresh to update" prompt — never leave it to chance that users will eventually close every tab.
