# Output: IndexedDB Version Upgrade Blocked Across Tabs

```js
function openDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open('app-db', 3); // bumped from version 2
    req.onupgradeneeded = (e) => { /* create new object store */ };
    req.onsuccess = () => resolve(req.result);
    req.onblocked = () => console.warn('upgrade blocked');
    req.onerror = () => reject(req.error);
  });
}
```

**Scenario:** A user has the app open in two browser tabs, both on the old deploy (DB version 2). They then load the app fresh in a third tab, which has the new deploy requesting DB version 3.

**Question:** What happens to the third tab's `indexedDB.open()` call?

**Answer:** It **hangs** — neither `onsuccess` nor `onerror` fires. `onblocked` fires instead, and the `open()` request simply sits pending indefinitely, because a version-change transaction (which `onupgradeneeded` runs inside) requires exclusive access: every other connection to that database must be closed first. The two older tabs still hold open connections at version 2, and unless something explicitly closes them, they never will on their own.

The two old tabs, meanwhile, receive an `onversionchange` event on their existing connections (assuming a handler is registered) — but if the app never listens for it, nothing happens there either, and the third tab stays stuck.

**Fix, both sides:**

```js
// on every open connection, anywhere in the app:
db.onversionchange = () => {
  db.close(); // release the lock so a pending upgrade elsewhere can proceed
  showToast('App updated in another tab — please refresh this one too.');
};
```

```js
// on the requesting side, don't let onblocked hang forever silently:
req.onblocked = () => {
  showToast('Please close other tabs of this app to finish updating.');
};
```

**Why this is a real production bug:** without the `onversionchange` handler, a user who keeps several tabs open across a deploy that bumps the schema version can get the new tab permanently stuck on "loading" with no error surfaced anywhere, because the promise from `openDB()` in the new tab never resolves or rejects — it just hangs until the old tabs happen to close.
