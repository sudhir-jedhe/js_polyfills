# Output: Network-First With a Timeout Race

```js
async function networkFirst(request) {
  const cache = await caches.open('api-cache');
  try {
    const response = await Promise.race([
      fetch(request),
      new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), 2000)),
    ]);
    cache.put(request, response.clone());
    return response;
  } catch {
    return (await cache.match(request)) || new Response('offline', { status: 503 });
  }
}
```

**Scenario:** The user is on a slow 3G connection. The API takes 5 seconds to respond, but it *does* eventually succeed. A previous, older cached response for the same request exists.

**Question:** What does the user see, and does the slow-but-successful network response go to waste?

**Answer:** The user sees the **stale cached response** almost immediately (~2 seconds, when the timeout wins the race). The `fetch(request)` promise is not cancelled by `Promise.race` losing — it keeps running in the background even after the timeout branch has already resolved the `try` block's rejection. So when it finishes at the 5-second mark, its result is simply discarded (nothing is `await`-ing it or storing it), and the cache is never updated with the newer data despite the network call having actually succeeded.

**The fix (worth naming in an interview):** don't let the race discard the in-flight fetch — continue awaiting it in the background to update the cache for *next* time, even after returning the fallback to the user:

```js
} catch {
  fetch(request).then((response) => {
    if (response.ok) cache.put(request, response.clone()); // salvage the slow response
  }).catch(() => {});
  return (await cache.match(request)) || new Response('offline', { status: 503 });
}
```

This turns "network-first with a fast timeout" into something closer to stale-while-revalidate under slow-network conditions — fast response now, freshness banked for later, instead of thrown away.
