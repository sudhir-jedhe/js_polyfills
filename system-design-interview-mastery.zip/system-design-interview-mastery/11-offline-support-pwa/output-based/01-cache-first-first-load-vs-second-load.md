# Output: Cache-First on First Load vs. Second Load

```js
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open('v1').then((cache) => cache.addAll(['/', '/app.js']))
  );
});

self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request).then((cached) => cached || fetch(event.request))
  );
});
```

**Scenario:** A user visits the site for the very first time (no SW registered yet), then reloads immediately after.

**Question:** Does the *first* page load benefit from the cache-first fetch handler at all? What about the second load?

**Answer:**

- **First load:** No. Registering a service worker is asynchronous and the SW does not control the very page that triggered its own registration (unless `clients.claim()` was used and even then, only after `activate` completes — which happens after the first load has already finished loading its resources). The first load goes straight to the network for everything, exactly as if there were no SW at all.
- **Second load (reload):** Yes, fully. By the time of the reload, the SW has installed and activated, and it now controls the page. The `fetch` handler intercepts every request; `/` and `/app.js` are served instantly from the `v1` cache with zero network round trip.

**Why this matters:** it's the reason "test your PWA's offline mode" instructions always say "load the page once online first, then go offline and reload" — the very first visit can never be offline-capable, because there's nothing installed yet to intercept it. A design that assumes offline works from the first request is wrong by construction.
