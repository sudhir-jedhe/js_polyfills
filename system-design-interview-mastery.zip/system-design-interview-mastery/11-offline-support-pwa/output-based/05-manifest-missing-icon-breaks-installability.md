# Output: Missing Manifest Field Silently Breaks Installability

```json
{
  "name": "My App",
  "start_url": "/",
  "display": "standalone",
  "icons": [
    { "src": "/icon-192.png", "sizes": "192x192", "type": "image/png" }
  ]
}
```

The app also has a registered service worker with a `fetch` handler, and is served over HTTPS.

**Question:** The team can't figure out why Chrome never shows the "Install app" option, despite meeting what they believe are all the criteria. What's missing, and why does the browser give no error?

**Answer:** The manifest is missing a **512×512 icon**. Chrome's installability check requires icons covering both a 192px *and* a 512px size (the larger one is used for splash screens and higher-density displays) — having only the 192px icon fails the check silently. There's no console error, no rejected promise, no event fired for "installability failed" by default; the browser simply never dispatches `beforeinstallprompt`, and any custom "Install" button wired to that event never appears.

**How to actually debug this (worth naming in interview):** Chrome DevTools → Application panel → Manifest section lists installability errors explicitly, including this exact one ("no supplied icon is at least 512x512px"). This is the correct diagnostic step — guessing field-by-field against memory is unreliable since the criteria are numerous (HTTPS, manifest validity, icon sizes, service worker presence, engagement heuristic) and none of them throw a runtime error.

**Fix:**
```json
"icons": [
  { "src": "/icon-192.png", "sizes": "192x192", "type": "image/png" },
  { "src": "/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any maskable" }
]
```

**Broader lesson:** installability is an all-or-nothing gate checked against a fixed checklist, and every criterion fails the same way — silently, with no event and no error — which is why a defensive PWA implementation logs each criterion's status manually during development (or just relies on DevTools) rather than assuming "it'll just work" once the manifest file exists.
