# Background Sync and Periodic Background Sync

Both APIs let a service worker do network work *after* the page that requested it may have already closed — the core mechanism for reliable offline-to-online reconciliation.

## The problem they solve

Without them, "retry a failed request when back online" has to be implemented as: keep the tab open, listen for the `online` event, retry manually. If the user closes the tab (very likely — they were offline, gave up, and left), the retry never happens. Background Sync moves that responsibility to the browser/OS, which can wake the service worker even without an open tab.

## One-off Background Sync API

```js
// main.js — on the page, after a failed POST
async function queueForSync(payload) {
  await saveToOutbox(payload); // persist to IndexedDB first — the sync event has no payload of its own
  const registration = await navigator.serviceWorker.ready;
  await registration.sync.register('sync-outbox');
}
```

```js
// sw.js
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-outbox') {
    event.waitUntil(flushOutbox());
  }
});

async function flushOutbox() {
  const db = await openDB();
  const pending = await getAllFromOutbox(db);
  for (const item of pending) {
    try {
      await fetch('/api/items', { method: 'POST', body: JSON.stringify(item) });
      await removeFromOutbox(db, item.id);
    } catch {
      // still offline — leave it queued, browser will retry the sync event later
      throw new Error('sync failed, will retry');
    }
  }
}
```

**Key semantics:**
- The `sync` event does not carry the request data itself — you persist the pending work (usually to IndexedDB) *before* registering the sync, and the handler reads it back out.
- If `event.waitUntil()`'s promise rejects, the browser automatically retries later with exponential backoff — you don't hand-roll retry logic.
- The sync can fire even if the registering tab is closed, as long as the SW is still registered and the device regains connectivity — this is precisely the "close the tab, request still goes out later" guarantee.
- Browser support is uneven — Safari has never shipped the one-off Background Sync API, so it cannot be the *only* mechanism; a foreground `online` event listener as a fallback is still required for full coverage.

## Periodic Background Sync API

A separate, more restricted API for recurring background refresh (e.g., "refresh cached news articles every few hours") — closer to what native push/refresh does.

```js
// main.js — requires the page to already be an installed PWA in most implementations
const registration = await navigator.serviceWorker.ready;
const status = await navigator.permissions.query({ name: 'periodic-background-sync' });
if (status.state === 'granted') {
  await registration.periodicSync.register('refresh-content', {
    minInterval: 24 * 60 * 60 * 1000, // 24 hours — a *minimum*, not a guarantee
  });
}
```

```js
// sw.js
self.addEventListener('periodicsync', (event) => {
  if (event.tag === 'refresh-content') {
    event.waitUntil(refreshCachedContent());
  }
});
```

Support is much narrower than one-off sync (Chromium-based browsers only, and typically gated behind the app being installed with reasonable engagement), and the interval is a lower bound the OS may extend significantly to save battery — it is not a cron job.

## Design implication: always have a fallback layer

Because Background Sync support is inconsistent across browsers, a robust offline-write design layers three mechanisms rather than depending on one:

1. **Immediate retry** if the network call fails while the tab is open (simple `fetch` retry/backoff).
2. **`sync` event registration** for the "tab closed while offline" case, where supported.
3. **Retry-on-load**: on every app boot/foreground, check the outbox and flush any pending items — this is the universal fallback that works even on browsers with zero Background Sync support, and it's what actually guarantees eventual consistency in practice.
