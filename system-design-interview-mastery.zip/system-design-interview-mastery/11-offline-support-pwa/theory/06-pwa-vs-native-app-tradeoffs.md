# PWA vs. Native App Tradeoffs

A recurring system-design interview question: "would you build this as a PWA or a native app?" There's no universally correct answer — it depends on the product's requirements around distribution, device API access, and offline depth. Answering with a real comparison, not "PWAs are cheaper," is what distinguishes a strong answer.

## Comparison table

| Dimension | PWA | Native (iOS/Android) |
|---|---|---|
| Distribution | Instant — a URL, no app store review | App store submission + review delay for every update |
| Install friction | One tap "Add to Home Screen" / install prompt, no store account needed | Store download, larger initial install size |
| Codebase | One codebase, one deploy, for all platforms + desktop web | Typically separate codebases per platform (or cross-platform framework tradeoffs) |
| Update rollout | Instant — next SW `fetch` picks up new version | Gated by store review + user-initiated update |
| Offline capability | Full — service worker + IndexedDB, entirely developer-controlled | Full — and typically simpler, since native storage/network APIs don't have the SW lifecycle's edge cases |
| Push notifications | Supported on Android/desktop Chrome; historically unsupported on iOS Safari until iOS 16.4+, and only for installed PWAs | Fully supported everywhere, mature APIs |
| Device API access | Growing but incomplete (camera, geolocation, some sensors, Web Bluetooth/USB on some platforms) — no access to things like deep Bluetooth LE peripherals, ARKit/ARCore, background location on iOS | Full access to every platform API |
| Performance ceiling | Very good for typical CRUD/content apps; noticeably behind for heavy graphics, animations, or CPU-bound work (games, video editing) | Native rendering, GPU access, best possible performance |
| Discoverability | Indexed by search engines, shareable as a normal URL | Must be found via app store search/ads, or an external link driving a store page |
| App store presence | Optional (Trusted Web Activities can wrap a PWA for the Play Store; iOS App Store listing is not really viable for a pure PWA) | Required — this is the primary discovery channel for many users |
| Engineering cost | Lower — web skills, one deploy pipeline | Higher — platform-specific skills, App Store/Play Store ops overhead |

## When a PWA is the right call

- Content-driven or transactional apps (news, e-commerce, booking, dashboards, forms) where the core value is fast access to information/actions, not deep OS integration.
- Products where install friction directly kills conversion — an e-commerce site converting "browse" traffic benefits enormously from skipping the app store entirely.
- Teams that need to ship on a single codebase across web + mobile + desktop with one deploy pipeline and instant rollout of fixes.
- Emerging markets / low-end devices, where a multi-hundred-MB native app install is a real barrier and a PWA's smaller footprint + instant update matters.

## When native is the right call

- The product's core value *is* a device capability the web can't reach well (deep camera/AR processing, background location tracking, Bluetooth peripheral control, high-performance gaming).
- Push notifications are mission-critical on iOS today and can't wait on the constraints of the web push story there.
- The business model depends on app-store discovery/ranking as a primary acquisition channel.
- Performance requirements are hard-real-time (video editing, 3D games) where JS/DOM overhead is disqualifying.

## The pragmatic middle ground

Many production systems (interviewers like hearing this) don't pick one exclusively — they ship a PWA as the default web experience (fast iteration, universal reach) and layer a thin native shell only for the subset of users who need push notifications or deep device APIs, sharing as much business logic as possible (e.g., a Capacitor/React Native wrapper reusing the same web codebase where feasible). Framing the answer this way signals you understand it's a spectrum of investment, not a binary choice.
