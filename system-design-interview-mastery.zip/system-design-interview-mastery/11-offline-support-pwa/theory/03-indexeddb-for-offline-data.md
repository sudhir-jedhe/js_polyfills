# IndexedDB for Offline Data

`caches` (the Cache API) stores request/response pairs — good for assets and API responses. It's not a fit for structured, queryable application data (a to-do list, a draft queue, a local copy of records the user edits offline). That's IndexedDB's job: an asynchronous, transactional, NoSQL object store built into the browser.

## Why not `localStorage`?

| | `localStorage` | IndexedDB |
|---|---|---|
| API style | Synchronous | Asynchronous (event-based, or wrapped in Promises) |
| Blocks main thread | Yes — synchronous reads/writes freeze the page | No |
| Storage limit | ~5-10MB (browser-dependent) | Hundreds of MB to GBs (origin storage quota, often disk-based) |
| Data types | Strings only (must `JSON.stringify`) | Structured data: objects, arrays, Blobs, Files, typed arrays — stored natively |
| Querying | None — key lookup only | Indexes, key ranges, cursors for range queries |
| Accessible from Service Worker | No | Yes |
| Transactions | No | Yes (atomic reads/writes across multiple object stores) |

`localStorage`'s synchronous, blocking nature alone rules it out for any non-trivial offline data — and it's the reason it's unavailable inside a service worker at all (SW APIs are async-only by design).

## Core concepts

- **Database**: a named, versioned container (`myapp-db`, version `3`).
- **Object store**: roughly "a table" — a collection of records, each with a key.
- **Key path / key generator**: how a record's key is derived — either a property on the object (`keyPath: 'id'`) or an auto-incrementing number.
- **Index**: a secondary lookup structure on a non-key field, enabling queries like "find all orders with `status: 'pending'`" without a full scan.
- **Transaction**: all reads/writes happen inside a transaction scoped to specific object stores and a mode (`readonly` or `readwrite`); it auto-commits when its callback queue empties, or aborts entirely on any error (all-or-nothing).

## Setting up a database and handling upgrades

```js
function openDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('myapp-db', 2); // version 2

    request.onupgradeneeded = (event) => {
      const db = event.target.result;
      const oldVersion = event.oldVersion;

      if (oldVersion < 1) {
        const store = db.createObjectStore('todos', { keyPath: 'id' });
        store.createIndex('by-status', 'status'); // secondary index
      }
      if (oldVersion < 2) {
        db.createObjectStore('outbox', { keyPath: 'id', autoIncrement: true });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}
```

`onupgradeneeded` fires only when the requested version number is higher than what's stored — it's the *only* place you're allowed to create/delete object stores and indexes, and it runs inside a versionchange transaction that blocks all other connections to that DB until it completes.

## Reading and writing with transactions

```js
async function addTodo(db, todo) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction('todos', 'readwrite');
    tx.objectStore('todos').add(todo);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

async function getPendingTodos(db) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction('todos', 'readonly');
    const index = tx.objectStore('todos').index('by-status');
    const request = index.getAll('pending'); // uses the secondary index — no full scan
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}
```

## The version-upgrade gotcha

If a user has the app open in two tabs and tab A tries to open a new DB version, tab B's existing open connection **blocks** the upgrade (`onblocked` fires on tab A's request) until tab B closes its connection — usually done by listening for `onversionchange` on every open connection and calling `db.close()` in response. This is a real production bug source: an app that never handles `onversionchange` can leave users stuck with a perpetually-blocked upgrade after a deploy that bumped the DB version.

## Where this fits in offline architecture

IndexedDB is typically the durable local store in an offline-first design: application writes go to IndexedDB first (so the UI can respond instantly, online or not), and a background sync process later reconciles that local state with the server. Libraries like `idb` (a thin Promise-based wrapper) or `Dexie.js` are standard in production to avoid hand-rolling the callback-heavy raw API.
