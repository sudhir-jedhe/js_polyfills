# Service Worker Lifecycle

A service worker is a JavaScript file that runs in its own thread, separate from the page, with no DOM access. It sits as a programmable network proxy between your app and the network, which is what makes offline support, custom caching, and background sync possible. Understanding its lifecycle precisely — not just "it caches stuff" — is the single most-tested PWA fundamental in interviews, because the lifecycle is what causes the classic "I deployed a fix but users still see the old version" bug.

## The three lifecycle events

| Event | When it fires | What you do in it |
|---|---|---|
| **install** | Once, when the browser first sees a new/changed SW script (byte-diffed against the currently installed one) | Pre-cache the "app shell" (static assets needed to boot the app) via `caches.open()` + `cache.addAll()` |
| **activate** | After install succeeds, once no other tab is using the *old* SW (or immediately if `skipWaiting()` was called) | Clean up old caches from previous versions, claim existing clients |
| **fetch** | Every network request the page makes, once the SW is activated and controlling the page | Intercept the request, decide a caching strategy, return a response via `event.respondWith()` |

## Registration → install → waiting → activate

```js
// main.js — runs on the page
navigator.serviceWorker.register('/sw.js');
```

```js
// sw.js
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open('app-shell-v3').then((cache) =>
      cache.addAll(['/', '/index.html', '/app.css', '/app.js'])
    )
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys.filter((key) => key !== 'app-shell-v3').map((key) => caches.delete(key))
      )
    )
  );
});

self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request).then((cached) => cached || fetch(event.request))
  );
});
```

The critical, frequently-misunderstood detail: **a new service worker does not take control of already-open tabs the moment it activates.** By default, an existing tab keeps being controlled by the *old* SW until that tab is fully closed (not just refreshed — refreshing a tab still hands control to the old SW right up until the very last moment of navigation, then the new one takes over from the reload onward, but any tab that stays open is stuck on the old SW's cache indefinitely). This is why users report "I still see the old version" after a deploy even though a new SW installed successfully — it's sitting in the "waiting" state.

## Skipping the wait: `skipWaiting()` and `clients.claim()`

```js
self.addEventListener('install', (event) => {
  self.skipWaiting(); // don't wait for old tabs to close — activate immediately
});

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim()); // take control of already-open, uncontrolled tabs
});
```

- `skipWaiting()` forces the new SW to move from "waiting" to "activating" immediately, without waiting for existing tabs to release the old one.
- `clients.claim()` makes the newly-activated SW take control of any currently-open page that was still being controlled by the previous SW (or by no SW at all, on first install).

**Tradeoff:** this combination guarantees users always run the latest SW quickly, but it can cause a page that's mid-session to suddenly start getting responses from a differently-versioned SW/cache, which can produce inconsistent state if the API contract changed. The safer alternative many production apps use is to detect a waiting SW and prompt the user ("A new version is available — refresh?") rather than force it silently.

## Full state machine

```
parsed → installing → installed (waiting) → activating → activated → redundant
```

- **redundant**: the SW is discarded — either install failed, or it was replaced by a newer SW that finished activating.
- Only one SW can be "active" (controlling pages) per scope at a time; only one can be "waiting" at a time. A third SW registration attempt while one is installing and one is waiting will queue behind them.

## Scope

A service worker only controls pages under its **registration scope**, which defaults to the directory it's served from. `/sw.js` registered with no explicit scope controls everything under `/`; `/app/sw.js` would default to scoping only `/app/*`. You can widen the default scope via the `Service-Worker-Allowed` response header, but you can never scope a SW to control a path *above* where the script file itself is served from.
