# Web App Manifest and Installability Criteria

The Web App Manifest is a JSON file that tells the browser (and OS) how your PWA should behave when installed: its name, icons, start URL, display mode, and theme colors. Without it, a site can be a great offline experience but the browser has no way to offer "Install app."

## Minimal manifest

```json
{
  "name": "My Offline Notes App",
  "short_name": "Notes",
  "start_url": "/?source=pwa",
  "scope": "/",
  "display": "standalone",
  "background_color": "#ffffff",
  "theme_color": "#1a73e8",
  "icons": [
    { "src": "/icons/icon-192.png", "sizes": "192x192", "type": "image/png" },
    { "src": "/icons/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any maskable" }
  ]
}
```

Linked from HTML:

```html
<link rel="manifest" href="/manifest.json">
```

## Key fields explained

| Field | Purpose |
|---|---|
| `name` / `short_name` | Full name (splash screen) vs. short name (home screen label, limited space) |
| `start_url` | URL loaded when launched from the home screen — usually includes a query param to distinguish PWA launches in analytics |
| `scope` | Which URLs are considered "inside" the app (navigating outside it may open a normal browser tab instead) |
| `display` | `standalone` (looks like a native app, no browser chrome), `fullscreen`, `minimal-ui`, or `browser` (falls back to a normal tab) |
| `theme_color` | Colors the OS status bar / task switcher UI |
| `background_color` | Shown on the splash screen before the app's CSS loads |
| `icons` | Multiple sizes required; `purpose: "maskable"` provides a safe zone so OS icon masks (circle, squircle, etc.) don't clip content |

## Installability criteria (Chrome/Chromium baseline)

A browser will *not* offer the install prompt unless all of these are true:

1. Served over **HTTPS** (or `localhost` for dev).
2. A valid **Web App Manifest** is linked, with at minimum `name`/`short_name`, `start_url`, `icons` (including a 192px and 512px), and `display` set to `standalone`, `fullscreen`, or `minimal-ui`.
3. A **registered service worker** with a `fetch` event handler (even a no-op one) — this is the browser's proxy for "this app has at least attempted offline capability."
4. The user has some minimum engagement with the site (heuristic, varies by browser — e.g. Chrome requires some interaction signal before firing `beforeinstallprompt`).

Missing any one of these silently means no install prompt ever fires, with no error thrown — this is one of the most common "why doesn't my install button show up" production bugs.

## Custom install UI with `beforeinstallprompt`

Browsers show a default install affordance, but most production apps intercept it to show their own "Install" button at a better moment:

```js
let deferredPrompt;

window.addEventListener('beforeinstallprompt', (event) => {
  event.preventDefault(); // stop the automatic mini-infobar
  deferredPrompt = event; // stash it to trigger later
  showCustomInstallButton();
});

installButton.addEventListener('click', async () => {
  if (!deferredPrompt) return;
  deferredPrompt.prompt();
  const { outcome } = await deferredPrompt.userChoice; // 'accepted' | 'dismissed'
  deferredPrompt = null;
});

window.addEventListener('appinstalled', () => {
  hideCustomInstallButton();
  // fire analytics event
});
```

## iOS Safari: no `beforeinstallprompt` at all

Safari on iOS does not support `beforeinstallprompt` or automatic install prompts. "Add to Home Screen" is a manual step the user performs through the Share sheet, and the manifest's influence is more limited — Safari relies more heavily on `<meta name="apple-mobile-web-app-*">` tags and `<link rel="apple-touch-icon">` for its equivalent behavior. Interviewers often probe this specifically: a design that assumes `beforeinstallprompt` will always fire is a design that silently fails ~universally on iOS Safari, so a robust PWA shows platform-appropriate install instructions (detected via UA sniffing or feature detection) rather than relying solely on the event.
