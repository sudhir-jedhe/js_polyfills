# Offline-First Architecture Patterns

"Offline-first" means the app's default assumption is *no network*, and connectivity is treated as an enhancement layered on top — the inverse of a typical web app, where network is assumed and offline is a degraded fallback bolted on later. This reframing changes almost every architectural decision.

## Local-first data flow

```
User action → write to local store (IndexedDB) immediately → UI reads from local store (instant, always works)
                                                              → background process syncs local store ↔ server
```

The UI never waits on the network for a read or a write to feel complete. This is what makes an app feel instant even on a good connection — the perceived latency is however long the local write takes (milliseconds), not however long the round trip takes.

```js
async function addTodo(text) {
  const todo = { id: crypto.randomUUID(), text, done: false, updatedAt: Date.now(), synced: false };
  await db.todos.put(todo);   // local write — UI updates from this immediately
  renderTodo(todo);
  queueSync(todo);            // fire-and-forget background reconciliation
}
```

## Optimistic UI

A direct consequence of local-first writes: the UI reflects the *intended* end state immediately, before the server has confirmed it, then reconciles or rolls back if the server rejects it.

```js
async function queueSync(todo) {
  try {
    const saved = await fetch('/api/todos', { method: 'POST', body: JSON.stringify(todo) });
    await db.todos.put({ ...todo, synced: true, serverId: (await saved.json()).id });
  } catch {
    await registerBackgroundSync(todo.id); // network down — fall back to Background Sync retry
  }
}
```

The rollback path matters as much as the happy path: if the server later rejects the write (validation failure, conflict), the UI must be able to undo the optimistic change and surface that to the user — a design that only handles the optimistic-success case is incomplete.

## Conflict resolution strategies

Once writes can happen offline on multiple devices (or offline + another session), the same record can be edited in two places before either sees the other's change. Interviewers want you to name a concrete strategy, not just "sync it up":

| Strategy | How it works | Good for |
|---|---|---|
| **Last-write-wins (LWW)** | Compare timestamps (or a version counter); the most recent write overwrites | Simple state, low conflict likelihood (personal notes, settings) |
| **Server-authoritative** | Server is always right; client discards local change on conflict, or re-applies it on top of the server's latest | Systems where data integrity matters more than the offline user's intent (inventory counts, pricing) |
| **Operational Transform / CRDTs** | Merge concurrent edits algorithmically instead of picking a winner (used by Google Docs–style collaborative editors) | Rich collaborative text/structured editing where both users' intent should survive |
| **Manual merge (conflict surfaced to user)** | Detect the conflict, show both versions, let the user choose/merge | High-stakes data where silent loss is unacceptable (a legal document, a shared calendar event) |

Most CRUD-style offline apps default to LWW with a `updatedAt`/version field, escalating to manual merge only for fields where silent overwrite would be genuinely bad (interviewers like hearing you scope this per-field rather than picking one blanket policy).

## The outbox pattern

A dedicated IndexedDB object store (`outbox`) holds mutations that haven't yet been confirmed by the server, decoupling "the user did something" from "the server knows about it":

```
write → append to outbox → optimistically apply to local read-model → UI renders from read-model
                                                                      ↓
                                                    background flush: pop outbox → send to server → on success, remove from outbox
                                                                                  → on failure, leave queued, retry later (see Background Sync)
```

This pattern is the backbone of nearly every "offline order queue" / "offline note-taking" design question — it separates the durability guarantee (outbox is written to disk before anything else happens) from the sync guarantee (a background process, independent of any specific tab being open, eventually drains it).

## Read-through cache vs. full local replica

Two ends of a spectrum for how much data lives locally:

- **Read-through cache**: only cache what's been viewed/fetched; a never-visited resource requires network. Cheaper, but offline access is unpredictable (only what happens to already be cached works).
- **Full local replica**: proactively sync the entire relevant dataset to the device (e.g., all of a user's own notes, or a bounded working set like "this week's schedule") so offline access is guaranteed for that dataset regardless of prior browsing history. More storage and sync complexity, but a much stronger, predictable offline guarantee — this is what apps like offline-capable email clients or note apps (Notion offline mode, Google Docs offline) actually do for the user's own data.

Choosing between these is a capacity/product tradeoff worth stating explicitly in an interview: "which subset of data does this user need guaranteed access to offline, and is that subset small enough to fully replicate?"
