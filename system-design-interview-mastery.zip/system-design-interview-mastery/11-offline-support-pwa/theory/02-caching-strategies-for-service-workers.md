# Caching Strategies for Service Workers

The `fetch` event handler is where you decide, per-request, how to reconcile the cache and the network. There's no single "right" strategy — the right choice depends on how fresh a given resource needs to be, and interviewers expect you to justify the strategy per resource type, not apply one strategy globally.

## The five core strategies

| Strategy | Behavior | Best for | Risk |
|---|---|---|---|
| **Cache-first** | Check cache → if hit, return it; only hit network on cache miss | Versioned static assets (hashed JS/CSS bundles, fonts, icons) | Serves stale content forever if the cache is never invalidated |
| **Network-first** | Try network → on success, update cache and return it; on failure, fall back to cache | HTML pages, API responses that should be fresh when online | Slower on flaky networks (must wait for timeout before falling back) |
| **Stale-while-revalidate** | Return cached response immediately AND fire a network request in the background to update the cache for *next* time | Frequently-updated content where a one-request-stale lag is acceptable (avatars, feed data, non-critical API responses) | User always sees data that's at least one fetch cycle old |
| **Cache-only** | Only ever read from cache; never touch network | Assets guaranteed to be pre-cached at install time and never change (app shell) | Fails hard if the resource wasn't pre-cached |
| **Network-only** | Always go to network, cache is bypassed entirely | Non-idempotent requests (POST/PUT/PATCH), analytics beacons | No offline fallback at all |

## Cache-first

```js
async function cacheFirst(request) {
  const cached = await caches.match(request);
  if (cached) return cached;
  const response = await fetch(request);
  const cache = await caches.open('runtime-cache');
  cache.put(request, response.clone()); // clone: body can only be read once
  return response;
}
```

## Network-first

```js
async function networkFirst(request, timeoutMs = 3000) {
  const cache = await caches.open('runtime-cache');
  try {
    const response = await Promise.race([
      fetch(request),
      new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), timeoutMs)),
    ]);
    cache.put(request, response.clone());
    return response;
  } catch {
    const cached = await cache.match(request);
    if (cached) return cached;
    throw new Error('No cache fallback available');
  }
}
```

Note the `response.clone()` — a `Response` body is a stream that can only be consumed once. If you `await response.json()` for logic and also want to cache the raw response, you must clone before consuming.

## Stale-while-revalidate

```js
async function staleWhileRevalidate(request) {
  const cache = await caches.open('runtime-cache');
  const cached = await cache.match(request);
  const networkFetch = fetch(request).then((response) => {
    cache.put(request, response.clone());
    return response;
  });
  return cached || networkFetch; // return cache immediately if present, else wait for network
}
```

This is the most common default for API GET requests in production PWAs (it's literally the reasoning behind the `stale-while-revalidate` HTTP `Cache-Control` directive, reused at the SW layer) — the user always gets an instant response, and the cache silently heals itself in the background for the next visit.

## Routing multiple strategies by request type

Real apps don't use one strategy everywhere — they route based on the request:

```js
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  if (request.destination === 'document') {
    event.respondWith(networkFirst(request));
  } else if (/\.(js|css|woff2?)$/.test(url.pathname)) {
    event.respondWith(cacheFirst(request));
  } else if (url.pathname.startsWith('/api/')) {
    event.respondWith(staleWhileRevalidate(request));
  } else {
    event.respondWith(fetch(request)); // network-only fallback, e.g. POST requests
  }
});
```

## Choosing a strategy: the decision question

Ask: **"If this resource is stale, how bad is that, and how often does it change?"**
- Never changes after deploy (hashed filename) → cache-first, cache forever.
- Changes occasionally, staleness is unacceptable (HTML shell, pricing, auth state) → network-first.
- Changes often, one-cycle staleness is fine, and instant response matters more than freshness (social feed, avatar) → stale-while-revalidate.
- Must never be silently retried/duplicated (payments, mutations) → network-only, never intercept.
