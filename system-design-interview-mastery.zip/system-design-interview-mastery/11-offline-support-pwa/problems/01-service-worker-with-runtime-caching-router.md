# Problem: Implement a Service Worker With a Runtime Caching Router

## Problem Statement

Implement a single service worker that routes incoming requests to different caching strategies based on request type, without any external library (no Workbox). It must handle:

- The app shell (`/`, `/app.js`, `/app.css`) — pre-cached at install, served cache-first.
- API GET requests under `/api/` — stale-while-revalidate.
- Navigation requests (full page loads) — network-first with a 2.5s timeout, falling back to a cached `/offline.html`.
- Everything else (POST/PUT/DELETE, third-party requests) — pass through untouched, no caching.

## Constraints

- Old cache versions must be cleaned up on activate.
- `response.clone()` must be used correctly everywhere a response is both returned and cached.
- The service worker must not crash (unhandled rejection) if `caches.match()` finds nothing and the network also fails.

## Solution

```js
const VERSION = 'v7';
const SHELL_CACHE = `shell-${VERSION}`;
const API_CACHE = `api-${VERSION}`;
const NAV_CACHE = `nav-${VERSION}`;
const SHELL_ASSETS = ['/', '/app.js', '/app.css', '/offline.html'];
const ALL_CACHES = [SHELL_CACHE, API_CACHE, NAV_CACHE];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(SHELL_CACHE).then((cache) => cache.addAll(SHELL_ASSETS))
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => !ALL_CACHES.includes(k)).map((k) => caches.delete(k)))
    )
  );
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  if (request.method !== 'GET' || url.origin !== self.location.origin) {
    return; // let it pass through untouched — no respondWith call at all
  }

  if (SHELL_ASSETS.includes(url.pathname)) {
    event.respondWith(cacheFirst(request, SHELL_CACHE));
  } else if (url.pathname.startsWith('/api/')) {
    event.respondWith(staleWhileRevalidate(request, API_CACHE));
  } else if (request.mode === 'navigate') {
    event.respondWith(networkFirstWithTimeout(request, NAV_CACHE, 2500));
  }
});

async function cacheFirst(request, cacheName) {
  const cached = await caches.match(request);
  if (cached) return cached;
  try {
    const response = await fetch(request);
    const cache = await caches.open(cacheName);
    cache.put(request, response.clone());
    return response;
  } catch {
    return new Response('Asset unavailable offline', { status: 504 });
  }
}

async function staleWhileRevalidate(request, cacheName) {
  const cache = await caches.open(cacheName);
  const cached = await cache.match(request);
  const networkUpdate = fetch(request)
    .then((response) => {
      if (response.ok) cache.put(request, response.clone());
      return response;
    })
    .catch(() => null);
  return cached || (await networkUpdate) || new Response(JSON.stringify({ error: 'offline' }), {
    status: 503, headers: { 'Content-Type': 'application/json' },
  });
}

async function networkFirstWithTimeout(request, cacheName, timeoutMs) {
  const cache = await caches.open(cacheName);
  try {
    const response = await Promise.race([
      fetch(request),
      new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), timeoutMs)),
    ]);
    cache.put(request, response.clone());
    return response;
  } catch {
    const cached = await cache.match(request);
    return cached || caches.match('/offline.html');
  }
}
```

## Why this design

- **Method + origin filtering happens before any strategy dispatch**, so mutating requests and cross-origin (e.g., analytics, CDN) requests are never accidentally intercepted — a common bug when a `fetch` handler tries to be too clever and `respondWith()`s everything unconditionally.
- **Separate cache names per category** (`shell-`, `api-`, `nav-`) rather than one shared cache, so cleanup, size limits, and versioning can be reasoned about independently — clearing stale API cache entries never risks the app shell.
- **Every strategy function has a terminal fallback** (never just `throw`), because an uncaught rejection inside `respondWith()` produces an ugly default browser network-error page instead of a controlled offline experience.
- **Versioned cache names + activate-time cleanup** means a redeploy that changes `VERSION` automatically retires every old cache in one place, rather than needing per-cache cleanup logic scattered around.
