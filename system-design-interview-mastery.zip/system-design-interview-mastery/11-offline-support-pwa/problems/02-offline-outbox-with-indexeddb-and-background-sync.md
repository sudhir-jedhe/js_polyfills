# Problem: Build an Offline Outbox for Failed POST Requests

## Problem Statement

Build a reusable outbox module that:

1. Accepts any POST-like write (`{ url, method, body }`), persists it to IndexedDB immediately, and returns instantly (never blocks on network).
2. Attempts an immediate send; if it fails, leaves the item queued.
3. Registers a Background Sync tag so a queued item is retried even if the tab closes, with a foreground `online`-event fallback for browsers without Background Sync support.
4. Preserves **submission order** — if the user submits three edits offline, they must reach the server in the order they were made, and a later item must not be sent if an earlier one is still pending (to avoid out-of-order server state).
5. Exposes a way for the UI to know an item's status (`pending`, `sent`, `failed`) so it can render sync indicators.

## Constraints

- Must not lose data if the tab is killed immediately after the write call returns.
- Must not double-send an item (at-least-once is acceptable, but avoid it where reasonably possible within a single flush run).
- No external libraries.

## Solution

```js
const DB_NAME = 'outbox-db';
const STORE = 'outbox';

function openDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      const store = req.result.createObjectStore(STORE, { keyPath: 'id', autoIncrement: true });
      store.createIndex('by-status', 'status');
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function enqueue({ url, method, body }) {
  const db = await openDB();
  const record = { url, method, body, status: 'pending', createdAt: Date.now() };
  const id = await new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    const req = tx.objectStore(STORE).add(record);
    req.onsuccess = () => resolve(req.result);
    tx.onerror = () => reject(tx.error);
  });

  attemptSend(); // fire-and-forget immediate attempt; caller doesn't wait on this
  registerBackgroundSyncOrFallback();
  return id;
}

let flushing = false;

async function attemptSend() {
  if (flushing) return; // avoid overlapping flush runs racing each other
  flushing = true;
  try {
    const db = await openDB();
    const pending = await getByStatus(db, 'pending');
    pending.sort((a, b) => a.createdAt - b.createdAt); // preserve submission order

    for (const item of pending) {
      try {
        const res = await fetch(item.url, {
          method: item.method,
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(item.body),
        });
        if (!res.ok) throw new Error(`server rejected: ${res.status}`);
        await updateStatus(db, item.id, 'sent');
      } catch {
        // network still down, or server rejected — stop here to preserve ordering;
        // don't attempt later items out of order ahead of this one
        break;
      }
    }
  } finally {
    flushing = false;
  }
}

function getByStatus(db, status) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readonly');
    const req = tx.objectStore(STORE).index('by-status').getAll(status);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function updateStatus(db, id, status) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    const store = tx.objectStore(STORE);
    const getReq = store.get(id);
    getReq.onsuccess = () => {
      const record = getReq.result;
      record.status = status;
      store.put(record);
    };
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

async function registerBackgroundSyncOrFallback() {
  try {
    const reg = await navigator.serviceWorker.ready;
    if ('sync' in reg) {
      await reg.sync.register('flush-outbox');
      return;
    }
    throw new Error('no background sync');
  } catch {
    window.addEventListener('online', attemptSend, { once: true });
  }
}
```

```js
// sw.js
self.addEventListener('sync', (event) => {
  if (event.tag === 'flush-outbox') {
    event.waitUntil(attemptSend()); // same function, importable via a shared module
  }
});
```

## Why this design

- **Ordering is enforced by breaking on first failure**, not by using per-item independent retries — sending item 3 before item 1 has been confirmed could put server state ahead of where the user's actions implied it should be (e.g., edits to the same resource applied out of sequence).
- **The `flushing` guard** prevents two triggers (say, a `sync` event and a manual retry button) from running overlapping flush loops that could double-send the same item.
- **Status stays observable** (`pending`/`sent`/`failed` via the by-status index) so the UI can subscribe and show per-item sync state without polling the network.
- **The fallback chain** (Background Sync → `online` event → next app-boot flush, which a real deployment would also wire up) means delivery is guaranteed on every browser, with Background Sync purely as a latency optimization on top.
