# Problem: Design a Cache Versioning and Cleanup System

## Problem Statement

Design a cache-naming and cleanup scheme for a service worker that supports:

- Multiple independently-versioned caches (e.g., app shell, API responses, images) that can be bumped on different release cadences (a shell version bumps every deploy; an image cache almost never needs a version bump).
- Safe cleanup on `activate` that removes only caches this SW no longer recognizes, without ever deleting a cache another concurrently-active SW (e.g., during a rolling deploy where two SW versions might briefly coexist across different users) still depends on.
- A maximum entry count per runtime cache (LRU-style eviction), independent of the version bump mechanism.

## Constraints

- Cache names must encode both a logical purpose and a version, so cleanup can pattern-match by purpose.
- Must not require the developer to remember to manually update a cleanup allowlist in more than one place per deploy.

## Solution

```js
// cache-config.js — the single source of truth for cache identity
const BUILD_VERSION = self.__BUILD_VERSION__ || 'dev'; // injected at build time, e.g. a git short-sha

const CACHES = {
  shell: `shell-${BUILD_VERSION}`,       // bumps every deploy
  api: `api-${BUILD_VERSION}`,           // bumps every deploy (API contracts can change)
  images: `images-static`,               // intentionally NOT tied to BUILD_VERSION — long-lived
};

const CACHE_LIMITS = {
  [CACHES.api]: 100,
  [CACHES.images]: 300,
};
```

```js
// sw.js
importScripts('cache-config.js'); // or bundle it in, depending on build tooling

self.addEventListener('activate', (event) => {
  event.waitUntil(
    (async () => {
      const keep = new Set(Object.values(CACHES));
      const existing = await caches.keys();
      await Promise.all(
        existing
          .filter((name) => !keep.has(name)) // anything not in this SW's current config is stale
          .map((name) => caches.delete(name))
      );
    })()
  );
});

async function putWithLimit(cacheName, request, response) {
  const cache = await caches.open(cacheName);
  await cache.put(request, response);
  const limit = CACHE_LIMITS[cacheName];
  if (!limit) return;
  const keys = await cache.keys();
  const excess = keys.length - limit;
  for (let i = 0; i < excess; i++) {
    await cache.delete(keys[i]); // caches.keys() is insertion-order — oldest first
  }
}
```

## Why this design

- **`BUILD_VERSION` is injected once at build time** (e.g., via a bundler define/replace step using the git SHA or a content hash) and threaded through every version-bumped cache name — this is the "only update it in one place" requirement: bumping the build automatically bumps `shell-*` and `api-*` together without touching cleanup logic.
- **The `images` cache deliberately opts out of version-tied naming.** Images are content-addressed by their own URL/hash already, so there's no correctness reason to blow away a perfectly good image cache on every unrelated deploy — only the shell/API contract caches need to churn on each release. This is a real design decision worth stating explicitly: not every cache should share one version lifecycle.
- **Cleanup is allowlist-based** (`keep = new Set(Object.values(CACHES))`), not "delete anything with a version older than the current one" — an allowlist is robust to caches from unrelated experiments or previous architecture versions that don't fit a predictable naming pattern, whereas a version-comparison approach would need every historical naming scheme to remain parseable forever.
- **Per-cache entry limits are enforced independently of version bumps**, at write time — this bounds runtime cache growth (see the quota-exhaustion scenario) without being coupled to how often a deploy happens, since deploy frequency and cache-size pressure are unrelated concerns.
- **Rolling-deploy safety**: because each build's cache names are unique (via `BUILD_VERSION`), two SW versions active across different users simultaneously (during a gradual rollout) never collide on cache names or accidentally delete each other's caches — each SW's `activate` only ever deletes names outside its own `CACHES` set, and a different build's cache names simply aren't in either set's collision path.
