# Problem: Build a Cross-Platform Install Prompt Flow

## Problem Statement

Build an install-prompt UI module that:

- Shows a custom "Install app" button only when installation is actually possible (not on already-installed sessions, not on unsupported platforms without a fallback).
- Uses the native `beforeinstallprompt` flow where supported.
- Shows iOS-specific manual instructions where `beforeinstallprompt` will never fire.
- Never re-shows the prompt/button after the user has explicitly dismissed it within the last 14 days (avoid nagging).
- Tracks the outcome (`accepted`/`dismissed`/`installed`) for analytics.

## Constraints

- Must correctly detect "already running as an installed app" so the button never shows in that case.
- Must not throw if `deferredPrompt.prompt()` is called twice (event objects are single-use).
- No external libraries; `localStorage` is fine for the dismissal cooldown.

## Solution

```js
const DISMISS_KEY = 'pwa-install-dismissed-at';
const COOLDOWN_MS = 14 * 24 * 60 * 60 * 1000;

let deferredPrompt = null;

function isStandalone() {
  return window.matchMedia('(display-mode: standalone)').matches
    || window.navigator.standalone === true; // iOS legacy flag
}

function isIOS() {
  return /iP(hone|ad|od)/.test(navigator.userAgent) && !window.MSStream;
}

function isDismissedRecently() {
  const raw = localStorage.getItem(DISMISS_KEY);
  if (!raw) return false;
  return Date.now() - Number(raw) < COOLDOWN_MS;
}

function markDismissed() {
  try {
    localStorage.setItem(DISMISS_KEY, String(Date.now()));
  } catch {
    /* storage unavailable (private mode etc.) — degrade to "always eligible", acceptable tradeoff */
  }
}

function initInstallPrompt({ onShow, onHide }) {
  if (isStandalone() || isDismissedRecently()) {
    onHide();
    return;
  }

  window.addEventListener('beforeinstallprompt', (event) => {
    event.preventDefault();
    deferredPrompt = event;
    onShow({ platform: 'chromium' });
  });

  window.addEventListener('appinstalled', () => {
    deferredPrompt = null;
    onHide();
    trackEvent('pwa_installed');
  });

  if (isIOS() && !isStandalone()) {
    onShow({ platform: 'ios' }); // no event needed — iOS has no beforeinstallprompt at all
  }
}

async function triggerInstall(platform) {
  if (platform === 'chromium') {
    if (!deferredPrompt) return; // already consumed, or event never fired — guard against double-invoke
    const promptEvent = deferredPrompt;
    deferredPrompt = null; // single-use: consume immediately so a second click can't reuse it
    promptEvent.prompt();
    const { outcome } = await promptEvent.userChoice;
    trackEvent('pwa_install_prompt_result', { outcome });
    if (outcome === 'dismissed') markDismissed();
    return outcome;
  }

  if (platform === 'ios') {
    showIOSInstructionsModal(); // static "tap Share, then Add to Home Screen" UI
    trackEvent('pwa_install_ios_instructions_shown');
  }
}

function dismissInstallUI() {
  markDismissed();
  trackEvent('pwa_install_banner_dismissed');
}
```

## Why this design

- **`deferredPrompt` is nulled out the instant it's used**, before `await`ing `userChoice` — `BeforeInstallPromptEvent.prompt()` can only be called once per event instance; consuming the reference synchronously prevents a double-click race from calling `.prompt()` twice on the same (already-used) event.
- **iOS is treated as a fully separate, event-less branch** rather than trying to force-fit it into the `beforeinstallprompt` flow, because that event genuinely never fires there — the platform check (`isIOS()`) is the trigger for showing UI, not a listener.
- **The dismissal cooldown is a UX decision worth naming explicitly in an interview**: without it, a user who dismisses the prompt gets re-nagged on every visit, which measurably hurts perceived app quality — 14 days is a reasonable default balancing "give them another chance" against "don't be annoying," and should be tuned per product.
- **`isStandalone()` checks both the modern `display-mode` media query and the legacy iOS `navigator.standalone` flag**, since relying on only one silently fails to detect "already installed" on the platform that doesn't support the other.
- **Storage failures degrade gracefully** — wrapping the `localStorage` write in try/catch means Safari private browsing (which can throw on `setItem`) doesn't crash the flow; it just means the cooldown doesn't persist, which is a minor UX regression, not a functional break.
