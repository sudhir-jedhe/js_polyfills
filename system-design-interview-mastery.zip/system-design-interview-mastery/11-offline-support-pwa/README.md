# Offline Support & Progressive Web Apps

Offline support is where frontend system design meets the network layer directly: a service worker sits as a programmable proxy between your app and the network, and the decisions you make there — caching strategy per resource type, how durable writes survive a closed tab, what "installable" actually requires — are exactly what interviewers probe when they ask "design an offline-capable version of X." Getting this right requires precision about lifecycle timing (when does a new service worker actually take control?) and honest tradeoffs (which browsers don't support Background Sync? what does iOS Safari never give you?), not just "add a service worker and cache stuff."

## Folder structure

- **`theory/`** — the service worker lifecycle (install/activate/fetch), the five caching strategies with a decision framework, IndexedDB for structured offline data, the Web App Manifest and installability criteria, Background Sync and Periodic Background Sync, PWA vs. native tradeoffs, and offline-first architecture patterns (outbox, optimistic UI, conflict resolution).
- **`snippets/`** — 6 runnable examples: SW registration with update detection, cache-first, network-first, stale-while-revalidate, an IndexedDB outbox wrapper, and a manifest + install-prompt flow.
- **`output-based/`** — 5 "what happens?" deep dives: first-load vs. second-load caching, a wasted slow-network response, a service worker stuck in "waiting," a blocked IndexedDB version upgrade, and a silently-failed install prompt.
- **`scenarios/`** — 6 real-world situations: stale post-deploy UI, iOS install failures, offline form submission guarantees, cache quota exhaustion, a mid-session SW update race, and migrating a legacy SPA to offline-first incrementally.
- **`interview-qa/`** — 4 themed files: service worker fundamentals, caching strategies, storage & sync, and installability/native comparison.
- **`problems/`** — 4 hands-on builds: a full runtime-caching router service worker, an ordered offline outbox with Background Sync, a multi-cache versioning/cleanup system, and a cross-platform install-prompt flow.
- **`assets/`** — placeholder for diagrams (see `assets/README.md`).

## What's covered

- The service worker lifecycle in precise detail: install/activate/fetch, `skipWaiting()`/`clients.claim()`, scope, and the update-detection pattern real apps use to avoid silently-stale deploys
- All five caching strategies (cache-first, network-first, stale-while-revalidate, cache-only, network-only) with a concrete "which one for which resource" decision framework
- IndexedDB fundamentals: object stores, indexes, transactions, version upgrades, and why it — not `localStorage` — is the right tool for offline application data
- The Web App Manifest, installability criteria, and the `beforeinstallprompt` flow, including iOS Safari's fundamentally different (event-less) install story
- Background Sync and Periodic Background Sync, and why a robust design layers them as an optimization rather than a sole mechanism
- Offline-first architecture: local-first writes, optimistic UI, the outbox pattern, and a framework for choosing a conflict-resolution strategy (LWW, server-authoritative, CRDT, manual merge)
- PWA vs. native app tradeoffs, with a decision framework rather than a blanket recommendation
