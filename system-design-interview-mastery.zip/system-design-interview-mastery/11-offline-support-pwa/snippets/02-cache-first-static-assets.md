# Snippet: Cache-First Strategy for Static Assets

```js
const STATIC_CACHE = 'static-v4';
const STATIC_ASSETS = ['/', '/app.css', '/app.js', '/logo.svg'];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(STATIC_CACHE).then((cache) => cache.addAll(STATIC_ASSETS))
  );
});

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);
  const isStaticAsset = /\.(css|js|svg|png|woff2?)$/.test(url.pathname);

  if (isStaticAsset) {
    event.respondWith(
      caches.match(event.request).then((cached) => {
        if (cached) return cached;
        return fetch(event.request).then((response) => {
          const clone = response.clone();
          caches.open(STATIC_CACHE).then((cache) => cache.put(event.request, clone));
          return response;
        });
      })
    );
  }
});
```

Because hashed static bundle filenames (`app.a1b2c3.js`) change on every build, cache-first here is safe forever — a stale cache hit is impossible by construction, since a new deploy means a new URL, not the same URL with different content.
