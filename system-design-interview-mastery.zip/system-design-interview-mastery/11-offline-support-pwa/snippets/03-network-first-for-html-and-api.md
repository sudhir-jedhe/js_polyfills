# Snippet: Network-First Strategy for HTML and API Requests

```js
const RUNTIME_CACHE = 'runtime-v1';
const TIMEOUT_MS = 3000;

function timeout(ms) {
  return new Promise((_, reject) => setTimeout(() => reject(new Error('network-timeout')), ms));
}

async function networkFirst(request) {
  const cache = await caches.open(RUNTIME_CACHE);
  try {
    const response = await Promise.race([fetch(request), timeout(TIMEOUT_MS)]);
    cache.put(request, response.clone());
    return response;
  } catch {
    const cached = await cache.match(request);
    if (cached) return cached;
    // last resort: a dedicated offline fallback page, precached at install time
    if (request.destination === 'document') {
      return caches.match('/offline.html');
    }
    return new Response(JSON.stringify({ error: 'offline' }), {
      status: 503,
      headers: { 'Content-Type': 'application/json' },
    });
  }
}

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);
  if (event.request.destination === 'document' || url.pathname.startsWith('/api/')) {
    event.respondWith(networkFirst(event.request));
  }
});
```

Every layer of fallback is deliberate: fresh network response → cached response → a dedicated offline page (for navigations) → a structured JSON error (for API calls, so the frontend can show a proper "you're offline" state instead of a generic fetch failure).
