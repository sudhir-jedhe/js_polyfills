# Snippet: Stale-While-Revalidate for Feed Data

```js
const FEED_CACHE = 'feed-v1';

async function staleWhileRevalidate(request) {
  const cache = await caches.open(FEED_CACHE);
  const cached = await cache.match(request);

  const networkUpdate = fetch(request)
    .then((response) => {
      if (response.ok) cache.put(request, response.clone());
      return response;
    })
    .catch(() => null); // network failed; that's fine, we may already have `cached`

  return cached || (await networkUpdate) || new Response('[]', { status: 200 });
}

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);
  if (url.pathname.startsWith('/api/feed')) {
    event.respondWith(staleWhileRevalidate(event.request));
  }
});
```

Notifying the page that fresher data has arrived (since the cached response was already returned synchronously):

```js
// inside staleWhileRevalidate, after a successful background update:
const clients = await self.clients.matchAll();
clients.forEach((client) => client.postMessage({ type: 'FEED_UPDATED' }));
```

```js
// main.js
navigator.serviceWorker.addEventListener('message', (event) => {
  if (event.data?.type === 'FEED_UPDATED') {
    refetchFeedFromCache(); // silently re-render with the now-fresher cached data
  }
});
```
