# Snippet: Service Worker Registration With Update Detection

```js
// main.js
async function registerSW() {
  if (!('serviceWorker' in navigator)) return;

  const registration = await navigator.serviceWorker.register('/sw.js');

  // A new SW found itself waiting behind an already-active one
  registration.addEventListener('updatefound', () => {
    const newWorker = registration.installing;
    newWorker.addEventListener('statechange', () => {
      if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
        // there's an old SW already controlling the page -> this is an update, not first install
        showUpdateToast('A new version is available.', () => {
          newWorker.postMessage({ type: 'SKIP_WAITING' });
        });
      }
    });
  });

  // Reload once the new SW actually takes control
  let refreshing = false;
  navigator.serviceWorker.addEventListener('controllerchange', () => {
    if (refreshing) return;
    refreshing = true;
    window.location.reload();
  });
}

registerSW();
```

```js
// sw.js
self.addEventListener('message', (event) => {
  if (event.data?.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});
```

This is the standard "safe" update pattern: instead of silently force-activating (`skipWaiting()` unconditionally in `install`), the new SW waits, the app tells the user, and the update only takes effect once the user opts in — avoiding the mid-session inconsistent-state problem.
