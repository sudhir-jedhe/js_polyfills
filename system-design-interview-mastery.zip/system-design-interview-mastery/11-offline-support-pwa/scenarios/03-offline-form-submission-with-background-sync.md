# Scenario: Offline Form Submission Must Not Be Lost

**Scenario:** A field-service app is used by technicians who frequently work in basements/rural areas with no signal. They fill out a job-completion form; today, if the network is down at submit time, `fetch()` throws, an error toast appears, and the technician's data is gone unless they remember to retry manually before navigating away. Support wants a guarantee that a submitted form is never silently lost.

**Requirements:**
- A submission must survive the tab being closed while offline.
- It must retry automatically once connectivity returns, without requiring the user to do anything.
- The technician needs local confirmation ("saved, will send when back online") distinct from server confirmation ("received by server").

**Design:**

1. **Write-through to IndexedDB first, always** — the form's submit handler never calls `fetch()` directly; it writes the payload to an `outbox` object store synchronously (well, as the first async step) before anything else, so the write survives regardless of what the network does next.
2. **Optimistic local confirmation** — the UI immediately shows "Saved locally, will sync" the moment the IndexedDB write resolves, decoupled entirely from server round-trip latency.
3. **Register a Background Sync** so the browser retries even if the tab closes:

```js
async function submitJob(formData) {
  const record = { id: crypto.randomUUID(), formData, status: 'pending', createdAt: Date.now() };
  await outboxDB.add(record);
  renderLocalConfirmation(record.id);

  try {
    const registration = await navigator.serviceWorker.ready;
    await registration.sync.register('sync-job-forms');
  } catch {
    // Background Sync unsupported (e.g. Safari) — fall back to foreground retry
    window.addEventListener('online', flushOutboxOnce, { once: true });
  }
}
```

```js
// sw.js
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-job-forms') event.waitUntil(flushJobOutbox());
});

async function flushJobOutbox() {
  const pending = await outboxDB.getAllByStatus('pending');
  for (const record of pending) {
    try {
      const res = await fetch('/api/jobs', { method: 'POST', body: JSON.stringify(record.formData) });
      if (!res.ok) throw new Error('server rejected');
      await outboxDB.update(record.id, { status: 'synced' });
      notifyClients({ type: 'JOB_SYNCED', id: record.id });
    } catch {
      throw new Error('retry'); // rejecting inside waitUntil triggers the browser's own backoff retry
    }
  }
}
```

4. **Third fallback layer, since Background Sync has no Safari support**: on every app foreground/boot, unconditionally check the outbox and flush pending records — this is what actually guarantees delivery on every browser, with Background Sync as an optimization that shortens the delay on browsers that support it rather than being the sole mechanism.

**Result:** a technician who fills the form underground, closes the app, and resurfaces with signal an hour later gets the submission delivered automatically with no action required — the guarantee comes from "durable write before anything else" plus "retry on every plausible trigger" (sync event, online event, app foreground), not from any single API being reliable on its own.
