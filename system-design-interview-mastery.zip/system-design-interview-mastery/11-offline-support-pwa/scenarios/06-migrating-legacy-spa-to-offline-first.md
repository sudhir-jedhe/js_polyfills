# Scenario: Migrating a Legacy SPA to Offline-First

**Scenario:** An existing React SPA (no service worker at all today) fetches everything from a REST API on every navigation, with no local persistence beyond in-memory Redux state that's lost on refresh. The company wants to support "keep working on the train with no signal" for their core read/edit flows (viewing and editing a personal task list) without a full rewrite.

**Constraints:**
- Cannot break the existing app for the 95% of usage that's online.
- Rollout needs to be incremental — not a big-bang rewrite of the data layer.
- Must handle the transition period where some users have the old cache-less version and some have the new one.

**Migration plan:**

**Phase 1 — Add a service worker with zero behavior change to app logic.** Register a SW that only handles static asset caching (cache-first for the JS/CSS bundle, network-first for `index.html`) — this alone gets the app shell to boot offline (even if it then fails to load data), and is low-risk since it doesn't touch any application data flow yet.

**Phase 2 — Introduce a local read-model in IndexedDB, populated from existing API responses.** Don't change how writes work yet — just start mirroring every successful GET response for tasks into IndexedDB as a read-through cache:

```js
async function fetchTasks() {
  try {
    const response = await fetch('/api/tasks');
    const tasks = await response.json();
    await db.tasks.bulkPut(tasks); // mirror to IndexedDB, keyed by id
    return tasks;
  } catch {
    return db.tasks.toArray(); // offline fallback: last known state
  }
}
```
This makes reads offline-capable immediately, with the existing Redux/UI layer unchanged — it still calls `fetchTasks()` the same way, and now gets a graceful degrade instead of a thrown error when offline.

**Phase 3 — Move writes to the outbox pattern.** Task edits go to IndexedDB immediately (optimistic local apply + UI update), then to an outbox queue, then attempt network sync with Background-Sync-or-online-event-triggered retry — same pattern as the durable-write designs elsewhere in this topic. This is the highest-risk phase (conflict handling, partial failure) so it ships behind a feature flag, rolled out gradually.

**Phase 4 — Conflict handling**, scoped down deliberately for v1: since this is a personal (not shared/collaborative) task list, last-write-wins by `updatedAt` timestamp is sufficient — no need to build operational-transform-level merge logic for a single-user dataset. This is explicitly called out as a scoping decision, not an oversight, so it can be revisited only if the product later adds shared/collaborative lists.

**Handling the mixed-version rollout:** because Phase 1's SW registration and Phase 2/3's IndexedDB logic ship independently, a user who has the old JS bundle cached (Phase 1 SW is cache-first for JS!) could be stuck running pre-Phase-3 code even after the deploy. This is solved by the same update-detection-and-prompt mechanism used for any SW deploy (see `scenarios/01`), and by explicitly bumping the cache name at each phase boundary so there's no ambiguity about which phase's code a given cached bundle represents.

**Why phase it this way rather than shipping IndexedDB + outbox + SW all at once:** each phase is independently shippable and rollback-able, and the riskiest logic (writes with conflict potential) ships last, after the lower-risk plumbing (asset caching, read mirroring) has already proven stable in production — a standard incremental-migration structure interviewers want to see named explicitly rather than "just add a service worker."
