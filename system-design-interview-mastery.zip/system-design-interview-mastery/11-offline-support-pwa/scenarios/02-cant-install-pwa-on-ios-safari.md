# Scenario: Users Can't Install the PWA on iOS Safari

**Scenario:** The team built a fully-compliant PWA — manifest, service worker, `beforeinstallprompt` handling, a polished custom install button. Analytics show install conversion is strong on Android/Chrome but essentially zero on iOS Safari, despite it being ~40% of traffic. The install button on iOS just does nothing when tapped.

**Diagnosis:** Safari on iOS has never implemented the `beforeinstallprompt` event or any programmatic install trigger — "Add to Home Screen" is exclusively a manual action through the native Share sheet, and no JavaScript API can invoke it. The custom install button, wired only to `deferredPrompt.prompt()`, has `deferredPrompt` permanently `null` on iOS because the event that would populate it never fires. Tapping it silently no-ops.

**Fix — platform-branch the install UX instead of assuming one universal flow:**

```js
const isIOS = /iP(hone|ad|od)/.test(navigator.userAgent) && !window.MSStream;
const isInStandaloneMode = window.matchMedia('(display-mode: standalone)').matches
  || window.navigator.standalone === true; // iOS-specific legacy flag

installButton.addEventListener('click', () => {
  if (deferredPrompt) {
    deferredPrompt.prompt(); // Chromium path
  } else if (isIOS && !isInStandaloneMode) {
    showIOSInstallSheet(); // custom UI: "Tap the Share icon, then Add to Home Screen"
  } else {
    hideInstallButton(); // already installed, or unsupported platform
  }
});
```

The iOS "instructions" UI is typically a small overlay with a screenshot of the Share icon and the exact tap sequence, since there's no way to shortcut it programmatically. Some teams additionally detect iOS + not-yet-dismissed + enough engagement to show this proactively (a banner) rather than waiting for a button tap, since iOS users have no ambient "install" affordance from the browser chrome itself to discover on their own.

**Secondary gotcha worth flagging:** the iOS manifest/meta-tag story is also less complete — icons and splash-screen-like behavior lean more heavily on `<link rel="apple-touch-icon">` and `<meta name="apple-mobile-web-app-*">` tags than on the manifest JSON alone, so a manifest-only implementation that never added those tags will also look worse cosmetically once installed on iOS (wrong icon, browser chrome visible when it shouldn't be), even after the user does complete the manual install.
