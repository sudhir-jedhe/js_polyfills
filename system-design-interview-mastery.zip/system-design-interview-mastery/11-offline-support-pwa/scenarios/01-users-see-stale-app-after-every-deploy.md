# Scenario: Users See a Stale App After Every Deploy

**Scenario:** A team ships a cache-first service worker that pre-caches the app shell at install. After every deploy, support tickets come in from users seeing the previous version's UI and bugs that were supposedly fixed. Hard-refreshing (Ctrl+Shift+R) fixes it, but regular users don't know to do that.

**Diagnosis:** Two compounding issues. First, the SW's own cache name never changes between deploys (`caches.open('app-shell')` with a static, unversioned name), so `cache.addAll()` at install time either throws (trying to re-add already-present keys in some implementations) or silently reuses stale entries instead of fetching fresh ones — the install step isn't actually replacing anything. Second, even if the cache *were* versioned correctly, without `skipWaiting()`/`clients.claim()` or an update-prompt flow, the new SW sits in "waiting" behind any open tab, so users who don't fully close the app never get the update anyway.

**Fix — versioned cache names + explicit update flow:**

```js
const CACHE_VERSION = 'v12'; // bump on every deploy (e.g. injected from build hash)
const CACHE_NAME = `app-shell-${CACHE_VERSION}`;

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(SHELL_ASSETS))
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
});
```

Combined with the update-detection + user-prompt pattern (see `snippets/01-sw-registration-with-update-detection.md`): the new SW installs under a fresh cache name (no stale-key collision), the old cache gets swept on activate, and the user is explicitly told a new version is ready rather than silently stuck on the old one indefinitely.

**Why not just force `skipWaiting()` everywhere unconditionally?** It solves the "stuck on old version" problem but reintroduces a different one: a page mid-session could start getting responses shaped by a new SW/cache version if the API contract changed between deploys, causing inconsistent behavior without a reload. A visible "update available, refresh?" prompt is the middle ground production apps generally land on — instant enough to avoid stale bug reports, safe enough to avoid silent inconsistency.
