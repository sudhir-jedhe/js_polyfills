# Scenario: Cache Storage Quota Exceeded

**Scenario:** A media-heavy PWA (photo gallery app) caches every image the user views via a cache-first strategy so previously-viewed photos work offline. After a few weeks of heavy use, `cache.put()` calls start throwing `QuotaExceededError`, new images silently fail to be cached (though they still display, since the network fetch itself succeeds — only the caching side-effect fails), and eventually even the app shell cache starts getting evicted by the browser, breaking offline boot entirely.

**Diagnosis:** Origin storage in browsers is quota-limited (a percentage of free disk space, browser-dependent, often loosely "50% of disk" divided among origins under pressure) and, critically, **the browser can evict an entire origin's storage — including Cache Storage and IndexedDB — under global disk pressure**, with no guarantee of which origin or which cache gets cleared first unless `navigator.storage.persist()` has been granted. An unbounded "cache everything forever" strategy has no natural ceiling, so it eventually collides with the quota or gets swept by the browser's eviction policy, and the app has no way to distinguish "this image isn't cached because it was never viewed" from "this image isn't cached because it got evicted."

**Fix — bound the cache with an LRU eviction policy, split shell vs. runtime caches, and request persistence for the shell:**

```js
const MAX_RUNTIME_ENTRIES = 200;

async function cachePut(cacheName, request, response) {
  const cache = await caches.open(cacheName);
  await cache.put(request, response);
  await trimCache(cache, MAX_RUNTIME_ENTRIES);
}

async function trimCache(cache, maxEntries) {
  const keys = await cache.keys();
  if (keys.length <= maxEntries) return;
  // caches.keys() returns insertion order in practice — oldest first — good enough for a simple LRU-ish trim
  const excess = keys.length - maxEntries;
  for (let i = 0; i < excess; i++) {
    await cache.delete(keys[i]);
  }
}
```

- **Split caches by purpose**: `app-shell` (small, critical, rarely changes) stays separate from `runtime-images` (large, unbounded growth potential) — so runtime cache pressure/eviction never risks the shell that offline boot depends on.
- **Request persistent storage** for the origin so the browser treats it as exempt from best-effort eviction under disk pressure (still not a hard guarantee, and still subject to the user manually clearing site data, but meaningfully more durable):

```js
if (navigator.storage?.persist) {
  const granted = await navigator.storage.persist();
}
```

- **Surface quota usage to the user** for a media-heavy app like this rather than failing silently — `navigator.storage.estimate()` returns `{ usage, quota }`, which the app can use to show "X of Y offline photos cached" and let the user manage what's kept, rather than the app silently thrashing between caching and eviction.

**Why this is the right framing for an interview:** the fix isn't "cache less" in the abstract — it's introducing an explicit, bounded, evictable **policy** (LRU cap on the volatile cache) so the app degrades predictably (oldest photos become network-only again) instead of unpredictably (browser eviction picks arbitrarily, potentially breaking the app shell itself).
