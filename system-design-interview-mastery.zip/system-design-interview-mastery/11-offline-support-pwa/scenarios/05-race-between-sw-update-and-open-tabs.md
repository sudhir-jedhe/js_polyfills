# Scenario: Race Condition Between SW Update and Open Tabs Mid-Session

**Scenario:** An app uses `skipWaiting()` + `clients.claim()` for instant updates (no user prompt). A user has the app open, mid-way through filling a multi-step form (client-side state held in memory, not yet submitted). A deploy happens in the background. The new SW activates and claims the open tab immediately. The next API call the form makes — to fetch a dropdown's options — gets intercepted by the *new* SW, which points at a different API version that expects a request shape the old, in-memory client code doesn't send. The request fails with a confusing 400, and the user's in-progress form work still sitting in memory is at risk if they refresh to "fix" it.

**Diagnosis:** `clients.claim()` changes which SW intercepts requests for an *already-loaded* page without reloading that page's JS. The HTML/JS the user is running is still the old version — only the network interception layer switched underneath it. This creates a window where old client code and new SW/backend expectations coexist in the same tab, which is exactly the failure mode `skipWaiting()`+`clients.claim()` trades away safety for speed.

**Fix — decouple "SW updates instantly" from "the running page's JS silently starts talking to a mismatched backend":**

1. **Version the API contract defensively** so the backend accepts the previous minor version's request shape for a deprecation window (standard API evolution practice — this problem isn't really SW-specific, the SW instant-update just makes the race window much more likely to actually be hit).
2. **Detect the controller change and warn before it causes an error, rather than after:**

```js
navigator.serviceWorker.addEventListener('controllerchange', () => {
  if (formHasUnsavedChanges()) {
    showNonBlockingBanner('A new version is available. Finish this step, then refresh to update.');
  } else {
    window.location.reload(); // safe to reload silently if there's nothing to lose
  }
});
```

3. **Prefer the prompt-based update pattern over unconditional `skipWaiting()`** for any app with meaningful in-page state (forms, drafts, editors) — trading a few seconds of "user is on the previous version a bit longer" for eliminating this whole class of mid-session mismatch is almost always the right call. Save `skipWaiting()`+`clients.claim()` without a prompt for apps where sessions are short and stateless enough that a silent takeover is low-risk (a simple content/news reader, for instance).

**The broader interview point:** "instant update" and "safe update" are in tension specifically because the SW and the page's JS update on different clocks — the SW can flip in the background while the page's JS stays frozen in memory until a full reload, and any design that changes network behavior underneath a long-lived page needs an explicit plan for that gap, not just "call `skipWaiting()`."
