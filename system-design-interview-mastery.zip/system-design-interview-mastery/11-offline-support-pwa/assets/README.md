Diagrams and reference images for offline support & PWAs (e.g. a service worker lifecycle state diagram, a caching-strategy decision flowchart) will be added here.
