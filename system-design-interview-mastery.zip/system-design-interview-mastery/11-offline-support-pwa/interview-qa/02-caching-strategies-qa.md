# Interview Q&A — Caching Strategies

**Q: When would you use cache-first vs. network-first vs. stale-while-revalidate?**
Cache-first for content that's immutable once deployed (hashed static assets — a stale hit is impossible by construction, since a content change means a new URL). Network-first for content where freshness matters more than latency and an occasional slow/failed request is acceptable to fall back from (HTML documents, auth-sensitive API calls). Stale-while-revalidate when instant response matters more than perfect freshness and one-cycle-stale data is acceptable (feeds, avatars, non-critical reads) — it returns the cached copy immediately while updating the cache in the background for next time.

**Q: Why do you need to call `.clone()` on a `Response` before caching it?**
A `Response` (and `Request`) body is backed by a `ReadableStream`, which can only be consumed once. If you both return the response to the page *and* store it in the cache, each of those is a separate "read" of the body — without cloning first, the second read throws because the stream is already exhausted.

**Q: What's the risk with a strategy that races `fetch()` against a timeout for network-first, and how do you avoid wasting a slow-but-successful response?**
`Promise.race` doesn't cancel the losing promise — if the timeout wins and you fall back to cache, the underlying `fetch()` keeps running and its eventual result is simply discarded unless you separately keep awaiting it (e.g., in a `.then()` chain that updates the cache once it resolves, even after already responding to the page with the fallback).

**Q: How would you route different caching strategies for different request types in one service worker?**
Inspect the intercepted `Request` inside the `fetch` handler — `request.destination` (`'document'`, `'script'`, `'style'`, `'image'`, etc.) or the URL's path/extension — and dispatch to a different strategy function per category (e.g., network-first for documents, cache-first for hashed static assets, stale-while-revalidate for API GETs, and pass POST/PUT/DELETE straight through untouched since mutating requests should never be served from cache).

**Q: Should a service worker ever intercept and cache POST requests?**
Generally no — mutating, non-idempotent requests should go network-only. Caching a POST response (or worse, replaying a cached POST) risks duplicate side effects and violates the expectation that a mutation always reaches the server exactly when the user triggers it. Offline handling for mutations belongs in a durable queue (IndexedDB outbox + Background Sync), not in the Cache API.
