# Interview Q&A — Installability and PWA vs. Native

**Q: List the criteria a browser checks before offering to install a PWA.**
Served over HTTPS (or localhost), a linked Web App Manifest with at least `name`/`short_name`, `start_url`, `icons` including 192px and 512px sizes, and `display` set to `standalone`/`fullscreen`/`minimal-ui`, a registered service worker with a `fetch` handler, and some minimum user-engagement heuristic (browser-specific). Missing any one silently means `beforeinstallprompt` never fires — there's no error thrown for a failed check.

**Q: Why does `beforeinstallprompt` sometimes never fire even though the manifest and service worker both look correct?**
Most commonly a missing 512px icon, a `display` mode of `browser` instead of `standalone`/`fullscreen`/`minimal-ui`, or the engagement heuristic not yet being met. Chrome DevTools' Application → Manifest panel lists the exact failing criterion explicitly — that's the right diagnostic tool rather than guessing.

**Q: Does iOS Safari support `beforeinstallprompt`?**
No — Safari has never implemented it. "Add to Home Screen" on iOS is a manual action through the Share sheet with no programmatic trigger available. Any install-prompt implementation needs an iOS-specific fallback (custom instructional UI) rather than assuming the event will ever fire there.

**Q: What tradeoffs would push you toward a PWA over a native app for a given product, and vice versa?**
PWA: instant distribution and updates with no app store review, one codebase, lower engineering cost, strong for content/transactional apps where install friction hurts conversion. Native: needed when the product's core value depends on deep OS/device APIs the web can't reach well (background location, deep Bluetooth/AR, hard-real-time performance), when push notifications are mission-critical on iOS today, or when app-store discovery is a primary acquisition channel. Many production systems use both — a PWA as the default web experience with a thin native shell layered in only for users needing device APIs or push.

**Q: What's the difference between `display: standalone` and `display: browser` in the manifest, and why does it matter for installability?**
`standalone` (and `fullscreen`/`minimal-ui`) hides the browser's URL bar/chrome, making the installed app look and feel native — this is required for the browser to consider the manifest install-eligible. `browser` explicitly opts back into normal tab chrome, which signals "this isn't meant to be an app-like experience," and browsers won't offer an install prompt for it.
