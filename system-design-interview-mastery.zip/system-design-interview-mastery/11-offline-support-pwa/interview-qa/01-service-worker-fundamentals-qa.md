# Interview Q&A — Service Worker Fundamentals

**Q: What are the three core service worker lifecycle events, and what belongs in each?**
`install` (fires once per new/changed SW script — precache the app shell here, wrapped in `event.waitUntil()` so the browser knows to wait for it), `activate` (fires once the SW is ready to take control — clean up old cache versions here), and `fetch` (fires on every network request while the SW controls the page — intercept and decide a response via `event.respondWith()`).

**Q: Why doesn't a newly-registered service worker control the page that registered it?**
Because the current page load already started without a controller — registration is asynchronous and happens after the page has begun loading. The SW only starts controlling *future* navigations/requests once it activates, unless the page explicitly calls `clients.claim()` from within the SW's `activate` handler to take over already-open, uncontrolled clients.

**Q: Explain `skipWaiting()` and `clients.claim()` and what problem they solve together.**
By default, a newly-installed SW sits in a "waiting" state until every tab controlled by the previous SW closes — this is a safety mechanism to avoid two different SW versions controlling different tabs' requests inconsistently mid-session. `skipWaiting()`, called during `install`, forces the new SW straight to "activating" without waiting for old tabs to close. `clients.claim()`, called during `activate`, makes the now-active SW immediately take control of any already-open page that was still on the old SW (or uncontrolled). Together they make updates apply instantly instead of requiring every tab to be closed — at the cost of the safety guarantee they bypass.

**Q: What determines a service worker's scope, and can it be widened?**
Scope defaults to the directory the SW script is served from (`/app/sw.js` defaults to controlling `/app/*`). It can be widened via the `Service-Worker-Allowed` response header when registering, but a SW can never be scoped to control a path *above* its own script location — placing `sw.js` at the site root is the common way to guarantee it can control the entire origin without needing that header.

**Q: A service worker's `fetch` handler doesn't call `event.respondWith()` for a given request. What happens?**
The request falls through to the browser's normal network handling, exactly as if no SW were intercepting it at all — `event.respondWith()` is what claims responsibility for the response; without it, the SW is effectively just observing, not intervening.

**Q: Why can't a service worker access the DOM directly?**
It runs in a separate worker thread/context, similar to a Web Worker, specifically so its potentially-expensive network-interception and caching logic never blocks the main thread's rendering. Any communication with a page has to go through `postMessage`/`client.postMessage()`, not direct DOM references.
