# Interview Q&A — Storage and Background Sync

**Q: Why is IndexedDB preferred over `localStorage` for offline application data?**
`localStorage` is synchronous and blocks the main thread on every read/write, is capped around 5-10MB, only stores strings (requiring manual `JSON.stringify`/`parse`), offers no querying beyond exact key lookup, and — critically — isn't accessible from inside a service worker at all. IndexedDB is asynchronous, holds structured data natively (objects, Blobs), supports much larger storage quotas, offers indexes for range/secondary queries, and is fully usable from a service worker, making it the only realistic choice for any non-trivial offline dataset.

**Q: What is `onupgradeneeded` and when does it fire?**
It fires when `indexedDB.open(name, version)` is called with a version number higher than the database's currently stored version (or on first creation). It's the only place object stores and indexes can be created or deleted, and it runs inside a special "versionchange" transaction that blocks all other open connections to that database until it completes.

**Q: A tab's `indexedDB.open()` call for a bumped version number never resolves. What's likely happening, and how do you prevent it?**
It's almost certainly blocked by another tab holding an open connection to the older version — a version-change transaction needs exclusive access, and the `open()` call just hangs (with `onblocked` firing, not `onerror`) until every other connection closes. Prevent it by registering `db.onversionchange` on every open connection to proactively `db.close()` and notify the user when another tab requests an upgrade, rather than leaving it to chance.

**Q: What problem does the Background Sync API solve that a simple `window.addEventListener('online', retry)` doesn't?**
The `online` event only fires while the tab is open — if the user closes the tab while offline (very likely, since they were probably giving up on a failed action), the retry never has a chance to run. Background Sync registers a sync request with the browser/OS itself, which can wake the service worker to retry even after the originating tab has closed, as long as the SW registration is still present when connectivity returns.

**Q: If a `sync` event handler's `event.waitUntil()` promise rejects, what happens?**
The browser treats it as a failed sync and automatically retries later with its own exponential backoff — you don't need to hand-roll retry scheduling; rejecting is literally how you signal "please try again."

**Q: Why can't you rely on the Background Sync API alone for reliable offline delivery?**
Browser support is inconsistent — Safari has never shipped the one-off Background Sync API — so any design that depends on it exclusively silently fails to guarantee delivery on a large share of real users. A robust design layers it as an optimization on top of a universal fallback: retry on the `online` event while the tab is open, and — most importantly — flush any pending outbox items unconditionally on every app boot/foreground, which works regardless of Background Sync support.
