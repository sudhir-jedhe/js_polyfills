# Interview Q&A — Load Balancing

**Q: What's the precise difference between L4 and L7 load balancing?**
L4 (transport layer) makes its routing decision using only IP address and TCP/UDP port — it forwards packets without parsing the application-layer payload at all, so it has no concept of an HTTP request, path, or header. L7 (application layer) terminates the connection and parses the actual HTTP request, which lets it route based on path, headers, cookies, or method, at the cost of more per-request CPU overhead (connection termination, TLS handshake, HTTP parsing) than L4's comparatively cheap packet forwarding.

**Q: Why can't an L4 load balancer do path-based routing like `/api/*` vs `/static/*`?**
Because path-based routing requires reading the HTTP request line, which is application-layer data — an L4 balancer only ever sees IP/port information and forwards packets/connections without inspecting what's inside them, so the URL path simply isn't visible to it at the layer it operates on.

**Q: When would you choose round robin over least connections, or vice versa?**
Round robin is fine when requests have roughly uniform processing cost across a fleet of roughly equal-capacity servers — its simplicity is a feature, not a limitation, in that case. Least connections is the better choice whenever request duration is variable or unpredictable (mixed light/heavy endpoints, long-polling, streaming), because it actively balances by real-time load rather than blindly cycling through servers regardless of how busy each currently is.

**Q: What problem does IP hash solve, and what's its main weakness?**
IP hash provides session affinity ("sticky sessions") without needing a shared session store — the same client IP deterministically maps to the same backend every time, so session state can live in that backend's local memory. Its weakness is uneven distribution when client IPs are skewed (many users behind one shared corporate/carrier NAT IP all hash to the same backend) and significant reshuffling when the server pool changes size, unless the implementation specifically uses consistent hashing to minimize remapping.

**Q: What's the difference between active and passive health checks?**
Active health checks are synthetic — the load balancer itself periodically sends a dedicated probe request (e.g., `GET /health`) to each backend and marks it unhealthy after consecutive failures. Passive health checks observe real production traffic — if requests actually routed to a backend start failing or timing out at an elevated rate, it's marked unhealthy without any dedicated probe. Active checks catch problems even during traffic lulls; passive checks add no extra probe load and reflect real request behavior, but are slower to detect issues on a low-traffic backend.

**Q: What causes health-check flapping, and how do you prevent it?**
Flapping happens when the unhealthy threshold is too low (e.g., a single failed probe removes a server) — a momentarily slow-but-healthy server gets yanked from rotation, which concentrates its load onto the remaining servers and can push one of *them* into the same transient slowness, repeating the cycle. The standard fix is an asymmetric threshold: require several consecutive failures to mark a server down (tolerating a blip) but fewer consecutive successes to bring it back (rejoining quickly once actually healthy), combined with a realistic timeout that accounts for real tail latency under load.

**Q: In an architecture with both L4 and L7 load balancers, why layer them instead of using just one?**
A common pattern uses an L4 layer (or DNS/anycast) as the outermost tier to cheaply spread raw connections across a fleet of L7 load balancers, which then do the more expensive content-aware routing. This uses L4's low per-connection overhead to handle the highest-volume, coarsest-grained distribution, while reserving L7's costlier parsing/termination for the layer that actually needs path/header-based intelligence — avoiding paying L7's overhead at the outermost, highest-traffic tier unnecessarily.
