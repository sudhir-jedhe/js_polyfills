# Interview Q&A — Rate Limiting Algorithms

**Q: Compare token bucket and leaky bucket in one sentence each — what's the actual difference?**
Token bucket fixes the *refill* rate and lets accumulated tokens be spent instantly, so it allows bursts up to the bucket's capacity; leaky bucket fixes the *outflow/processing* rate and queues or smooths everything to that constant rate, so it does not allow bursts even if the average rate is within budget.

**Q: Why does fixed window counter allow up to 2x the stated limit?**
Because the window is defined by wall-clock alignment (e.g., every minute on the minute), not by a rolling interval relative to each request. A burst of `limit` requests can land at the very end of one window, and another burst of `limit` requests can land at the very start of the next window — both bursts individually respect their own window's cap, but the combined pair is separated by less than one full window duration, so up to `2 * limit` requests can pass within a span shorter than the intended window.

**Q: How does sliding window log fix that, and what does it cost?**
It stores a timestamp per request and, on each new request, discards timestamps older than `now - windowSize` before counting what remains against the limit — this evaluates the *true* trailing window relative to `now` on every request, so no boundary-doubling is possible. The cost is `O(n)` space per entity, where `n` is the number of requests within the window, instead of the `O(1)` space fixed window and token bucket use.

**Q: How does sliding window counter get `O(1)` space while still approximating a rolling window?**
It keeps just two counters — current window and previous window — and weights the previous window's count by the fraction of it still "inside" the true trailing window, based on how far into the current window `now` is. It assumes requests were uniformly distributed within the previous window, which is usually a good enough approximation, but can be measurably wrong if traffic was actually clustered near the window boundary.

**Q: If I need exact enforcement with a very high per-entity limit, which algorithm should I pick, and why not sliding window log?**
Token bucket or sliding window counter — sliding window log's `O(n)` memory becomes a real cost at high limits (a 50,000/min limit means up to 50,000 stored timestamps per entity in the worst case), whereas token bucket and sliding window counter both stay `O(1)` regardless of the limit's magnitude. Sliding window log is the right choice specifically when the limit is low (so `n` stays small) and exactness matters more than memory, e.g. "5 login attempts per 15 minutes."

**Q: Does token bucket protect against a client that's been idle for a long time then bursts?**
Only up to `capacity`, never more — the refill calculation is always clamped to `min(capacity, tokens + elapsed * refillRate)`, so no matter how long a client has been idle, it can never accumulate more than `capacity` tokens to spend at once. This is precisely why `capacity` is chosen deliberately (often just a few seconds' worth of the refill rate) rather than left unbounded — it caps the worst-case instantaneous burst regardless of idle duration.

**Q: What's the fundamental tradeoff across all five algorithms, stated as one axis?**
Memory/precision tradeoff: fixed window counter and token bucket/leaky bucket are `O(1)` space but either inaccurate at boundaries (fixed window) or not window-based at all (bucket algorithms); sliding window log is exact but `O(n)`; sliding window counter is the middle ground — `O(1)` space with a small, bounded approximation error instead of fixed window's unbounded boundary error.
