# Interview Q&A — Distributed Rate Limiting

**Q: Why can't each app server just keep its own in-memory counter when you have multiple instances behind a load balancer?**
Because a client's requests can land on any instance, and each instance would have its own independent view of that client's usage — the effective limit becomes `limit * numberOfInstances` instead of `limit`, since a client could get `limit` requests through on each instance separately. There's no shared state, so no single instance ever sees the client's true total request count.

**Q: What specific race condition breaks a naive "GET count, check, INCR" implementation against a shared store?**
Two requests from the same client, landing on two different app servers, can both `GET` the same pre-increment count (say 99, with limit 100) before either has written back its increment. Both see `99 < 100` and both decide ALLOW, then both `INCR`, taking the count to 101 — the limit was exceeded because the check-then-act sequence wasn't atomic, allowing a stale read to be acted on by two callers concurrently.

**Q: How do you make the check-and-increment atomic in Redis?**
Wrap the read-compute-write sequence in a Lua script executed via `EVAL`. Redis guarantees a Lua script runs to completion without any other client's commands interleaving mid-script, so the entire "read current tokens, compute refill, check against limit, write back" sequence becomes a single indivisible operation — eliminating the race, since no other request can observe or act on an intermediate state.

**Q: Should a rate limiter fail open or fail closed if its backing store (Redis) goes down?**
Fail open, as the common default — a rate limiter exists to protect the system from overload, and an outage in the limiter itself shouldn't cascade into rejecting all legitimate traffic too. This is different from an authorization/authentication check, which should almost always fail closed, because the cost of wrongly allowing an unauthenticated request is a security breach, not just temporarily reduced abuse protection.

**Q: What is a "hot key" problem in a distributed rate limiter, and why doesn't adding more Redis shards fix it?**
A hot key is a single rate-limit key (e.g., one very high-volume customer's counter) whose traffic saturates the one Redis shard it happens to hash to. Redis Cluster shards by key, spreading *different* keys across shards, but a single key always lives entirely on one shard — so no matter how many total shards exist, that one key's throughput ceiling is bounded by what a single shard can serve. Fixing it requires either splitting the logical counter into multiple sub-keys (each landing on a potentially different shard) or reducing how often that key needs to be read/written at all (e.g., local pre-filtering).

**Q: Where should the rate limiter live architecturally — API gateway, or each app server?**
API gateway is the more common and generally better answer: it's a single choke point that rejects abusive requests before they ever reach app server compute, applies policy uniformly without every service needing its own integration, and is easier to reason about and change centrally. Per-service middleware is viable too but pushes the responsibility (and risk of inconsistent configuration) onto every individual service.
