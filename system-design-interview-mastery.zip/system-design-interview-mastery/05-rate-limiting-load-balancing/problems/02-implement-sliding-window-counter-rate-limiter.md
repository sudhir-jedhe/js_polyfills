# Problem: Implement a Sliding Window Counter Rate Limiter

## Problem Statement

Implement a rate limiter using the sliding window counter algorithm (weighted current + previous fixed window), exposing `allow(key)`. It must approximate a true rolling window in `O(1)` space per key, unlike sliding window log's `O(n)`.

## Constraints

- `O(1)` space and time per key, regardless of the request volume within the window.
- Must correctly roll over from "previous" to "current" window as time advances, including the case where an entire window passes with zero requests (previous window's count must not incorrectly carry forward as if it were the immediately preceding window).

## Approach

Track `currentWindowStart`, `currentCount`, `previousCount` per key. On each request, compute which fixed window `now` falls into; if it's a new window, shift `currentCount` into `previousCount` **only if** the new window is the very next one after the old — if more than one window's worth of time has elapsed (a gap with no traffic), `previousCount` must be zeroed instead of retaining stale data, since a window that's not immediately prior to the current one contributes nothing to the true rolling count.

## Solution

```js
class SlidingWindowCounterLimiter {
  constructor(limit, windowSizeMs) {
    this.limit = limit;
    this.windowSizeMs = windowSizeMs;
    this.state = new Map(); // key -> { windowStart, currentCount, previousCount }
  }

  allow(key) {
    const now = Date.now();
    const windowIndex = Math.floor(now / this.windowSizeMs);
    const windowStart = windowIndex * this.windowSizeMs;

    let s = this.state.get(key);
    if (!s) {
      s = { windowStart, currentCount: 0, previousCount: 0 };
      this.state.set(key, s);
    } else if (windowStart !== s.windowStart) {
      const windowsElapsed = (windowStart - s.windowStart) / this.windowSizeMs;
      s.previousCount = windowsElapsed === 1 ? s.currentCount : 0; // gap > 1 window: previous data is stale, discard
      s.currentCount = 0;
      s.windowStart = windowStart;
    }

    const elapsedIntoCurrent = now - s.windowStart;
    const weight = 1 - elapsedIntoCurrent / this.windowSizeMs;
    const estimated = s.currentCount + s.previousCount * weight;

    if (estimated < this.limit) {
      s.currentCount += 1;
      return true;
    }
    return false;
  }
}

// --- verification ---
const limiter = new SlidingWindowCounterLimiter(3, 1000); // 3 per second

// simulate real time via a fake clock in a real test; here, rapid calls approximate t=0
console.log(limiter.allow("k")); // true (count 1)
console.log(limiter.allow("k")); // true (count 2)
console.log(limiter.allow("k")); // true (count 3, at limit)
console.log(limiter.allow("k")); // false (estimated >= 3)
```

## Verifying the "stale previous window" edge case

```js
// Manually construct state to simulate: window 5 had 10 requests, then NOTHING happened
// for 3 whole windows, and now we're in window 8.
const s = { windowStart: 5000, currentCount: 10, previousCount: 0 };
// on the next request at t=8300 (window index 8):
// windowsElapsed = (8000 - 5000) / 1000 = 3  →  NOT 1  →  previousCount correctly reset to 0
// without this check, a naive "always carry currentCount into previousCount" would wrongly
// treat window 5's traffic as if it were window 7's (the actual previous window), inflating
// the estimate long after that traffic should have fully aged out of any rolling window.
```

## Complexity

- **Time:** `O(1)` per `allow()` call.
- **Space:** `O(k)` for `k` distinct keys — exactly two counters and a timestamp each, independent of request volume.
