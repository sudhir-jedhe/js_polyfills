# Problem: Implement a Token Bucket Rate Limiter

## Problem Statement

Implement a `RateLimiter` class supporting multiple independent buckets (one per client key), with:
- `constructor(capacity, refillRatePerSecond)`
- `allow(key)` → returns `true`/`false`, consuming one token from that key's bucket if allowed

No external dependencies (single-process, in-memory) — this is the building block that gets ported to Redis Lua for a distributed deployment.

## Constraints

- `allow(key)` must be `O(1)` time and must not require a background timer/scheduled job per key (lazy refill only).
- Must correctly handle a key seen for the first time (bucket starts full).
- Must be safe to call with a very large number of distinct keys without pre-allocating state for keys never seen.

## Approach

Lazily create a bucket entry on first use, and compute the refill amount on every call based on elapsed wall-clock time since that key's last update — this avoids needing `setInterval`-style background refilling for every key, which wouldn't scale to millions of keys.

## Solution

```js
class RateLimiter {
  constructor(capacity, refillRatePerSecond) {
    this.capacity = capacity;
    this.refillRate = refillRatePerSecond;
    this.buckets = new Map(); // key -> { tokens, lastRefill }
  }

  allow(key, tokensRequested = 1) {
    const now = Date.now();
    let bucket = this.buckets.get(key);

    if (!bucket) {
      bucket = { tokens: this.capacity, lastRefill: now };
      this.buckets.set(key, bucket);
    }

    const elapsedSeconds = (now - bucket.lastRefill) / 1000;
    bucket.tokens = Math.min(this.capacity, bucket.tokens + elapsedSeconds * this.refillRate);
    bucket.lastRefill = now;

    if (bucket.tokens >= tokensRequested) {
      bucket.tokens -= tokensRequested;
      return true;
    }
    return false;
  }
}

// --- verification ---
const limiter = new RateLimiter(5, 1); // capacity 5, refill 1/sec

console.log(limiter.allow("userA")); // true  (5->4)
console.log(limiter.allow("userA")); // true  (4->3)
console.log(limiter.allow("userB")); // true  (independent bucket, 5->4)
for (let i = 0; i < 5; i++) limiter.allow("userA"); // drains userA further, several rejects expected
console.log(limiter.allow("userA")); // false (bucket empty, no time elapsed)
```

## Extension: memory cleanup

In a real long-running service, `this.buckets` grows unboundedly as new keys appear and are never removed. Add opportunistic eviction of stale entries (a bucket at full capacity whose `lastRefill` is old enough that it's provably back to `capacity` and irrelevant until touched again can simply be deleted — recreating it on next use is behaviorally identical to keeping it around, since a fresh bucket also starts full):

```js
evictStale(maxAgeMs) {
  const now = Date.now();
  for (const [key, bucket] of this.buckets) {
    if (bucket.tokens >= this.capacity && now - bucket.lastRefill > maxAgeMs) {
      this.buckets.delete(key);
    }
  }
}
```
Run this on a periodic sweep (e.g., every few minutes), not per-request — it's a housekeeping concern, not part of the hot path.

## Complexity

- **Time:** `O(1)` per `allow()` call.
- **Space:** `O(k)` where `k` is the number of distinct keys currently tracked (bounded by eviction above).
