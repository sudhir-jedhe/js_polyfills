# Problem: Design a Rate Limiter (End-to-End System Design)

## Problem Statement

Design a rate limiter for a large-scale API platform: hundreds of app server instances across multiple regions, millions of distinct API keys, needs to support both a global per-key limit and cheap enough operation to sit in the hot path of every request. Walk through the full design as you would in a system design interview.

## Constraints

- Must be correct under concurrency (no client should ever exceed its limit due to a race, beyond a small tolerable margin).
- Must add minimal latency to the request path (target: low single-digit milliseconds added).
- Must scale to millions of independent rate-limited entities.
- Must survive partial infrastructure failure without taking down unrelated healthy traffic.
- Multi-region: clients may hit different regional gateways.

## Approach — walked through like an interview

**1. Clarify requirements first.** What's being limited (per-user? per-API-key? per-IP?), what precision is actually needed (does a small approximation error matter, or must it be exact — e.g., billing-relevant limits lean toward more exactness than abuse-prevention limits), what's the expected read/write QPS, and is strict global consistency required or is "eventually converges, approximately enforced" acceptable across regions. For this design: per-API-key limiting, approximate enforcement acceptable (a few percent tolerance), high QPS (100K+ req/sec platform-wide).

**2. Algorithm choice — token bucket.** Public API traffic is bursty by nature (a client's app can legitimately fire a batch of requests at once); token bucket's burst tolerance up to `capacity` fits that pattern, stays `O(1)` in both time and space per key regardless of traffic volume, and is simple to reason about with two tunable parameters (capacity, refill rate) that map cleanly onto pricing tiers.

**3. Storage layer — Redis, sharded via Cluster, one hash per key.** Redis gives sub-millisecond in-memory access and atomic Lua execution for the read-check-write sequence (see `theory/06-distributed-rate-limiting-redis.md` for the exact race condition this prevents). Cluster mode shards keys across nodes so no single node needs to hold all millions of keys' state.

**4. Enforcement point — API gateway, before requests reach app servers.** Centralizing the check means rejected requests never consume app-server compute, and policy changes (new tiers, emergency overrides) happen in one place. Each gateway instance calls the shared Redis Lua script per request.

**5. Multi-region handling — regional Redis clusters, not one global cluster.** A single global Redis cluster would add cross-region latency to every request (defeating the "low single-digit ms" goal) and creates a single blast-radius for failure. Instead: each region runs its own Redis cluster and enforces the limit *regionally*, with the per-region limit set to `globalLimit / numRegions` as a reasonable approximation — accepting that a client hitting multiple regions simultaneously could technically exceed the intended global total by a bounded factor, which is judged acceptable given the "approximate enforcement is fine" requirement from step 1. If exact global enforcement were required, that would push toward a single strongly-consistent global store, at the direct cost of added per-request latency for every region — a tradeoff to state explicitly rather than assume.

**6. Local pre-filtering to cut Redis load and hide latency.** Each gateway instance keeps a small local in-memory token bucket approximating its share of a key's limit; only requests near the local threshold pay the full Redis round-trip. This is optional but meaningfully reduces both Redis QPS and average added latency for the common case (a request that's obviously fine doesn't need the authoritative check).

**7. Failure handling — fail open on Redis unavailability**, with the local in-memory fallback (from step 6) providing a degraded-but-nonzero safety net rather than either "reject everything" or "no limiting at all" during an outage.

**8. Hot key mitigation — sub-key sharding for unusually high-volume individual keys** (see `scenarios/03-hot-partition-in-distributed-rate-limiter.md`), applied selectively rather than universally, since most keys don't need it and it adds complexity.

**9. Response contract — `429` with `Retry-After`, `X-RateLimit-*` headers**, jittered `Retry-After` values to avoid a thundering herd of synchronized retries (see `scenarios/05-thundering-herd-after-rate-limit-window-reset.md`).

**10. Observability.** Emit metrics on allow/reject rate per key-tier, Redis latency percentiles, and fail-open activation events — a rate limiter silently fail-opening during an incident is exactly the kind of thing that needs to be visible, not discovered after the fact.

## Summary architecture

```
Client → Regional API Gateway (many instances)
             │
             ├─ local in-memory pre-filter (fast path for clearly-OK requests)
             │
             └─ Redis Cluster (regional) — atomic Lua token-bucket check
                    │
                    └─ ALLOW → forwarded to app server fleet
                       REJECT → 429 + Retry-After, never reaches app servers
```

## Key tradeoffs to state explicitly in an interview

- Token bucket over sliding window log: bounded `O(1)` memory at the cost of not being a strict "last N seconds" guarantee (bursts up to capacity are allowed by design).
- Regional enforcement over global: lower latency and smaller blast radius, at the cost of a client spread across regions potentially exceeding the nominal global limit by a bounded factor.
- Fail-open over fail-closed: preserves availability during a limiter outage, at the cost of temporarily losing abuse protection — judged acceptable because a rate limiter is a protective mechanism, not a security boundary.
