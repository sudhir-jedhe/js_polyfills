# Rate Limiting & Load Balancing

Rate limiting protects a system from being overwhelmed — by abusive clients, buggy retry loops, or simply more legitimate traffic than capacity allows — by rejecting or delaying requests once a client crosses a defined threshold. Load balancing is the complementary concern: distributing accepted traffic across a fleet of backend servers so no single instance is overloaded while others sit idle. Together they're two of the most heavily tested system design topics because they combine precise algorithmic tradeoffs (token bucket vs. leaky bucket vs. the three window-based counters) with real distributed-systems concerns (atomicity under concurrency, failure modes, hot keys) — interviewers use this topic specifically to separate candidates who've memorized "there are several rate limiting algorithms" from candidates who can state exactly why fixed window counter allows 2x the limit at a boundary, or why leaky bucket and token bucket produce opposite burst behavior despite looking superficially similar.

## Folder structure

- **`theory/`** — all five rate limiting algorithms (token bucket, leaky bucket, fixed window counter, sliding window log, sliding window counter) each with precise mechanism and complexity, distributed rate limiting with Redis (atomicity, hot keys, fail-open/closed), and load balancing algorithms with L4 vs. L7 and health checks.
- **`snippets/`** — 5 runnable examples: in-memory token bucket, sliding window counter, an atomic Redis Lua rate limiter, Express rate-limiting middleware, and an NGINX load balancer config covering all four LB algorithms.
- **`output-based/`** — 5 "trace this exact sequence" questions: token bucket through a burst, the fixed-window boundary burst in concrete numbers, leaky bucket queueing behavior, sliding window counter's approximation error made concrete, and round robin vs. least connections under uneven request cost.
- **`scenarios/`** — 5 real-world situations: designing a gateway rate limiter, per-user vs. per-IP limiting behind NAT, a hot-key bottleneck in a distributed limiter, load balancer health-check flapping, and a thundering herd from synchronized rate-limit window resets.
- **`interview-qa/`** — 3 themed files: rate limiting algorithms, distributed rate limiting, and load balancing.
- **`problems/`** — 3 hands-on challenges: implement a token bucket limiter, implement a sliding window counter limiter, and the full "design a rate limiter" system design question worked end to end.
- **`assets/`** — placeholder for diagrams/images (see `assets/README.md`).

## What's covered

- All five core rate-limiting algorithms with exact burst-capacity behavior, complexity, and precise numeric explanations of their failure modes (especially fixed window's boundary burst and sliding window counter's approximation error)
- Distributed rate limiting: why per-instance in-memory counters break under multiple app servers, the check-then-act race condition, atomic enforcement via Redis Lua scripting, fail-open vs. fail-closed, and hot-key/hot-partition mitigation
- Load balancing algorithms (round robin, weighted round robin, least connections, IP hash) with when each is the right choice
- L4 vs. L7 load balancing — the precise distinction in what each layer can see and route on, and why that determines what kind of routing decisions are even possible
- Health checks — active vs. passive, threshold tuning, and how misconfigured thresholds cause flapping
- The "design a rate limiter" system design question worked end to end, including multi-region and failure-mode tradeoffs
