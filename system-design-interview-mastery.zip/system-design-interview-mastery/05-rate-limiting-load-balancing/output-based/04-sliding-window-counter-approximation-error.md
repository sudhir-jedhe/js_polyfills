# Output: Sliding Window Counter's Approximation vs. True Count

```
Sliding window counter: limit = 100, window = 60s
Previous window [12:00:00-12:00:59]: 100 requests, ALL of them arrived in the last 5 seconds (12:00:55-12:00:59)
Current window [12:01:00-...]: 0 requests so far
New request arrives at 12:01:06 (6 seconds into the current window)
```

**Question:** Does the sliding window counter algorithm allow this new request? Is that the same answer a true sliding-window-log evaluation would give?

**Answer — sliding window counter's estimate:**

```
elapsed into current window = 6s → weight for previous window = 1 - 6/60 = 0.90
estimated_count = current_count (0) + previous_count (100) * 0.90 = 90
90 < 100 → ALLOW
```

**Answer — true sliding window log (exact):** the true trailing 60-second window as of `12:01:06` spans `12:00:06` to `12:01:06`. All 100 requests from the previous window landed at `12:00:55`–`12:00:59`, which **is** within that true trailing window → true count = 100. `100 < 100` is false → the exact algorithm would **REJECT**.

**So the two algorithms disagree here:** the sliding window counter's estimate (90) under-counts relative to the true value (100) and incorrectly allows a request that should have been rejected. This is precisely the approximation error the algorithm accepts as a tradeoff — it assumed the previous window's 100 requests were spread **uniformly** across the full 60s window (which would make the "10% weight I'm discounting" roughly correct), but they were actually clustered at the very end of that window, right next to the boundary, which is the worst case for the approximation's accuracy.

**Takeaway:** the sliding window counter's error is worst precisely when traffic is bursty *right at* a window boundary — which is also exactly the scenario fixed window counter fails at completely. Sliding window counter narrows that failure from "up to 2x the limit" down to a small bounded error, but does not eliminate it. Only sliding window log (paying `O(n)` memory) is exact in this adversarial-clustering case.
