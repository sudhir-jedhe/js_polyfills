# Output: Round Robin vs. Least Connections Under Mixed Request Costs

```
3 backend servers (A, B, C), all identical hardware.
6 requests arrive at t=0, routed by the load balancer as they come in.
Request processing times: req1=5s, req2=1s, req3=1s, req4=1s, req5=1s, req6=1s
```

**Question:** Trace where each request lands under (a) round robin and (b) least connections, and state which server is most overloaded at `t=1s` under each.

**Answer — Round robin** (cycles A, B, C, A, B, C regardless of load):

| Request | Server | Duration |
|---|---|---|
| req1 | A | 5s |
| req2 | B | 1s |
| req3 | C | 1s |
| req4 | A | 1s |
| req5 | B | 1s |
| req6 | C | 1s |

At `t=1s`: server A is still processing req1 (4s remaining) **and** has req4 queued behind it — A has 2 requests in its queue/processing while B and C have already finished their single 1s request each. **Server A is overloaded** — round robin gave it 2 of the 6 requests purely by position in the cycle, with zero awareness that req1 was a slow request.

**Answer — Least connections** (routes each new request to whichever server has the fewest active connections at that instant):

| Request | Active connections at routing time | Routed to |
|---|---|---|
| req1 | A=0, B=0, C=0 (tie, pick A) | A (now processing 5s job) |
| req2 | A=1, B=0, C=0 (tie, pick B) | B |
| req3 | A=1, B=1, C=0 | C |
| req4 | A=1, B=1, C=1 → but B, C are about to finish; assume requests arrive faster than 1s apart, so still A=1,B=1,C=1 (tie, pick A again in tie-break order) — **this is the risk case** | A (queues behind the 5s job) |

Depending on tie-breaking, least connections *can* still route req4 to A if it doesn't yet know B/C are about to free up (connection count is a real-time signal, not a predictive one) — but in the realistic case where req2/req3 finish quickly (1s each) and req4 arrives even slightly later, least connections would see `A=1, B=0, C=0` and correctly route req4 to B or C instead, avoiding stacking more work behind the slow request.

**Answer to "most overloaded at t=1s":** under round robin, **A** is guaranteed overloaded (2 requests, including the long one) purely by cycle position. Under least connections, A is *only* overloaded if a second request happens to arrive before B or C's fast requests complete — the algorithm actively tries to avoid it, and does avoid it once real-time connection counts diverge, whereas round robin has no mechanism to avoid it at all.

**Takeaway:** round robin's blindness to request duration is the core weakness the trace demonstrates — it treats a 5-second request identically to a 1-second one when deciding the next assignment, so any variance in request cost creates load imbalance that round robin structurally cannot self-correct.
