# Output: Token Bucket Trace Through a Burst and a Quiet Period

```
Token bucket: capacity = 6, refill rate = 2 tokens/sec, starts full (tokens = 6)

t=0.0s: 5 requests arrive back-to-back
t=1.5s: 1 request arrives
t=3.0s: 4 requests arrive back-to-back
```

**Question:** For each request, is it ALLOW or REJECT, and what is the token count immediately after each batch?

**Answer, traced step by step:**

`t=0.0s` (no time elapsed since start, tokens still 6): 5 requests consume 1 token each → all 5 **ALLOW**. Tokens: `6 - 5 = 1`.

`t=1.5s`: elapsed since last update = 1.5s → refill = `1.5 * 2 = 3` tokens → tokens = `min(6, 1 + 3) = 4`. Request consumes 1 → **ALLOW**. Tokens: `4 - 1 = 3`.

`t=3.0s`: elapsed since last update = `3.0 - 1.5 = 1.5s` → refill = `1.5 * 2 = 3` → tokens = `min(6, 3 + 3) = 6`. Four requests arrive:
- Request 1: tokens `6 → 5` → **ALLOW**
- Request 2: tokens `5 → 4` → **ALLOW**
- Request 3: tokens `4 → 3` → **ALLOW**
- Request 4: tokens `3 → 2` → **ALLOW**

**All 10 requests across the whole trace are ALLOW.** Total tokens remaining at t=3.0s: `2`.

**Why this matters:** notice the refill is capped at `capacity` (6) even though mathematically more tokens "should" have accumulated if capacity were unbounded — at `t=3.0s`, `3 (prior) + 3 (refill) = 6` exactly hits the cap, but if the gap had been longer (say 5s idle), the raw refill math (`3 + 2*5=10`) is still clamped to 6, not 10. This clamp is what prevents a client that's been idle for a long time from banking an unbounded number of tokens and unleashing a massive burst — the burst allowance is always bounded by `capacity`, never by how long the client was idle.
