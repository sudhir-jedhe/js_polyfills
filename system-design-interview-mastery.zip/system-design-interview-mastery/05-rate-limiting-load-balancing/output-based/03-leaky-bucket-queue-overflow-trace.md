# Output: Leaky Bucket Queue Behavior Under Burst

```
Leaky bucket (queue form): capacity = 4, leak rate = 1 request/sec, queue starts empty

t=0.0s: 6 requests arrive simultaneously
t=1.0s, 2.0s, 3.0s, ...: leak fires once per second, processing the head of the queue
```

**Question:** Which of the 6 requests are accepted into the queue vs. rejected outright, and at what wall-clock time is the last accepted request actually *processed*?

**Answer:**

At `t=0.0s`, the queue has capacity 4 and is empty. Requests are enqueued in arrival order until full:
- Request 1 → enqueued (queue: [1])
- Request 2 → enqueued (queue: [1,2])
- Request 3 → enqueued (queue: [1,2,3])
- Request 4 → enqueued (queue: [1,2,3,4]) — **queue now full**
- Request 5 → **REJECTED** (queue full)
- Request 6 → **REJECTED** (queue full)

Processing (leak) then drains one per second:
- `t=1.0s`: process request 1
- `t=2.0s`: process request 2
- `t=3.0s`: process request 3
- `t=4.0s`: process request 4 (the last accepted request)

**Answer: requests 1–4 accepted (2 rejected outright), and the last accepted request isn't actually processed until `t=4.0s` — 4 full seconds after it arrived**, even though it was "accepted" at `t=0.0s`.

**Why this is the defining leaky-bucket behavior:** contrast with token bucket, where an accepted request is processed **immediately** (it just consumes a token) — there's no queueing delay. Leaky bucket's "acceptance" only guarantees the request *will* be processed at some point at the fixed leak rate; it deliberately does not guarantee immediate processing, which is exactly the smoothing behavior that makes it suitable for protecting a downstream system that can only sustain a strictly constant throughput.
