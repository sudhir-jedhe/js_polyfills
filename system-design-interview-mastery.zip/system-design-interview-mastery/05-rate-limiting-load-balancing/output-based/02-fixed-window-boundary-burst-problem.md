# Output: Fixed Window Counter at a Boundary

```
Fixed window counter: limit = 50 requests per 30-second window, windows aligned to :00 and :30

Traffic pattern:
  50 requests arrive between 00:00:15 and 00:00:29
  50 requests arrive between 00:00:30 and 00:00:35
```

**Question:** How many total requests are allowed in the 20-second span from `00:00:15` to `00:00:35`? Is this compliant with a "50 requests per any 30 seconds" requirement?

**Answer:** All 100 requests are **ALLOWED**.

- The first 50 requests (`00:00:15`–`00:00:29`) fall in window `[00:00:00, 00:00:29]`. Counter for that window reaches exactly 50 → all allowed, right at the limit.
- At `00:00:30`, the window rolls over to `[00:00:30, 00:00:59]` and the counter resets to 0.
- The next 50 requests (`00:00:30`–`00:00:35`) fall in the new window, counter goes `0 → 50` → all allowed.

**Total: 100 requests allowed in a 20-second span**, double the stated "50 per 30 seconds" intent. This is the boundary burst problem in its exact numeric form: the algorithm enforces "50 per *aligned* window," which is a materially weaker guarantee than "50 per *any* 30-second span." A client aware of the window alignment could deliberately time bursts around `:00`/`:30` boundaries to sustain roughly double the intended rate indefinitely.

**Fix:** switching to sliding window counter or sliding window log would cap this — under sliding window log, evaluating the true trailing 30s window at `00:00:35` would count all requests from `00:00:05` onward, correctly seeing 100 requests against a limit of 50 and rejecting the second batch once the running count crosses 50.
