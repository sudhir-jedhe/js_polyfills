# Scenario: Add Rate Limiting to a Public API Gateway

**Scenario:** Your company's REST API is public, served through an API gateway in front of ~40 stateless app server instances. A few abusive clients have been hammering endpoints hard enough to degrade latency for everyone else. You're asked to add rate limiting. What do you build?

**Diagnosis:** Two requirements are in tension: (1) it must work correctly across 40 instances (any single-instance in-memory counter is trivially bypassed — the client just gets `limit * 40` effective throughput by hitting different instances), and (2) it must add negligible latency to every single request, since it now sits in the hot path of 100% of traffic.

**Design:**

1. **Algorithm choice — token bucket.** Public API traffic is naturally bursty (a client legitimately fires several requests when a user opens a dashboard), so a burst-tolerant algorithm is the right fit — token bucket over leaky bucket. Sliding window log is ruled out for a general-purpose high-limit API tier (memory scales with request volume); token bucket is `O(1)` space and time.

2. **Enforcement point — the gateway, not each app server.** Centralizing the check at the gateway means abusive requests are rejected with `429` before ever reaching an app server, protecting compute capacity from the abuse entirely, and it's a single place to change policy (per-tier limits, emergency overrides) without redeploying 40 services.

3. **Shared state — Redis**, holding one hash per rate-limit key (`ratelimit:{apiKey}`) with `tokens` and `timestamp` fields, updated atomically via a Lua script (see `snippets/03-redis-lua-atomic-rate-limiter.md`) so concurrent requests from the same client landing on different gateway instances can't race past the limit.

4. **Rate limit key — per API key**, not per IP: multiple legitimate users can share an IP (corporate NAT, mobile carrier NAT), and a single malicious actor can rotate IPs trivially, so IP alone is both under- and over-inclusive. API key ties the limit to the actual billing/identity boundary.

5. **Response contract:** `429 Too Many Requests` with `Retry-After`, `X-RateLimit-Limit`, `X-RateLimit-Remaining`, `X-RateLimit-Reset` headers, so well-behaved SDKs can self-throttle instead of hammering the gateway with retries.

6. **Failure mode for Redis unavailability — fail open.** A rate limiter's purpose is protecting the system from overload; if the limiter itself becomes unavailable, rejecting 100% of legitimate traffic (fail closed) is a worse outage than temporarily allowing unrestricted traffic through. Pair this with a lightweight local in-memory fallback limiter on each gateway instance as a degraded-mode safety net rather than truly unlimited pass-through.

7. **Tiering:** different limits per subscription plan (free: 100/min, pro: 5,000/min) is just a different `capacity`/`refillRate` pair looked up per API key — no algorithmic change needed, which is a nice property of the token bucket parameterization.

**Result:** a single Redis-backed, gateway-level token bucket limiter, keyed per API key, atomically enforced via Lua, fails open under Redis outage, and requires zero coordination logic in the 40 app servers themselves — they simply never see traffic that's already been rejected.
