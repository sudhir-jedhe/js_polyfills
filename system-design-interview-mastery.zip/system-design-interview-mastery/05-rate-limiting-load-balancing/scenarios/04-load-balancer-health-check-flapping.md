# Scenario: Health Check Flapping Amplifies an Outage

**Scenario:** A load balancer sits in front of 6 backend servers, running active health checks every 5 seconds with an unhealthy threshold of 1 failure and a healthy threshold of 1 success. During a traffic spike, one server's health check probe occasionally times out (it's just momentarily busy, not actually broken) — the LB immediately pulls it from rotation, which pushes its share of traffic onto the remaining 5, which makes one of *those* momentarily slow too, and within two minutes servers are cycling in and out of rotation constantly. Overall error rate is now far worse than if nothing had been removed at all.

**Diagnosis:** This is classic **flapping** caused by an overly aggressive health check configuration, and it's a self-reinforcing failure cascade: `threshold=1` means a single transient blip (one slow response under momentary load, not an actual failure) is treated identically to a genuinely dead server. Removing a healthy-but-momentarily-slow server doesn't fix anything — it makes the underlying cause (too much total load for current capacity) worse by concentrating that same load onto fewer servers, which manufactures the next false-positive failure.

**Fix — decouple "briefly slow" from "actually down" using thresholds and check design:**

1. **Raise the unhealthy threshold, keep the healthy threshold lower (asymmetric by design).** E.g., unhealthy threshold = 3 consecutive failures (requires sustained failure, not one blip) but healthy threshold = 2 consecutive successes (doesn't require an extended "prove yourself" period to rejoin). This asymmetry means a server needs to be *persistently* bad to be removed, but is welcomed back reasonably quickly once it recovers — avoiding both false removal and slow re-admission.

2. **Increase the health check timeout to something realistic under load**, not the fastest possible response time observed in ideal conditions — if p99 response time under real traffic is 800ms, a 200ms health check timeout will misclassify normal tail latency as failure.

3. **Add passive health checking alongside active probing.** Passive checks (observing real request outcomes, not a synthetic probe) avoid the specific pathology where the *probe itself* is a poor proxy for real request health — a dedicated `/health` endpoint that does nothing but return `200 OK` can stay fast even while the real request-serving path is degraded, or vice versa; correlating both signals is more robust than either alone.

4. **Add a circuit breaker / gradual traffic shifting instead of binary in/out.** Rather than a server being either "fully in rotation" or "fully removed," a load balancer that can shift traffic gradually (e.g., reduce a struggling server's effective weight rather than zeroing it) avoids the discrete, all-or-nothing jump that concentrates load onto the remaining fleet all at once.

5. **Separately, address the root cause:** if a normal traffic spike is enough to push any single server into occasional slow responses, the fleet is under-provisioned for its actual peak load — the health check tuning fixes the *symptom* (flapping), but capacity planning (autoscaling thresholds, base fleet size) is the fix for the *cause*.

**Takeaway:** health check parameters (interval, timeout, thresholds) are not a "set once" detail — an overly sensitive configuration turns transient, self-correcting blips into a cascading capacity failure, which is often worse than doing nothing. The asymmetric-threshold pattern (slow to remove, faster to re-admit) is the standard defense.
