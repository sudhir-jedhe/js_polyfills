# Scenario: Synchronized Retry Storm at Every Window Reset

**Scenario:** A fixed-window rate limiter resets at the top of every minute. Clients that get `429 Too Many Requests` all implement a naive retry: "wait until the window resets, then retry immediately." Because the window boundary is the same wall-clock instant for every client, at `:00` of every minute a huge fraction of previously-rejected clients retry simultaneously, producing a sharp traffic spike right at the boundary that's worse than steady load — sometimes bad enough to blow through the limit again instantly and get rate limited again, repeating the pattern every minute.

**Diagnosis:** This is a **thundering herd**, caused by two compounding design choices: (1) a rate limiter with a *predictable, globally synchronized* reset instant, and (2) clients whose retry strategy has no randomization, so they all converge on that exact instant. Neither piece alone is fatal — a synchronized reset with well-behaved jittered clients is fine, and unsynchronized retries against a fixed reset would spread out naturally — it's the combination that manufactures a recurring spike.

**Fix — address both sides:**

**Server side:**
1. **Move off fixed-window if the reset-boundary synchronization itself is the problem.** Sliding window counter/log has no single global "everyone resets now" instant — a client's own limit replenishes relative to *its own* request history, not a shared clock boundary, which structurally removes the synchronization point.
2. **If staying on token bucket (which many systems prefer for burst tolerance), the "boundary" problem mostly disappears already** — tokens refill continuously rather than in a discrete reset event, so there's no single instant where a herd of clients simultaneously becomes eligible again. This scenario is specifically a fixed-window pathology.
3. **Return `Retry-After` with a jittered value**, not just "seconds until the raw window boundary" — e.g., `Retry-After: <base + random(0, spread)>` so even clients that retry exactly on the header's instruction don't all pick the identical instant.

**Client side:**
4. **Exponential backoff with jitter** on the client SDK: instead of "retry immediately when allowed," retry after `min(cap, base * 2^attempt) * random(0.5, 1.5)`. This is the standard fix for any synchronized-retry thundering herd, not specific to rate limiting — the same pattern applies to service-outage recovery storms.
5. **Respect the `Retry-After` header exactly rather than polling on a fixed client-side interval** — a client polling "check every 5 seconds regardless of what the server said" reintroduces its own synchronization risk across many client instances that all started at similar times.

**Takeaway:** rate limiter design and client retry behavior are coupled — a limiter that resets at a predictable global instant is only safe if clients are guaranteed to jitter their retries, and since you can't always control third-party client behavior, preferring an algorithm without a hard synchronized reset boundary (token bucket, sliding window) is the more robust default specifically because it removes the failure mode at the source rather than relying on well-behaved clients.
