# Snippet: Atomic Token Bucket in Redis via Lua

Token bucket logic executed as a single atomic Redis operation — safe under concurrent requests from many app server instances, since Lua scripts run to completion without interleaving other clients' commands.

```lua
-- rate_limiter.lua
-- KEYS[1]   = bucket key, e.g. "ratelimit:user:12345"
-- ARGV[1]   = capacity (max tokens)
-- ARGV[2]   = refill rate (tokens per second)
-- ARGV[3]   = current unix time in milliseconds
-- ARGV[4]   = tokens requested (usually 1)

local capacity   = tonumber(ARGV[1])
local refillRate = tonumber(ARGV[2])
local now        = tonumber(ARGV[3])
local requested  = tonumber(ARGV[4])

local bucket = redis.call("HMGET", KEYS[1], "tokens", "timestamp")
local tokens = tonumber(bucket[1])
local lastRefill = tonumber(bucket[2])

if tokens == nil then
  tokens = capacity
  lastRefill = now
end

local elapsedSeconds = math.max(0, (now - lastRefill) / 1000)
tokens = math.min(capacity, tokens + elapsedSeconds * refillRate)

local allowed = 0
if tokens >= requested then
  tokens = tokens - requested
  allowed = 1
end

redis.call("HMSET", KEYS[1], "tokens", tokens, "timestamp", now)
redis.call("EXPIRE", KEYS[1], math.ceil(capacity / refillRate) * 2) -- cleanup safety net

return allowed
```

Calling it from a Node.js app server via `ioredis`:

```js
const fs = require("fs");
const script = fs.readFileSync("rate_limiter.lua", "utf8");

async function isAllowed(redis, userId, capacity = 10, refillRate = 5) {
  const result = await redis.eval(
    script,
    1,                    // number of KEYS
    `ratelimit:user:${userId}`,
    capacity,
    refillRate,
    Date.now(),
    1                     // tokens requested
  );
  return result === 1;
}
```

Because the entire read-compute-write sequence happens inside the Lua script, no other request (from any app server) can read a stale `tokens` value between the check and the update — this eliminates the check-then-act race condition described in `theory/06-distributed-rate-limiting-redis.md`.
