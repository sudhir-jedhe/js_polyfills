# Snippet: In-Memory Token Bucket

A self-contained, dependency-free token bucket suitable for a single-instance service or as the reference implementation to port to Redis Lua.

```js
class TokenBucket {
  constructor(capacity, refillRatePerSecond) {
    this.capacity = capacity;
    this.refillRate = refillRatePerSecond;
    this.tokens = capacity;          // start full
    this.lastRefill = Date.now();
  }

  #refill() {
    const now = Date.now();
    const elapsedSeconds = (now - this.lastRefill) / 1000;
    this.tokens = Math.min(this.capacity, this.tokens + elapsedSeconds * this.refillRate);
    this.lastRefill = now;
  }

  tryConsume(tokens = 1) {
    this.#refill();
    if (this.tokens >= tokens) {
      this.tokens -= tokens;
      return true; // ALLOW
    }
    return false;  // REJECT
  }
}

// --- usage ---
const bucket = new TokenBucket(10, 5); // capacity 10, refills 5/sec

for (let i = 0; i < 12; i++) {
  console.log(`request ${i + 1}:`, bucket.tryConsume() ? "ALLOW" : "REJECT");
}
// requests 1-10 -> ALLOW (bucket starts full)
// requests 11-12 -> REJECT (bucket empty, no time has passed to refill)
```

One bucket instance per rate-limited entity (per user ID, per API key, per IP) — store these in a `Map<entityId, TokenBucket>` for a single-process limiter, or port the `#refill`/`tryConsume` logic into a Redis Lua script for a distributed one (see `06-distributed-rate-limiting-redis.md` in `theory/`).
