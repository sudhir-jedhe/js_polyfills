# Snippet: NGINX as an L7 Load Balancer

Config showing round robin (default), weighted, least-connections, and IP-hash upstream strategies, plus active health checks — the four algorithms most likely to come up, expressed the way they actually appear in production config.

```nginx
# --- Round robin (the default when no directive is given) ---
upstream backend_round_robin {
  server 10.0.1.10:8080;
  server 10.0.1.11:8080;
  server 10.0.1.12:8080;
}

# --- Weighted round robin: server .10 gets 3x the traffic of the others ---
upstream backend_weighted {
  server 10.0.1.10:8080 weight=3;
  server 10.0.1.11:8080 weight=1;
  server 10.0.1.12:8080 weight=1;
}

# --- Least connections: routes to whichever backend has fewest active connections ---
upstream backend_least_conn {
  least_conn;
  server 10.0.1.10:8080;
  server 10.0.1.11:8080;
}

# --- IP hash: same client IP always routes to the same backend (sticky sessions) ---
upstream backend_ip_hash {
  ip_hash;
  server 10.0.1.10:8080;
  server 10.0.1.11:8080;
}

server {
  listen 443 ssl;                 # L7: terminates TLS here, can inspect the HTTP request
  server_name api.example.com;

  location /api/ {
    proxy_pass http://backend_least_conn;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;

    # passive health check: mark a server down after 3 failed attempts within 30s
    proxy_next_upstream error timeout http_502 http_503;
    proxy_connect_timeout 2s;
  }

  location /static/ {
    proxy_pass http://cdn_origin;  # L7 content-based routing by path — impossible at L4
  }
}
```

The `location /static/` block is the clearest illustration of why this is an **L7** load balancer: routing by URL path requires parsing the HTTP request, which means terminating the connection — an L4 balancer forwarding raw TCP packets by IP/port alone has no concept of "the request path" at all.
