# Snippet: Rate Limiting Middleware in an Express App

A practical wrapper showing where a rate limiter plugs into a real request pipeline, including the standard response headers clients rely on to self-throttle.

```js
function rateLimitMiddleware(limiter, { keyFn = (req) => req.ip } = {}) {
  return async function (req, res, next) {
    const key = keyFn(req);
    const { allowed, remaining, resetAtMs } = await limiter.check(key);

    // standard-ish headers so well-behaved clients can back off proactively
    res.set("X-RateLimit-Limit", String(limiter.limit));
    res.set("X-RateLimit-Remaining", String(Math.max(0, remaining)));
    res.set("X-RateLimit-Reset", String(Math.ceil(resetAtMs / 1000)));

    if (!allowed) {
      const retryAfterSeconds = Math.ceil((resetAtMs - Date.now()) / 1000);
      res.set("Retry-After", String(retryAfterSeconds));
      return res.status(429).json({
        error: "rate_limit_exceeded",
        message: `Too many requests. Retry after ${retryAfterSeconds}s.`,
      });
    }
    next();
  };
}

// --- wiring it up ---
const express = require("express");
const app = express();

// per-user limiting for authenticated routes, falling back to per-IP for anonymous ones
app.use(
  "/api",
  rateLimitMiddleware(apiLimiter, {
    keyFn: (req) => req.user?.id ?? `ip:${req.ip}`,
  })
);

app.get("/api/profile", (req, res) => res.json({ ok: true }));
```

Key points this demonstrates: rate limiting runs as **middleware before the route handler**, so a rejected request never touches business logic; the `429 Too Many Requests` status code plus `Retry-After` header is the standard contract clients (and load-testing tools) expect; and the key function is pluggable — per-user when authenticated, per-IP as a fallback (see `scenarios/02-per-user-vs-per-ip-rate-limiting-behind-nat.md` for why that fallback needs care).
