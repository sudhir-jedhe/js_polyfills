# Snippet: Sliding Window Counter

`O(1)` space, approximates a true rolling window by weighting the previous fixed window's count.

```js
class SlidingWindowCounter {
  constructor(limit, windowSizeMs) {
    this.limit = limit;
    this.windowSizeMs = windowSizeMs;
    this.currentWindowStart = 0;
    this.currentCount = 0;
    this.previousCount = 0;
  }

  #rotateIfNeeded(now) {
    const windowIndex = Math.floor(now / this.windowSizeMs);
    const windowStart = windowIndex * this.windowSizeMs;
    if (windowStart !== this.currentWindowStart) {
      // how many windows have elapsed since we last rotated?
      const windowsElapsed = (windowStart - this.currentWindowStart) / this.windowSizeMs;
      this.previousCount = windowsElapsed === 1 ? this.currentCount : 0;
      this.currentCount = 0;
      this.currentWindowStart = windowStart;
    }
  }

  tryRequest(now = Date.now()) {
    this.#rotateIfNeeded(now);
    const elapsedInCurrent = now - this.currentWindowStart;
    const weight = 1 - elapsedInCurrent / this.windowSizeMs;
    const estimated = this.currentCount + this.previousCount * weight;

    if (estimated < this.limit) {
      this.currentCount += 1;
      return true; // ALLOW
    }
    return false;   // REJECT
  }
}

// --- usage: limit 5 per 1000ms window ---
const limiter = new SlidingWindowCounter(5, 1000);
console.log(limiter.tryRequest(0));    // true, currentCount=1
console.log(limiter.tryRequest(200));  // true, currentCount=2
// ...simulate previous window having had 4 requests, now 300ms into new window:
// estimated = currentCount + 4 * (1 - 300/1000) = currentCount + 2.8
```

Note the estimate uses `<` against `limit`, not `<=`, and is a **float**, not an integer — this is expected; the whole point of the algorithm is a smoothed approximation rather than an exact count.
