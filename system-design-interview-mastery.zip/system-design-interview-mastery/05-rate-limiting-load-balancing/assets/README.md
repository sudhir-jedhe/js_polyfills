Diagrams and reference images for rate limiting & load balancing (e.g. algorithm comparison charts, distributed rate limiter architecture diagrams) will be added here.
