# Leaky Bucket Algorithm

Leaky bucket is the algorithm to reach for when the requirement is a **smooth, constant outbound rate** rather than "average rate over time with bursts allowed" — think of it as token bucket's stricter sibling.

## Mechanism (as a queue)

Model the bucket as a FIFO queue of fixed size `capacity`. Requests enter the queue when they arrive; a worker processes (drains/"leaks") requests from the queue at a **fixed rate** `r` requests/second, regardless of how bursty the arrivals were:

- Request arrives → if queue has room, enqueue it (it will be processed later, not immediately); if queue is full, **reject**.
- Every `1/r` seconds, dequeue and process exactly one request (if any are waiting).

```
capacity = 5, leak rate = 2 req/sec

t=0.0s: 8 requests arrive at once → 5 enqueued, 3 rejected (queue full)
t=0.0s: leak fires → 1 request processed, queue has 4
t=0.5s: leak fires → 1 request processed, queue has 3
t=1.0s: leak fires → 1 request processed, queue has 2
...output rate is a constant 2 req/sec no matter how bursty the input was
```

## Leaky bucket vs. token bucket — the key distinction

This is the single most-tested comparison in rate-limiting interviews, and it's easy to get backwards:

| | Token Bucket | Leaky Bucket |
|---|---|---|
| What's fixed | The **refill** rate (tokens added) | The **outflow/processing** rate |
| Bursts | Allowed, up to `capacity`, processed **instantly** | Smoothed — queued requests are processed at a steady drip, never instantly |
| Output rate | Can spike above `r` momentarily (bursty) | Constant `r`, always |
| Typical use | API rate limiting where you want to allow bursts but bound the average | Traffic shaping before a fixed-capacity downstream (e.g., feeding a legacy system that can only handle N req/sec, or network packet shaping) |
| Rejected traffic | Rejected outright if no tokens | Rejected outright if queue full; but **accepted** traffic is delayed, not instant |

The mental shortcut: token bucket controls *how much can go out at once* (burst-friendly); leaky bucket controls *how fast things go out, period* (burst-hostile, smoothing).

## Without a queue (counter-based leaky bucket)

A lighter-weight variant tracks just a "water level" that decays over time instead of literally queueing requests — functionally equivalent to token bucket's complement:

```
state = { level: 0, lastLeakTimestamp: now() }

on request:
  elapsed = now() - state.lastLeakTimestamp
  state.level = max(0, state.level - elapsed * leakRate)
  state.lastLeakTimestamp = now()
  if state.level + 1 <= capacity:
    state.level += 1
    return ALLOW
  else:
    return REJECT
```

This version rejects instead of queuing/delaying — it's used when you want leaky bucket's smoothing *ceiling* without literally holding requests in memory.

## Complexity and tradeoffs

| Aspect | Value |
|---|---|
| Time per check | `O(1)` |
| Space | `O(1)` for the counter variant; `O(capacity)` if literally queueing |
| Burst support | No — this is the point |
| Output smoothness | Perfectly constant rate |

**Con:** legitimate bursty traffic gets throttled/delayed even when the *average* rate is well within budget — a client sending 10 requests in one second then going idle for 9 seconds (average 1 req/sec) gets queued/delayed under leaky bucket even though token bucket would let all 10 through instantly. Choose leaky bucket specifically when downstream cannot tolerate instantaneous bursts at all (e.g., protecting a rate-sensitive hardware interface or a strict per-second SLA with a third party), not as a default rate limiter for a public API.
