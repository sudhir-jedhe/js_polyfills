# Sliding Window Counter

Sliding window counter is the pragmatic middle ground the industry actually converges on for high-throughput rate limiting (this is essentially what Cloudflare and many API gateways implement): it gets `O(1)` space like fixed window, while approximating the accuracy of sliding window log closely enough in practice.

## Mechanism

Keep two fixed-window counters: the **current** window's count and the **previous** window's count (exactly like fixed window counter, just retaining one extra window). Estimate the rolling-window count as a **weighted combination** of the two:

```
estimated_count = current_window_count
                 + previous_window_count * (fraction of previous window still "inside" the rolling window)
```

The weight for the previous window is `1 - (elapsed time into current window / windowSize)` — i.e., the further you are into the current window, the less the previous window's count is weighted, because less of it is still "inside" the trailing `windowSize`-length interval.

```
windowSize = 60s, limit = 100

previous window [12:00:00–12:00:59]: count = 80
current window  [12:01:00–12:01:59]: count = 30 so far
request arrives at 12:01:15 (15s into current window → 25% through it)

weight for previous window = 1 - (15/60) = 0.75
estimated_count = 30 + 80 * 0.75 = 30 + 60 = 90

90 < 100 → ALLOW
```

## Why this is only an approximation (and why that's usually fine)

The weighting assumes requests are **uniformly distributed** within the previous window, which isn't necessarily true — the real count of "requests in the true trailing 60s" could differ from the estimate if the previous window's 80 requests were clustered right at its very end (closer to the true sliding-log answer) vs. spread evenly. In practice this error is small and bounded, and Cloudflare's own published analysis found the approximation keeps the effective limit within roughly 0.003% of exact enforcement under typical traffic patterns — good enough that essentially no real system pays sliding-log's `O(n)` memory cost to close that last fraction of a percent.

## Complexity and footprint

| Aspect | Value |
|---|---|
| Time per check | `O(1)` |
| Space per entity | `O(1)` — exactly two counters (current + previous window) |
| Accuracy | Approximate, but tightly bounded and good in practice |
| Boundary burst problem | Effectively solved — a burst spanning the boundary is caught by the weighted previous-window contribution, unlike plain fixed window |

## Full comparison across all five algorithms

| Algorithm | Space / entity | Time / check | Burst behavior | Boundary accuracy |
|---|---|---|---|---|
| Token bucket | `O(1)` | `O(1)` | Allows bursts up to capacity | N/A (not window-based) |
| Leaky bucket | `O(1)` (counter form) | `O(1)` | Smooths to constant rate, no bursts | N/A (not window-based) |
| Fixed window counter | `O(1)` | `O(1)` | Uncontrolled — up to 2x limit at boundary | Poor |
| Sliding window log | `O(n)` requests in window | `O(log n)` | Exact | Perfect |
| Sliding window counter | `O(1)` | `O(1)` | Tightly bounded approximation | Very good, not perfect |

This table is the single most valuable thing to have memorized cold for a rate-limiting deep-dive — it's very common to be asked to fill in exactly this comparison live, including the space complexity distinction between log (`O(n)`) and counter (`O(1)`) variants.
