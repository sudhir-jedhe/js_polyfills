# Sliding Window Log

Sliding window log is the algorithm that fixes fixed-window's boundary burst problem **exactly** — it's the "ground truth" precise algorithm, at the cost of memory.

## Mechanism

Store a timestamp for every request (typically in a sorted set / list per entity). On each new request:

1. Drop all stored timestamps older than `now - windowSize` (they've fallen out of the rolling window).
2. Count what remains.
3. If count `< limit`, allow and record this request's timestamp; otherwise reject.

```
limit = 3 per 60s window

request log for user X: [12:00:05, 12:00:40, 12:00:55]
new request at 12:01:10:
  drop entries older than 12:01:10 - 60s = 12:00:10  →  12:00:05 is dropped
  remaining: [12:00:40, 12:00:55]  → count = 2 < 3 → ALLOW, log now [12:00:40, 12:00:55, 12:01:10]
```

Because the window boundary is computed relative to `now` on every single request (a true rolling window, not a clock-aligned bucket), it is **mathematically exact** — no boundary-doubling is possible, ever.

## Redis implementation shape

A Redis sorted set (`ZSET`) keyed per entity, with the timestamp as both member and score, is the canonical implementation:

```
ZREMRANGEBYSCORE key -inf (now - windowSize)   # evict expired entries
ZCARD key                                       # current count
if count < limit:
  ZADD key now now                              # record this request
  EXPIRE key windowSize                         # cleanup safety net
  ALLOW
else:
  REJECT
```

## Complexity and footprint

| Aspect | Value |
|---|---|
| Time per check | `O(log n)` for the sorted-set insert/evict (`n` = requests currently in window) |
| Space per entity | `O(n)` — one entry **per request** within the window, not `O(1)` |
| Accuracy | Exact — no boundary burst possible |
| Cost at scale | Grows with traffic volume, not fixed — a high-limit, high-traffic entity (e.g., limit = 10,000/min) stores up to 10,000 timestamps per window, per entity |

## Tradeoffs

- **Pro:** perfectly precise; conceptually simple to justify to a reviewer ("we literally count requests in the true trailing window").
- **Con:** memory scales linearly with the request volume within the window, which is the whole reason sliding window *counter* (the next algorithm) exists — it approximates this same rolling-window behavior in `O(1)` space by trading a small, bounded amount of precision. Sliding window log is the right choice when you need exact enforcement and the per-entity limit is low enough that the timestamp list stays small (e.g., "5 login attempts per 15 minutes"); it's the wrong choice for a high-throughput API gateway limiting at 50,000 req/min per key.
