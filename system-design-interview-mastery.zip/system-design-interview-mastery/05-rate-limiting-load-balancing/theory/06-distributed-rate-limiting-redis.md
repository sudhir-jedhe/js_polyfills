# Distributed Rate Limiting with Redis

A rate limiter that only tracks state on one server instance breaks the moment you run more than one instance behind a load balancer: a client can get `limit` requests allowed *per instance*, effectively multiplying the real limit by the number of instances. Distributed rate limiting solves this by centralizing the counter state.

## Why a shared, fast, atomic store is required

Requests from the same client can land on any of N app servers. For the limit to hold globally, every instance must read and update the **same** counter. This requires:

1. **Shared storage** — not in-process memory. Redis is the standard choice: sub-millisecond latency, built-in TTL/expiry, and (critically) atomic operations.
2. **Atomicity** — "read count, check against limit, increment" must happen as one indivisible operation. Without atomicity, two concurrent requests on two different app servers can both read `count = 99` (limit 100), both decide to allow, and both increment to 100 — letting through one more request than the limit permits (a classic race condition / check-then-act bug).

## The race condition, concretely

```
Server A: GET count → 99         Server B: GET count → 99
Server A: 99 < 100 → ALLOW       Server B: 99 < 100 → ALLOW
Server A: INCR count → 100       Server B: INCR count → 100
```
Both requests were allowed based on stale reads of the same value — the limit of 100 was never actually enforced as a hard ceiling; 101 requests got through (or worse, under higher concurrency, far more) because the check and the increment were two separate round-trips.

## Fix: atomic operations via Lua scripting

Redis executes a Lua script as a single atomic operation — no other client's commands can interleave mid-script. This is the standard way to implement any of the algorithms (token bucket, sliding window counter, etc.) correctly under concurrency:

```lua
-- KEYS[1] = rate limit key, ARGV[1] = limit, ARGV[2] = window (seconds)
local current = redis.call("INCR", KEYS[1])
if current == 1 then
  redis.call("EXPIRE", KEYS[1], ARGV[2])
end
if current > tonumber(ARGV[1]) then
  return 0  -- REJECT
else
  return 1  -- ALLOW
end
```
`INCR` itself is already atomic in Redis, but the surrounding "set TTL only on first increment" logic must be bundled with it atomically too, which is exactly what wrapping it in a Lua script guarantees — this is a fixed-window implementation; the token-bucket and sliding-window-counter algorithms follow the same pattern (do the read-modify-write inside one Lua script).

## Where to put the rate limiter architecturally

| Placement | Pro | Con |
|---|---|---|
| API Gateway / edge (e.g., Kong, Envoy, custom gateway) | Single choke point, rejects before hitting app servers, protects everything behind it uniformly | Extra network hop to Redis on every request; gateway becomes a dependency for all traffic |
| Middleware in each app server | Simple to add per-service | Every service must independently integrate with the shared store; easy for one service to be misconfigured/inconsistent |
| Sidecar / service mesh proxy | Decouples limiting logic from app code | Operational complexity of running a mesh |

The API gateway placement is the most common answer expected in a "design a rate limiter" interview, specifically because it centralizes the decision and avoids requests wastefully reaching app servers just to be rejected.

## Scaling the store itself: hot key problem

A single extremely popular key (e.g., a shared API key used by a huge customer, or a global "IP: 0.0.0.0 catch-all" bug) can turn one Redis key into a hotspot even though Redis overall is horizontally scaled via Cluster/sharding — every request for that one entity must serialize through the same shard. Mitigations: shard a single logical counter into N sub-counters (e.g., hash `(entityId, requestId) % N`) and sum them, accepting slightly relaxed precision, or use local in-memory pre-filtering at each app server (allow obviously-fine requests locally, only consult Redis near the limit) to cut the volume of Redis round-trips for hot keys.

## Latency and failure-mode considerations

- **Latency:** every request now pays a Redis round-trip (~sub-millisecond typically, but non-zero and it's in the critical path). Pipelining/batching and colocating Redis close to the gateway keeps this negligible.
- **Redis unavailable:** decide explicitly whether to **fail open** (allow all requests when Redis is down — availability over strict enforcement) or **fail closed** (reject all requests — protects downstream at the cost of availability). Fail-open is the common default for rate limiters specifically, since a rate limiter's job is to protect the system from overload, not to be a security boundary — an outage in the limiter itself shouldn't take down otherwise-healthy service. (Auth/authorization checks, by contrast, almost always fail closed.)
