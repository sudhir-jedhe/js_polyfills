# Load Balancing Algorithms, L4 vs. L7, and Health Checks

## Load balancing algorithms

| Algorithm | How it picks a server | Best for | Weakness |
|---|---|---|---|
| **Round robin** | Cycles through the server list in order, one request each | Servers with roughly equal capacity and roughly equal per-request cost | Ignores current load — a server still processing a slow request gets the next one anyway |
| **Weighted round robin** | Like round robin, but higher-weighted servers get proportionally more requests in the cycle (e.g., weights 3:1 → server A gets 3 requests for every 1 to server B) | Heterogeneous hardware (some servers genuinely more powerful) | Weight is static — doesn't adapt to real-time load either |
| **Least connections** | Routes to whichever server currently has the fewest active (in-flight) connections | Requests with variable/unpredictable processing time (long-polling, streaming, mixed light/heavy endpoints) | Requires the load balancer to track live connection counts per server (more state than round robin) |
| **Weighted least connections** | Least connections, adjusted by a capacity weight per server | Heterogeneous hardware **and** variable request cost combined | Most complex to tune correctly |
| **IP hash** | Hashes the client's IP (sometimes combined with port) to deterministically map it to the same backend server every time | Session affinity/"sticky sessions" without a shared session store — same client always lands on the same server | Uneven distribution if client IP distribution is skewed (e.g., many users behind one corporate NAT IP all hash to one server); rebalancing on server add/remove reshuffles many mappings unless consistent hashing is used |
| **Least response time** | Combines active connection count with observed average response time | Latency-sensitive traffic where "fewest connections" alone doesn't capture that a server has become slow | Needs continuous latency sampling, most operationally complex |

**Round robin vs. least connections** is the single most commonly asked pairwise comparison: round robin is blind to load and is fine only when request cost is roughly uniform; least connections actively balances by real-time load and is the better default whenever request duration varies meaningfully.

## L4 vs. L7 load balancing

This distinction is about **which OSI layer the load balancer makes its routing decision at**, and it changes what information is even available to route on.

| | L4 (Transport layer) | L7 (Application layer) |
|---|---|---|
| Decision based on | IP address + TCP/UDP port only | Full HTTP request — headers, cookies, URL path, method, body |
| Visibility into payload | None — forwards packets without inspecting/terminating the application protocol | Full — terminates the HTTP connection, can read/rewrite request and response |
| Routing examples | "Forward all traffic on port 443 to this pool" | "Route `/api/*` to the API service, `/static/*` to the CDN, route based on `Cookie: session=...`" |
| Performance | Faster, lower overhead — no need to parse HTTP, often can operate at near line-rate | Slower per-request — must terminate TCP/TLS and parse the HTTP request |
| SSL/TLS | Typically passes through encrypted (or terminates TCP only) | Commonly terminates TLS at the load balancer (offloading encryption from app servers) |
| Use case | High-throughput, protocol-agnostic load balancing (e.g., raw TCP services, or as the outer layer in front of an L7 balancer) | Content-based routing, A/B testing by header, canary releases by cookie, path-based microservice routing |
| Examples | AWS Network Load Balancer (NLB), plain TCP/IP-based hardware LBs | AWS Application Load Balancer (ALB), NGINX/HAProxy in HTTP mode, most API gateways |

The precise distinction to state clearly in an interview: **L4 load balancers cannot see the HTTP request at all** — they can't route based on URL path or headers because they never parse the application-layer payload; they only see IP/port. **L7 balancers must terminate the connection** to read the request, which is exactly why they can do smarter routing but cost more CPU per request. A common real architecture layers both: an L4 balancer (or DNS-based/anycast layer) spreads raw traffic across a fleet of L7 load balancers, which then do the content-aware routing.

## Health checks

Load balancers must stop routing to unhealthy backends, which requires continuously probing them.

- **Active health checks:** the load balancer itself periodically sends a probe request (e.g., `GET /health`) to each backend on an interval, and marks a server unhealthy after N consecutive failures (and healthy again after M consecutive successes — this asymmetry, e.g. 3 fails to mark down but 2 successes to mark back up, avoids flapping on a single blip).
- **Passive health checks:** the load balancer observes real traffic — if requests routed to a server start timing out or returning 5xx at an elevated rate, it's marked unhealthy without a dedicated probe. Lower overhead (no extra probe traffic) but slower to detect an issue with a low-traffic backend, and slower to detect an issue during a lull in real traffic.

**Key parameters to reason about:** check interval (how often), timeout (how long to wait for a response before counting it as a failure), unhealthy threshold (consecutive failures before removal), healthy threshold (consecutive successes before re-adding). Getting these wrong causes two opposite failure modes: too aggressive (short interval, low unhealthy threshold) → **flapping**, where a server briefly slow under normal load gets yanked in and out of rotation, amplifying load on the remaining servers; too lax (long interval, high threshold) → **slow failure detection**, where a genuinely dead server keeps receiving (and failing) requests for too long before removal.
