# Fixed Window Counter

The simplest rate-limiting algorithm to implement, and the one most likely to be found in a naive first implementation — important to know both how it works and *precisely* why it's flawed, since "explain the boundary burst problem" is a very common follow-up.

## Mechanism

Divide time into fixed-size windows (e.g., 1-minute windows aligned to the clock: `00:00–00:59`, `01:00–01:59`, ...). Keep a single counter per window per limited entity:

```
on request at time t:
  window = floor(t / windowSize)
  key = (entityId, window)
  count[key] += 1
  if count[key] <= limit:
    return ALLOW
  else:
    return REJECT
```

Counters for past windows can be dropped/expired (e.g., via Redis `EXPIRE` set to `windowSize`).

## The boundary burst problem (precise mechanism)

This is the critical flaw, and interviewers expect the exact numeric mechanism, not just "it's not accurate near boundaries":

Say the limit is 100 requests/minute, windows aligned to the minute boundary.

```
Window [00:00–00:59]: 100 requests arrive at 00:59:59 → all 100 allowed (window resets at 01:00)
Window [01:00–01:59]: 100 requests arrive at 01:00:00 → all 100 allowed (fresh counter)
```

**Result: 200 requests were allowed within a 1-second span** (`00:59:59` to `01:00:00`), even though the stated limit is 100 per **any** 60-second period. The algorithm only guarantees 100 per *aligned* window, not 100 per *any rolling* 60-second window — and that distinction is exactly what "fixed" vs. "sliding" means in this topic.

## Complexity and footprint

| Aspect | Value |
|---|---|
| Time per check | `O(1)` |
| Space per entity | `O(1)` — a single integer counter (plus a window-id or reliance on TTL expiry) |
| Accuracy | Poor at window boundaries — up to 2x the stated limit can pass through |
| Implementation simplicity | Highest of all five algorithms |

## When it's still a reasonable choice

Despite the boundary flaw, fixed window counter is still used in practice — e.g., "1000 requests per day" quota-style limits where a burst at the day boundary is inconsequential, or as a cheap coarse-grained secondary limiter layered underneath a more precise primary limiter. It's rarely the right choice as the *sole* limiter for anything where doubling the effective limit for a brief window is a real problem (e.g., protecting a login endpoint from brute force, or enforcing a strict per-second downstream capacity).
