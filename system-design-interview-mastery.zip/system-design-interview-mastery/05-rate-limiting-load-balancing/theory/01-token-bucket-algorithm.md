# Token Bucket Algorithm

The token bucket is the most commonly implemented rate-limiting algorithm in production systems (AWS API Gateway, Stripe's API, Google Cloud all use variants of it) because it naturally supports **bursts** while still enforcing a long-run average rate.

## Mechanism

A bucket holds up to `capacity` tokens. Tokens are added to the bucket at a fixed **refill rate** `r` tokens/second, up to the capacity ceiling (excess refill is discarded, not queued). Every incoming request must remove one token to proceed:

- If the bucket has ≥1 token, remove a token and **allow** the request.
- If the bucket is empty, **reject** (or queue) the request.

```
capacity = 10 tokens, refill rate = 5 tokens/sec

t=0s:  bucket=10, burst of 10 requests arrives → all 10 allowed, bucket=0
t=0s:  11th request arrives → rejected (bucket empty)
t=1s:  bucket refilled by 5 → bucket=5
t=1s:  5 requests arrive → all allowed, bucket=0
```

## Why it allows bursts

Unlike the leaky bucket (which smooths output to a constant rate), the token bucket lets accumulated tokens be spent instantly. If no requests arrive for 2 seconds at a 5 token/sec refill rate, up to `capacity` tokens (capped, not 10) are available to spend in a single instant — this is a deliberate design choice: it tolerates realistic bursty client behavior (a user opening an app and firing 8 requests at once) without rejecting legitimate traffic, as long as the *average* rate over time stays at or below `r`.

## Implementation shape

Two numbers per bucket suffice — no per-request timestamp history is needed:

```
state = { tokens: capacity, lastRefillTimestamp: now() }

on request:
  elapsed = now() - state.lastRefillTimestamp
  state.tokens = min(capacity, state.tokens + elapsed * refillRate)
  state.lastRefillTimestamp = now()
  if state.tokens >= 1:
    state.tokens -= 1
    return ALLOW
  else:
    return REJECT
```

This "lazy refill" (compute elapsed tokens on read instead of running a background timer) avoids needing a scheduled job per bucket, which matters enormously when you have millions of independent buckets (one per user/API key).

## Complexity and footprint

| Aspect | Value |
|---|---|
| Time per check | `O(1)` |
| Space per limited entity | `O(1)` — two numbers (tokens, timestamp) |
| Burst support | Yes, up to `capacity` |
| Precision | Exact (not approximated) |

## Tradeoffs

- **Pro:** `O(1)` memory and time, exact enforcement, natural burst tolerance, simple to reason about and parameterize (two knobs: capacity, refill rate).
- **Con:** the burst tolerance is also a con from an abuse-prevention angle — a client that has been idle can legitimately fire `capacity` requests instantly, which may be more than a downstream system can absorb in one instant even though it's within the "average rate" contract. This is why capacity is often set much lower than "however many requests we can technically survive," e.g. capacity = a few seconds' worth of the refill rate, not minutes' worth.
