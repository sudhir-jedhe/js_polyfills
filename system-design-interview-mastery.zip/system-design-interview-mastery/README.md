# System Design Interview Mastery

Covers both High-Level Design (backend/distributed systems) and Frontend System Design in one repo, since
they're increasingly asked together in senior frontend interviews. Same deep structure as the companion
repos: every topic is a folder of folders (`theory/`, `snippets/`, `output-based/`, `scenarios/`,
`interview-qa/`, `problems/`, `assets/`).

## Topics

| # | Topic | Folder |
|---|---|---|
| 01 | System Design Fundamentals & Scalability | [`01-system-design-fundamentals-scalability`](./01-system-design-fundamentals-scalability) |
| 02 | API Design & Real-Time Communication | [`02-api-design-realtime-communication`](./02-api-design-realtime-communication) |
| 03 | Caching Strategies | [`03-caching-strategies`](./03-caching-strategies) |
| 04 | Database Design & Scaling | [`04-database-design-scaling`](./04-database-design-scaling) |
| 05 | Rate Limiting & Load Balancing | [`05-rate-limiting-load-balancing`](./05-rate-limiting-load-balancing) |
| 06 | Frontend Architecture & Folder Structure | [`06-frontend-architecture-folder-structure`](./06-frontend-architecture-folder-structure) |
| 07 | Frontend Rendering & Performance | [`07-frontend-rendering-performance`](./07-frontend-rendering-performance) |
| 08 | Frontend State Management (architecture-level) | [`08-frontend-state-management`](./08-frontend-state-management) |
| 09 | Frontend Security | [`09-frontend-security`](./09-frontend-security) |
| 10 | Accessibility at Scale | [`10-accessibility-at-scale`](./10-accessibility-at-scale) |
| 11 | Offline Support & PWA | [`11-offline-support-pwa`](./11-offline-support-pwa) |
| 12 | Low-Level Design: Component Patterns | [`12-low-level-design-component-patterns`](./12-low-level-design-component-patterns) |
| 13 | HLD Case Studies (full walkthroughs) | [`13-hld-case-studies`](./13-hld-case-studies) |

## The centerpiece: `13-hld-case-studies/problems/`

Six full system design case studies, each run through requirements → estimation (with real numbers) → API →
data model → architecture → deep dive → bottlenecks: a URL shortener, a rate limiter service, a WhatsApp-style
chat app, a job portal, an e-commerce checkout flow, and a movie ticket booking system.

You already have real, runnable reference implementations for most of these — see
[`SOURCE-MAP.md`](./SOURCE-MAP.md), which points at `instagram/`, `whatsapp/`, `Job Portal/`, `Eccommerge/`,
`movie Ticketing/`, and `Url Shortner/` in your `js_polyfills/System Design/` folder. Reading your own
implementation alongside the case-study walkthrough is the highest-value use of this repo.

## How to use this repo

1. **Learning a topic for the first time** — read `theory/`, then the `snippets/`.
2. **Weekly review** — skim `interview-qa/` across all topics.
3. **The night before an interview** — do `scenarios/` and `output-based/`, plus one full case study from
   `13-hld-case-studies/problems/` talked through out loud.
4. **Adding new material** — drop a new numbered file in the matching subfolder.
