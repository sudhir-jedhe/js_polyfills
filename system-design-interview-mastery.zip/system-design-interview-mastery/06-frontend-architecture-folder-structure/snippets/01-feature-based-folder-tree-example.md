# Snippet: Feature-Based Folder Tree with Shared Layer

A concrete, complete example of the hybrid structure most production apps converge on — feature folders for domain code, plus a disciplined `shared/` layer for genuinely cross-cutting code.

```
src/
  app/
    App.tsx
    routes.tsx
    providers.tsx          # top-level context providers (theme, auth, query client)

  features/
    checkout/
      index.ts             # public API: re-exports what other code may import
      Checkout.tsx
      CheckoutSummary.tsx
      useCheckout.ts
      checkoutApi.ts
      checkoutSlice.ts
      internal/
        promoCodeValidator.ts   # implementation detail, never imported outside this feature

    user-profile/
      index.ts
      ProfilePage.tsx
      useProfile.ts
      profileApi.ts

    product-catalog/
      index.ts
      ProductGrid.tsx
      ProductCard.tsx
      useProductSearch.ts
      productApi.ts

  shared/
    components/            # design-system-adjacent, domain-agnostic UI
      Button.tsx
      Modal.tsx
      Input.tsx
    hooks/
      useDebounce.ts
      useMediaQuery.ts
    lib/
      apiClient.ts          # generic fetch wrapper, no domain knowledge
      formatCurrency.ts

  index.tsx
```

```ts
// features/checkout/index.ts — the feature's public API surface
export { Checkout } from "./Checkout";
export { useCheckout } from "./useCheckout";
// note: promoCodeValidator is deliberately NOT re-exported — it's internal
```

```ts
// features/checkout/Checkout.tsx — allowed: importing from shared/
import { Button, Modal } from "@/shared/components";
import { useDebounce } from "@/shared/hooks";

// features/checkout/Checkout.tsx — NOT allowed (should be flagged by dependency-cruiser):
// import { useProfile } from "@/features/user-profile/useProfile"; // reaching past the public API
import { useProfile } from "@/features/user-profile"; // correct: goes through index.ts
```

The dependency direction is strictly one-way: `shared/` never imports from `features/`, and features only ever import each other through `index.ts`, never by reaching into another feature's internal files directly.
