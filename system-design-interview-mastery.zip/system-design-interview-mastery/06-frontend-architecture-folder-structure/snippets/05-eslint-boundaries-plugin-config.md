# Snippet: ESLint Boundary Rules for Editor-Time Feedback

`eslint-plugin-boundaries` catches boundary violations directly in the editor as the developer types, complementing dependency-cruiser's CI-time enforcement (see `02-dependency-cruiser-config.md`) with much faster feedback.

```js
// .eslintrc.js
module.exports = {
  plugins: ["boundaries"],
  settings: {
    "boundaries/elements": [
      { type: "feature", pattern: "src/features/*" },
      { type: "shared", pattern: "src/shared/*" },
      { type: "app", pattern: "src/app/*" },
    ],
  },
  rules: {
    "boundaries/element-types": [
      "error",
      {
        default: "disallow",
        rules: [
          // shared/ may only import from shared/ — no upward knowledge of features
          { from: "shared", allow: ["shared"] },
          // features may import shared/ and their OWN feature, never another feature directly
          { from: "feature", allow: ["shared", ["feature", { name: "${from.name}" }]] },
          // app/ (the composition root) may import anything
          { from: "app", allow: ["feature", "shared", "app"] },
        ],
      },
    ],
    "boundaries/no-private": [
      "error",
      { allowUncles: false }, // disallow reaching into a sibling feature's internal/ folder
    ],
  },
};
```

```jsx
// features/checkout/Checkout.jsx
import { useProfile } from "../user-profile/useProfile"; // ← red squiggly in editor immediately:
// "Importing 'feature' elements is not allowed in 'feature' elements
//  according to the rule from 'feature' to 'feature' (boundaries/element-types)"

import { useProfile } from "@/features/user-profile"; // ✓ correct — through the feature's index.ts
```

The combination is deliberate: ESLint gives immediate, in-editor feedback during development (fast but easy to bypass with `--no-verify` or a disabled rule comment), while dependency-cruiser's CI check is the actual unbypassable gate before merge — treat editor linting as a developer-experience convenience, not the enforcement mechanism itself.
