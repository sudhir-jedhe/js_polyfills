# Snippet: Design Tokens Compiled to CSS Custom Properties

Shows the token → primitive pipeline concretely: a platform-agnostic token source compiled into CSS variables that primitives consume, so a token change propagates without touching component code.

```json
// tokens/colors.json — the single source of truth
{
  "color": {
    "brand": { "primary": { "value": "#2563eb" }, "primaryHover": { "value": "#1d4ed8" } },
    "text": { "default": { "value": "#111827" }, "muted": { "value": "#6b7280" } },
    "surface": { "danger": { "value": "#fef2f2" } }
  },
  "spacing": {
    "sm": { "value": "8px" },
    "md": { "value": "16px" },
    "lg": { "value": "24px" }
  }
}
```

```css
/* generated/tokens.css — output of a build step (e.g. Style Dictionary), never hand-edited */
:root {
  --color-brand-primary: #2563eb;
  --color-brand-primary-hover: #1d4ed8;
  --color-text-default: #111827;
  --color-text-muted: #6b7280;
  --color-surface-danger: #fef2f2;
  --spacing-sm: 8px;
  --spacing-md: 16px;
  --spacing-lg: 24px;
}
```

```css
/* primitives/Button.module.css — consumes tokens, never hardcodes raw values */
.button {
  background: var(--color-brand-primary);
  padding: var(--spacing-sm) var(--spacing-md);
  border-radius: var(--radius-default);
  color: white;
}
.button:hover {
  background: var(--color-brand-primary-hover);
}
```

```jsx
// components/Modal.jsx — a component built from primitives, still no raw values
import { Button } from "../primitives/Button";
import styles from "./Modal.module.css"; // uses var(--spacing-lg), var(--color-text-default), etc.

export function Modal({ title, children, onClose }) {
  return (
    <div className={styles.overlay}>
      <div className={styles.panel}>
        <h2 className={styles.title}>{title}</h2>
        {children}
        <Button onClick={onClose}>Close</Button>
      </div>
    </div>
  );
}
```

Rebranding `--color-brand-primary` in exactly one place (`tokens/colors.json`) ripples through `Button`, every component that uses `Button`, and every pattern built from those components — no hunting for hardcoded hex values, precisely because the layering (tokens → primitives → components → patterns) was respected end to end.
