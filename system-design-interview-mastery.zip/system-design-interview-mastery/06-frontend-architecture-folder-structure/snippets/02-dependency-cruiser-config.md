# Snippet: dependency-cruiser Config for Feature Boundaries

A working `.dependency-cruiser.js` enforcing the boundary rules described in `theory/03-module-boundaries-and-enforcement.md`, runnable in CI to fail the build on a violation.

```js
// .dependency-cruiser.js
module.exports = {
  forbidden: [
    {
      name: "no-internal-imports-across-features",
      severity: "error",
      comment: "Nothing outside a feature may import that feature's internal/ files",
      from: { pathNot: "^src/features/([^/]+)/" },
      to: { path: "^src/features/([^/]+)/internal/" },
    },
    {
      name: "features-must-use-public-api",
      severity: "error",
      comment: "Feature A may only import feature B via feature B's index.ts",
      from: { path: "^src/features/(?<from>[^/]+)/" },
      to: {
        path: "^src/features/(?<to>(?!\\1)[^/]+)/(?!index)",
      },
    },
    {
      name: "no-circular-dependencies",
      severity: "error",
      comment: "Circular imports between any modules indicate features aren't actually independent",
      from: {},
      to: { circular: true },
    },
    {
      name: "shared-cannot-import-features",
      severity: "error",
      comment: "shared/ must have no knowledge of domain-specific feature code (one-way dependency)",
      from: { path: "^src/shared/" },
      to: { path: "^src/features/" },
    },
  ],
  options: {
    doNotFollow: { path: "node_modules" },
    tsPreCompilationDeps: true,
  },
};
```

Run it as a CI gate:

```json
// package.json
{
  "scripts": {
    "check:boundaries": "depcruise --config .dependency-cruiser.js --output-type err src"
  }
}
```

```
# CI output on a violation:
error no-internal-imports-across-features: src/features/checkout/Checkout.tsx →
  src/features/user-profile/internal/tokenStorage.ts

✖ 1 dependency violation (1 error, 0 warnings). 3 modules checked, 87 dependencies.
```

A non-zero exit code fails the pipeline, turning "please don't do this" from a code-review comment into an automated, unbypassable check.
