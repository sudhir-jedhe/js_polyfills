# Snippet: Compound Component Implementation (Tabs)

A complete compound-component implementation showing the context-sharing mechanism that lets subcomponents coordinate without explicit prop-drilling.

```jsx
// Tabs.jsx
import { createContext, useContext, useState } from "react";

const TabsContext = createContext(null);

function Tabs({ defaultValue, children }) {
  const [activeValue, setActiveValue] = useState(defaultValue);
  return (
    <TabsContext.Provider value={{ activeValue, setActiveValue }}>
      <div className="tabs">{children}</div>
    </TabsContext.Provider>
  );
}

function TabList({ children }) {
  return <div role="tablist" className="tabs__list">{children}</div>;
}

function Tab({ value, children }) {
  const { activeValue, setActiveValue } = useContext(TabsContext);
  const isActive = activeValue === value;
  return (
    <button
      role="tab"
      aria-selected={isActive}
      className={isActive ? "tabs__tab tabs__tab--active" : "tabs__tab"}
      onClick={() => setActiveValue(value)}
    >
      {children}
    </button>
  );
}

function TabPanel({ value, children }) {
  const { activeValue } = useContext(TabsContext);
  if (activeValue !== value) return null;
  return <div role="tabpanel">{children}</div>;
}

Tabs.List = TabList;
Tabs.Tab = Tab;
Tabs.Panel = TabPanel;

export { Tabs };
```

```jsx
// usage — the consumer freely composes and orders subcomponents, no prop explosion
<Tabs defaultValue="overview">
  <Tabs.List>
    <Tabs.Tab value="overview">Overview</Tabs.Tab>
    <Tabs.Tab value="details">Details</Tabs.Tab>
    <Tabs.Tab value="reviews">Reviews</Tabs.Tab>
  </Tabs.List>

  <Tabs.Panel value="overview">Product overview content...</Tabs.Panel>
  <Tabs.Panel value="details">Spec details...</Tabs.Panel>
  <Tabs.Panel value="reviews">Customer reviews...</Tabs.Panel>
</Tabs>
```

Compare to what a single-component, prop-driven API would need to support the same flexibility: a `tabs={[{label, content}]}` array prop loses the ability to freely interleave custom markup between tabs, conditionally render extra elements in the tab list, or let a consumer add a tab-specific badge — all things that fall out naturally from composing JSX children instead of serializing everything into a data prop.
