# Interview Q&A — Folder Structure Fundamentals

**Q: What's the core difference between feature-based and layer-based folder structure?**
Layer-based groups files by technical role — all components together, all hooks together, all services together — across the entire app, regardless of what business domain they serve. Feature-based groups files by business capability instead, so everything needed for one feature (its components, hooks, API calls, state) lives together in one folder. The practical consequence is colocation: working on one feature in a layer-based structure means jumping across every top-level folder, while in a feature-based structure it means working within one folder.

**Q: Why does layer-based structure tend to break down as an app grows, specifically?**
Because nothing in a layer-based structure creates a boundary between unrelated features that happen to sit in the same layer folder — `components/OrderSummary.jsx` and `components/UserCard.jsx` are neighbors with no structural signal preventing one from importing the other's dependencies directly, so accidental coupling between unrelated domains creeps in silently. It also means every layer folder (`components/`, `hooks/`, `services/`) grows without bound as the app grows, eventually becoming a "god folder" with hundreds of unrelated files.

**Q: Is feature-based structure always the right choice?**
No — for a small app or prototype with only a couple of features, the overhead of maintaining per-feature `index.ts` files and boundary discipline may not be worth it yet, and layer-based structure's simplicity is a reasonable fit at that scale. The crossover point is roughly when the app has several distinct domains and/or more than a couple of contributors, at which point feature-based structure's colocation and boundary benefits start clearly outweighing the extra upfront organization.

**Q: What typically goes in a `shared/` folder, and what's the risk of that folder?**
Genuinely cross-cutting code with no business-domain knowledge — a generic `Button`, a `useDebounce` hook, a `formatCurrency` utility, an API client wrapper. The risk is `shared/` slowly becoming a dumping ground for anything a developer isn't sure where else to put, recreating the exact "unstructured pile of files" problem feature-based structure was meant to solve, just under a different folder name — discipline about what actually qualifies as shared (used by multiple unrelated features, no domain knowledge) is what prevents that drift.

**Q: What's a practical rule of thumb for "does this code belong in a feature, or in shared?"**
If removing the code would only affect one feature, it belongs in that feature. If it's used by, or would reasonably be used by, three or more unrelated features and contains no domain-specific business logic, it's a shared candidate. A common trap is moving something to `shared/` after only two features use it and it later turns out those two features' needs diverge — premature sharing can be as costly as premature optimization, since it couples two features indirectly through a "shared" piece that isn't really shared in intent.

**Q: How does folder structure relate to team ownership in a large organization?**
A well-chosen feature-based structure lets folder boundaries map directly onto team ownership — "the checkout team owns `features/checkout/`" is unambiguous and enforceable via CODEOWNERS. Layer-based structure has no equivalent mapping; a team's ownership is scattered across `components/`, `hooks/`, `services/`, making it much harder to define or enforce who's responsible for what, which becomes a real organizational cost as team count grows.
