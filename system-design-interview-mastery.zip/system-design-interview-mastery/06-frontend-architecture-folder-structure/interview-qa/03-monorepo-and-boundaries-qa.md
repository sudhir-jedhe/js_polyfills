# Interview Q&A — Monorepos and Module Boundaries

**Q: What's the core benefit of a monorepo over polyrepo for frontend code specifically?**
The ability to update a shared package (design system, shared utilities) and every consumer of it in a single atomic commit, with CI verifying nothing broke before merge — this eliminates the version-drift problem polyrepo has, where different apps can silently pin different, increasingly divergent versions of the same shared package indefinitely, with no forcing function to keep them in sync.

**Q: What does a monorepo need, tooling-wise, to not become unbearably slow as it grows?**
Affected-graph-aware task running (Nx, Turborepo) that computes which packages actually changed — and which downstream packages depend on them — and only builds/tests/lints that subset, plus remote caching so work already done (by CI or a teammate) isn't repeated. Without this, a monorepo's CI degrades toward "rerun everything on every commit," which is often what people mean when they say monorepos "don't scale" — the actual missing piece is usually the tooling, not the monorepo structure itself.

**Q: What's a real cost of a monorepo that polyrepo doesn't have?**
A shared package change reaches every consumer immediately and atomically, with no version-bump checkpoint where a consuming team reviews and opts in on their own schedule — a behavioral change intended to fix one team's problem can silently regress another team's usage the moment it merges, as opposed to polyrepo where that team would only be affected once they explicitly bump the dependency version.

**Q: What does a module boundary consist of, concretely?**
A defined public API (typically everything re-exported from a module's `index.ts`) and everything else treated as internal/private implementation detail that outside code should never import directly. The distinction matters because internal files are free to change without being a breaking change for anyone — if a consumer imported an internal file directly, refactoring that internal file becomes a breaking change for a dependency the module's author never intended to support.

**Q: Name two concrete tools used to enforce module boundaries and describe how they differ.**
`dependency-cruiser` performs static import-graph analysis and is typically run as a required CI check, making a boundary violation a hard build failure — the actual enforcement gate. `eslint-plugin-boundaries` (or `no-restricted-paths`) surfaces the same kind of violation directly in the editor as the developer types, giving much faster feedback but being easier to bypass (disabled inline, skipped hooks) than a CI-level check — the two are typically used together, ESLint for fast in-editor feedback and dependency-cruiser as the unbypassable gate.

**Q: A circular import is detected between two feature folders — what does that actually indicate architecturally, and what's the fix?**
It indicates the two "features" aren't actually independent — some piece of logic both depend on has been placed inside one of them rather than extracted into a shared/lower layer, so each ends up needing something from the other. The fix is almost always extracting the shared logic into a genuinely shared module that both features depend on one-directionally, not reordering imports or otherwise working around the cycle, since the underlying coupling remains either way.

**Q: If a rule like "no cross-feature internal imports" already has 40 existing violations in a mature codebase, how do you roll out enforcement without it just becoming an obstacle everyone routes around?**
Add the check in warn-only mode first, track and pay down the existing violations (or fix them upfront if feasible), then flip it to a hard-blocking CI failure once the backlog is cleared — introducing a hard block against a codebase already full of violations just teaches the team to disable or bypass the check rather than respect it, which defeats the purpose of automating enforcement in the first place.
