# Output: Identifying When Prop Drilling Signals a Composition Fix

```jsx
function Dashboard({ user }) {
  return <Panel title="Settings" showEditButton={user.isAdmin} editLabel="Edit Settings" onEdit={handleEdit} />;
}

function Panel({ title, showEditButton, editLabel, onEdit }) {
  return (
    <div className="panel">
      <div className="panel__header">
        <h2>{title}</h2>
        {showEditButton && <button onClick={onEdit}>{editLabel}</button>}
      </div>
      <div className="panel__body">{/* ... */}</div>
    </div>
  );
}
```

**New requirement:** some panels need a secondary "info" icon button next to the edit button, some need a dropdown menu instead of a single edit button, and one panel needs a custom badge in the header showing an unread count.

**Question:** If you extend `Panel` by adding more props (`showInfoButton`, `infoIcon`, `useDropdownInsteadOfButton`, `dropdownItems`, `badgeCount`, ...), what specifically goes wrong, and what's the composition-based fix?

**Answer — what goes wrong with more props:**

Each new header variation becomes another prop, and `Panel`'s internals accumulate more conditional branches to decide what to render in the header based on which combination of props is set. Worse, some combinations are mutually exclusive or ambiguous (`showEditButton` **and** `useDropdownInsteadOfButton` both `true` — which wins?) that the component now has to defensively guard against, and the header's actual visual composition (icon button, then dropdown, then badge, in what order?) is entirely opaque from the call site — you'd have to read `Panel`'s implementation to know what a given prop combination actually renders.

**Answer — the composition fix (compound component / slot):**

```jsx
function Panel({ children }) {
  return <div className="panel">{children}</div>;
}
function PanelHeader({ children }) {
  return <div className="panel__header">{children}</div>;
}
function PanelBody({ children }) {
  return <div className="panel__body">{children}</div>;
}
Panel.Header = PanelHeader;
Panel.Body = PanelBody;

// usage — each panel composes exactly what it needs, visible at the call site:
<Panel>
  <Panel.Header>
    <h2>Settings</h2>
    {user.isAdmin && <button onClick={handleEdit}>Edit Settings</button>}
    <InfoIconButton />
    <UnreadBadge count={5} />
  </Panel.Header>
  <Panel.Body>{/* ... */}</Panel.Body>
</Panel>

<Panel>
  <Panel.Header>
    <h2>Billing</h2>
    <DropdownMenu items={billingActions} />
  </Panel.Header>
  <Panel.Body>{/* ... */}</Panel.Body>
</Panel>
```

**Why this is strictly better here:** every panel's header composition is now explicit JSX at the call site — no hidden internal branching logic to reverse-engineer, no risk of an invalid prop combination, and a genuinely new header requirement (a third panel needing two badges and a tooltip) requires zero changes to `Panel` itself, just different children passed in. This is precisely the signal described in `theory/05-component-composition-patterns-at-scale.md`: the props being added were about **layout/content structure** (what's in the header, in what order), not small behavioral variants — exactly the case where composition beats configuration.
