# Output: Tracing a Change Through a Layer-Based Structure

```
src/
  components/
    OrderList.jsx
    OrderDetail.jsx
    UserAvatar.jsx
  hooks/
    useOrders.js
    useUser.js
  services/
    orderApi.js
    userApi.js
  reducers/
    orderReducer.js
    userReducer.js
```

**Task given:** "Add a feature: when a user cancels an order, show a confirmation toast and refund any loyalty points that were earned on that order."

**Question:** List every file this change touches, and identify the number of distinct top-level folders that must be modified.

**Answer, traced through:**

- `components/OrderDetail.jsx` — add the cancel button and confirmation UI
- `components/OrderList.jsx` — likely needs to reflect the new "cancelled" status in the list view
- `hooks/useOrders.js` — add a `cancelOrder` action/mutation
- `services/orderApi.js` — add the API call to cancel the order
- `reducers/orderReducer.js` — handle the new cancelled state transition
- `hooks/useUser.js` — loyalty points live on the user, so refunding them touches user state too
- `services/userApi.js` — add/modify the API call adjusting loyalty point balance
- `reducers/userReducer.js` — handle the loyalty point refund state update
- A new toast/notification concern, which likely doesn't cleanly belong to *either* `components/`, `hooks/`, or `services/` as currently organized, forcing an ad hoc decision about where it goes

**Total: 8+ files across all 4 top-level folders** (`components/`, `hooks/`, `services/`, `reducers/`), for what is conceptually one feature.

**Why this demonstrates the scaling problem:** every one of those 4 folders now contains files belonging to two different domains (orders and users) with nothing in the folder structure itself indicating that `orderReducer.js` and `userReducer.js` are related by this feature, or separating them from a third domain's reducer that happens to live right next to them. A reviewer looking at a PR touching all 4 folders has no structural signal for "these 8 file changes are one cohesive feature" versus "this PR touches 8 unrelated things" — feature-based structure would instead show a single `features/order-cancellation/` (or extending `features/order/`) folder boundary, making the change's actual scope visible at a glance, and any accidental reach into `features/user/internal/` would be exactly the kind of cross-feature coupling dependency-cruiser rules are meant to catch.
