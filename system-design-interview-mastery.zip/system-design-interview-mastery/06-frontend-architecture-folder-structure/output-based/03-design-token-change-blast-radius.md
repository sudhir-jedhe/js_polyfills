# Output: Tracing the Blast Radius of a Design Token Change

```css
/* generated/tokens.css */
:root {
  --color-brand-primary: #2563eb;
}
```

```css
/* primitives/Button.module.css */
.button--primary { background: var(--color-brand-primary); }
```

```css
/* primitives/Link.module.css */
.link { color: var(--color-brand-primary); }
```

```css
/* components/Alert.module.css */
.alert--info { border-left: 4px solid var(--color-brand-primary); }
```

```jsx
// features/checkout/CheckoutButton.jsx
<button style={{ backgroundColor: "#2563eb" }}>Pay Now</button>  // hardcoded, NOT using the token
```

**Question:** A rebrand changes `--color-brand-primary` from `#2563eb` to `#7c3aed`. Which of the four consumers above correctly pick up the new color automatically, and which doesn't — and why?

**Answer:**

`Button.module.css`, `Link.module.css`, and `Alert.module.css` **all update automatically** — each references `var(--color-brand-primary)` rather than a hardcoded value, so the moment `tokens.css` is regenerated with the new hex value, every one of these picks it up on next render with zero code changes, exactly the layered architecture (tokens → primitives → components) working as intended.

`CheckoutButton.jsx` **does not update** — it hardcodes `#2563eb` directly in an inline style rather than consuming the token (whether via the CSS variable or a primitive `Button` component that itself uses the token). It will silently keep showing the old brand color after the rebrand ships everywhere else, and nothing in the build will flag this — hardcoded values don't error, they just silently diverge.

**Why this happened:** `CheckoutButton.jsx` is in `features/checkout/`, application/feature-layer code, and it bypassed the primitive layer entirely by writing a raw `<button>` with an inline style instead of importing and using the design system's `Button` primitive. This is exactly the "skipping the primitive layer" mistake described in `theory/04-design-system-architecture-tokens-to-patterns.md` — a pattern (feature-level component) that reaches straight past components and primitives to a raw token value (or worse, a value that isn't even a token reference) breaks the whole point of having tokens.

**Fix and prevention:** replace the hardcoded button with the shared primitive (`import { Button } from "@/shared/components"`), and add a lint rule (e.g., `stylelint`'s `declaration-property-value-disallowed-list`, or a custom rule) that flags raw hex color values in component/feature code outside the design system's own primitive definitions — turning "someone forgot to use the token" from a silent visual bug into a caught lint error before merge.
