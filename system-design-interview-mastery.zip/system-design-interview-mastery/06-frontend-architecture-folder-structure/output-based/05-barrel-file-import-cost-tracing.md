# Output: Tracing a Barrel File's Effect on Bundle Size

```ts
// shared/components/index.ts — a barrel file re-exporting everything
export { Button } from "./Button";
export { Modal } from "./Modal";
export { DataTable } from "./DataTable";       // pulls in a heavy third-party grid library
export { ChartWidget } from "./ChartWidget";   // pulls in a heavy charting library
export { RichTextEditor } from "./RichTextEditor"; // pulls in a heavy editor library
```

```jsx
// features/settings/SettingsPage.jsx
import { Button } from "@/shared/components"; // only needs Button
```

**Question:** Given this setup, and a bundler *without* effective tree-shaking configured for this barrel (e.g., the package's `package.json` is missing `"sideEffects": false`, or one of the barrel'd modules has a top-level side effect), what ends up in `SettingsPage`'s bundle chunk, and why?

**Answer:** Potentially **all five components' code — including the heavy grid, charting, and rich-text-editor libraries** — even though `SettingsPage` only imports `Button`. This happens because importing from a barrel file (`@/shared/components`) makes the bundler resolve the *entire* `index.ts` module first; if the bundler can't prove that evaluating `Modal.ts`, `DataTable.ts`, etc. has no side effects (missing `sideEffects: false`, or an actual side effect like a global CSS import or a module-level `analytics.register(...)` call in one of those files), it conservatively includes all of them in the dependency graph rather than risk dropping code that does something the module system can't statically verify is safe to remove.

**Why this is easy to miss:** the import statement (`import { Button } from "@/shared/components"`) *looks* like it should only pull in `Button` — named imports create that intuition — but the barrel file itself is the actual module being resolved, and whether unused re-exports get eliminated depends entirely on whether tree shaking can prove they're side-effect-free, which is a build-configuration detail invisible from the import line itself.

**Fix:**
1. **Mark the package/directory `"sideEffects": false`** in `package.json` (or list the specific files that do have side effects, e.g. CSS imports, so the bundler knows everything else is safe to drop) — this is often the single highest-leverage fix and requires no code restructuring.
2. **Import directly from the specific file, bypassing the barrel**, when the barrel can't be made side-effect-free for some reason: `import { Button } from "@/shared/components/Button"` — guarantees only that file's dependency graph is pulled in, independent of tree-shaking correctly eliminating the rest.
3. **Split heavy, rarely-co-used components out of the shared barrel entirely** (e.g., `DataTable`, `ChartWidget`, `RichTextEditor` each get their own explicit import path rather than living in the general-purpose `shared/components` barrel) — reduces the blast radius of the barrel pattern for the specific components most likely to cause this problem.

See `07-frontend-rendering-performance/theory/07-bundle-size-tree-shaking-minification-compression.md` for the underlying tree-shaking mechanics this scenario depends on.
