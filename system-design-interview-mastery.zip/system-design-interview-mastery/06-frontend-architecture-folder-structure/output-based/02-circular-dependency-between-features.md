# Output: Diagnosing a Circular Dependency Between Features

```js
// features/cart/useCart.js
import { getLoyaltyDiscount } from "../checkout/checkoutUtils";

export function useCart() {
  const discount = getLoyaltyDiscount(items);
  // ...
}
```

```js
// features/checkout/checkoutUtils.js
import { useCart } from "../cart/useCart";

export function getLoyaltyDiscount(items) {
  const cart = useCart(); // uh oh
  // ...
}
```

**Question:** What does dependency-cruiser's `no-circular-dependencies` rule flag here, and what does this circular import actually mean architecturally — is it just a lint nuisance, or a real design problem?

**Answer:**

Dependency-cruiser flags a cycle: `features/cart/useCart.js → features/checkout/checkoutUtils.js → features/cart/useCart.js`. This isn't just a style nitpick — a circular import between two supposedly independent features is direct evidence that **`cart` and `checkout` aren't actually independent modules**, they're one entangled unit artificially split across two folders. In practice, module bundlers can often still resolve circular imports (with caveats around initialization order — a value imported before its module has finished executing can be `undefined`), so this might not even throw an immediate error, making it an easy problem to miss until it causes a confusing runtime bug where `getLoyaltyDiscount` is `undefined` on first render because of load-order timing.

**Diagnosis of the underlying design issue:** `getLoyaltyDiscount` needing `cart`'s state, while `cart` needing checkout's discount logic, means these two "features" actually share a piece of core logic (loyalty discount calculation) that has been placed in the wrong feature. Neither `cart` nor `checkout` truly owns it — it's a shared concern masquerading as feature-specific code.

**Fix:** extract the shared logic into its own module that both features depend on **one-directionally**:

```js
// shared/loyalty/calculateDiscount.js  (or features/loyalty/ if it's domain-significant enough to be its own feature)
export function calculateLoyaltyDiscount(items, loyaltyPoints) {
  // pure function, no dependency on cart or checkout state
}
```

```js
// features/cart/useCart.js
import { calculateLoyaltyDiscount } from "@/shared/loyalty/calculateDiscount";
// cart now depends on shared/, not on checkout — cycle broken
```

```js
// features/checkout/checkoutUtils.js
import { calculateLoyaltyDiscount } from "@/shared/loyalty/calculateDiscount";
// checkout also depends on shared/, not on cart — cycle broken
```

**Takeaway:** a circular dependency between two feature folders is almost always a signal that a piece of shared logic was misplaced inside one of the features rather than extracted into a genuinely shared/lower layer — the fix is nearly always "pull the shared piece out," not "just reorder the imports," since reordering doesn't fix the underlying fact that both features need the same logic.
