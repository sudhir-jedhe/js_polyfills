# Scenario: Migrating a Large App from Layer-Based to Feature-Based Structure

**Scenario:** A 3-year-old React app has grown to `components/` (140 files), `hooks/` (60 files), `services/` (45 files), and `reducers/` (30 files) — all layer-based, all flat. New engineers take weeks to become productive because there's no structural map of what belongs together, and PRs routinely touch 4+ top-level folders for what's conceptually one feature. Leadership wants to migrate to feature-based structure, but the app can't stop shipping for months to do it. How do you approach the migration?

**Diagnosis:** A big-bang rewrite is the wrong approach for a live, continuously-shipping app — it freezes feature work, is high-risk (large-diff PRs are hard to review thoroughly), and 275 files don't cleanly sort into feature boundaries on the first attempt anyway (that's usually only discovered partway through). The migration needs to be incremental and non-blocking.

**Migration plan:**

1. **Identify feature boundaries first, without moving any code.** Walk the existing `components/`/`hooks/`/`services/`/`reducers/` folders and group files by the business domain they actually serve (this is itself valuable groundwork — some existing files will turn out to serve *no* clear single domain, which is useful signal about what should become `shared/`). Produce a target map: `features/order/`, `features/user/`, `features/product/`, `shared/`.

2. **Introduce the new top-level structure alongside the old one.** Create `features/` and `shared/` folders, but don't touch existing code yet — new work starts landing in the new structure immediately, while old code stays where it is. This means day one of the migration, the "getting worse" trend (more files landing in flat `components/`) stops, even before a single old file has moved.

3. **Migrate feature-by-feature, opportunistically, tied to real work.** Whenever a developer is already touching a given domain's code for a feature/bugfix, that's the moment to move the touched files (and closely related ones) into the new `features/<domain>/` structure as part of that same PR — the move happens "for free" alongside work that was going to touch those files anyway, rather than as a separate, disconnected migration PR that's harder to justify prioritizing. Use codemods (`jscodeshift`) to automate the mechanical parts (updating import paths across the codebase when a file moves) so a move doesn't require manually fixing dozens of import statements by hand.

4. **Keep both structures working simultaneously during the transition**, using re-export shims from old paths to new ones if needed (`components/OrderList.jsx` becomes a one-line re-export of `features/order/OrderList.jsx`) so files that haven't been updated to import from the new location yet don't break — remove the shims once nothing references the old path anymore (a codebase-wide import search confirms this cleanly).

5. **Add boundary enforcement (dependency-cruiser) as soon as a critical mass of features have moved**, even before the migration is 100% complete — this locks in the boundaries for the migrated portion immediately, preventing new violations from creeping into features that have already been cleaned up, rather than waiting until the very end to add enforcement.

6. **Track migration progress as a visible metric** (e.g., "% of files moved to feature-based structure") so it doesn't silently stall once the initial enthusiasm fades — opportunistic, tied-to-real-work migrations have a real risk of never finishing the long tail of rarely-touched files, which is an acceptable outcome as long as it's a deliberate tradeoff rather than an accident.

**Takeaway:** a large-scale structural migration on a live codebase succeeds by making the new structure the path of least resistance for new work immediately, then riding ordinary maintenance work to migrate the rest incrementally — not by scheduling a dedicated "big rewrite" that competes with feature delivery and carries much higher risk per unit of progress.
