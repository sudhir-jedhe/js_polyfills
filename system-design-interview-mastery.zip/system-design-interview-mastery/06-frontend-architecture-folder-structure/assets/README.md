Diagrams and reference images for frontend architecture & folder structure (e.g. layered design system diagrams, module boundary graphs) will be added here.
