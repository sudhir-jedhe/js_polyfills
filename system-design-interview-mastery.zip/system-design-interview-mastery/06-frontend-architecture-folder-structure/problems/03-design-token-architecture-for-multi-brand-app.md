# Problem: Design a Token Architecture Supporting Multiple Brands and Dark Mode

## Problem Statement

Your company operates three consumer-facing brands (BrandA, BrandB, BrandC) that share the same underlying application and component library, each with distinct brand colors/typography, and each needing both light and dark mode. Design a design-token architecture that lets a component like `Button` render correctly for any brand/theme combination **without any brand- or theme-specific logic inside the component itself**.

## Constraints

- Adding a 4th brand in the future must require zero changes to primitive/component code — only new token values.
- Switching theme (light/dark) must not require a page reload or remount of the component tree (a runtime toggle).
- Components must reference only semantic token names, never brand-specific or raw values directly.

## Approach

Introduce a **two-tier token system**: brand-and-theme-specific raw values ("core" tokens) mapped onto **semantic** token names that components actually consume. Components only ever reference semantic tokens (`--color-action-primary`), never the underlying brand-specific raw value (`--brandA-blue-500`) directly — this indirection is exactly what makes brand/theme swapping possible without touching component code, since only the mapping layer changes per brand/theme, never the component's references.

## Solution

```json
// tokens/core/brandA.json — raw brand-specific values, one file per brand
{
  "brandA": {
    "blue": { "500": "#2563eb", "700": "#1d4ed8" },
    "gray": { "50": "#f9fafb", "900": "#111827" }
  }
}
```

```json
// tokens/semantic/light.json — maps semantic names onto core values, per theme
{
  "color": {
    "action": { "primary": "{brandA.blue.500}", "primaryHover": "{brandA.blue.700}" },
    "surface": { "default": "{brandA.gray.50}" },
    "text": { "default": "{brandA.gray.900}" }
  }
}
```

```json
// tokens/semantic/dark.json — same semantic names, different mapped values for dark mode
{
  "color": {
    "action": { "primary": "{brandA.blue.500}", "primaryHover": "{brandA.blue.700}" },
    "surface": { "default": "{brandA.gray.900}" },
    "text": { "default": "{brandA.gray.50}" }
  }
}
```

Compiled output (via a build tool like Style Dictionary), scoped so runtime brand/theme selection is just a data attribute:

```css
/* generated/brandA-light.css */
[data-brand="brandA"][data-theme="light"] {
  --color-action-primary: #2563eb;
  --color-surface-default: #f9fafb;
  --color-text-default: #111827;
}

/* generated/brandA-dark.css */
[data-brand="brandA"][data-theme="dark"] {
  --color-action-primary: #2563eb;
  --color-surface-default: #111827;
  --color-text-default: #f9fafb;
}
/* ...repeated per brand: brandB-light.css, brandB-dark.css, brandC-light.css, brandC-dark.css */
```

```css
/* primitives/Button.module.css — references ONLY semantic tokens, no brand/theme awareness at all */
.button {
  background: var(--color-action-primary);
  color: var(--color-surface-default);
}
.button:hover {
  background: var(--color-action-primary-hover, var(--color-action-primary));
}
```

```jsx
// app/providers.tsx — runtime brand/theme switching via data attributes, no remount needed
function ThemeProvider({ brand, theme, children }) {
  return (
    <div data-brand={brand} data-theme={theme}>
      {children}
    </div>
  );
}
// toggling `theme` state re-renders this wrapper's attributes; CSS custom properties
// cascade to every descendant instantly — no component tree remount required
```

## Why this satisfies all three constraints

**Zero component changes for a new brand:** adding BrandD means creating `tokens/core/brandD.json` and generating `brandD-light.css`/`brandD-dark.css` from the existing semantic mapping — `Button.module.css` never changes, because it only ever referenced `--color-action-primary`, a semantic name that exists identically (just with different resolved values) for every brand.

**No remount for theme toggling:** because brand/theme selection is expressed as CSS custom properties scoped by a `data-*` attribute on a wrapper element, switching `data-theme` from `light` to `dark` is a pure CSS cascade update — the browser repaints with new variable values, no React re-render of the component tree's structure is needed at all (this is a meaningfully cheaper operation than, say, conditionally rendering different component trees per theme).

**No raw/brand-specific references in components:** the two-tier indirection (core tokens → semantic tokens → components) is what enforces this — a component physically cannot reference `brandA.blue.500` directly without explicitly breaking the pattern, since that value doesn't even exist as a name in the components' CSS, only `--color-action-primary` does.

## Complexity/tradeoff to note

This requires more upfront tooling investment (a token build pipeline like Style Dictionary, disciplined naming conventions for semantic tokens) than simply hardcoding `--color-primary: blue` once — that investment pays off specifically at 2+ brands/themes; a single-brand, single-theme app wouldn't need the two-tier indirection and could reasonably skip straight to semantic tokens without a separate "core" layer underneath.
