# Problem: Set Up Import Boundary Enforcement for an Existing Codebase

## Problem Statement

Given an existing feature-based codebase (`features/billing/`, `features/user/`, `features/reporting/`, `shared/`) that currently has **no** automated boundary enforcement, set up both editor-time (ESLint) and CI-time (dependency-cruiser) enforcement of these rules:
1. No feature may import another feature's files except through its `index.ts`.
2. `shared/` may never import from any `features/*` folder.
3. No circular dependencies anywhere in the codebase.

Then describe the rollout plan given that a quick manual audit already found 12 existing violations of rule 1.

## Constraints

- Both tools must be configured to enforce the exact same three rules (no drift between editor warnings and CI failures).
- The 12 existing violations must not block unrelated PRs from merging on day one of rollout.
- The final state must have all three rules as hard CI failures.

## Solution

**Step 1 — dependency-cruiser config (the CI-enforced source of truth):**

```js
// .dependency-cruiser.js
module.exports = {
  forbidden: [
    {
      name: "features-public-api-only",
      severity: "warn", // START as warn, not error — see rollout plan below
      from: { path: "^src/features/(?<from>[^/]+)/" },
      to: { path: "^src/features/(?<to>(?!\\1)[^/]+)/(?!index)" },
    },
    {
      name: "shared-no-feature-imports",
      severity: "error", // no existing violations found for this rule — safe to hard-block immediately
      from: { path: "^src/shared/" },
      to: { path: "^src/features/" },
    },
    {
      name: "no-circular-dependencies",
      severity: "error", // circular deps are unambiguously bad, no reason to soften this one
      from: {},
      to: { circular: true },
    },
  ],
};
```

**Step 2 — matching ESLint config for editor-time feedback:**

```js
// .eslintrc.js
module.exports = {
  plugins: ["boundaries"],
  settings: {
    "boundaries/elements": [
      { type: "feature", pattern: "src/features/*" },
      { type: "shared", pattern: "src/shared/*" },
    ],
  },
  rules: {
    "boundaries/element-types": [
      "warn", // matches dependency-cruiser's temporary "warn" for rule 1
      {
        default: "disallow",
        rules: [
          { from: "shared", allow: ["shared"] }, // this one's an error-equivalent — see note below
          { from: "feature", allow: ["shared", ["feature", { name: "${from.name}" }]] },
        ],
      },
    ],
  },
};
```
(In practice, split this into two ESLint rule entries at different severities to mirror dependency-cruiser's per-rule severity exactly — shown combined here for brevity.)

**Step 3 — CI wiring:**

```json
{
  "scripts": {
    "check:boundaries": "depcruise --config .dependency-cruiser.js --output-type err src",
    "lint": "eslint src --max-warnings 0"
  }
}
```
Note: `--max-warnings 0` would turn the intentionally-temporary "warn" rule into a hard failure immediately — for the rollout period, either exclude the boundaries warning from that flag's scope or don't apply `--max-warnings 0` codebase-wide until rule 1's violations are cleared.

## Rollout plan for the 12 existing violations

1. **Land both configs with rule 1 (`features-public-api-only`) at `severity: "warn"`**, rules 2 and 3 at `severity: "error"` immediately (no existing violations found for those, so there's no reason to delay hard-blocking them).
2. **File a tracked issue per violation** (or one issue with a checklist of all 12), and fix them incrementally — each fix is typically small (change an import path to go through the target feature's `index.ts`, possibly adding a missing export to that `index.ts` first).
3. **Add a CI comment/annotation surfacing the current warn-count** on every PR touching `features/`, so the remaining count stays visible rather than silently ignored.
4. **Once all 12 are fixed, flip rule 1's severity to `"error"` in one dedicated PR** (not bundled with unrelated changes, so it's easy to revert in isolation if the flip surfaces something unexpected), completing the rollout to "all three rules are hard CI failures."

## Why start rules 2 and 3 at error but rule 1 at warn

Rules 2 and 3 had zero existing violations — making them hard failures immediately costs nothing and locks in correct behavior from day one. Rule 1 had 12 existing violations, and hard-blocking it immediately would fail CI on any PR that merely touches a file adjacent to (not even causing) one of those pre-existing violations, teaching the team to view the check as an annoyance to route around rather than a meaningful gate — the incremental warn-then-error rollout avoids that specific failure mode.
