# Problem: Design a Feature-Based Folder Structure for a Multi-Domain App

## Problem Statement

You're starting a new e-commerce admin dashboard from scratch, covering four domains: **inventory management**, **order processing**, **customer support tickets**, and **analytics/reporting**. There's also a company-wide design system package already published as `@company/design-system`. Design the top-level and per-feature folder structure, including where shared/cross-cutting app code lives, and specify the import rules that should be enforced between folders.

## Constraints

- Must support 4+ engineers working on different domains concurrently with minimal merge conflicts.
- Must make it structurally obvious where new code for a given domain belongs.
- Must be enforceable (not just documented) — specify what a dependency-cruiser config for this structure would forbid.
- Analytics needs read-only data from both inventory and orders (e.g., "units sold per SKU") — this cross-domain dependency needs an explicit, deliberate design, not an ad hoc import.

## Solution

```
src/
  app/
    App.tsx
    routes.tsx
    providers.tsx

  features/
    inventory/
      index.ts
      InventoryList.tsx
      InventoryDetail.tsx
      useInventory.ts
      inventoryApi.ts
      internal/
        stockLevelCalculator.ts

    orders/
      index.ts
      OrderList.tsx
      OrderDetail.tsx
      useOrders.ts
      ordersApi.ts
      internal/
        orderStatusMachine.ts

    support-tickets/
      index.ts
      TicketQueue.tsx
      TicketDetail.tsx
      useTickets.ts
      ticketsApi.ts

    analytics/
      index.ts
      Dashboard.tsx
      useSalesReport.ts
      analyticsApi.ts        # calls a dedicated backend analytics/reporting endpoint —
                              # does NOT import inventory's or orders' internal modules directly

  shared/
    components/              # re-exports/wraps @company/design-system where app-specific
    hooks/
      useDebounce.ts
      usePagination.ts
    lib/
      apiClient.ts
      formatCurrency.ts
```

## Key design decision: how analytics gets cross-domain data

Rather than `features/analytics/` importing directly from `features/inventory/` and `features/orders/` (which would violate the "features only interact through explicit contracts" principle and create exactly the coupling/circular-dependency risk covered in `output-based/02-circular-dependency-between-features.md`), analytics consumes a **dedicated backend reporting endpoint** (`analyticsApi.ts` calling `/api/reports/units-sold`) that the backend computes by joining inventory and order data server-side. This keeps `analytics` decoupled from the internal implementation details of `inventory` and `orders` — if either of those features' internals change, `analytics` is unaffected, because it never depended on them directly in the first place; it depends on a stable API contract instead.

## dependency-cruiser rules for this structure

```js
module.exports = {
  forbidden: [
    {
      name: "no-cross-feature-internals",
      severity: "error",
      from: { pathNot: "^src/features/([^/]+)/" },
      to: { path: "^src/features/([^/]+)/internal/" },
    },
    {
      name: "features-via-public-api-only",
      severity: "error",
      from: { path: "^src/features/(?<from>[^/]+)/" },
      to: { path: "^src/features/(?<to>(?!\\1)[^/]+)/(?!index)" },
    },
    {
      name: "no-analytics-direct-domain-coupling",
      severity: "error",
      comment: "analytics must consume its own API layer, never reach into inventory/orders directly",
      from: { path: "^src/features/analytics/" },
      to: { path: "^src/features/(inventory|orders)/" },
    },
    {
      name: "shared-no-feature-imports",
      severity: "error",
      from: { path: "^src/shared/" },
      to: { path: "^src/features/" },
    },
  ],
};
```

## Why this scales to 4+ concurrent engineers

Each domain folder is a self-contained unit an engineer can work within without touching the other three, minimizing merge conflicts to genuine overlaps (shared code, or deliberate cross-feature API changes) rather than incidental ones caused by a layer-based structure scattering related files across shared top-level folders. The explicit forbidden-imports rules mean a well-intentioned shortcut (importing `inventory`'s internal stock calculator directly from `analytics` "just this once" to save a backend round-trip) fails CI immediately rather than becoming a silent architectural debt discovered months later.
