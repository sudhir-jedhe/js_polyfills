# Frontend Architecture & Folder Structure

How a frontend codebase is organized determines how it ages: a structure that feels fine at 20 files and one contributor can become the single biggest source of friction at 200 files and eight contributors, once every feature touches four scattered folders and nothing stops accidental coupling between unrelated domains. This topic covers the organizational decisions that actually compound over a codebase's lifetime — feature-based vs. layer-based structure, monorepo vs. polyrepo, how to make module boundaries real rather than aspirational, how a design system is layered, and how component APIs should evolve from props to composition as they grow. It's tested heavily in senior/staff-level frontend interviews specifically because the "right" answer is rarely universal — the value is in reasoning precisely about tradeoffs (what problem does a monorepo actually solve? when does composition genuinely beat more props?) rather than reciting a single "best practice."

## Folder structure

- **`theory/`** — feature-based vs. layer-based structure, monorepo vs. polyrepo, module boundaries and how to enforce them, design system architecture (tokens → primitives → components → patterns), component composition patterns at scale, and micro-frontends as a light-touch architecture-choice overview.
- **`snippets/`** — 5 runnable examples: a complete feature-based folder tree, a dependency-cruiser config, a design-token-to-CSS-variable pipeline, a compound-component implementation, and an ESLint boundaries config.
- **`output-based/`** — 5 "given this setup, what happens?" questions: tracing a change through a layer-based structure, diagnosing a circular dependency between features, a design token's blast radius, a prop-drilling-vs-composition refactor, and a barrel file's effect on bundle size.
- **`scenarios/`** — 5 real-world situations: migrating layer-based to feature-based on a live app, actually enforcing module boundaries (not just documenting them), standing up a design system across three teams, a monorepo shared-component change breaking one consumer, and evaluating a push toward micro-frontends.
- **`interview-qa/`** — 3 themed files: folder structure fundamentals, design systems & composition, and monorepos & module boundaries.
- **`problems/`** — 3 hands-on challenges: designing a feature-based structure for a multi-domain app, setting up import boundary enforcement end to end, and designing a multi-brand/multi-theme design token architecture.
- **`assets/`** — placeholder for diagrams/images (see `assets/README.md`).

## What's covered

- Feature-based vs. layer-based structure, including precisely why layer-based structure breaks down at scale and the hybrid (`features/` + `shared/`) pattern most real codebases converge on
- Monorepo vs. polyrepo, the tooling a monorepo needs (affected-graph builds, remote caching) to not degrade, and the specific tradeoff each makes (version drift vs. atomic blast radius)
- Module boundaries: what a public API vs. internal implementation means for a feature folder, and enforcing it with dependency-cruiser (CI-level) and ESLint boundary plugins (editor-level)
- Design system layering — tokens, primitives, components, patterns — and why skipping the primitive layer (hardcoding raw values) defeats the point of tokens
- Component composition patterns at scale: when prop APIs should give way to compound components, render props/hooks, and slots, with the precise signal for when to make that shift
- Micro-frontends as an architecture choice (light-touch coverage) — what problem it actually solves (independent deployability across genuinely blocked teams) and when it isn't justified by team size alone
