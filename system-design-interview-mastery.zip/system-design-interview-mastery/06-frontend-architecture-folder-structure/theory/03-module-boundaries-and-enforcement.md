# Module Boundaries and Enforcing Them

A folder structure that *implies* boundaries (feature-based organization, a `shared/` folder) is only a convention until something actually enforces it — without enforcement, nothing stops `features/checkout/Checkout.jsx` from directly importing `features/user/internal/authToken.js`, quietly recreating the exact coupling a feature-based structure was meant to prevent.

## What a "module boundary" actually means

A boundary defines two things per module/feature: what it **exposes** (its public API — typically everything re-exported from an `index.js`/`index.ts` barrel file) and what's **internal** (implementation details other modules should never import directly). The distinction matters because internal files are free to change without notice — if another feature reached in and imported an internal file directly, that internal refactor becomes a breaking change for a consumer that was never supposed to depend on it in the first place.

```
features/user/
  index.ts          <- public API: only this should be imported from outside
  UserCard.jsx
  useUser.js
  internal/
    tokenStorage.js  <- internal, never imported from outside features/user/
```

## Enforcement mechanism 1: dependency-cruiser

`dependency-cruiser` statically analyzes your import graph and can fail a build/CI check when a forbidden import exists — e.g., a rule that says "nothing outside `features/user/` may import from `features/user/internal/`," or "no feature may import from another feature except through its `index.ts`."

```js
// .dependency-cruiser.js
module.exports = {
  forbidden: [
    {
      name: "no-cross-feature-internals",
      severity: "error",
      from: { pathNot: "^src/features/([^/]+)/" },
      to: { path: "^src/features/([^/]+)/internal/" },
      comment: "Features must not reach into another feature's internal/ folder",
    },
    {
      name: "no-cross-feature-direct-imports",
      severity: "error",
      from: { path: "^src/features/(?<from>[^/]+)/" },
      to: { path: "^src/features/(?<to>[^/]+)/(?!index)" , pathNot: "^src/features/\\1/" },
      comment: "Features must import each other only via index.ts, not internal files",
    },
  ],
};
```

Running `depcruise --validate` in CI turns "please don't import internals directly" from a code-review nag into a hard, automated failure.

## Enforcement mechanism 2: ESLint boundaries plugins

`eslint-plugin-boundaries` (or `eslint-plugin-import`'s `no-restricted-paths`) achieves a similar result but surfaces the violation directly in the editor as a lint error, catching it before the developer even commits — faster feedback than a separate CI-only check, though typically used alongside dependency-cruiser rather than instead of it (editor-time linting for fast feedback, CI-time graph validation as the actual gate).

## Enforcement mechanism 3: TypeScript project references / path restrictions

In a monorepo, TypeScript project references can make it a **compile error** (not just a lint warning) to import across certain boundaries, by only exposing a package's `dist`/public types rather than its internal source files — this is a stronger guarantee than lint rules because it's enforced by the type system itself, though it requires more upfront project structure investment (separate `tsconfig` per package/feature).

## Why this matters enough to automate

Without enforcement, boundary violations creep in gradually — a developer under deadline pressure reaches into another feature's internals "just this once," it works, nobody notices in review, and six months later there are dozens of such shortcuts, each one making both features harder to change independently (exactly the coupling the folder structure was meant to prevent). Automated enforcement converts an easily-ignored convention into something that fails CI, which is the only reliably durable way large teams keep boundaries intact over years of contributions from many different people.

## What to enforce, concretely

- No feature imports another feature's non-public files (only via its `index`).
- No feature imports "downward" into implementation details of a shared package (only its published/exported API).
- Circular imports between features are forbidden outright (a strong signal the features aren't actually independent and should be merged or have a piece extracted into `shared/`).
- Optionally, layer rules (`shared/` may not import from `features/`, enforcing that shared code has no domain-specific knowledge and the dependency direction stays one-way).
