# Micro-Frontends as an Architecture Choice

Micro-frontends extend the microservices idea to the frontend: splitting a single large application into multiple independently deployable frontend applications, composed together at runtime (or build time) into what the user experiences as one app. This file covers it as a folder/architecture decision at a light touch — it's a large enough topic to deserve full dedicated coverage elsewhere; the goal here is knowing when it's the right call relative to the monorepo/feature-based structures covered in this topic.

## What problem it actually solves

Micro-frontends solve an **organizational scaling** problem, not primarily a technical one: when multiple large, independent teams need to ship to the same product surface on their own release cadence, without coordinating deploys or blocking on each other's release train. A single large SPA owned by one team doesn't have this problem — feature-based folder structure plus good module boundaries (covered elsewhere in this topic) is sufficient there. Micro-frontends earn their complexity specifically when the team-scaling pressure is real: dozens of engineers across several independent teams, each needing to deploy their part of the product without a shared release process becoming the bottleneck.

## The core tradeoff vs. a single (even large, monorepo-based) frontend app

| | Single app (monorepo, feature-based) | Micro-frontends |
|---|---|---|
| Deploy independence | No — one build, one deploy, for the whole app | Yes — each micro-frontend deploys on its own schedule |
| Runtime overhead | Minimal — one framework instance, shared bundle | Real — potentially multiple framework instances, duplicated dependencies unless carefully shared |
| Cross-team coordination for shared UI (design system, auth state) | Straightforward — shared code, shared runtime | Requires deliberate contracts (shared design system package, a defined way to pass auth/user context across app boundaries) |
| Consistency of UX | Easier to keep uniform (one codebase, one set of conventions) | Harder — different teams' micro-frontends can drift in library versions, patterns, even framework choice if not actively governed |
| Operational complexity | Lower | Higher — orchestration layer (module federation, iframe composition, or a meta-framework), versioning contracts between shell and micro-frontends |
| Right team size | Small-to-medium number of contributors, or a monorepo with good boundary enforcement scaling reasonably well even for larger teams | Large number of largely-independent teams where deploy coupling is a proven, felt bottleneck |

## Why "we're a big team" alone isn't sufficient justification

A large team with good feature-based structure, enforced module boundaries (dependency-cruiser/ESLint boundary rules), and solid monorepo tooling (Nx/Turborepo with affected-graph builds) can scale to a genuinely large number of contributors without micro-frontends' runtime and operational costs — those tools solve the *codebase organization* and *build performance* problems that people sometimes reach for micro-frontends to solve. Micro-frontends specifically solve **independent deployability**, which those tools don't provide (a monorepo, however well-organized, typically still ships as one deployed artifact per app unless deliberately split). The decision should hinge on whether independent deployment cadence is a real, felt need — not just team size — because the added runtime/operational cost is substantial and not worth paying otherwise.

## Common integration approaches (brief)

- **Build-time integration:** each micro-frontend is published as a package, composed into a shell app at build time. Simpler, but loses true independent *deployment* (the shell still needs a rebuild to pick up a new version) — closer to a well-structured monorepo than true micro-frontends.
- **Runtime integration via Module Federation (Webpack 5+):** micro-frontends are loaded and composed in the browser at runtime, each independently deployed and fetched on demand — true independent deployability, at the cost of the coordination complexity described above.
- **Server-side/edge composition:** a shell server assembles HTML fragments from multiple independently deployed services (an older but still-used pattern, seen in some large e-commerce platforms) — avoids client-side runtime coordination entirely, shifting composition to the server.

This is intentionally the light-touch version of this topic — see a dedicated micro-frontends resource for integration mechanics, shared-dependency strategies, and cross-app state/routing patterns in depth.
