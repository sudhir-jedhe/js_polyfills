# Component Composition Patterns at Scale

As a component's configurability grows, there's a recurring architectural choice: keep adding props, or restructure around composition. This file covers the patterns that keep components maintainable as requirements grow — the same underlying problem shows up across React, Vue, and most component-based UI frameworks.

## The prop-explosion problem

A component that starts simple accretes props as new requirements arrive:

```jsx
<Modal
  title="Confirm"
  showCloseButton
  footerAlign="right"
  footerButtons={[{ label: "Cancel" }, { label: "Confirm", variant: "danger" }]}
  headerIcon="warning"
  bodyPadding="lg"
  onClose={handleClose}
/>
```

Every new layout variation becomes another prop, the component's internals grow a wall of conditionals to interpret prop combinations, and eventually some desired layout simply isn't expressible through the prop API at all — forcing either an escape-hatch prop (`renderCustomFooter`) or a fork of the component.

## Fix: compound components (composition over configuration)

Instead of configuring internals via props, expose the pieces as separate components meant to be composed by the consumer, sharing implicit state via context:

```jsx
<Modal onClose={handleClose}>
  <Modal.Header icon="warning">Confirm</Modal.Header>
  <Modal.Body>Are you sure you want to proceed?</Modal.Body>
  <Modal.Footer align="right">
    <Button variant="secondary">Cancel</Button>
    <Button variant="danger">Confirm</Button>
  </Modal.Footer>
</Modal>
```

`Modal.Header`, `Modal.Body`, `Modal.Footer` are subcomponents that share context set up by the parent `Modal` (e.g., an `onClose` handler, focus-trap state) without the consumer needing to pass it explicitly at every level. This is the pattern used by most mature component libraries (Radix, Reach UI, Headless UI) precisely because it scales to arbitrary layout variation — the consumer controls composition/order/content directly with JSX, rather than the component author needing to anticipate every combination as a prop.

## Fix: render props / children-as-function (logic reuse without prop explosion)

When the thing being shared is **behavior/state**, not layout, a render-prop pattern exposes that state to arbitrary consumer-defined rendering:

```jsx
<Toggle>
  {({ isOn, toggle }) => (
    <button onClick={toggle}>{isOn ? "ON" : "OFF"}</button>
  )}
</Toggle>
```

Largely superseded by hooks in React specifically (`useToggle()` achieves the same reuse more directly when no wrapping DOM/context is needed), but the underlying pattern — separate stateful logic from rendering, let the consumer own the render — remains relevant, and render props are still the right tool when the shared logic needs to wrap children in DOM/context the way a hook alone cannot.

## Fix: slots (explicit named composition points)

Similar goal to compound components, implemented via named prop slots instead of subcomponent context:

```jsx
<Card
  header={<CardHeader title="Report" />}
  actions={<Button>Export</Button>}
>
  {bodyContent}
</Card>
```

Simpler to implement than full compound components (no context needed), but less flexible about ordering/conditional composition than compound components, since each slot is a fixed prop position rather than freely arranged JSX children.

## Comparison: when to reach for which

| Pattern | Best for | Weakness |
|---|---|---|
| Plain props | Small, stable configuration surface (a handful of variants) | Explodes combinatorially as variation grows |
| Compound components | Complex layout composition with implicit shared state (Modal, Tabs, Accordion, Menu) | More implementation complexity (context setup); consumer must know the subcomponent API |
| Render props / children-as-function | Sharing stateful *behavior* without prescribing markup | Can nest awkwardly ("render prop hell") when combining several; largely replaced by hooks where a wrapper isn't required |
| Slots | Simple named composition points without full compound-component machinery | Less flexible ordering/conditional logic than compound components |
| Hooks (logic extraction) | Sharing pure stateful logic with no required wrapping markup/context | Doesn't help when the shared concern requires DOM structure or context, not just state |

## The general principle

The signal that a component should shift from configuration (props) to composition (compound components/slots) is when you notice yourself adding boolean/enum props specifically to control **layout or content structure** rather than genuine behavioral variants — `showFooter`, `footerAlign`, `hideCloseButton` are all layout decisions that composition expresses more naturally than an ever-growing prop surface, whereas `variant="danger"` or `disabled` are legitimate small-surface configuration that composition would be overkill for.
