# Design System Architecture: Tokens → Primitives → Components → Patterns

A design system is a layered architecture, not a flat folder of components — and understanding the layering is what lets you answer "where does this new piece of UI belong" consistently, rather than every contributor guessing.

## The four layers

### 1. Design tokens

The smallest, most atomic values — raw design decisions with no UI behavior attached: colors, spacing units, font sizes, border radii, shadow values, animation durations. Tokens are typically defined once (often in a platform-agnostic format like JSON) and compiled to whatever each consumer needs (CSS custom properties, a JS object, iOS/Android native formats for cross-platform design systems).

```json
{
  "color.brand.primary": "#2563eb",
  "color.text.default": "#111827",
  "spacing.sm": "8px",
  "spacing.md": "16px",
  "radius.default": "6px"
}
```

### 2. Primitives

The smallest reusable UI building blocks, styled using *only* tokens, with no business logic and minimal-to-no composition of other components: `Button`, `Input`, `Text`, `Icon`, `Stack` (a layout primitive for spacing children). A primitive should be usable in essentially any context — it knows nothing about the product domain.

### 3. Components

Compositions of multiple primitives into a more complete, still domain-agnostic UI unit: `Modal` (composes `Stack`, `Button`, `Text`, an overlay), `Card`, `FormField` (composes `Input` + a label `Text` + error message handling). Still no business/domain knowledge — a `Card` doesn't know about "orders" or "users," just that it renders a bordered container with a header/body/footer slot structure.

### 4. Patterns

Domain-aware compositions built from components (and primitives), often living outside the design system itself, in application/feature code: a `CheckoutSummaryCard` that uses the design system's `Card` and `Button` but knows about order totals, line items, and checkout-specific business rules. Patterns are the boundary where "design system" ends and "application code" begins.

## Why the layering matters

Each layer should only depend on the layer(s) below it, never sideways or up — a primitive never imports a pattern, and ideally components don't reach past primitives into raw token values directly (they should go through primitives, or well-defined component-level tokens) except where the primitive layer doesn't yet cover a needed value. This one-way dependency flow is what makes token changes safely propagate: updating `color.brand.primary` in the token layer should ripple through every primitive, component, and pattern that (transitively) uses it, without anyone needing to touch each consumer individually — but only if every layer actually respects the boundary and nothing hardcodes a raw hex value bypassing tokens.

```
tokens  →  primitives  →  components  →  patterns (app-level)
 (values)   (Button)      (Modal, Card)   (CheckoutSummaryCard)
```

## Comparison of what belongs where

| Layer | Example | Knows about brand/tokens? | Knows about business domain? |
|---|---|---|---|
| Tokens | `color.brand.primary` | N/A (it *is* the value) | No |
| Primitives | `Button`, `Input`, `Text` | Yes, via tokens | No |
| Components | `Modal`, `Card`, `FormField` | Yes, transitively | No |
| Patterns | `CheckoutSummaryCard` | Yes, transitively | Yes |

## Common architectural mistake

Skipping the primitive layer and having components hardcode raw values (`padding: 16px` instead of `padding: var(--spacing-md)`) defeats the entire point of tokens — a rebrand or theme change then requires hunting down every hardcoded value instead of updating the token source once. Similarly, letting patterns leak upward into the design system package (a `CheckoutButton` living inside the design system rather than application code) couples the design system's release cycle to one product's domain logic, which breaks the "usable by any product" premise a shared design system exists for.
