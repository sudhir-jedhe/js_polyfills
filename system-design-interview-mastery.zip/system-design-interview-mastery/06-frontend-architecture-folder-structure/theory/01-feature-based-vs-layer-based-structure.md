# Feature-Based vs. Layer-Based Folder Structure

This is the foundational organizational decision for any nontrivial frontend codebase, and it's usually the very first thing that goes wrong at scale when teams default to the structure that felt natural for a small app.

## Layer-based (a.k.a. "technical" or "type-based") structure

Files are grouped by **what kind of thing they are**, across the whole app:

```
src/
  components/
    UserCard.jsx
    ProductCard.jsx
    OrderSummary.jsx
    Checkout.jsx
  hooks/
    useUser.js
    useProduct.js
    useOrder.js
  services/
    userApi.js
    productApi.js
    orderApi.js
  reducers/
    userReducer.js
    productReducer.js
    orderReducer.js
```

This is the structure almost every tutorial and starter template ships with, because it maps directly onto framework concepts (components, hooks, services) and looks organized at a small scale.

## Feature-based (a.k.a. "domain" or "module") structure

Files are grouped by **what business capability they implement**, with each feature folder internally containing its own components, hooks, services, etc.:

```
src/
  features/
    user/
      UserCard.jsx
      useUser.js
      userApi.js
      userReducer.js
    product/
      ProductCard.jsx
      useProduct.js
      productApi.js
      productReducer.js
    order/
      OrderSummary.jsx
      Checkout.jsx
      useOrder.js
      orderApi.js
      orderReducer.js
```

## Why layer-based structure breaks down at scale

The core problem is that **working on one feature requires touching files scattered across every top-level folder** — implementing "orders" means jumping between `components/OrderSummary.jsx`, `hooks/useOrder.js`, `services/orderApi.js`, and `reducers/orderReducer.js`, none of which are colocated. As the app grows, each layer folder (`components/`, `hooks/`, `services/`) accumulates files from every feature with no structural boundary between them — nothing stops `OrderSummary.jsx` from importing `userApi.js` directly, because there's no folder boundary signaling "these belong to different domains." This is precisely what makes layer-based structure prone to accidental coupling between unrelated features, and why deleting or extracting a feature later means hunting through every layer folder rather than deleting one directory.

## Why feature-based structure scales better

Each feature folder is a self-contained vertical slice: everything needed to understand, modify, or delete the "order" feature lives in `features/order/`. This gives you natural, enforceable module boundaries (see `03-module-boundaries-and-enforcement.md`), makes it obvious where new code for a feature belongs, and means deleting a feature is (ideally) deleting one folder. It also parallels how most teams are actually organized — a team owning "checkout" typically owns a folder, not a scattered set of files across `components/`, `hooks/`, and `services/`.

## Comparison

| | Layer-based | Feature-based |
|---|---|---|
| Grouped by | Technical role (component, hook, service) | Business capability (user, order, product) |
| Colocation | Poor — related files scattered across top-level folders | Strong — everything for a feature lives together |
| Coupling risk | High — nothing prevents cross-feature imports at the same layer | Lower — folder boundary makes cross-feature imports visible, enforceable |
| Scales to large teams | Poorly — team ownership doesn't map to any folder | Well — a feature folder can map directly to a team's ownership |
| Best for | Very small apps, prototypes, apps unlikely to grow past a handful of features | Apps with multiple features/domains and more than a couple of contributors |
| Common pitfall | "God folders" (`components/` with 200 files) | Ambiguous features (does `notifications` belong in every feature, or its own?), shared code sprawl |

## The realistic answer: hybrid

Most production codebases end up hybrid: feature-based at the top level for anything domain-specific, plus a `shared/` (or `common/`) top-level folder for genuinely cross-cutting things — a design-system button, a generic `useDebounce` hook, an API client wrapper. The discipline that matters is being deliberate about what qualifies as "shared" (used by 3+ unrelated features, has no business-domain knowledge) rather than letting `shared/` become a dumping ground that recreates the layer-based god-folder problem one level down.
