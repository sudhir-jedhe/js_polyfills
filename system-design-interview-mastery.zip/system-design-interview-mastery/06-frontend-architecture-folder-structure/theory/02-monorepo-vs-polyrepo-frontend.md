# Monorepo vs. Polyrepo for Frontend

This decision is about where **repository boundaries** sit relative to your applications and shared packages (e.g., a design system, a set of shared utilities, multiple related frontend apps) — separate from feature-based vs. layer-based structure, which is about organization *within* a single codebase.

## Polyrepo

Each app or package lives in its own separate git repository, published/consumed via a package registry (npm, a private registry) when one needs another's code.

```
design-system/         (own repo, own CI, publishes @company/design-system to npm)
marketing-site/        (own repo, depends on @company/design-system@2.3.1)
admin-dashboard/       (own repo, depends on @company/design-system@2.1.0)
```

## Monorepo

All apps and shared packages live in one repository, typically with a workspace tool (Nx, Turborepo, Lerna, or plain npm/pnpm/yarn workspaces) managing cross-package dependencies without needing to publish to a registry for internal consumption.

```
repo/
  apps/
    marketing-site/
    admin-dashboard/
  packages/
    design-system/
    utils/
    api-client/
```

## Comparison

| | Monorepo | Polyrepo |
|---|---|---|
| Cross-package changes | One PR can update a shared package and all its consumers atomically | Requires publishing a new version, then separate PRs in each consuming repo to bump it |
| Versioning | Can use a single version, or per-package versioning with tooling (Changesets) — internal consumers often just use the workspace's latest via symlink, no publish step needed | Every shared package change requires an explicit publish + version bump cycle |
| Dependency drift | Much harder to end up with 4 apps on 4 different major versions of the design system | Common — apps can each pin different versions indefinitely, silently diverging |
| CI/build complexity | Needs smart build tooling (only rebuild/retest what changed) to stay fast as the repo grows — the naive "run everything on every commit" doesn't scale | Simpler per-repo CI, but no visibility into whether a shared package change broke a downstream consumer until that consumer bumps and finds out |
| Discoverability | Easy to see and grep across all usages of a shared component/utility | Requires searching multiple repos, or trusting each repo's own dependency declarations |
| Access control granularity | Coarser by default — everyone with repo access can see everything (mitigated with tooling like CODEOWNERS and path-based permissions) | Finer-grained naturally — repo-level access controls map directly to project boundaries |
| Tooling investment | Higher upfront (workspace tool, task orchestration, caching) to avoid CI slowdown at scale | Lower upfront — plain per-repo CI works fine initially |

## The core tradeoff, stated precisely

Monorepo optimizes for **coordinated change across many consumers of shared code** — the moment you have a design system or shared utility library consumed by 3+ apps, the ability to update the shared package and all consumers in one atomic commit (and have CI verify nothing broke, before merge) is the single biggest practical win, because it eliminates the "shared package version drift" problem where different apps silently run different, incompatible versions of the same code indefinitely. Polyrepo optimizes for **independent deployability and access isolation** — teams that genuinely don't share code, or need strict repository-level access boundaries (e.g., separating a public open-source package's repo from private app code), are better served by polyrepo's clean separation.

## What tooling a monorepo needs to not fall over

A monorepo without proper tooling degrades badly as it grows: CI that reruns every app's full test suite on every commit becomes unbearably slow. The standard fix is **affected-graph-aware task running** — tools like Nx or Turborepo compute which packages actually changed (and which downstream packages depend on them) and only build/test/lint that subset, plus remote caching so a build already done by one CI run (or one teammate) is reused rather than repeated. Without this, teams often "discover" monorepo doesn't scale, when the actual issue is missing incremental-build tooling, not the monorepo structure itself.

## Practical guidance

Default to monorepo when you have (or will soon have) multiple apps sharing a meaningful amount of code (design system, common utilities, API clients) — the coordinated-change benefit compounds as the number of shared-code consumers grows. Default to polyrepo (or keep apps split) when apps are genuinely independent with minimal code sharing, or when strict access isolation between codebases is a hard requirement rather than a nice-to-have.
