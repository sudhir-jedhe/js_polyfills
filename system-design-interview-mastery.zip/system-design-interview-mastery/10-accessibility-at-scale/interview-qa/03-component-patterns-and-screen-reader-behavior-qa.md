# Interview Q&A — Component Patterns and Screen Reader Behavior

**Q: Why does a custom combobox use `aria-activedescendant` instead of moving real DOM focus into the suggestion list as the user presses arrow keys?**
Because moving real focus off the text input breaks the fundamental type-ahead interaction — the user could no longer type/refine their query while browsing suggestions, since keystrokes would no longer reach the input. `aria-activedescendant` lets the input announce which option is virtually "active" to assistive technology while real DOM focus stays on the input the entire time, so typing and arrow-key browsing can happen seamlessly together.

**Q: What's the difference between a screen reader's "browse mode" and "focus mode," and why does it matter for custom widgets?**
Browse (virtual cursor) mode lets a user read through static content using the screen reader's own navigation, independent of real keyboard focus. Focus mode passes keystrokes through to the actual page/component, activated when the virtual cursor lands on an interactive element. It matters for custom widgets because a `<div>` with a click handler but no proper role/focus semantics may never trigger focus mode at all — making it effectively invisible as an interactive control to a screen reader user, even though it visually works for a mouse user.

**Q: What four things does a fully correct accessible modal need, together?**
Correct ARIA (`role="dialog"`, `aria-modal="true"`, a labelled accessible name/description), a real focus trap (focus moves in on open, `Tab` is contained, focus restored to the trigger on close), background content made genuinely `inert` (not just visually covered), and a reliable close mechanism (`Escape` key plus a visible, labeled close button). All four are required together — correct ARIA without focus management, or vice versa, leaves the component broken for at least one class of user.

**Q: Why is `aria-hidden="true"` on a focusable element a real bug rather than a harmless simplification?**
Because `aria-hidden` removes an element from the accessibility tree but does nothing to remove it from the keyboard tab order — a keyboard user can still `Tab` onto and interact with the element, but a screen reader running alongside announces nothing when focus lands there. This creates an inconsistent state across modalities (visually/keyboard present, but silent to screen readers) rather than cleanly hiding the element for everyone.

**Q: Why should you test with more than one screen reader/browser pairing rather than just one?**
ARIA support and the mapping from the accessibility tree to browser behavior isn't perfectly uniform across engines — the same page can behave differently between, say, NVDA+Firefox and NVDA+Chrome. Testing in only one pairing and assuming the result generalizes is a common real gap; a realistic testing routine covers at least the most common pairings relevant to the actual user base (e.g. VoiceOver+Safari and NVDA+Firefox/Chrome).

**Q: A page's CSS visually reorders content (e.g. via flexbox `order`) so it looks correct to sighted users. Does this affect screen reader users?**
Yes — a screen reader's browse-mode reading order follows DOM order, not visual/CSS order. If CSS repositions content so the visual order diverges from the DOM order, a screen reader user hears content in a sequence that doesn't match what a sighted user sees, which is confusing in a way no automated structural tool flags, since the DOM itself is perfectly "valid" markup regardless of how it's visually repositioned.
