# Interview Q&A — WCAG Conformance and Organizational Practice

**Q: What are the three WCAG conformance levels, and which one should most organizations actually target?**
A (minimum baseline), AA (mid-tier, addresses the most common and significant barriers), and AAA (highest, but includes criteria not achievable for all content types). AA is the practical, near-universal target — it's what most legal/regulatory frameworks reference in practice, and WCAG itself explicitly does not recommend AAA as a general sitewide policy.

**Q: Does conformance to "AA" mean only satisfying the AA-level success criteria?**
No — conformance to a level requires satisfying that level's criteria **and** every level below it. "AA conformance" means all of Level A's criteria plus all of Level AA's criteria; there's no such thing as meeting only the AA-specific items while skipping Level A.

**Q: If AAA has valuable criteria, why not adopt some of them even without claiming full AAA conformance?**
That's the recommended practical approach — cherry-pick individual AAA criteria where they're low-cost and high-value for specific content (e.g. a plain-language/lower-reading-level requirement for critical instructional content), without claiming or requiring full AAA conformance sitewide. This avoids committing to a blanket standard some content genuinely can't meet, while still capturing the value of the criteria that are cheap to adopt.

**Q: How should conformance be tracked across a large product — as a single pass/fail score, or something more granular?**
Per-criterion, not as one aggregate number. A product might be fully compliant on contrast and keyboard operability but have real gaps in a specific criterion in one feature area — an aggregate score obscures exactly where remediation work is needed, while per-criterion tracking makes the actual gaps visible and prioritizable.

**Q: For a regulated industry (e.g. healthcare, finance), does the WCAG target change?**
The recommended target level (AA) generally stays the same — WCAG's own AAA caveats don't change based on industry. What changes is the **rigor of enforcement**: a regulated, high-exposure context justifies treating AA conformance as a hard launch gate with manual/screen-reader verification on core flows, rather than a best-effort aspiration, given the elevated legal and user-impact stakes.

**Q: What's a common mistake teams make when trying to comply with WCAG at the organizational level?**
Treating it as a one-time audit/checklist exercise rather than an ongoing practice embedded in tooling and defaults (design system primitives, CI-enforced automated checks, PR review habits). A point-in-time audit can certify a product as compliant on the day it's checked, but without embedded practice, the next feature shipped can just as easily reintroduce the same violations that were fixed.
