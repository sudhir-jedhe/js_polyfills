Diagrams and reference images for accessibility at scale (e.g. a focus trap flow diagram, a roving tabindex state diagram, a WCAG conformance level comparison chart) will be added here.
