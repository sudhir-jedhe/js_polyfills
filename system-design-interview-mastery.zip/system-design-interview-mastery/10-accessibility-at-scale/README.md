# Accessibility at Scale

Accessibility interview questions rarely stop at "add alt text and ARIA labels" — the harder, more senior version of this topic is how accessibility holds up across a large product surface with many teams: whether correctness lives in shared design-system primitives or gets re-derived per page, whether automated tooling actually catches what it claims to, and whether custom widgets (a modal, a combobox) implement the real interaction model or just superficially valid markup. This topic is built around that scaling lens throughout — not "what is WCAG" in isolation, but how an organization keeps a large, many-team product accessible without relying on every engineer independently getting every detail right.

## Folder structure

- **[`theory/`](./theory)** — accessible design systems (tokens, primitives), focus management (trapping, roving tabindex), automated vs. manual testing, WCAG conformance levels in a real org context, the accessible modal pattern, the accessible autocomplete/combobox pattern, and screen reader testing basics.
- **[`snippets/`](./snippets)** — 5 focused examples: contrast-validated color tokens, a focus-trap hook in use, axe-core in component and E2E tests, `aria-live` region announcements, and roving tabindex for a tab list.
- **[`output-based/`](./output-based)** — 5 "given this setup, what happens?" questions: a modal that passes axe-core but fails manual keyboard testing, `alt` text that passes automated checks but fails real usability, a combobox that breaks by moving real focus into its suggestion list, dark-mode token inversion silently breaking contrast, and `aria-hidden` on a still-focusable element.
- **[`scenarios/`](./scenarios)** — 5 real-world design/fix situations: embedding accessibility into a design-system rollout, rolling out automated testing on a 5-year-old codebase without blocking development, diagnosing a custom dropdown a screen reader user reports as broken, choosing a WCAG conformance target for a regulated industry, and onboarding a team with zero prior accessibility practice.
- **[`interview-qa/`](./interview-qa)** — 3 themed files: design systems/focus management/testing strategy, WCAG conformance and organizational practice, and component patterns/screen reader behavior.
- **[`problems/`](./problems)** — 3 hands-on challenges: build a reusable, dynamically-correct focus-trap hook, design an accessible multi-select combobox (tag input), and audit-and-fix a realistically broken signup form.
- **[`assets/`](./assets)** — placeholder for diagrams (see `assets/README.md`).

## What's covered

- Why accessibility fixes that live in shared design-system tokens and component primitives scale across many teams in a way page-by-page fixes never do — and why theme/dark-mode generation must re-validate contrast rather than assume it's preserved under a color transform
- The precise mechanics of focus trapping (modals) and roving tabindex (toolbars, tab lists) — what each solves, and why a `tabindex`-based composite widget needs exactly one live `tabindex="0"` stop at a time
- What automated tools (axe-core) can and structurally cannot catch, why a component can pass every automated check and still be unusable by keyboard, and how to roll out CI-enforced testing on a large existing codebase without an all-or-nothing cutover (baseline-gating)
- WCAG conformance levels (A/AA/AAA) and why AA — not AAA — is the real-world target WCAG itself recommends, including how conformance is defined cumulatively and how to selectively adopt individual AAA criteria
- The accessible modal pattern (ARIA + focus trap + inert background + reliable close) and the accessible combobox pattern (`aria-activedescendant`-driven virtual navigation that keeps real focus on the input) as the two most commonly mis-implemented custom widgets
- Screen reader testing fundamentals — browse mode vs. focus mode, why browser/screen-reader pairing affects behavior, and what a minimal but realistic manual testing routine actually checks
