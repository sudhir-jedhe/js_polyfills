# Output: `aria-hidden="true"` on a Focusable Element

```html
<div class="card">
  <img src="promo.png" alt="" />
  <div aria-hidden="true">
    <button onclick="dismissPromo()">Dismiss</button>
  </div>
</div>
```
The developer's intent, per a code comment left in the original PR: "hide this decorative wrapper div from screen readers since the promo card is non-essential."

**Question:** What actually happens for a keyboard/screen-reader user encountering this markup, and why is this a real bug rather than achieving the intended "hide non-essential content" goal?

**Answer:** This produces a **broken, inconsistent state**, not a clean hide. `aria-hidden="true"` removes the element (and its subtree) from the accessibility tree — so a screen reader user browsing via their virtual cursor will correctly skip over "Dismiss" and never hear it announced. **But** the `<button>` inside is still a real, focusable DOM element — nothing about `aria-hidden` removes it from the **keyboard tab order**. A keyboard-only user (who may or may not also be a screen-reader user — this affects sighted keyboard-only users too, e.g. someone with a motor impairment using only a keyboard) can still `Tab` directly onto this button, see it visually rendered (assuming no other CSS hides it), and interact with it — but a screen reader running alongside would announce **nothing** when focus lands there, because `aria-hidden="true"` suppressed it from the accessibility tree despite real focus landing on it. This exact mismatch — focusable but `aria-hidden` — is one of axe-core's actual flagged rules (`aria-hidden-focus`), specifically because it's a common, non-obvious bug.

**Why this is worse than either extreme:** a fully hidden button (`display: none`) would be consistently absent for everyone. A fully visible, focusable, announced button would be consistently present for everyone. This configuration is inconsistent **across modalities** — visually present, keyboard-focusable, but silent to screen readers — which is confusing specifically for the population most likely to be relying on multiple assistive technologies together, or for a screen-reader user whose device also has a physical keyboard sending focus events independently of their swipe-based virtual cursor navigation (common on mobile screen readers).

**Fix:** if the goal is genuinely to remove the entire card (including the dismiss button) from both keyboard and screen-reader access, use the `inert` attribute (or `hidden`) on the actual container, which removes an element from **both** the tab order and the accessibility tree consistently:
```html
<div class="card" inert>
  <img src="promo.png" alt="" />
  <div><button onclick="dismissPromo()">Dismiss</button></div>
</div>
```
If instead the button should remain interactive for everyone (which is far more likely the actual intent for a "Dismiss" action — it's not decorative, it's a real control the user might want), the fix is simply removing the errant `aria-hidden="true"` entirely rather than trying to selectively hide only "supporting" content around a real interactive control.
