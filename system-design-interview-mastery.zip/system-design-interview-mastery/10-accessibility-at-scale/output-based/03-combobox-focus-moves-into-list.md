# Output: Combobox Implementation Moves Real Focus Into the List

```jsx
function BrokenCombobox({ options }) {
  const [query, setQuery] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const optionRefs = useRef([]);
  const filtered = options.filter(o => o.includes(query));

  function handleKeyDown(e) {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      optionRefs.current[0]?.focus(); // moves REAL DOM focus to the first option
    }
  }

  return (
    <>
      <input value={query} onChange={(e) => setQuery(e.target.value)} onKeyDown={handleKeyDown} />
      {isOpen && (
        <ul role="listbox">
          {filtered.map((opt, i) => (
            <li key={opt} ref={(el) => (optionRefs.current[i] = el)} tabIndex={-1} role="option">
              {opt}
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
```

**Question:** A user types "app" to filter a fruit list, then presses `ArrowDown` intending to browse suggestions while continuing to refine their search. What goes wrong?

**Answer:** Pressing `ArrowDown` calls `.focus()` on the first `<li>` option, moving **real DOM focus away from the `<input>`**. The user can no longer type — their next keystroke doesn't reach the text input at all (it's not focused anymore), so continuing to refine the query ("appl" → "apple") is now impossible without first navigating focus back to the input manually. This directly breaks the fundamental interaction model of a type-ahead: filter while browsing, seamlessly, without focus ping-ponging between the input and the list.

**Why this is the textbook combobox mistake:** the correct pattern (see the accessible-autocomplete theory file) keeps real DOM focus on the `<input>` at all times and represents the "currently highlighted option" purely via `aria-activedescendant` pointing at the option's ID — arrow keys update which option is virtually active without ever calling `.focus()` on a list item. This implementation does the opposite: it uses real focus movement to represent list navigation, which happens to make the currently-focused `<li>` announced correctly by a screen reader (focus did move there, after all) but at the direct cost of the input losing focus and becoming unusable for continued typing.

**Fix:** remove the `.focus()` call on the list item entirely; instead track `activeIndex` in component state, set `aria-activedescendant={`option-${activeIndex}`}` on the `<input>`, and set `aria-selected` on the corresponding `<li>` — focus never leaves the input, and the screen reader still correctly announces the active option via the ARIA relationship rather than an actual focus change.
