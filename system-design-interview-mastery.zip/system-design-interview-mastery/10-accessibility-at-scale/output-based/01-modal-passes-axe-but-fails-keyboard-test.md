# Output: Modal Passes axe-core but Fails Manual Keyboard Testing

```jsx
function Modal({ isOpen, onClose, title, children }) {
  if (!isOpen) return null;
  return (
    <div role="dialog" aria-modal="true" aria-labelledby="modal-title">
      <h2 id="modal-title">{title}</h2>
      {children}
      <button onClick={onClose} aria-label="Close">×</button>
    </div>
  );
}
```
This component's `jest-axe` test reports **zero violations**.

**Question:** A QA engineer manually tests this modal with only a keyboard and finds it unusable — what's broken, and why didn't axe-core catch it?

**Answer:** Opening the modal never moves keyboard focus into it, and nothing constrains `Tab` to stay within it — a keyboard user who opens the modal finds focus still sitting wherever it was on the underlying page (e.g. the button that triggered the modal, or worse, has moved elsewhere if the page re-rendered). Pressing `Tab` continues cycling through the page **behind** the modal, which the user may not even be able to see clearly is now covered. Closing the modal doesn't restore focus anywhere deliberate either.

**Why axe-core reports no violations despite this being badly broken:** axe-core checks static, mechanically-verifiable DOM properties — `role="dialog"` is present, `aria-modal="true"` is present, `aria-labelledby` correctly references an existing element, the close button has an accessible name. All of that is **structurally valid**. What's missing is **behavior** — where focus moves on open, whether `Tab` is contained, where focus goes on close — none of which is a static DOM property axe-core (or any purely static analysis tool) can observe, because it only exists as a sequence of events over time, not a fixed markup state. This is the concrete illustration of the automated-vs-manual-testing theory file's central point: axe-core verifies mechanical correctness, not actual keyboard interaction behavior.

**Fix:** add the focus-trap logic (move focus in on open via `.focus()` on the first focusable element or the dialog container, intercept `Tab`/`Shift+Tab` at the boundaries to wrap within the dialog, and restore focus to the triggering element on close) — none of which axe-core would have flagged as missing, but all of which a five-minute manual keyboard walkthrough surfaces immediately.
