# Scenario: Rolling Out Automated Accessibility Testing on a 5-Year-Old Codebase

**Scenario:** Leadership wants CI-enforced accessibility testing added to a large, 5-year-old product with no prior a11y tooling. A first trial run of axe-core against the main app pages surfaces 1,400 violations. The team is asking whether to just fix everything before turning on CI enforcement (estimated: months of work) or skip automated testing since "the codebase is too far gone."

**Approach:**

**1. Reject both extremes explicitly — this is a false binary.** "Fix everything first" blocks any enforcement value for months and risks the effort stalling entirely (a giant, unscoped remediation backlog rarely gets prioritized against feature work). "Skip it because there's too much debt" guarantees the violation count only grows as new code ships, making the eventual fix even larger. The right framing: **stop the bleeding immediately, remediate the backlog separately and incrementally.**

**2. Snapshot the current 1,400 violations as a tracked baseline, and gate CI on "no new violations beyond the baseline."** This is the direct technical answer:
```js
const baseline = loadBaseline(); // the 1,400 known violations, committed as a JSON snapshot
const current = await runAxeAcrossPages();
const newViolations = current.filter(v => !baseline.some(b => matchesViolation(b, v)));
if (newViolations.length > 0) throw new Error(`${newViolations.length} new violations introduced`);
```
This ships CI enforcement **today**, with zero remediation work required upfront — it guarantees the codebase never gets *worse* from this point forward, which is a real, immediate, and achievable win, independent of how long the existing-debt cleanup takes.

**3. Separately, prioritize the 1,400-item backlog by real user impact, not by count.** Not all 1,400 are equally severe — group them by rule type and by page traffic/criticality: a missing-label violation on a low-traffic internal admin page is a very different priority than a broken focus trap on the checkout flow. A reasonable triage: critical user flows (checkout, account creation, core product actions) first, high-frequency violation types (if 400 of the 1,400 are the same root-cause pattern — e.g. one shared component — fixing that one component clears a large fraction of the backlog at once) second, then long-tail cleanup.

**4. Track baseline reduction as an explicit, visible metric over time**, not just a one-time snapshot — e.g. a dashboard showing baseline count trending down sprint over sprint, so remediation progress is visible and can be prioritized against other work with actual data, rather than being an invisible, perpetually-deprioritized backlog item.

**5. Set an explicit end-state goal and timeline, even if generous** — e.g. "baseline reaches zero within two quarters," reviewed periodically — an open-ended "we'll get to it eventually" baseline tends to never actually shrink, since the CI gate already prevents things from getting *worse*, which quietly removes the forcing function that would otherwise pressure teams to also fix the *existing* debt.

**Why this converts an unscoped 1,400-item problem into two scoped, independently-solvable problems:** *"Gating on 'no new violations' is a small, immediate, unconditional win that requires zero cleanup work to ship — it just stops the debt from growing. The 1,400 existing violations become a separate, prioritizable backlog rather than a blocker to getting any automated protection live at all. Treating both as one all-or-nothing problem is exactly what leads teams to either stall for months or give up on tooling entirely."*
