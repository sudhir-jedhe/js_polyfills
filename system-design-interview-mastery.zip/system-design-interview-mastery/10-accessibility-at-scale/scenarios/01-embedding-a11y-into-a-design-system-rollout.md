# Scenario: Embedding Accessibility Into a Design System Rollout

**Scenario:** Your company has 40 product teams consuming a shared design system. An accessibility audit found the same three bug classes repeated across dozens of teams' pages: insufficient contrast on secondary text, unlabeled icon-only buttons, and modals with broken focus management. Leadership wants this fixed for good, not just patched page by page. Design the plan.

**Approach:**

**1. Diagnose that this is a systemic, not per-team, problem — and say so explicitly before proposing a fix.** Three bug classes repeated across 40 teams independently is strong evidence the root cause lives in the **shared primitives and tokens**, not in 40 teams independently making the same mistake by coincidence — most likely, the design system's `IconButton`, `Modal`, and secondary-text color token don't enforce correctness, so every consuming team has to independently know and apply the right pattern, and most don't.

**2. Fix each bug class at its root — the shared component/token, not each occurrence.**
- **Contrast:** audit and, if necessary, darken the `text-secondary` token itself so it passes AA by construction against its documented surface pairing (per the design-systems theory file) — this one token change propagates the fix to every consumer automatically, with zero code changes required on their part.
- **Unlabeled icon buttons:** add a build-time or runtime guardrail directly in the `IconButton` primitive that requires an `aria-label` (or visible text) whenever no text children are passed — a missing label becomes a build error or a loud dev-console warning, not a silent accessibility bug that ships.
- **Modal focus management:** fix the focus-trap/restore logic once inside the shared `Modal` primitive (see the focus-management theory file) — every team using `<Modal>` inherits the fix without touching their own code, the moment they bump the design system's version.

**3. Distinguish "fixed going forward" from "fixed for existing usages" — these require different follow-up.** Token and primitive fixes only help teams who **update to the new design system version** — a team pinned to an old version, or one that copy-pasted a modal implementation instead of using the shared primitive (a common way teams drift from a design system in practice), doesn't get the fix automatically. The plan needs an explicit remediation track: identify teams still on outdated versions or with local forks, and prioritize their migration separately from "the fix now exists."

**4. Add regression prevention at the design-system level, not just the fix.** Wire axe-core into the design system's own component test suite (not just each consuming team's tests) so a future regression in `IconButton` or `Modal` is caught before a new version ships to all 40 teams at once — a single regression at this layer has a 40x larger blast radius than a bug in one team's page, which raises the bar for how rigorously the shared layer itself needs to be tested.

**5. Communicate the fix as a mandatory version bump with a migration deadline, not an optional upgrade.** Given the audit already found real, repeated violations, this isn't a "nice to have when you get to it" — pair the technical fix with a rollout plan (a company-wide announcement, a tracked migration dashboard across the 40 teams, and a deadline, potentially tied to legal/compliance risk if that's a live factor for the organization).

**Why fixing the primitive is the actual leverage point, not a 40-team fix-it sprint:** *"Patching the same three bugs across 40 teams' individual pages fixes today's instances but not the next feature any of those teams ship — the design system's shared primitives are the single point of leverage where a fix propagates everywhere at once. The harder, equally necessary part is the migration/version-adoption tracking, since a token or primitive fix only helps teams who actually pull in the new version."*
