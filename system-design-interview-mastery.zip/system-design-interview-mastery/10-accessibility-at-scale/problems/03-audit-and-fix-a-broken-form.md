# Problem: Audit and Fix an Inaccessible Signup Form

## Problem Statement

Given the following signup form markup, identify every accessibility defect and produce a corrected version. Treat this as a real audit — justify each fix against a specific user-impact reason, not just "this is a rule."

```html
<div class="signup-form">
  <div class="field">
    <div class="field-label">Email</div>
    <input type="text" class="email-input" />
  </div>
  <div class="field">
    <div class="field-label">Password</div>
    <input type="text" />
    <div class="hint" style="color: #999;">Must be at least 8 characters</div>
  </div>
  <div class="field">
    <div class="field-label">I agree to the terms</div>
    <div class="fake-checkbox" onclick="toggleAgree()"></div>
  </div>
  <div class="error-text" style="color: red;">Please enter a valid email</div>
  <div class="submit-btn" onclick="submitForm()">Sign Up</div>
</div>
```

## Constraints

- Every fix must be justified by what specific assistive-technology or keyboard-only interaction it repairs — not asserted as a bare rule.
- The corrected version must remain a plausible, realistically-stylable form (don't just say "use `<form>` and native elements" without addressing why the original avoided them, if there's a legitimate-seeming reason, or confirming there isn't one here).

## Solution

**Defects found, and the fix for each:**

**1. `<div class="field-label">Email</div>` is not programmatically associated with its input.** A sighted user infers the label visually; a screen reader user focusing the input hears nothing identifying what it's for. Fix: use a real `<label for="email">` (or wrap the input in the label) paired with a matching `id`:
```html
<label for="email">Email</label>
<input type="email" id="email" name="email" />
```
Also changing `type="text"` to `type="email"` is a real, separate improvement — it gives mobile users the correct on-screen keyboard and enables basic native format validation, at essentially zero cost.

**2. The password hint ("Must be at least 8 characters") is visually present but not programmatically linked to the input, and its low-contrast gray (`#999` on presumably white) likely fails AA contrast for body text.** A screen reader user focusing the password field hears nothing about the requirement until (if ever) they discover the hint text separately; a low-vision sighted user may not be able to read it at all. Fix: link via `aria-describedby` and fix the contrast:
```html
<label for="password">Password</label>
<input type="password" id="password" aria-describedby="password-hint" />
<div id="password-hint" style="color: #595959;">Must be at least 8 characters</div>
<!-- #595959 on white is ~7:1, comfortably passing AA (4.5:1) — verify against actual final background -->
```

**3. `<div class="fake-checkbox" onclick="...">` is not a real form control at all.** It has no role, no keyboard support (a `<div>` isn't focusable or activatable via `Enter`/`Space` by default), and no way to announce checked/unchecked state. This is unusable by keyboard-only and screen-reader users entirely — not degraded, but completely inoperable. Fix: use a real `<input type="checkbox">`, which gets all of this for free natively:
```html
<label>
  <input type="checkbox" id="agree" name="agree" />
  I agree to the terms
</label>
```
If the visual design specifically requires a custom-styled checkbox appearance, style the native `<input type="checkbox">` directly (feasible with modern CSS, including `accent-color` and `appearance` overrides) rather than replacing it with a non-semantic `<div>` — there's no legitimate reason in this example to abandon the native element, since modern CSS can achieve custom visuals without sacrificing built-in keyboard/AT support.

**4. The error text has no programmatic association with the field it describes, and no mechanism to announce it when it appears.** A static `<div class="error-text">` present in the initial markup (rather than conditionally rendered/announced) suggests it may show constant, unconditional error text regardless of actual validation state — but even assuming it's meant to appear dynamically on validation failure, nothing here announces that appearance to a screen reader user, and nothing associates it with the email field specifically. Fix:
```html
<input type="email" id="email" name="email" aria-describedby="email-error" aria-invalid="true" />
<div id="email-error" role="alert">Please enter a valid email</div>
<!-- role="alert" gives this an implicit assertive live region — appropriate here since a validation
     error is the kind of urgent, action-relevant content assertive announcement is meant for -->
```
`aria-invalid="true"` should be set on the input specifically when validation fails (and removed/set to `"false"` once corrected) — this gives assistive technology an explicit signal about the field's validity state, not just the presence of nearby error text.

**5. `<div class="submit-btn" onclick="...">` has the same fundamental problem as the fake checkbox — not a real, operable control.** No keyboard focusability, no `Enter`/`Space` activation, no semantic role announcing it as a button. Fix: a real `<button type="submit">`:
```html
<button type="submit">Sign Up</button>
```

**6. The whole form isn't wrapped in a `<form>` element (implied by the lack of one in the original, and the JS-`onclick`-driven submit pattern).** Without a real `<form>`, pressing `Enter` while focused in a text field doesn't trigger submission (a native, expected browser behavior for form fields), and there's no natural mechanism for basic browser-native validation UX. Fix: wrap in `<form onsubmit="submitForm(); return false;">` (or the framework-appropriate equivalent) so `Enter`-to-submit and native validation behaviors work as users expect from any web form.

**Why every one of these defects is a "completely broken for some users," not "slightly degraded":** *"The recurring pattern here is styled `<div>`s standing in for real form controls — checkboxes, buttons — which aren't degraded accessibility experiences, they're entirely non-functional ones for keyboard-only and screen-reader users, since a `<div>` has none of the native focusability, activation, or semantic-role behavior a real form control gets for free. The fix in every case is preferring the native element unless there's a concrete reason it can't achieve the needed visual design, which modern CSS makes true far less often than teams assume."*
