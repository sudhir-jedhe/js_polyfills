# Problem: Design an Accessible Multi-Select Combobox (Tag Input)

## Problem Statement

Design (markup + interaction model, not necessarily full working code) an accessible "multi-select combobox" — a common pattern for things like "add tags," "select recipients," or "choose skills" — where a user types to filter suggestions, selects multiple options that render as removable tags/chips inside the same input area, and can remove a tag via keyboard.

## Constraints

- Real DOM focus must stay on the text input while browsing filtered suggestions (same requirement as the single-select combobox pattern, and for the same reason — the user needs to keep typing while browsing).
- Selecting an option must announce the updated selection state to screen reader users, not just visually add a chip.
- A user must be able to remove the most recently added tag via `Backspace` when the input is empty, entirely via keyboard, with the removal announced.
- Must specify what happens to focus when a tag is removed via a dedicated "remove" button on the chip itself (not via `Backspace`).

## Solution

**1. Structure — an editable combobox with an embedded list of removable tags, using the same `aria-activedescendant`-driven suggestion pattern as a single-select, plus a live region for selection changes.**

```html
<div>
  <label id="skills-label">Skills</label>
  <div class="tag-input-container" role="group" aria-labelledby="skills-label">
    <!-- Existing selections, each independently removable -->
    <span class="tag">
      React
      <button aria-label="Remove React">×</button>
    </span>
    <span class="tag">
      TypeScript
      <button aria-label="Remove TypeScript">×</button>
    </span>

    <!-- The actual combobox input, sharing the row with the tags -->
    <input
      role="combobox"
      aria-expanded="true"
      aria-controls="skills-listbox"
      aria-autocomplete="list"
      aria-activedescendant="option-1"
      aria-describedby="tag-input-help"
    />
  </div>
  <span id="tag-input-help" class="visually-hidden">
    Type to filter skills. Press Enter to add the highlighted skill. Press Backspace to remove the last added skill when the input is empty.
  </span>
  <ul id="skills-listbox" role="listbox" aria-labelledby="skills-label">
    <li id="option-1" role="option" aria-selected="true">Vue</li>
    <li id="option-2" role="option">Svelte</li>
  </ul>
  <span class="visually-hidden" aria-live="polite" aria-atomic="true" id="selection-announcer"></span>
</div>
```

**2. Selection announcement via a dedicated live region, not relying on the visual chip alone.** When a user selects "React" from the suggestion list (via `Enter` on the highlighted option), the visible chip is added **and** the `#selection-announcer` region's text content is updated to something like `"React added. 3 skills selected."` — this is the mechanism that actually informs a screen reader user their action succeeded, since a screen reader has no reliable way to notice a new, silently-appearing DOM node elsewhere on the page unless a live region explicitly calls it out.

**3. `Backspace`-to-remove, gated specifically on the input being empty.** This is a real design decision worth stating explicitly: `Backspace` should only trigger tag removal when `input.value === ''` — otherwise a user editing their filter text (e.g. correcting a typo) would accidentally delete a previously-selected tag every time they backspace past the last character, which is a common, frustrating real-world bug in naive implementations of this pattern.
```js
function handleKeyDown(e) {
  if (e.key === 'Backspace' && inputValue === '' && selectedTags.length > 0) {
    const removed = selectedTags[selectedTags.length - 1];
    removeTag(removed);
    announce(`${removed} removed. ${selectedTags.length - 1} skills selected.`);
    // deliberately do NOT move focus anywhere — it stays on the input, matching
    // the "keep typing" model the whole widget is built around
  }
}
```

**4. Focus handling when a tag's own "×" remove button is clicked/activated (not via Backspace) — the trickiest part of this design.** Removing a chip's DOM node while focus is currently *on that chip's remove button* leaves focus nowhere (the focused element was just removed from the DOM) — browsers handle this inconsistently (often silently resetting focus to `<body>`), which is a real accessibility dead-end for a keyboard user. The correct handling: after removing a tag via its own remove button, **explicitly move focus back to the main text input** (or, if there are remaining tags, to the *next* tag's remove button, matching the pattern used in the roving-tabindex toolbar theory file for "removing an item from a list of focusable items") — never leave focus to fall wherever the browser default lands it.
```js
function handleRemoveTagClick(tag) {
  removeTag(tag);
  announce(`${tag} removed. ${selectedTags.length - 1} skills selected.`);
  inputRef.current?.focus(); // explicit, deliberate focus destination — not left to chance
}
```

**Why this is a meaningfully harder design than a single-select combobox, and what the added complexity actually is:** *"A multi-select combobox has two things a single-select doesn't: state changes that need explicit live-region announcement (since a new chip silently appearing isn't itself announced), and multiple genuinely independently-focusable elements (each tag's remove button) whose removal creates a real 'where does focus go now' problem that has no correct default — every removal path (Backspace vs. clicking a specific chip's button) needs its own deliberate focus-destination decision, not just correct ARIA roles."*
