# Problem: Build a Reusable, Correct Focus Trap Hook

## Problem Statement

Implement a `useFocusTrap(containerRef, isActive)` React hook usable by any overlay component (modal, drawer, popover) that:

1. On activation, moves focus to the first focusable element inside the container (or the container itself if none exist).
2. While active, contains `Tab`/`Shift+Tab` so focus cycles only among focusable elements inside the container, wrapping at both ends.
3. On deactivation (or unmount), restores focus to whatever element had focus immediately before activation.
4. Correctly handles a container whose focusable contents change while the trap is active (e.g. a list that adds/removes items dynamically) — the trap must not go stale and reference now-removed elements.

## Constraints

- No third-party focus-trap library — implement the mechanism directly to demonstrate understanding.
- Must not assume a fixed, static list of focusable elements captured once at activation time.
- Must handle the edge case of zero focusable elements inside the container gracefully (no crash, focus still lands somewhere sane).

## Solution

```jsx
const FOCUSABLE_SELECTOR =
  'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), ' +
  'textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';

function getFocusableElements(container) {
  if (!container) return [];
  return Array.from(container.querySelectorAll(FOCUSABLE_SELECTOR)).filter(
    (el) => el.offsetParent !== null // excludes elements hidden via display:none / detached
  );
}

function useFocusTrap(containerRef, isActive) {
  const previouslyFocusedRef = useRef(null);

  useEffect(() => {
    if (!isActive) return;

    previouslyFocusedRef.current = document.activeElement; // 3. snapshot for restoration

    const focusables = getFocusableElements(containerRef.current);
    if (focusables.length > 0) {
      focusables[0].focus(); // 1. move focus in
    } else {
      containerRef.current?.setAttribute('tabindex', '-1');
      containerRef.current?.focus(); // graceful fallback: focus the container itself
    }

    function handleKeyDown(e) {
      if (e.key !== 'Tab') return;

      // Recompute on EVERY Tab press rather than once at activation — this is what makes
      // the trap correct against dynamically changing content (constraint 4).
      const currentFocusables = getFocusableElements(containerRef.current);
      if (currentFocusables.length === 0) {
        e.preventDefault();
        return;
      }

      const first = currentFocusables[0];
      const last = currentFocusables[currentFocusables.length - 1];
      const activeIndex = currentFocusables.indexOf(document.activeElement);

      if (e.shiftKey) {
        if (document.activeElement === first || activeIndex === -1) {
          e.preventDefault();
          last.focus(); // 2. wrap backward
        }
      } else {
        if (document.activeElement === last || activeIndex === -1) {
          e.preventDefault();
          first.focus(); // 2. wrap forward
        }
      }
    }

    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      // 3. restore focus, but guard against a removed/detached element
      const toRestore = previouslyFocusedRef.current;
      if (toRestore && document.body.contains(toRestore)) {
        toRestore.focus();
      }
    };
  }, [isActive, containerRef]);
}
```

**Why constraint 4 requires recomputing `getFocusableElements` on every `Tab` press, not once at activation:** capturing `first`/`last` once when the trap activates and never updating them creates a stale-reference bug — if the container's contents change while the trap is active (e.g. a dynamically-filtered list inside a modal), the cached "last" element might no longer exist in the DOM, or a newly-added element after it should now be the real last stop but isn't recognized as such. Recomputing on every keypress is a small performance cost (querying a small subtree is cheap) that buys correctness against exactly this class of bug.

**Why the `document.body.contains(toRestore)` guard on restoration matters:** if the element that had focus before the trap activated was itself removed from the DOM while the trap was open (e.g. the trigger button was part of a list item that got deleted), calling `.focus()` on a detached element is a silent no-op in some browsers and can throw in others — guarding against it avoids an unhandled edge case that would otherwise only surface in production under a specific, hard-to-reproduce sequence of user actions.
