# Snippet: axe-core in Component Tests and E2E

```jsx
// Component-level (jest-axe) — runs in the normal unit test suite
import { render } from '@testing-library/react';
import { axe, toHaveNoViolations } from 'jest-axe';
expect.extend(toHaveNoViolations);

test('IconButton with no visible label has no violations when aria-label is set', async () => {
  const { container } = render(<IconButton icon={<TrashIcon />} aria-label="Delete item" />);
  expect(await axe(container)).toHaveNoViolations();
});

test('IconButton WITHOUT a label fails the check', async () => {
  const { container } = render(<IconButton icon={<TrashIcon />} />); // no aria-label — should fail
  const results = await axe(container);
  expect(results.violations.length).toBeGreaterThan(0); // demonstrates the check actually catches the bug
});
```

```js
// E2E-level (Playwright + @axe-core/playwright) — catches composition issues across a full page
import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

test('checkout page has no automatically-detectable a11y violations', async ({ page }) => {
  await page.goto('/checkout');
  const results = await new AxeBuilder({ page }).analyze();
  expect(results.violations).toEqual([]);
});
```

```js
// A baseline-gated CI check for large existing codebases (avoids an all-or-nothing cutover)
const currentViolations = await runAxeAcrossPages();
const baseline = require('./a11y-baseline.json'); // committed snapshot of known, tracked violations

const newViolations = currentViolations.filter(v => !baseline.includes(v.id));
if (newViolations.length > 0) {
  throw new Error(`${newViolations.length} NEW accessibility violations introduced`);
}
// pre-existing baseline violations are tracked separately as a prioritized backlog, not silently ignored
```
