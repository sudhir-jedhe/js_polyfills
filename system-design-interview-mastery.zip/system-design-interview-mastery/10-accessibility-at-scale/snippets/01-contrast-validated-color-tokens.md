# Snippet: Contrast-Validated Design Tokens

```js
// Design tokens defined by ROLE and PAIRING, not raw swatches —
// each pairing's contrast ratio is verified once, at definition time.
const tokens = {
  color: {
    surface: { default: '#FFFFFF', raised: '#F7F7F8' },
    brand: { default: '#0B5FFF' },       // verified: 4.5:1+ against white text
    text: {
      primary: '#1A1A1E',                 // verified: 4.5:1+ on surface.default (13.1:1 actual)
      onBrand: '#FFFFFF',                 // verified: 4.5:1+ on brand.default (4.8:1 actual)
      disabled: '#9B9BA3',                // WCAG-exempt: disabled controls are excluded from contrast requirements
    },
  },
};
```

```js
// A small build-time check (run in CI, not just trusted by convention) that fails
// if a new token pairing is added without meeting the contrast bar.
function contrastRatio(hexA, hexB) { /* WCAG relative-luminance formula */ }

const requiredPairs = [
  [tokens.color.text.primary, tokens.color.surface.default, 4.5],
  [tokens.color.text.onBrand, tokens.color.brand.default, 4.5],
];

requiredPairs.forEach(([fg, bg, minRatio]) => {
  const ratio = contrastRatio(fg, bg);
  if (ratio < minRatio) {
    throw new Error(`Token pair ${fg}/${bg} fails contrast: ${ratio.toFixed(2)}:1 < ${minRatio}:1`);
  }
});
```

Consumers pick `text.onBrand` for anything rendered on `brand.default` — they never need to independently verify contrast themselves, because the pairing was validated once, in the token layer, and CI would catch a future change that breaks it.
