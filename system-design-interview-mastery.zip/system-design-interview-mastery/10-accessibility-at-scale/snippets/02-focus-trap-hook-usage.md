# Snippet: Using a Focus Trap in a Modal Component

```jsx
function Modal({ isOpen, onClose, title, children }) {
  const containerRef = useRef(null);
  useFocusTrap(containerRef, isOpen); // see the focus-management theory file for the hook's implementation

  useEffect(() => {
    function handleEscape(e) {
      if (e.key === 'Escape') onClose();
    }
    if (isOpen) document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <>
      <div className="modal-backdrop" onClick={onClose} aria-hidden="true" />
      <div
        ref={containerRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="modal-title"
        className="modal"
      >
        <h2 id="modal-title">{title}</h2>
        {children}
        <button onClick={onClose} aria-label="Close dialog">×</button>
      </div>
    </>
  );
}
```

```jsx
// Marking the rest of the app inert while the modal is open (modern approach)
function App() {
  const [modalOpen, setModalOpen] = useState(false);
  return (
    <>
      <div inert={modalOpen || undefined}>
        {/* main app content — becomes unreachable via keyboard/AT while modal is open */}
      </div>
      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="Confirm">
        Are you sure you want to continue?
      </Modal>
    </>
  );
}
```
