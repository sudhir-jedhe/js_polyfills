# Snippet: Roving Tabindex for a Tab List Widget

```jsx
function TabList({ tabs, activeTab, onTabChange }) {
  const tabRefs = useRef([]);

  function handleKeyDown(e, index) {
    let nextIndex = null;
    if (e.key === 'ArrowRight') nextIndex = (index + 1) % tabs.length;
    if (e.key === 'ArrowLeft') nextIndex = (index - 1 + tabs.length) % tabs.length;
    if (e.key === 'Home') nextIndex = 0;
    if (e.key === 'End') nextIndex = tabs.length - 1;

    if (nextIndex !== null) {
      e.preventDefault();
      onTabChange(tabs[nextIndex].id); // moves the "roving" tabIndex=0 to the new tab
      tabRefs.current[nextIndex]?.focus(); // moves REAL focus to match — required, not optional
    }
  }

  return (
    <div role="tablist" aria-label="Settings sections">
      {tabs.map((tab, i) => (
        <button
          key={tab.id}
          ref={(el) => (tabRefs.current[i] = el)}
          role="tab"
          id={`tab-${tab.id}`}
          aria-controls={`panel-${tab.id}`}
          aria-selected={tab.id === activeTab}
          tabIndex={tab.id === activeTab ? 0 : -1} // only the active tab is a real Tab stop
          onClick={() => onTabChange(tab.id)}
          onKeyDown={(e) => handleKeyDown(e, i)}
        >
          {tab.label}
        </button>
      ))}
    </div>
  );
}
```

A keyboard user `Tab`s once to reach the tab list (landing on whichever tab is currently active), then uses `ArrowLeft`/`ArrowRight`/`Home`/`End` to move between tabs — `Tab` again moves focus **out** of the tab list entirely, into the active panel's content, matching the native composite-widget interaction model rather than requiring a `Tab` press per tab.
