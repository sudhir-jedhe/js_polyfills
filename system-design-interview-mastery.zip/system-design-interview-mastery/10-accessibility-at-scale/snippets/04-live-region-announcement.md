# Snippet: `aria-live` Regions for Dynamic Content

```jsx
// A visually-hidden live region that announces search result count changes —
// without this, a screen reader user gets no feedback that typing changed anything.
function SearchResults({ query, results }) {
  return (
    <div>
      <input
        role="combobox"
        aria-expanded={results.length > 0}
        aria-controls="results-list"
        value={query}
        // ...
      />
      <span className="visually-hidden" aria-live="polite" aria-atomic="true">
        {results.length} result{results.length !== 1 ? 's' : ''} available
      </span>
      <ul id="results-list">
        {results.map(r => <li key={r.id}>{r.name}</li>)}
      </ul>
    </div>
  );
}
```

```css
/* Standard visually-hidden pattern: present for screen readers, invisible on screen —
   NOT display:none or visibility:hidden, which remove it from the accessibility tree entirely. */
.visually-hidden {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border: 0;
}
```

```jsx
// aria-live="assertive" reserved for genuinely urgent/interrupting content — a form submission error,
// not a routine update. Overusing "assertive" is a common real mistake that makes screen reader
// output feel chaotic, since it interrupts whatever is currently being announced.
function FormError({ message }) {
  return message ? <div role="alert" aria-live="assertive">{message}</div> : null;
  // role="alert" implies an assertive live region by default — using it IS the deliberate choice here
}
```
