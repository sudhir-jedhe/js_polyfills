# Accessible Component Pattern: Autocomplete / Combobox

An autocomplete (type-ahead search with a suggestion list) is one of the more complex custom widgets to make accessible, because it combines a text input, a dynamically-updating list, and keyboard navigation between them — and it has no single native HTML element that does this out of the box, unlike a modal (which can at least start from `<dialog>`). This makes it a favorite "design an accessible component" interview prompt; a related widget worth cross-referencing is covered in this repo's low-level-design/component-patterns topic if present, since the underlying combobox interaction model recurs across dropdowns, multi-selects, and command palettes.

## The ARIA structure (the WAI-ARIA "combobox" pattern)

```html
<label id="fruit-label" for="fruit-input">Choose a fruit</label>
<input
  id="fruit-input"
  role="combobox"
  aria-expanded="true"
  aria-controls="fruit-listbox"
  aria-autocomplete="list"
  aria-activedescendant="option-2"
  autocomplete="off"
/>
<ul id="fruit-listbox" role="listbox" aria-labelledby="fruit-label">
  <li id="option-1" role="option">Apple</li>
  <li id="option-2" role="option" aria-selected="true">Apricot</li>
  <li id="option-3" role="option">Avocado</li>
</ul>
```

- **`role="combobox"` on the input** — identifies it as a composite widget combining a text input with a popup, not a plain text field.
- **`aria-expanded`** — reflects whether the suggestion list is currently visible; toggles `true`/`false` as the list opens/closes, so a screen reader knows whether there's a list to interact with right now.
- **`aria-controls`** — points to the ID of the listbox this input controls, establishing the relationship for assistive technology.
- **`aria-autocomplete="list"`** — tells assistive technology that typing produces a filtered list of suggestions (as opposed to `"inline"`, where the input's own value gets auto-completed with a suggested continuation, or `"both"`).
- **`aria-activedescendant`** — this is the piece that's most often implemented incorrectly, covered below.
- **`role="listbox"` / `role="option"`** on the suggestions — identifies the popup as a selectable list and each item as a selectable option, with `aria-selected` marking the currently highlighted one.

## Why `aria-activedescendant`, not moving real DOM focus into the list

This is the detail that trips up most implementations. The naive approach — actually moving keyboard focus (`.focus()`) into the list as the user presses arrow keys — breaks the pattern: focus leaving the text input means the user can no longer type/edit their query while navigating suggestions, which defeats the entire point of a type-ahead.

The correct pattern keeps **real DOM focus on the `<input>` at all times**, while `aria-activedescendant` on the input announces, to assistive technology, which option is currently "virtually" highlighted:

```jsx
function Combobox({ options }) {
  const [query, setQuery] = useState('');
  const [activeIndex, setActiveIndex] = useState(-1);
  const [isOpen, setIsOpen] = useState(false);
  const filtered = options.filter(o => o.toLowerCase().includes(query.toLowerCase()));

  function handleKeyDown(e) {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setActiveIndex(i => Math.min(i + 1, filtered.length - 1)); // moves the VIRTUAL cursor, not real focus
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setActiveIndex(i => Math.max(i - 1, 0));
    } else if (e.key === 'Enter' && activeIndex >= 0) {
      setQuery(filtered[activeIndex]);
      setIsOpen(false);
    } else if (e.key === 'Escape') {
      setIsOpen(false);
    }
  }

  return (
    <>
      <input
        role="combobox"
        aria-expanded={isOpen}
        aria-controls="listbox"
        aria-autocomplete="list"
        aria-activedescendant={activeIndex >= 0 ? `option-${activeIndex}` : undefined}
        value={query}
        onChange={(e) => { setQuery(e.target.value); setIsOpen(true); }}
        onKeyDown={handleKeyDown}
        // NOTE: no .focus() call ever targets the list — real DOM focus stays here throughout
      />
      {isOpen && (
        <ul id="listbox" role="listbox">
          {filtered.map((opt, i) => (
            <li key={opt} id={`option-${i}`} role="option" aria-selected={i === activeIndex}>
              {opt}
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
```

Arrow keys update `activeIndex` (React state) and, correspondingly, `aria-activedescendant` — the screen reader announces the newly "active" option based on that ARIA relationship, entirely without any real focus change, so the user can keep typing at any point while still navigating suggestions with arrow keys.

## Announcing result count changes

Because the option list updates dynamically as the user types, a screen reader user needs to know how many results are available without having to navigate into the (possibly empty, possibly large) list manually. A visually-hidden `aria-live="polite"` region announcing something like "5 results available" on each filter update is the standard supplementary pattern — without it, a screen reader user gets no feedback that their typing changed anything until they explicitly navigate into the list.

## Interview framing

*"The core design decision in an accessible combobox is that real keyboard focus never leaves the text input — arrow-key navigation through suggestions is represented purely via `aria-activedescendant` pointing at the currently-highlighted option's ID, which lets a screen reader announce the active suggestion without taking real focus away from where the user is still typing. Getting this wrong — moving actual DOM focus into the list on arrow-key press — is the single most common mistake in custom combobox implementations, and it breaks the ability to keep refining the query while browsing suggestions."*
