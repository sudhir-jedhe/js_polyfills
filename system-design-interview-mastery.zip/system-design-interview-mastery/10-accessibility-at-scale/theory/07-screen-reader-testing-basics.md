# Screen Reader Testing Basics

Automated tools and code review can verify structural correctness, but the only way to know whether an experience actually *works* for a screen reader user is to test it with a real screen reader. This file covers the practical baseline: which tools to use, the core navigation model, and what to actually check.

## The major screen readers and their typical pairings

| Screen reader | Platform | Typical browser pairing | Notes |
|---|---|---|---|
| **VoiceOver** | macOS / iOS | Safari (best support) | Built into macOS/iOS — free, no install needed, the most accessible starting point for most engineers |
| **NVDA** | Windows | Firefox or Chrome | Free, open-source — the most common Windows screen reader for testing purposes |
| **JAWS** | Windows | Chrome or Edge | The most widely used screen reader among actual blind/low-vision users professionally, especially in enterprise contexts — commercial/paid, less accessible to spin up for casual testing but worth prioritizing for high-stakes flows given real-world usage share |
| **TalkBack** | Android | Chrome | Mobile-specific testing |

**A practical note for interviews and real work alike:** browser/screen-reader pairing matters more than people expect — the same page can behave differently between, say, NVDA+Firefox and NVDA+Chrome, because ARIA support and the accessibility-tree-to-browser mapping isn't perfectly uniform across engines. Testing in only one pairing and assuming it generalizes is a common, real gap.

## The core interaction model: browse mode vs. focus mode

Screen readers on desktop generally operate in two modes:

- **Browse (virtual cursor) mode** — the default for reading static content. The screen reader's own virtual cursor moves through the page's accessibility tree independently of real keyboard focus, letting a user read headings, paragraphs, and landmarks without needing every element to be individually tabbable.
- **Focus mode** — activated automatically (or manually) when the virtual cursor lands on an interactive element (a form field, a custom widget) — keystrokes are then passed through to the actual page/component rather than used for virtual-cursor navigation, so the user can type into a field or interact with a custom widget's own keyboard handling.

This is precisely why correct ARIA roles matter beyond just "having a label" — a screen reader decides whether to switch into focus mode partly based on the element's role and interactivity semantics; a `<div>` with a click handler but no `role="button"`/no real focus handling may never trigger focus mode at all, effectively making it invisible as an interactive control to a screen reader user even though a sighted mouse user can click it fine.

## What to actually check in a screen reader pass

1. **Landmark and heading navigation** — can a user jump directly to `<nav>`, `<main>`, `<header>` regions, and does the heading structure (`h1`→`h2`→`h3`, without skipped levels) let a user scan the page's structure the way a sighted user visually scans a page layout? Most screen readers offer dedicated shortcuts to jump between headings/landmarks (e.g. VoiceOver's rotor, NVDA's single-letter navigation) — a page with a flat or skipped heading structure defeats this entirely.
2. **Form labels and error announcements** — does every input announce a meaningful label when focused, and are validation errors announced at the point they occur (typically via `aria-live` or `aria-describedby` pointing at the error text), not just visually displayed?
3. **Dynamic content announcements** — do live updates (a toast notification, a cart-item-count change, a form submission result) get announced via `aria-live`, and is the `aria-live` politeness level (`polite` vs `assertive`) appropriate — `assertive` interrupts whatever the screen reader is currently announcing, which is correct for urgent/error content but jarring and disorienting if overused for routine updates.
4. **Custom widget interaction** — does a custom combobox/modal/tab list behave the way the ARIA pattern promises (see the dedicated pattern theory files), tested by actually using it with the screen reader's keyboard commands, not just inspecting the markup.
5. **Reading order matches visual/logical order** — CSS can visually reposition content (flexbox `order`, absolute positioning) in ways that diverge from DOM order; a screen reader's browse-mode reading order follows the DOM, so a mismatch here means the announced order doesn't match what a sighted user sees, which is confusing in a way no automated tool flags (DOM order is "valid" regardless of what it's visually positioned to look like).

## A minimal, practical testing routine

For a team without a dedicated accessibility specialist, a realistic minimum: pick one screen reader/browser pairing (VoiceOver+Safari is the lowest-friction starting point on macOS, NVDA+Firefox on Windows), turn off the mouse/trackpad entirely, and complete the actual user flow being shipped (not just spot-check individual elements) using only the keyboard and the screen reader's navigation commands. Getting through a real task end-to-end surfaces composition-level issues (focus order across components, an unlabeled dynamic update) that element-by-element automated checks structurally cannot.

## Interview framing

*"Automated tools verify structural correctness, but only an actual screen reader pass tells you whether the experience works — because screen readers operate through browse mode and focus mode, and whether an element even participates correctly in that model depends on real ARIA semantics and keyboard handling, not just markup validity. The minimum realistic bar is completing an actual user flow, not individual elements, using one real screen reader/browser pairing with the mouse disabled, since composition-level issues like focus order and dynamic-content announcements only show up when you use the page the way an assistive-technology user actually would."*
