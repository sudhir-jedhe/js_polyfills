# Accessible Component Pattern: The Modal Dialog

The modal is one of the most commonly mis-implemented accessible components — it requires coordinating ARIA semantics, focus management (see the dedicated focus-management theory file), and keyboard handling correctly *together*, and getting any one piece wrong breaks the whole pattern for assistive technology users even if the other pieces are right.

## The required pieces, and what each one does

**1. Correct ARIA role and properties, so a screen reader announces it as a dialog, not generic content.**
```html
<div role="dialog" aria-modal="true" aria-labelledby="dialog-title" aria-describedby="dialog-desc">
  <h2 id="dialog-title">Delete this item?</h2>
  <p id="dialog-desc">This action cannot be undone.</p>
  <button>Cancel</button>
  <button>Delete</button>
</div>
```
- `role="dialog"` (or `role="alertdialog"` for a dialog that requires immediate attention/response, e.g. a destructive confirmation) tells assistive technology this is a distinct, focused interaction, not part of the normal page flow.
- `aria-modal="true"` signals that content outside the dialog is inert while it's open — modern screen readers use this to avoid navigating a user "into" the page behind the dialog via their own browse-mode navigation, complementing (not replacing) the actual focus trap.
- `aria-labelledby`/`aria-describedby` give the dialog an accessible name and description, so opening it announces *what it's for*, not just "dialog" with no context.

**2. Focus management — move focus in on open, trap it while open, restore it on close.** Covered in full mechanical detail in the focus-management theory file; a modal without correct focus handling is broken regardless of how correct its ARIA markup is, because a keyboard user's `Tab` key would still escape into content behind it.

**3. Background content must be inert, not just visually covered.** It's not enough for the modal to visually sit on top of the page — the content behind it must be genuinely unreachable via keyboard and hidden from assistive technology, not merely obscured:
```html
<div id="page-content" aria-hidden="true" inert> <!-- while modal is open -->
  <!-- rest of the page -->
</div>
```
The `inert` HTML attribute (now broadly supported) is the modern, simplest way to do this — it removes an entire subtree from both the tab order and assistive technology's accessibility tree in one attribute, superseding the older pattern of manually setting `aria-hidden="true"` and separately preventing focus via `tabindex="-1"` on every focusable descendant (which was easy to implement incompletely).

**4. `Escape` closes the dialog; a click on a backdrop/overlay is a nice-to-have, not a substitute for a real close button.** Keyboard users need a reliable close mechanism that doesn't depend on a visible "X" being their only option — supporting `Escape` is close to universally expected. A visible, properly-labeled close button (`aria-label="Close dialog"` if it's icon-only) should also always be present; relying solely on `Escape` or a backdrop click leaves users who don't know that convention (or use switch/voice-control input where "press Escape" isn't a natural action) without a discoverable way out.

## A common near-miss: correct ARIA, broken focus (or vice versa)

Teams frequently get one piece right and assume the component is "accessible" as a result:
- **ARIA correct, focus broken:** `role="dialog"` and `aria-modal="true"` are present, but focus never actually moves into the dialog on open — a screen reader user's *virtual cursor* might still be able to browse into content that's `aria-modal`-hidden in theory, and a keyboard user's real `Tab` focus continues through the underlying page, which the ARIA attributes alone don't prevent.
- **Focus correct, ARIA missing:** the trap/restore logic works mechanically, but with no `role="dialog"`/`aria-labelledby`, a screen reader announces the dialog's content as generic, unlabeled text with no indication a modal just opened or what it's about — technically keyboard-navigable, but confusing and context-free for a non-visual user.

Both pieces are required together; neither compensates for the other's absence.

## Interview framing

*"A correct modal needs four things working together: ARIA (`role="dialog"`, `aria-modal`, a labelled name/description) so it's announced meaningfully, a real focus trap so `Tab` can't escape into hidden content behind it, the background content made genuinely `inert` rather than just visually covered, and an `Escape` key handler plus a visible close button as reliable close mechanisms. I've seen teams implement the ARIA correctly while the focus trap is broken (or vice versa) and call it done — both pieces are required, since ARIA describes the semantics but doesn't itself constrain where keyboard focus can go."*
