# WCAG Conformance Levels in a Real Org Context

WCAG (Web Content Accessibility Guidelines) defines success criteria at three conformance levels — A, AA, AAA — and interviewers frequently probe whether a candidate understands not just what the levels mean technically, but what level an organization should actually target and why "just do AAA, it's the strictest" is usually the wrong answer.

## The three levels, what distinguishes them

| Level | Meaning | Example criteria | Practical target |
|---|---|---|---|
| **A** | Minimum — baseline accessibility; failing these makes content unusable for some users in a fairly absolute way | Non-text content has a text alternative; keyboard-operable functionality; no keyboard traps | Legal/practical floor — almost never sufficient as a stated target on its own |
| **AA** | Mid-tier — addresses the most common and significant barriers without imposing very high design/content constraints | 4.5:1 text contrast (3:1 for large text); resizable text up to 200% without loss of content/function; visible focus indicators; consistent navigation | **The near-universal real-world target** — this is what most legal frameworks (ADA-related litigation standards in the US, EN 301 549 in the EU, AODA in Canada) reference in practice |
| **AAA** | Highest — includes criteria that are valuable but often impose significant constraints on design/content that aren't achievable for all content types | 7:1 text contrast; sign language interpretation for prerecorded audio; no timing requirements at all | WCAG **itself** states AAA conformance is not recommended as a general policy for entire sites — some AAA criteria are acknowledged as not achievable for certain content types regardless of effort |

## Why AA, not AAA, is the standard real-world target — this is the load-bearing fact

This isn't organizational laziness — it's what the WCAG specification itself says. The WCAG spec explicitly notes that it is **not recommended that Level AAA conformance be required as a general policy for entire sites**, because some AAA success criteria cannot be satisfied for some content no matter what (e.g. 7:1 contrast is not achievable for all legitimate visual designs/logos/live video without fundamentally compromising them). AA represents the level where the guidelines themselves consider broad, sitewide conformance realistic and appropriate.

## Conformance is not "AAA, but we skip the hard parts" — it's a strict per-level bar

A common misunderstanding: conformance to a level requires satisfying **all** success criteria at that level **and** all levels below it — "AA conformance" means all of A's criteria plus all of AA's criteria, not just AA's criteria alone. There's no partial-credit "AA-ish" official conformance claim; a single failing AA criterion, even on one page, technically breaks a site-wide AA conformance claim for WCAG's formal definition (in practice, most orgs still describe their *target* as AA while tracking and remediating known gaps, rather than claiming strict formal conformance).

## What this looks like operationally in an organization

1. **Set AA as the explicit target level**, documented in an accessibility policy/statement, not left implicit.
2. **Track conformance per-criterion, not as a single pass/fail score** — a site might be fully AA-compliant on contrast and keyboard operability but have gaps in a specific criterion (e.g. `2.4.6 Headings and Labels`) in one product area; treating conformance as one aggregate number obscures where the actual remediation work is.
3. **Selectively adopt individual AAA criteria where they're cheap and valuable**, without claiming full AAA conformance — e.g. providing extended audio descriptions for key marketing video content is a AAA criterion that's often worth doing even without pursuing AAA site-wide, since it's low-cost relative to its value for that specific content type. This is a common, practical middle ground: "AA as the baseline, cherry-pick AAA where it's cheap."
4. **New feature launches gate on AA for the specific criteria relevant to that feature** — e.g. a new custom widget must meet the operable/keyboard criteria and correct name/role/value (criterion 4.1.2) before shipping, rather than accessibility being a post-launch audit finding.

## Interview framing

*"AA is the target almost every real organization should state and design toward — it's what WCAG itself recommends for general sitewide conformance, and it's the level referenced by most legal/regulatory frameworks in practice. AAA isn't 'stricter and therefore better as a blanket target' — WCAG explicitly notes some AAA criteria aren't achievable for all content, so a sensible policy is AA as the baseline with individual AAA criteria adopted selectively where they're low-cost and high-value for specific content, rather than an all-or-nothing AAA commitment that isn't realistically achievable site-wide."*
