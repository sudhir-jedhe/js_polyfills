# Automated Accessibility Testing (axe-core, CI) vs Manual Testing

Neither automated nor manual testing alone is sufficient at scale — automated testing catches a narrow but real slice of issues cheaply and continuously; manual testing catches the majority of real-world accessibility problems but doesn't scale to every PR on every page. A mature accessibility program uses both, deliberately, for what each is actually good at.

## What automated tools (axe-core) can and cannot catch

axe-core (and tools built on it — `jest-axe`, Cypress/Playwright axe plugins, the axe DevTools browser extension) programmatically checks the rendered DOM against a large ruleset of WCAG success criteria that are **mechanically verifiable**:

**Catches reliably:**
- Missing `alt` attributes on `<img>`
- Insufficient color contrast (computable from actual rendered colors)
- Missing form label associations (`<label for>` / `aria-label` / `aria-labelledby`)
- Invalid/duplicate ARIA attribute usage (e.g. `aria-hidden="true"` on a focusable element, invalid `role` values)
- Missing document language (`<html lang="...">`)
- Duplicate IDs (which break `aria-labelledby`/`aria-describedby` references)

**Cannot catch, structurally — not a tooling gap, a fundamental limitation:**
- Whether `alt` text is **meaningful** — `alt="image123.jpg"` or `alt="photo"` passes the automated check (an `alt` attribute is present and non-empty) but is useless to a screen reader user. Automated tools verify *presence* and *mechanical correctness*, not *semantic quality*.
- Whether a focus order is **logical** given the visual layout (a component can have valid, non-trapped focus that still tabs through the page in a confusing sequence relative to what's visually adjacent).
- Whether custom keyboard interactions **behave correctly** (does arrow-key navigation in a custom combobox actually move through options the way a screen reader user expects, or does an `Escape` key properly close a menu) — axe-core can verify the ARIA roles/states are structurally valid without verifying the actual interactive behavior matches them.
- Whether the overall experience **makes sense** to someone using a screen reader end-to-end (can they understand what a page is for, complete a task, recover from an error) — this is fundamentally a usability question, not a rule-checkable one.

Industry estimates commonly cited (varying by source, but directionally consistent) put automated tools at catching roughly **30-50% of WCAG success criteria** — useful as a rough calibration that automation is a floor, not a ceiling.

## CI integration pattern

```js
// jest-axe example — runs as part of the normal component test suite
import { axe, toHaveNoViolations } from 'jest-axe';
expect.extend(toHaveNoViolations);

test('Modal has no accessibility violations', async () => {
  const { container } = render(<Modal isOpen title="Confirm">Are you sure?</Modal>);
  const results = await axe(container);
  expect(results).toHaveNoViolations();
});
```
```yaml
# CI: fail the build on new violations, but don't silently block on pre-existing ones during rollout
- run: npm run test:a11y
```
**A rollout detail worth naming:** introducing automated a11y testing on an existing large codebase all at once typically surfaces hundreds of pre-existing violations — gating CI on zero violations immediately either blocks all merges or forces a rushed mass-fix. A more realistic rollout snapshots the current violation count as a baseline, gates CI on "no *new* violations beyond the baseline," and tracks baseline reduction as a separate, prioritized backlog — this is analogous to how a CSP report-only rollout (see the frontend-security topic) avoids an all-or-nothing cutover.

## What manual testing catches that automation structurally cannot

- **Actual screen reader walkthroughs** (VoiceOver, NVDA, JAWS) — does the announced content make sense in the order it's read, are dynamic updates (`aria-live` regions) announced at a sensible time and not too aggressively, does a custom widget's interaction model match user expectations built from other software.
- **Keyboard-only navigation of full user flows** — completing a real task (checkout, form submission, search) using only the keyboard, which surfaces focus-order and focus-trap issues that a component-level automated test, run in isolation, would never catch (they typically only manifest when components are composed together on a real page).
- **Cognitive/readability review** — is error messaging clear, is the reading level appropriate, are instructions unambiguous — none of this is DOM-structure-checkable.
- **Testing with actual assistive technology users**, where feasible — the highest-signal source of real usability issues, and the one most organizations under-invest in relative to automated tooling, precisely because automated tooling is cheaper and easier to run continuously.

## A practical division of labor at scale

| Layer | Tool | Catches | Runs |
|---|---|---|---|
| Component-level | axe-core in unit/component tests | Structural/mechanical violations in isolated components | Every PR, every commit — cheap, fast, continuous |
| Page/flow-level | axe-core in E2E tests (Cypress/Playwright) + manual keyboard walkthroughs | Composition issues (focus order across components), some structural issues in full pages | Per release / per major feature, less frequent |
| Full experience | Manual screen-reader testing, ideally with real AT users | Semantic quality, usability, real task completion | Periodic audits, new major features, before high-stakes launches |

## Interview framing

*"I'd treat automated axe-core checks as a continuous, cheap floor — wired into CI to catch structural regressions on every PR — but explicitly not as sufficient on its own, since it can only verify mechanical correctness (an `alt` attribute exists) not semantic quality (the `alt` text is actually meaningful) or real interaction behavior. Manual keyboard and screen-reader testing is where the majority of real-world usability issues get caught, so it belongs at the flow/release level and for any new complex custom widget, layered on top of the automated floor rather than replacing it."*
