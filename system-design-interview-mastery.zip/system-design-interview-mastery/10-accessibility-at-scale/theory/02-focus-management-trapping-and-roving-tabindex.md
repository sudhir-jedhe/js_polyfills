# Focus Management Patterns at Scale: Focus Trapping and Roving Tabindex

Keyboard and screen-reader users navigate almost entirely via focus — where it currently is, and what `Tab`/`Shift+Tab`/arrow keys move it to next. Two focus-management patterns show up constantly in interviews because they're both common and commonly implemented incorrectly: **focus trapping** (for modals/dialogs) and **roving tabindex** (for composite widgets like toolbars, tab lists, and menus).

## Focus trapping — why a modal needs it

When a modal dialog opens, sighted mouse users' attention is naturally drawn to it, but a keyboard user's focus doesn't move anywhere unless the code explicitly moves it. Without focus management, `Tab` continues cycling through the underlying page — a keyboard user can end up interacting with content **behind** a modal that's visually covering it, which is confusing at best and a serious usability blocker at worst (e.g. tabbing into a "Delete Account" button hidden behind an open, unrelated modal).

**The three requirements of correct focus trapping:**

1. **On open, move focus into the modal** — typically to the first focusable element, or to the modal container itself (`tabindex="-1"` + `.focus()`) if there's a reason not to auto-focus a specific control (e.g. a destructive action shouldn't be pre-focused).
2. **While open, contain `Tab`/`Shift+Tab` cycling within the modal** — pressing `Tab` on the last focusable element inside the modal should wrap to the first (and `Shift+Tab` on the first should wrap to the last), rather than escaping into the page behind it.
3. **On close, return focus to the element that opened the modal** — not to `document.body`, and not left wherever it happened to be. This is the detail most often skipped: without it, a screen reader user closes a modal and has no idea where focus landed, effectively losing their place in the page.

```jsx
function useFocusTrap(containerRef, isOpen) {
  const triggerRef = useRef(null);

  useEffect(() => {
    if (!isOpen) return;
    triggerRef.current = document.activeElement; // 3. remember what opened it

    const focusables = containerRef.current.querySelectorAll(
      'a[href], button:not([disabled]), input:not([disabled]), select, textarea, [tabindex]:not([tabindex="-1"])'
    );
    const first = focusables[0];
    const last = focusables[focusables.length - 1];
    first?.focus(); // 1. move focus in

    function handleKeyDown(e) {
      if (e.key !== 'Tab') return;
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus(); // 2. wrap backward
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus(); // 2. wrap forward
      }
    }

    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      triggerRef.current?.focus(); // 3. restore focus on close/unmount
    };
  }, [isOpen]);
}
```

## Roving tabindex — for composite widgets (toolbars, tabs, menus, radio groups)

A composite widget (a toolbar with 8 buttons, a tab list with 5 tabs) should generally be **one stop** in the page's overall `Tab` order, with **arrow keys** moving focus *within* the widget — not 8 separate `Tab` stops for a single toolbar. This matches how these widgets behave natively (a native `<select>` is one tab stop; arrow keys move through its options) and avoids forcing a keyboard user to `Tab` through every individual item just to get past one widget.

**The mechanism:** only one item in the composite widget has `tabindex="0"` at any time (making it the single reachable-via-Tab stop); every other item has `tabindex="-1"` (focusable programmatically, but skipped by `Tab`). Arrow-key handling moves logical focus by updating which item has `tabindex="0"` and calling `.focus()` on it.

```jsx
function Toolbar({ items }) {
  const [activeIndex, setActiveIndex] = useState(0);
  const refs = useRef([]);

  function handleKeyDown(e, index) {
    let next = index;
    if (e.key === 'ArrowRight') next = (index + 1) % items.length;
    if (e.key === 'ArrowLeft') next = (index - 1 + items.length) % items.length;
    if (next !== index) {
      setActiveIndex(next);
      refs.current[next]?.focus(); // move actual DOM focus, not just visual state
    }
  }

  return (
    <div role="toolbar">
      {items.map((item, i) => (
        <button
          key={item.id}
          ref={(el) => (refs.current[i] = el)}
          tabIndex={i === activeIndex ? 0 : -1} // only one real Tab stop at a time
          onKeyDown={(e) => handleKeyDown(e, i)}
          onClick={() => setActiveIndex(i)} // clicking also updates the roving index
        >
          {item.label}
        </button>
      ))}
    </div>
  );
}
```

**Why not just leave every item at `tabindex="0"`?** It would technically work for pure keyboard reachability, but it breaks the expected interaction model — a screen reader/keyboard user would need to `Tab` through every single toolbar button individually to get past the widget, rather than `Tab` once into it and use arrow keys, which is both slower and inconsistent with how native composite controls behave.

## Comparison

| Pattern | Used for | Tab behavior | Arrow key behavior |
|---|---|---|---|
| **Focus trap** | Modals, dialogs | Contained within the trap; wraps at edges | N/A — not primarily an arrow-key pattern |
| **Roving tabindex** | Toolbars, tab lists, menus, radio groups | One stop for the whole widget | Moves focus between items within the widget |

## Interview framing

*"Both patterns exist because default browser Tab order doesn't match how these widgets should behave. A modal needs Tab actively contained inside it and focus restored to the trigger on close, or keyboard users can interact with hidden content behind it or lose their place entirely. A composite widget like a toolbar needs to be a single Tab stop with arrow keys moving focus internally — implemented via roving `tabindex`, keeping exactly one item at `tabindex=0` and the rest at `-1` — so it matches the interaction model of native composite controls instead of forcing users to Tab through every individual item."*
