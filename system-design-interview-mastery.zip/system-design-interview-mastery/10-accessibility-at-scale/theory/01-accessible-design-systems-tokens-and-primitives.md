# Building Accessibility Into a Design System

Retrofitting accessibility onto individual pages/features, one bug at a time, doesn't scale past a handful of teams — the same contrast violation, the same missing focus state, and the same unlabeled icon button get reintroduced independently by every team that didn't happen to read the same accessibility checklist. The scalable fix is pushing accessibility guarantees down into the **design system** itself, so consuming teams get correct behavior by default, not by remembering a rule.

## Contrast-compliant color tokens, not just "brand colors"

A design system's color tokens should be defined with their **contrast relationships already validated**, not left for each team to check per-usage. Concretely: rather than shipping a single `brand-blue` and trusting every consumer to manually verify it passes contrast against whatever background they pair it with, ship semantic, pre-paired tokens:

| Token | Purpose | Guaranteed pairing |
|---|---|---|
| `color-text-primary` on `color-surface-default` | Body text | Passes WCAG AA (4.5:1) by construction — verified once, at the token-definition level |
| `color-text-on-brand` on `color-brand-default` | Text on a brand-colored button | Verified pairing — if `color-brand-default` is a mid-saturation blue, `color-text-on-brand` is defined as white or near-white specifically because that pairing was checked |
| `color-text-disabled` | Disabled state text | Deliberately **exempted** from AA contrast (WCAG explicitly excludes disabled/inactive UI from contrast requirements) — worth encoding as a documented exception, not an oversight |

The key architectural point: **tokens should be named and paired by role** (text-on-surface, text-on-brand), not just raw color swatches — so a consumer who picks "the button token" automatically gets a validated text/background pair, rather than independently selecting a text color and a background color that happen to have never been checked together.

## Dark mode and theming must re-validate contrast, not just invert lightness

A common scaling failure: a token system defines light-mode contrast pairs correctly, then generates a dark theme by naively inverting lightness values, without re-validating that the new pairs still meet contrast minimums — a color that was AA-compliant in light mode is not guaranteed to remain compliant after a lightness inversion, because contrast ratio is a function of the *specific pair*, not a property that transforms predictably. Each theme variant needs its own contrast validation pass, ideally automated (see the automated-testing theory file) so a new theme can't ship with silently broken contrast.

## Accessible component primitives — correctness built once, reused everywhere

The second pillar: base/primitive components (`Button`, `Modal`, `Tooltip`, `Tabs`, `Combobox`) should have their accessibility semantics (correct ARIA roles/states, keyboard interaction, focus management) implemented **once**, inside the design system, rather than each product team re-implementing a modal's focus trap or a tab list's arrow-key navigation from scratch.

```jsx
// A design-system Button primitive bakes in accessible defaults
// so consumers can't accidentally ship an unlabeled icon button.
function Button({ children, icon, 'aria-label': ariaLabel, ...props }) {
  if (icon && !children && !ariaLabel) {
    if (process.env.NODE_ENV !== 'production') {
      console.warn('Icon-only Button requires an aria-label.'); // dev-time guardrail, not just documentation
    }
  }
  return <button {...props}>{icon}{children}</button>;
}
```
This kind of dev-time guardrail (a runtime warning, a lint rule, or a TypeScript type that requires `aria-label` when `children` is absent) catches the mistake **at the point a team uses the primitive incorrectly**, rather than relying on that team's own accessibility knowledge or a later audit to catch it.

## Why this scales where page-by-page fixes don't

| Approach | Failure mode |
|---|---|
| Per-page/per-team accessibility fixes | Same bug class (unlabeled icon buttons, uncontrasted text, missing focus traps) reintroduced independently across every team; fixes don't propagate |
| Accessible design system primitives + validated tokens | A bug fixed once in the primitive is fixed everywhere it's used; new usages inherit correctness by default rather than by discipline |

The trade-off worth naming explicitly: this requires the design system team to treat accessibility as a **first-class part of the component API contract**, not an afterthought bolted on after a component ships — retrofitting accessibility into an already-widely-adopted primitive is far more disruptive (breaking changes across every consumer) than building it in from the primitive's first version.

## Interview framing

*"At scale, accessibility bugs aren't really page-level bugs — they're the same handful of root causes (uncontrasted tokens, primitives missing keyboard/ARIA semantics) instantiated hundreds of times across a large product surface. The fix that actually scales is pushing correctness into the design system's tokens and base component primitives, so consuming teams get accessible behavior by default rather than needing to re-derive it, with dev-time guardrails (lint rules, runtime warnings, required props) catching misuse at the point of consumption rather than relying on a later audit to find it."*
