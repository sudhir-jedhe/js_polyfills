# Scenario: Rolling Out CSP on a Large Existing App Without Breaking It

**Scenario:** A five-year-old app with no CSP has accumulated inline `<script>` blocks (analytics snippets, A/B test bootstrapping, server-rendered initial state), several third-party script tags (a chat widget, a payments SDK, an ads/analytics pixel), and scattered `eval`-adjacent code in an old templating library. Leadership wants CSP enabled to reduce XSS blast radius, but a botched rollout that breaks checkout or the chat widget is a business risk. Design the rollout.

**Approach:**

**1. Start in report-only mode — never ship straight to enforcement on a codebase this size.** `Content-Security-Policy-Report-Only` applies the same policy syntax but only logs violations (via `report-uri`/`report-to`) instead of blocking anything, so real user traffic surfaces exactly what an enforced policy would break, with zero risk to functionality during the discovery phase.
```
Content-Security-Policy-Report-Only: default-src 'self'; script-src 'self' https://chat-widget.example.com https://payments-sdk.example.com; report-uri /csp-violations;
```

**2. Inventory and categorize every current script/style source before writing the policy, not after.** Grep the codebase for inline `<script>` blocks, external `<script src>` tags, and known `eval`/`new Function`/`setTimeout(string)` usages. Each inline script needs either: removal, conversion to an external file (`'self'`-compatible), or a nonce; each third-party script's origin needs to be explicitly allowlisted; each `eval`-adjacent usage needs either removal/refactor or an accepted `'unsafe-eval'` carve-out with a documented justification and a ticket to remove it.

**3. Convert legitimate inline scripts to use nonces rather than blanket `'unsafe-inline'`.** The server-rendered initial-state bootstrap script is a common, legitimate case:
```html
<script nonce="<%= cspNonce %>">window.__INITIAL_STATE__ = {...};</script>
```
Reaching for `'unsafe-inline'` "to make the report-only errors go away faster" defeats the entire point of the rollout — it would suppress violation reports for the inline scripts the team actually needs to fix while also permanently reopening the exact hole CSP exists to close.

**4. Run report-only for a full realistic traffic window (at least one full business cycle, including e.g. month-end if usage patterns differ) before flipping to enforcement.** Violation reports need time to surface rarely-hit code paths — a report-only period that's too short risks missing an infrequently-triggered inline script (e.g. a specific error-handling branch, or a seasonal promotion banner) that only breaks once enforcement goes live.

**5. Flip to enforcement incrementally by directive or by traffic percentage if the platform supports it, prioritizing `object-src` and `frame-ancestors` first.** Some directives (`object-src 'none'`, `frame-ancestors 'none'`/`'self'`) carry very low risk of breaking legitimate functionality (almost nothing legitimately needs `<object>`/`<embed>`, and clickjacking protection rarely conflicts with real usage) — enforcing those first delivers real security value immediately with minimal risk, while `script-src` (the highest-risk, highest-reward directive) gets the longest report-only soak time.

**6. Keep the violation-reporting endpoint live even after enforcement.** Post-launch, `report-uri`/`report-to` continues catching both regressions (a new feature accidentally adding an inline script) and active attack attempts (a real XSS injection attempt hitting the policy and getting logged, which is itself valuable security telemetry — a spike in CSP violation reports for `script-src` can be an early signal of an attempted or successful injection elsewhere).

**Why report-only-first is the load-bearing decision here:** *"The risk isn't whether CSP is a good idea — it clearly is — it's shipping a policy that's wrong for this specific app's five years of accumulated inline scripts and third-party integrations straight to enforcement. Report-only mode turns that unknown into a data-gathering exercise with zero user-facing risk, and lets me fix each surfaced violation properly (nonces, explicit origin allowlisting) rather than reaching for blanket `'unsafe-inline'`/`'unsafe-eval'` just to silence errors, which would ship a CSP that provides close to no real XSS protection."*
