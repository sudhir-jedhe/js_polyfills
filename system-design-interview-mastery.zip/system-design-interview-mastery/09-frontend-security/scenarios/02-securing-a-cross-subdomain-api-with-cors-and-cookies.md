# Scenario: Securing a Cross-Subdomain API (app.example.com → api.example.com)

**Scenario:** Your frontend at `https://app.example.com` calls an API at `https://api.example.com` using cookie-based session auth. Requests currently fail in the browser with CORS errors, and a teammate proposes setting `Access-Control-Allow-Origin: *` on the API to "just make it work." Evaluate that proposal and design the correct configuration.

**Approach:**

**1. Reject the wildcard proposal — explain precisely why it's disallowed here, not just "it's insecure."** `app.example.com` and `api.example.com` are different origins (different hosts, despite sharing a parent domain), so this is genuinely cross-origin. Because the request needs to carry the session cookie (`credentials: 'include'`), the spec **forbids** `Access-Control-Allow-Origin: *` in combination with credentialed requests — browsers actively reject this combination client-side, so `*` wouldn't even "just work" here; it would continue failing, just with a different error. Beyond the spec-level block, even where the browser might tolerate a wildcard for non-credentialed requests, it would mean **any origin on the internet** could read this API's authenticated response data if credentials were ever added later — a considerably larger exposure than intended.

**2. Configure the server to echo back a specific, validated allowlist.**
```js
const allowedOrigins = ['https://app.example.com', 'https://staging-app.example.com'];
app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (allowedOrigins.includes(origin)) {
    res.setHeader('Access-Control-Allow-Origin', origin); // never '*'
    res.setHeader('Access-Control-Allow-Credentials', 'true');
  }
  next();
});
```
Only requests from origins explicitly on the list get a permissive response; any other origin's browser-based script attempting to read the response is blocked by the browser, since the response won't carry a matching `Access-Control-Allow-Origin`.

**3. Client explicitly opts into sending credentials.**
```js
fetch('https://api.example.com/dashboard-data', { credentials: 'include' });
```
Without this, cookies aren't sent cross-origin by default even with the server correctly configured — both sides (client opt-in AND server allow-credentials) must agree.

**4. Set the session cookie's `SameSite` and `Domain` deliberately for this cross-subdomain shape.** Since `app.` and `api.` are different subdomains of the same registrable domain, the cookie's `Domain` attribute matters: setting `Domain=.example.com` (note the leading dot, or the modern equivalent of omitting `Domain` but scoping intentionally) makes the cookie available to both subdomains, whereas `SameSite=Strict` would still allow it here since same-site (registrable-domain-based) is a broader concept than same-origin — `app.example.com` and `api.example.com` count as the *same site* even though they're different *origins*, so `SameSite=Strict`/`Lax` cookies set with the right `Domain` are still sent between them, while `SameSite` continues to block truly cross-site (different registrable domain, e.g. `evil.com`) requests.

**5. Add CSRF protection regardless — CORS being correctly configured does not substitute for it.** Because the cookie is same-site (per step 4) and thus sent on requests even from other pages that happen to also be on `*.example.com` (if such a page existed and were compromised), and because CORS doesn't stop plain-form-based CSRF at all (forms aren't subject to CORS), a CSRF token or an equivalent header-based check should still gate state-changing endpoints — this is a case for explicitly naming "CORS is not a CSRF defense" as one of the design decisions, not an assumption left implicit.

**Why the wildcard proposal was the wrong instinct to fix a broken-looking error:** *"CORS errors are often 'fixed' by loosening the policy until the browser stops complaining, but here that specific fix (`*` with credentials) is actually disallowed by the spec and wouldn't resolve the error at all — the correct fix is a validated origin allowlist plus explicit `credentials: 'include'` on the client, matched to a deliberately-scoped cookie `Domain`/`SameSite`, with CSRF protection layered on top since CORS doesn't provide that."*
