# Scenario: An Embeddable Widget Needs Controlled Framing, Not a Blanket Block

**Scenario:** Your company ships a "reviews widget" that partner sites embed via `<iframe>` on their own pages. Currently there's no framing protection at all on your app (a general clickjacking risk for your *other*, non-widget pages), but naively adding `X-Frame-Options: DENY` site-wide would also break the legitimate embeddable widget. Design the fix.

**Approach:**

**1. Recognize this isn't a single site-wide policy problem — different routes have different legitimate framing needs.** The main app (account settings, checkout, admin panels) should never be frameable by anyone — that's a pure clickjacking risk with no legitimate embedding use case. The widget route specifically *needs* to be frameable, but ideally not by literally anyone (an attacker embedding the widget itself isn't dangerous content-wise, but it's still worth being deliberate rather than leaving it wide open by omission).

**2. Apply route-scoped headers rather than one global policy.**
```js
// Default: deny framing everywhere
app.use((req, res, next) => {
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Content-Security-Policy', "frame-ancestors 'none'");
  next();
});

// Override specifically for the widget route
app.get('/widget/reviews', (req, res, next) => {
  res.setHeader('X-Frame-Options', 'ALLOWALL'); // not a real standard value — see step 3
  res.removeHeader('Content-Security-Policy');
  res.setHeader('Content-Security-Policy', "frame-ancestors *"); // or an explicit partner allowlist
  next();
});
```

**3. Prefer `frame-ancestors` with an explicit allowlist over a fully open policy, using `X-Frame-Options` only as a coarse fallback.** `X-Frame-Options` can't express "allow these specific partner domains" — its only values are effectively deny-all or same-origin-only, so it can't be made partner-specific at all; the practical choice for the widget route is to either omit `X-Frame-Options` entirely (accepting older-browser fallback is just "unrestricted" there) or set a permissive value, while `frame-ancestors` carries the real, expressive policy:
```
Content-Security-Policy: frame-ancestors https://partner-a.com https://partner-b.com https://partner-c.com;
```
If the list of partner domains is dynamic/large (a self-serve embeddable widget product), an open `frame-ancestors *` may be the pragmatic choice for that route specifically — but that decision should be scoped to exactly the widget route/response, not leak into the rest of the app via a shared middleware default.

**4. The widget's own JS should not assume trust of its embedding context.** Independent of framing headers, the widget's client-side code should avoid reading/writing `document.cookie` for anything sensitive, should validate `postMessage` origins strictly if it communicates with the parent page, and should treat itself as running in a context it doesn't fully control — since "allowed to be framed by many partner domains" is inherently a lower-trust deployment context than the main app.

**5. Verify the fix doesn't regress the main app's protection — this is the part easy to get wrong with route-scoped overrides.** A common mistake: a shared middleware/config bug ends up applying the widget's permissive `frame-ancestors` to routes it wasn't intended for (e.g. because of route-matching order, or a misconfigured wildcard). The fix should be tested explicitly for both directions: confirm the widget route is embeddable by an allowed partner, and confirm every *other* route still rejects framing entirely.

**Why route-scoping is the right level of granularity:** *"A single site-wide framing policy can't satisfy both requirements at once, so the fix isn't picking one policy — it's applying `frame-ancestors 'none'`/`X-Frame-Options: DENY` as the default everywhere, then explicitly overriding to a scoped allowlist only on the specific widget route that needs to be embeddable, with the widget's own client code still not assuming a trusted embedding context even where framing is permitted."*
