# Scenario: Fixing a Stored XSS in a Comment System

**Scenario:** A security researcher reports that your app's comment feature is vulnerable to stored XSS — posting a comment containing `<img src=x onerror=alert(document.cookie)>` causes the alert to fire for every subsequent visitor to that page. You need to both fix this specific hole and reduce the blast radius of similar bugs elsewhere in the app that haven't been found yet.

**Approach:**

**1. Fix the immediate injection point: encode on output, not just on input.** The core bug is that comment text is rendered into HTML without escaping. The fix belongs at the **rendering** layer, not (only) at submission time — output encoding is the authoritative defense because it's applied at the exact point where trust boundaries are crossed (data → markup), and it protects against every path that data could have taken to get there (a compromised admin tool, a direct DB edit, an API integration — not just the comment form).
```jsx
// If using React: switch from a raw-HTML sink to plain text interpolation
- <div dangerouslySetInnerHTML={{ __html: comment.text }} />
+ <div>{comment.text}</div>  // auto-escaped by JSX
```
If rich text (bold/links) is a genuine product requirement, don't ban HTML entirely — sanitize with an allowlist-based library (DOMPurify) rather than hand-rolled regex stripping, which reliably misses edge cases (encoded payloads, unusual tag/attribute combinations).

**2. Add `HttpOnly` to the session cookie as a defense-in-depth measure, independent of fixing the hole itself.** The reported payload specifically targets `document.cookie` — marking the session cookie `HttpOnly` means that even if another, not-yet-found XSS hole exists elsewhere, the most damaging outcome (session token exfiltration and replay) is closed off, even though the injected script could still perform other damage using the live session (see step 4).

**3. Deploy a CSP with a strict `script-src` as a systemic backstop.** Rather than relying solely on finding and fixing every injection point (which is an ongoing, never-fully-complete effort across a large codebase), a `script-src 'self'` policy (with nonces for any legitimate inline scripts) means that **any** future injected inline script — even one from a bug not yet discovered — fails to execute. This converts "we hope we found every XSS hole" into "even holes we haven't found yet mostly can't be exploited for script execution."

**4. Audit for other raw-HTML sinks across the codebase, not just the reported one.** Search for `dangerouslySetInnerHTML`, `innerHTML =`, `document.write`, `v-html`, `eval(` across the codebase — the reported bug is very likely not unique; the same anti-pattern (raw HTML injection without sanitization) tends to be repeated by multiple engineers/features independently. Fixing only the reported instance without this audit step is a common mistake that leaves the same bug class live elsewhere.

**5. Note what `HttpOnly`/CSP do NOT fully solve, and communicate that clearly.** Even with `HttpOnly` in place, a successful XSS injection can still make authenticated requests (the browser attaches cookies to same-origin requests the injected script triggers, `HttpOnly` only blocks `document.cookie` *read* access) and manipulate the DOM the user sees (e.g. a fake login form). The real fix is closing the injection point (step 1); `HttpOnly` and CSP reduce the severity of exploitation, they don't make the underlying bug non-exploitable in every way.

**Why this layered response is the right scope:** *"I'd fix the specific bug at the rendering layer with proper output encoding, since that's the authoritative fix regardless of how untrusted data got there — but I'd also treat it as a signal to audit the whole codebase for the same sink pattern, and add `HttpOnly` plus a strict CSP as defense-in-depth so that any similar bug we haven't found yet has a much smaller blast radius."*
