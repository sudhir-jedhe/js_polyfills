# Scenario: Responding to a Compromised npm Dependency Already in Production

**Scenario:** A widely-used npm package your app depends on (a small utility library, three levels deep in your dependency tree) is publicly disclosed as compromised — a malicious version was published that exfiltrates form input to an attacker server, and it was live on the registry for six hours before being pulled. Your CI ran a build during that window. Walk through the response.

**Approach:**

**1. Determine exposure before assuming the worst, but don't assume safety either — verify.** Check the lockfile (`package-lock.json`/`yarn.lock`) history in version control for the exact resolved version of the compromised package across that six-hour window — a committed lockfile makes this answerable precisely ("did any commit's lockfile resolve to the malicious version?") rather than a guess. If the lockfile pinned an earlier, unaffected version and `npm ci` (not `npm install`) is used in CI, exposure may be fully avoided regardless of the compromised version's brief availability — this is the concrete payoff of lockfile discipline discussed in the dependency-security theory file.

**2. If exposure is confirmed (a build during the window resolved the malicious version), treat every artifact built during that window as compromised, not just "probably fine."** Any bundle shipped to production users from a build using the malicious version needs to be considered as having potentially shipped the malicious payload to real users — this drives the response urgency (rollback/reissue) rather than a quieter "patch it in the next deploy" response.

**3. Immediate containment:**
   - Roll back production to the last known-good build (pre-compromise-window), or rebuild from a commit pinned to the verified-safe version, and redeploy immediately — don't wait for a "proper" fix while a malicious bundle is potentially still serving live traffic.
   - Pin the dependency to the last known-good version explicitly in the lockfile (and ideally as an exact version, not a range) to prevent any subsequent install from silently drifting back toward a similarly compromised future release.
   - Rotate any secrets/tokens that could plausibly have been exposed if the malicious code ran in a build/CI context (not just browsers) — a build-time compromise (e.g. via a `postinstall` script) can exfiltrate environment variables, deploy credentials, or signing keys, which is a materially different and often worse exposure than the disclosed browser-side form-exfiltration behavior.

**4. User-facing assessment.** Since the disclosed payload exfiltrates form input, determine what forms exist on pages served by the compromised bundle (login forms, payment forms, personal data forms) and treat any credentials/data submitted through those forms during the exposure window as **potentially compromised** — this typically means forcing a password reset for affected users and notifying them, scoped to the actual exposure window determined in step 1, not a vague "sometime recently."

**5. Post-incident structural fixes, not just the immediate patch:**
   - Add automated dependency vulnerability/advisory scanning to CI if not already present, ideally with a fast-response alert channel (not just a weekly digest) for critical advisories.
   - Evaluate whether `postinstall`/lifecycle scripts should be restricted for third-party packages (e.g. via `pnpm`'s script-allowlisting) to reduce the blast radius of a similar future compromise at the build/CI layer specifically.
   - Consider Subresource Integrity for any dependency that's loaded from a CDN at runtime rather than bundled, and package provenance verification where the registry/tooling supports it, as an additional layer beyond lockfile pinning.

**Why exposure verification comes first, before any rollback:** *"The instinct is to panic-rollback everything, but the actually useful first step is answering a precise question — did any build in the exposure window resolve to the malicious version — using the committed lockfile history, because that determines whether this is a full incident-response event (rollback, secret rotation, user notification) or a non-event that a lockfile pin already prevented. Once exposure is confirmed, the response has to treat build-time secret exposure as at least as serious as the disclosed browser-side behavior, since a `postinstall`-based compromise often reaches further than what's publicly described."*
