# Interview Q&A — CSRF, CORS, and Cookies

**Q: Explain why CSRF is possible at all — what browser behavior does it exploit?**
Browsers automatically attach a domain's cookies to any request to that domain, regardless of which site initiated the request. An attacker's page on a different origin can trigger a request to your site (via a form, an image tag, etc.) and the browser will still attach the victim's session cookie, making the forged request look fully authenticated to the server.

**Q: Does CORS protect against CSRF?**
No — this is one of the most common mix-ups. CORS governs whether a script on another origin is allowed to **read the response** of a cross-origin request; it does nothing to stop the browser from **sending** the request in the first place, and a classic CSRF attack (an auto-submitting HTML form) doesn't even go through the CORS-governed `fetch`/XHR path at all — plain form submissions aren't subject to CORS preflight or response-reading restrictions.

**Q: What's the difference between `SameSite=Strict` and `SameSite=Lax`, concretely?**
`Strict` withholds the cookie on every cross-site request, including a top-level navigation from an external link — clicking a link to your site from elsewhere won't show the user as logged in on that first load. `Lax` (the modern default) still withholds the cookie on cross-site subresource requests and cross-site POST/PUT/DELETE, but allows it on cross-site top-level GET navigations (clicking a link), which is why `Lax` is the practical default — it blocks the classic form-based CSRF attack while not breaking normal cross-site linking.

**Q: If a session cookie is `SameSite=Lax`, is a CSRF token still necessary?**
Generally yes, for sensitive actions. `Lax` doesn't protect a state-changing action that's exposed on a plain top-level-navigable GET request (a bad but real API design choice) — a crafted link that a victim clicks would still carry the cookie in that specific case. A CSRF token protects the request itself regardless of the cookie's `SameSite` setting, so using both is standard defense-in-depth, not redundant.

**Q: What triggers a CORS preflight request?**
Any request that isn't a "simple request" — meaning it uses a method other than GET/HEAD/POST, includes a header that isn't CORS-safelisted (e.g. `Authorization`, custom `X-*` headers), or has a `Content-Type` other than `application/x-www-form-urlencoded`, `multipart/form-data`, or `text/plain` (most notably, `application/json` triggers a preflight).

**Q: Can a non-browser client (like `curl` or a server-to-server call) bypass CORS?**
Yes, entirely — CORS is enforced by the browser, not the server. A `curl` request or a backend service calling your API ignores `Access-Control-Allow-Origin` completely and reads whatever the server returns. This means CORS should never be treated as an authorization mechanism — the server must independently enforce real authentication/authorization; CORS only controls whether a browser-based script from a given origin is allowed to read a response.

**Q: Why must `Access-Control-Allow-Origin: *` never be paired with credentialed requests?**
Because it would mean any origin on the internet could read authenticated response data from a user's browser session — the spec explicitly forbids this combination, and browsers enforce it client-side (a request with `credentials: 'include'` against a `*` response is rejected). The server must instead validate the request's `Origin` header against an allowlist and echo back that specific origin.
