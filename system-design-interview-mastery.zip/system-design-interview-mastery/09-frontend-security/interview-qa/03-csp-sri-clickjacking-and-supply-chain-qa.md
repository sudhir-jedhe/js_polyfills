# Interview Q&A — CSP, SRI, Clickjacking, and Supply Chain

**Q: How does CSP actually stop an XSS payload from running, given that the injection already succeeded?**
CSP doesn't prevent the injection (the malicious tag can still land in the DOM) — it prevents **execution**. With `script-src 'self'` and no `'unsafe-inline'`, the browser evaluates every script execution attempt against the policy, and an injected inline `<script>` (without a valid nonce) is refused execution outright; a `<script src="...">` pointing at a non-allowlisted origin is likewise blocked from loading at all.

**Q: What's the practical difference between `X-Frame-Options` and CSP's `frame-ancestors`?**
`X-Frame-Options` only supports `DENY` or `SAMEORIGIN` (an old `ALLOW-FROM` value is deprecated/unreliable) — it can't express "allow framing by these specific N trusted partner domains." `frame-ancestors` accepts a full list of allowed origins, making it the only viable option for legitimate multi-partner embedding scenarios. Where both are supported, browsers prioritize `frame-ancestors`; sending both headers maximizes compatibility across browser versions.

**Q: Why does SRI require the `crossorigin` attribute alongside `integrity`?**
Computing a hash of a cross-origin resource's content requires the browser to actually read those bytes, which is restricted by default for cross-origin loads. The resource must be served with proper CORS headers and the tag must declare `crossorigin` — without this pairing, the browser can't perform the integrity check at all for a cross-origin resource.

**Q: Why can't SRI be used for a CDN URL that always serves "latest" with no version pinned?**
SRI pins an exact content hash — if the content is expected to change over time (as "latest" implies), there's no stable hash that stays valid, and every legitimate update would break the integrity check. SRI fundamentally requires committing to a specific, immutable version of a resource.

**Q: How does clickjacking differ mechanically from CSRF, even though both abuse an authenticated session?**
CSRF forges a request the browser sends automatically (with ambient cookies attached) without the victim clicking anything relevant to the actual target site. Clickjacking doesn't forge anything — it tricks the victim into personally, physically clicking a real, genuine button on the real site, rendered invisibly via an iframe under a decoy UI. The server sees a completely normal, legitimately-clicked request in both the clickjacking case and an intended user action — it has no way to distinguish them without frame protections.

**Q: What's the specific frontend-relevant risk of a compromised npm dependency, as opposed to a compromised backend one?**
A compromised frontend dependency, once bundled, executes with the full trust of your origin inside **every visiting user's browser** — able to read non-`HttpOnly` cookies, make authenticated `fetch` calls, and manipulate the DOM, all without needing a separate XSS bug. A compromised backend dependency's blast radius is contained to your own server infrastructure; a compromised frontend one is distributed to your entire user base the moment the new bundle ships.

**Q: What's the concrete purpose of committing a lockfile beyond "reproducible installs"?**
It pins exact resolved versions across the full dependency tree (including transitive dependencies), so an `npm ci`-style install in CI/production always gets the identical tree that was tested — closing the gap where a version range (`^1.2.3`) could silently resolve to a newly-published, compromised patch release between one install and the next, with no code change on your side to review.
