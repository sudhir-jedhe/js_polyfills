# Problem: Design a CSRF-Protected Form Submission Flow, End to End

## Problem Statement

Design (with real request/response shapes) a CSRF protection scheme for a session-cookie-authenticated app's `POST /api/settings` endpoint, covering: token generation, token delivery to the client, token validation, and token rotation policy. Your design must remain secure even if an attacker can view the page's publicly-served HTML source (e.g. via `view-source:`) but cannot execute JavaScript in the victim's authenticated session.

## Constraints

- The token must not be guessable or replayable across sessions.
- The design must explain specifically why an attacker who can craft an arbitrary cross-site form (the classic CSRF vector) cannot produce a valid request, even knowing your endpoint's exact shape.
- State whether the token should be a cookie itself, and justify the answer (a common wrong instinct is "just put it in a cookie too").

## Solution

**1. Token generation — server-side, cryptographically random, tied to the session.**
```js
function issueCsrfToken(session) {
  const token = crypto.randomBytes(32).toString('base64url');
  session.csrfToken = token; // stored server-side against this session's data, not sent as a second cookie
  return token;
}
```
Using `crypto.randomBytes` (not `Math.random()`, which is not cryptographically secure and can be predictable) ensures the token can't be guessed or brute-forced.

**2. Delivery — embedded in the authenticated HTML response or a same-origin API response, never in a cookie.**
```html
<form id="settings-form" method="POST" action="/api/settings">
  <input type="hidden" name="csrf_token" value="{{csrfToken}}" />
  <!-- other fields -->
</form>
```
**Why not a cookie:** this is the key design decision the constraint is probing. If the token were delivered as a second cookie (e.g. `csrf_token=xyz; SameSite=None`), the browser would attach it to a cross-site forged request **automatically, just like the session cookie** — the entire point of a CSRF token is that it's a value the attacker's forged form cannot know or supply, and a cookie is exactly the "ambient, automatically-attached" credential type CSRF exploits in the first place. The token must be delivered through a channel the forging page cannot read — embedded in the authenticated page's HTML (which `view-source:`-level static inspection of the attacker's *own* page obviously can't retrieve, since it's not their page) or fetched via a same-origin JS call, and then submitted back as a **form field or custom header**, not a cookie.

**3. Validation — server compares the submitted token against the session-stored one, on every state-changing request.**
```js
app.post('/api/settings', (req, res) => {
  const submitted = req.body.csrf_token;
  if (!submitted || submitted !== req.session.csrfToken) {
    return res.status(403).json({ error: 'CSRF validation failed' });
  }
  // ... proceed with the settings update
});
```

**4. Why the attacker fails even knowing the endpoint's exact shape.** The constraint specifies the attacker can view the *publicly served* HTML source but cannot execute JS in the victim's *authenticated* session — meaning they can see the *structure* of the form (field names, the endpoint URL) from an unauthenticated view of a similar page, but they cannot obtain the actual `csrf_token` **value**, because that value is generated per-session and embedded only in the authenticated response, which the attacker's own page never receives (the victim's browser does, but the attacker's page has no way to read the victim's authenticated page content — that would require an XSS bug on your site, a separate vulnerability class, not a CSRF weakness). A forged form on the attacker's site can submit the exact right field name (`csrf_token`) with a guessed or omitted value, but not the correct per-session value, and the server rejects the mismatch.

**5. Rotation policy.** Rotate the token on privilege-level transitions (login, logout, password change) at minimum — a token issued before authentication (or before a permission escalation) should not remain valid after it, closing a narrow session-fixation-adjacent gap. Rotating on *every* request is a stricter but often UX-costly option (breaks multi-tab usage, back-button-then-resubmit flows) — a reasonable middle ground is a per-session token that persists across requests within that session but is invalidated on logout and re-issued fresh on the next login.

**Why this design holds up against the stated threat model:** *"The token's security doesn't come from secrecy of the endpoint or field names — the attacker can know those. It comes from the fact that the token's actual value is delivered only through the victim's authenticated session and never through a channel (like a cookie) that the browser would attach automatically to a cross-origin forged request. That's also why it must never be reissued as a second cookie — doing so would recreate exactly the ambient-credential problem CSRF tokens exist to avoid."*
