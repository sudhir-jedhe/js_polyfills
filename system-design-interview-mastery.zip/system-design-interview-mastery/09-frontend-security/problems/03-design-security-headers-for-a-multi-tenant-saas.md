# Problem: Design the Security Header Set for a Multi-Tenant SaaS App

## Problem Statement

You're launching a multi-tenant SaaS product (`app.example.com`) with these requirements:
- It embeds a third-party support-chat widget (`https://chat.intercom-like.com`) via a `<script>` tag and an iframe.
- It must never itself be embeddable in another site's iframe (no legitimate embedding use case, and clickjacking on billing/settings pages is a real risk).
- It calls its own API on a separate subdomain (`api.example.com`) with cookie-based auth.
- It loads user-uploaded avatar images from an S3-backed CDN (`https://cdn-uploads.example.com`).
- Marketing wants a couple of small third-party analytics/tag-manager scripts added later without a full CSP redesign each time.

Design the complete header set (CSP, frame protection, cookie flags, CORS) and justify each directive/value against a specific requirement above.

## Constraints

- Every allowlisted origin in your CSP must trace back to a specific stated requirement — no blanket wildcards "to be safe."
- Explain how the design accommodates "add an analytics script later" without weakening the policy for everything else.
- State the cookie configuration for both the `app.` and `api.` cookies and justify `SameSite`/`Domain` choices given the two-subdomain architecture.

## Solution

**1. CSP, directive by directive, each justified:**
```
Content-Security-Policy:
  default-src 'self';
  script-src 'self' https://chat.intercom-like.com 'nonce-{per-request-nonce}';
  style-src 'self' 'unsafe-inline';
  img-src 'self' https://cdn-uploads.example.com data:;
  connect-src 'self' https://api.example.com https://chat.intercom-like.com;
  frame-src https://chat.intercom-like.com;
  frame-ancestors 'none';
  object-src 'none';
  base-uri 'self';
```
- `script-src 'self' https://chat.intercom-like.com` — the chat widget's script tag is the one stated third-party script requirement; nothing else is allowlisted. The nonce covers any legitimate first-party inline bootstrap script without resorting to `'unsafe-inline'`.
- `img-src ... https://cdn-uploads.example.com` — directly matches the avatar-CDN requirement; `data:` is added for small inline-encoded placeholder/fallback images, a narrow and common legitimate need, not a broad allowance.
- `connect-src ... https://api.example.com https://chat.intercom-like.com` — the app's own API calls and the chat widget's likely need to make its own XHR/fetch calls (support-chat widgets typically do) are both named requirements; nothing else is added.
- `frame-src https://chat.intercom-like.com` — the chat widget's iframe is explicitly named in the requirements; this is a separate directive from `script-src` because framing and script-loading are different resource types.
- `frame-ancestors 'none'` — directly satisfies "must never itself be embeddable" — the strictest possible value, since no legitimate embedding use case was stated.
- `style-src 'unsafe-inline'` is a deliberate, named trade-off (many component libraries/CSS-in-JS approaches inject inline styles) — flagged explicitly rather than silently included, since it's a real (if lower-severity) weakening worth calling out in the design rather than treating as free.

**2. Accommodating future analytics scripts without a full redesign.** Structure the CSP generation so `script-src`/`connect-src` origins are read from a small, explicitly-maintained allowlist config (not hardcoded inline in the header-setting code) — adding a new analytics vendor becomes a one-line config change reviewed like any other allowlist addition, not a "redesign the policy" event. This is a process/architecture answer as much as a technical one: the CSP's *shape* doesn't change, only its allowlist *contents* — worth stating explicitly, since it's what actually prevents "add an analytics script" from becoming a recurring full-policy re-audit.

**3. Frame protection — belt and suspenders.**
```
X-Frame-Options: DENY
```
Sent alongside `frame-ancestors 'none'` for older-browser fallback coverage, per the clickjacking theory file's guidance — redundant on modern browsers (which prioritize `frame-ancestors`) but harmless and covers the gap.

**4. Cookies across the two-subdomain architecture.**
```
# app.example.com session cookie
Set-Cookie: app_session=...; Domain=.example.com; Path=/; HttpOnly; Secure; SameSite=Lax

# api.example.com session cookie (if a separate one is used, or shared via the same Domain)
Set-Cookie: api_session=...; Domain=.example.com; Path=/; HttpOnly; Secure; SameSite=Lax
```
- `Domain=.example.com` (registrable-domain scope) lets one cookie (or matching cookies) be sent to both `app.` and `api.` subdomains, since they need to share authenticated session identity for the `app.` → `api.` calls.
- `SameSite=Lax` rather than `Strict`: `app.` and `api.` are different origins but the *same site* (same registrable domain), so `Lax`/`Strict` would both actually still permit the cookie between them in most flows — `Lax` is chosen here as the safer-by-default general recommendation, reserving `Strict` for cases needing the extra protection against top-level-navigation-carried cookies at the cost of the logged-out-on-first-click-from-outside tradeoff, which doesn't clearly apply better here.
- `HttpOnly`+`Secure` on both, per the standard baseline — no reason either cookie needs client-side JS access.
- A CORS config on `api.example.com` allowlisting `https://app.example.com` specifically (not `*`) with `Access-Control-Allow-Credentials: true`, since the app-to-API calls are credentialed cross-origin requests (different origins, same site) — this is the CORS piece completing the cross-subdomain architecture the cookie `Domain` scoping alone doesn't fully cover (CORS governs script-readability of the API's responses; the cookie `Domain`/`SameSite` governs whether the cookie is sent at all).

**Why every allowlist entry is traceable to a requirement, and why that discipline matters:** *"Each origin in the policy maps to one of the five stated integrations — nothing is included 'just in case,' because every additional allowlisted origin is attack surface a future XSS or supply-chain compromise could potentially reach through. Keeping the allowlist in a reviewed config file rather than scattered through header-setting code is what makes 'add one more analytics script later' a small, auditable diff instead of a reason to loosen the whole policy."*
