Diagrams and reference images for frontend security (e.g. a CSRF request-flow diagram, a CORS preflight sequence diagram, a CSP directive cheat sheet) will be added here.
