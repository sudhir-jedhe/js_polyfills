# Output: Classify the XSS Variant

Three code snippets. For each, identify whether it's stored, reflected, or DOM-based XSS, and why.

**Snippet A:**
```js
// server route handler
app.get('/profile', (req, res) => {
  const user = db.getUser(req.session.userId); // user.bio was saved earlier via a profile-edit form with no sanitization
  res.send(`<div class="bio">${user.bio}</div>`);
});
```

**Snippet B:**
```js
// server route handler
app.get('/search', (req, res) => {
  res.send(`<p>Results for: ${req.query.q}</p>`); // req.query.q is never persisted anywhere
});
```

**Snippet C:**
```js
// client-side only, page is otherwise fully static
const params = new URLSearchParams(location.search);
document.getElementById('welcome').innerHTML = `Welcome back, ${params.get('user')}`;
```

**Answers:**

- **A is stored XSS.** `user.bio` was written to the database at some earlier point (via the profile-edit form) without sanitization, and is now rendered unescaped to **every** visitor of `/profile` for that user — the payload is persistent and served passively to anyone who views the page, no crafted link required.
- **B is reflected XSS.** `req.query.q` comes straight from the current request's query string and is never stored — the server reflects it directly into the response HTML unescaped. This only affects a victim who is sent (and clicks) a crafted URL like `/search?q=<script>...</script>`; it isn't persistent for other visitors.
- **C is DOM-based XSS.** The server serves a completely static page — `req.query`/server rendering is never involved in the injection. The vulnerable flow (`location.search` → `innerHTML`) happens **entirely in client-side JavaScript**; a URL like `?user=<img src=x onerror=alert(1)>` triggers it with no server bug required at all, which is the defining trait of DOM-based XSS.

**Common wrong answer to watch for:** calling C "reflected" because the payload arrives via a URL parameter, like B. The delivery mechanism (a crafted link) is superficially similar, but the classification is about *where the vulnerable rendering happens* — B's vulnerability is server-side (the server writes attacker data into HTML it generates), C's is entirely client-side (a source-to-sink flow inside browser JS, with the server never involved in producing the dangerous output).
