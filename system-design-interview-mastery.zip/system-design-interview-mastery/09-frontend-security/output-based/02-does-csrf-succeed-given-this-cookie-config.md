# Output: Does This CSRF Attempt Succeed?

The victim is logged into `bank.com`. Its session cookie is set as:
```
Set-Cookie: session_id=abc123; SameSite=Lax; Secure; HttpOnly
```

The attacker's page on `evil.com` contains, in three separate variants tested independently:

**Variant 1:**
```html
<img src="https://bank.com/transfer?to=attacker&amount=500" />
```

**Variant 2:**
```html
<form action="https://bank.com/transfer" method="POST">
  <input type="hidden" name="to" value="attacker" />
  <input type="hidden" name="amount" value="500" />
</form>
<script>document.forms[0].submit();</script>
```

**Variant 3:**
```html
<a href="https://bank.com/transfer?to=attacker&amount=500">Claim your prize</a>
<!-- victim clicks the link, which is a normal top-level GET navigation -->
```

Assume `/transfer` performs the transfer on **GET** in variant 1 and 3 (a bad but real-world-common API design), and on **POST** in variant 2.

**Question:** Which variant(s), if any, succeed in attaching the victim's session cookie and executing the transfer?

**Answer:**
- **Variant 1 fails.** An `<img>` tag's request is a cross-site **subresource** request (not a top-level navigation), and `SameSite=Lax` withholds the cookie on cross-site subresource requests regardless of method — the request goes out, but without `session_id`, so it hits the server unauthenticated and fails (or hits a public/unauthenticated code path, but not as the logged-in victim).
- **Variant 2 fails.** This is a cross-site **POST**. `SameSite=Lax`'s exception for top-level navigations only covers "safe" methods triggered by direct navigation (effectively GET-like top-level loads, e.g. clicking a link or a `GET` form submit) — a cross-site POST, whether from a script-submitted form or a real user click on a submit button, is still withheld under `Lax`. The cookie is not attached, and the transfer fails for the same reason as variant 1.
- **Variant 3 succeeds in attaching the cookie — and this is the important nuance.** A genuine top-level navigation via a clicked `<a href>` link is a cross-site **GET**, which `SameSite=Lax` explicitly **does** allow the cookie to accompany (this is precisely what `Lax` was designed to still permit, so that clicking a link to a site you're logged into doesn't dump you into a logged-out state). If `/transfer` genuinely executes a state change on a GET request, this succeeds as a real CSRF attack — the cookie IS sent, and the transfer executes with the victim's authenticated session.

**The lesson this is testing:** `SameSite=Lax` protects state-changing requests **only if they require a method Lax withholds on cross-site requests (POST/PUT/DELETE, and non-top-level GETs like `<img>`/`<script src>`/`fetch`)** — it does not protect a state-changing action exposed on a plain top-level-navigable GET, because `Lax` deliberately still allows the cookie on that specific request shape. This is exactly why "state-changing actions must never be triggered by GET" is a security requirement independent of `SameSite`, and why sensitive endpoints should also require a CSRF token as defense-in-depth even with `SameSite=Lax` cookies in place.
