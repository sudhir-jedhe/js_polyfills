# Output: Given This CSP, Which of These Load/Execute?

```
Content-Security-Policy: default-src 'self'; script-src 'self' https://trusted-cdn.com; img-src *; style-src 'self' 'unsafe-inline'; connect-src 'self' https://api.example.com;
```

For each, determine whether the browser allows it.

**1.**
```html
<script src="https://trusted-cdn.com/lib.js"></script>
```

**2.**
```html
<script>console.log('inline script')</script>
```

**3.**
```html
<img src="https://random-image-host.io/pic.jpg" />
```

**4.**
```js
fetch('https://analytics-tracker.io/collect', { method: 'POST', body: '...' });
```

**5.**
```html
<style>.highlight { color: red; }</style>
```

**6.**
```html
<script src="https://api.example.com/dynamic-script.js"></script>
```

**Answers:**

1. **Allowed.** `https://trusted-cdn.com` is explicitly listed in `script-src`.
2. **Blocked.** `script-src` doesn't include `'unsafe-inline'`, so any inline `<script>` block (without a matching nonce/hash) is refused execution — this is the exact mechanism that neutralizes most injected-script XSS payloads.
3. **Allowed.** `img-src *` permits images from any origin.
4. **Blocked.** `connect-src` only allows `'self'` and `https://api.example.com` — a `fetch`/XHR to `analytics-tracker.io` is refused by the browser before the request completes (this is precisely the control that would stop an XSS payload from exfiltrating stolen data to an attacker's server via `fetch`, even if the injected script itself somehow got past `script-src`).
5. **Allowed.** `style-src` includes `'unsafe-inline'` here, so inline `<style>` blocks are permitted (note: this is a real, if less dangerous, CSP weakening — inline styles have a narrower but non-zero attack surface, e.g. CSS-based data exfiltration via attribute selectors in some contexts).
6. **Blocked.** `https://api.example.com` is listed under `connect-src`, **not** `script-src` — CSP directives are resource-type-specific, and being allowlisted for one type (fetch/XHR connections) does not grant permission for another (loading it as an executable script). This is a common trap: assuming any origin appearing anywhere in the policy is broadly trusted, when in fact each directive independently gates its own resource type.
