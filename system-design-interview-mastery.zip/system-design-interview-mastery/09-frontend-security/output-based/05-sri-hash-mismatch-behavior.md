# Output: SRI Hash Mismatch — What Happens?

```html
<script
  src="https://cdn.example.com/chart-lib@3.2.0.js"
  integrity="sha384-oqVuAfXRKap7fdgcCY5uykM6+R9GqQ8K/uxy9rx7HNQlGYl1kPzQho1wx4JwY8wC"
  crossorigin="anonymous">
</script>
<script>
  console.log('after chart-lib tag');
  new Chart(); // assume Chart is exported globally by chart-lib
</script>
```

Three independent scenarios, each tested separately:

**Scenario 1:** The CDN is compromised and now serves modified, malicious content at that exact URL. The `integrity` attribute in the HTML is unchanged.

**Scenario 2:** The CDN legitimately ships a patch release at the *same* URL (no version bump in the path — a misconfigured CDN behavior), changing the file's bytes slightly.

**Scenario 3:** The `<script>` tag is missing the `crossorigin` attribute, but `integrity` is present and the CDN does send proper CORS headers.

**Answers:**

- **Scenario 1:** The browser downloads the (now malicious) file, computes its SHA-384 hash, compares it against the declared `integrity` value, finds a mismatch, and **refuses to execute the script**. The `<script>` tag effectively fails to load (a console error like "Failed to find a valid digest... integrity check failed"). Since `chart-lib` never executes, `Chart` is never defined, and the second `<script>` block's `new Chart()` call throws a `ReferenceError` at runtime — SRI successfully prevented the malicious payload from running, at the cost of breaking the page's charting functionality (fail-closed, not fail-silent-and-vulnerable).
- **Scenario 2:** Same outcome as scenario 1, mechanically — SRI cannot distinguish "malicious tampering" from "legitimate but unexpected content change"; it only knows the bytes don't match the pinned hash. The script fails to execute either way. This illustrates why SRI requires **strict version pinning discipline** on the hosting side — any content change at a URL with a fixed `integrity` hash breaks the page, whether that change was malicious or an innocent CDN misconfiguration.
- **Scenario 3:** Without `crossorigin`, the browser is not permitted to read the cross-origin resource's bytes at all under standard cross-origin resource-sharing restrictions — so it **cannot compute a hash to verify against `integrity` in the first place**. In this configuration, browsers refuse to apply/execute the resource specifically because the integrity check cannot be performed as specified (this is browser-implementation-defined behavior around SRI-without-CORS, but the safe assumption is that it does not silently skip the check and load the script anyway — treat `crossorigin` as a required pairing with `integrity` for any cross-origin resource, not an optional nicety).

**The underlying lesson:** SRI is a strict, content-exact allowlist, not a "close enough" similarity check — any byte-level difference from the pinned hash, for any reason, results in the resource being refused. This is deliberate (fail-closed is the correct security posture) but means SRI-pinned CDN resources need real version-pinning discipline on the hosting side, or every legitimate patch release breaks every page that references the un-updated hash.
