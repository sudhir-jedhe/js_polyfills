# Output: Does This Request Trigger a CORS Preflight?

A page on `https://app.example.com` makes each of these requests to `https://api.example.com`. For each, determine whether the browser sends a preflight `OPTIONS` request first.

**Request A:**
```js
fetch('https://api.example.com/users', { method: 'GET' });
```

**Request B:**
```js
fetch('https://api.example.com/users', {
  method: 'POST',
  headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
  body: 'name=alice',
});
```

**Request C:**
```js
fetch('https://api.example.com/users', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ name: 'alice' }),
});
```

**Request D:**
```js
fetch('https://api.example.com/users/42', {
  method: 'GET',
  headers: { 'Authorization': 'Bearer abc123' },
});
```

**Answers:**

- **A — no preflight.** `GET` with no custom headers is a "simple request" — qualifies directly, no `OPTIONS` round trip.
- **B — no preflight.** `POST` with `Content-Type: application/x-www-form-urlencoded` is one of the three content-types explicitly allowed under the "simple request" rules (the other two are `multipart/form-data` and `text/plain`) — still qualifies as simple.
- **C — preflight required.** `Content-Type: application/json` is **not** one of the safelisted simple content-types, even though the method (`POST`) alone would otherwise be fine — the browser sends an `OPTIONS` preflight with `Access-Control-Request-Headers: content-type` before attempting the real request.
- **D — preflight required.** `Authorization` is not a CORS-safelisted header (safelisted headers are limited to `Accept`, `Accept-Language`, `Content-Language`, and a restricted `Content-Type`) — adding any custom/non-safelisted header forces a preflight, **even though the method is a plain `GET`**. This is the detail people most often miss: it's not just the method that determines "simple" vs. preflighted, it's the full combination of method + headers + content-type.

**The general rule to internalize:** a request is preflighted unless it simultaneously satisfies the method constraint (GET/HEAD/POST only) AND the header constraint (only safelisted headers) AND the content-type constraint (only the three safelisted types, if POST). Failing any single one of those three conditions is enough to trigger a preflight — they're ANDed together for "simple," not independent optional relaxations.
