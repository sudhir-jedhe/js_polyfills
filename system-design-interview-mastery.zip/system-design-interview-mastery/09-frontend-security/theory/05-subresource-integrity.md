# Subresource Integrity (SRI)

Subresource Integrity lets a page assert "I expect this externally-hosted file to have exactly this content" — if the fetched file's actual content doesn't hash-match what's declared, the browser refuses to execute/apply it. It exists specifically for the scenario where you load a script or stylesheet from a third party (a CDN) you don't fully control the security of at every moment.

## The threat it addresses

A page includes a script from a public CDN:
```html
<script src="https://cdn.example.com/library@2.1.0.js"></script>
```
This is a trust delegation: the page's security now depends on that CDN never serving anything other than the exact, intended file — for that specific version, forever. If the CDN is compromised (attacker gains write access to its storage), suffers a supply-chain attack, or is tricked via a DNS/BGP-level attack into being impersonated, the attacker can serve **modified JavaScript** to every site that includes that URL, and every one of those sites' users executes it, fully trusted, in the including page's own origin.

## How SRI closes this gap

```html
<script
  src="https://cdn.example.com/library@2.1.0.js"
  integrity="sha384-oqVuAfXRKap7fdgcCY5uykM6+R9GqQ8K/uxy9rx7HNQlGYl1kPzQho1wx4JwY8wC"
  crossorigin="anonymous">
</script>
```
The `integrity` attribute is a cryptographic hash (SHA-256/384/512) of the **exact expected file content**. Before executing the fetched resource, the browser hashes what it actually downloaded and compares it to the declared hash. If they don't match — for any reason, whether malicious tampering or an innocent accidental content change — the browser **refuses to execute the script or apply the stylesheet** at all, and the resource fails to load (visible as a console error).

## Why `crossorigin` is required alongside `integrity`

Computing a content hash on a cross-origin resource requires the browser to actually read that resource's bytes, which by default is restricted for cross-origin loads (similar in spirit to the Same-Origin Policy concerns covered in the CORS theory file). The resource must be served with CORS headers permitting the read (`Access-Control-Allow-Origin`), and the including `<script>`/`<link>` tag must set `crossorigin="anonymous"` (or `"use-credentials"`) — without this pairing, SRI verification silently cannot happen for a cross-origin resource, since the browser isn't allowed to inspect the bytes to hash them.

## Generating the hash

```bash
cat library.js | openssl dgst -sha384 -binary | openssl base64 -A
# then format as: integrity="sha384-<base64 output>"
```
Most reputable CDNs (jsDelivr, cdnjs, unpkg) publish the correct `integrity` value alongside the script tag they recommend for each pinned version — the hash is tied to that exact file content, so it must be regenerated any time the pinned version/file changes.

## SRI and CSP work together, not redundantly

CSP's `script-src` controls **which origins** are allowed to serve scripts at all; SRI controls **whether the specific bytes served from an allowed origin match what's expected**. A CDN origin can be fully allowlisted by CSP (a legitimate, trusted source in principle) and still get compromised/tampered — SRI is what catches that case, since CSP alone has no concept of "and it must be exactly this content."

```
Content-Security-Policy: script-src 'self' https://cdn.example.com; require-sri-for script style;
```
The (largely deprecated in practice, but conceptually useful to know) `require-sri-for` CSP directive could even mandate that any script/style loaded must carry an `integrity` attribute at all — making SRI non-optional for a given resource type site-wide, rather than relying on each individual `<script>` tag remembering to include it.

## Limitations

- **Only works for static, versioned resources.** A CDN URL that always serves "latest" (no version pin) breaks SRI by design — the file's content, and therefore its correct hash, changes over time, so there's no stable hash to pin. SRI inherently requires committing to a specific, immutable version of a dependency.
- **Doesn't cover dynamically generated content** or resources fetched via `fetch()`/XHR (SRI is a resource-loading-attribute mechanism for `<script>`/`<link>` tags, not a general request-integrity system).
- **Adds an update step** — bumping a CDN-hosted dependency's version requires also updating the `integrity` hash, or the resource fails to load entirely (a deliberate fail-closed behavior, but it means version bumps aren't purely "change the URL").

## Interview framing

*"SRI addresses the trust-delegation risk of loading a script or stylesheet from a third-party CDN — it pins an expected cryptographic hash of the resource's exact content, and the browser refuses to execute anything that doesn't match, which protects against the CDN being compromised or tampered with after the fact. It requires `crossorigin` to be set so the browser is actually permitted to read the cross-origin bytes to hash them, and it only works for pinned, versioned resources since the hash has to match exact content."*
