# CSRF: The Attack, and How SameSite Cookies + Tokens Mitigate It

Cross-Site Request Forgery (CSRF) exploits a specific browser behavior: **cookies are attached to a request automatically based on the target domain, regardless of which site the request originated from.** If a user is logged into `bank.com` (holding a session cookie) and visits a malicious page, that malicious page can trigger a request to `bank.com` and the browser will happily attach the user's `bank.com` cookies to it — the request looks fully authenticated to the server, even though the *user* never intended to make it.

## The attack mechanics, precisely

1. Victim logs into `bank.com`; the browser stores a session cookie for that domain.
2. Victim visits `evil.com` (in the same browser, same session — doesn't need to be the same tab).
3. `evil.com`'s page contains something like:
```html
<form action="https://bank.com/transfer" method="POST" id="f">
  <input type="hidden" name="to" value="attacker-account" />
  <input type="hidden" name="amount" value="10000" />
</form>
<script>document.getElementById('f').submit();</script>
```
4. The browser submits this POST to `bank.com`. Because cookies are domain-scoped, not origin-scoped-to-the-initiator, the browser attaches the victim's `bank.com` session cookie automatically.
5. If `bank.com`'s server has no other check beyond "is there a valid session cookie," it processes the transfer as if the logged-in user requested it — because as far as cookie-based auth is concerned, they did.

**Critical distinction from XSS:** CSRF doesn't require the attacker to read anything from `bank.com` or execute code on `bank.com`'s origin — the malicious form lives entirely on the attacker's own site. It only needs to make the browser *send* a request with the victim's ambient credentials attached. This is why CSRF is sometimes called a "confused deputy" attack: the browser is deputized to act with the user's authority, and it can't tell a legitimate first-party request from a forged third-party one on its own.

## Mitigation 1: SameSite cookies

The `SameSite` cookie attribute tells the browser whether to attach a cookie to requests that originate from a **different site** than the one the cookie belongs to.

| Value | Behavior | Effect on CSRF |
|---|---|---|
| `SameSite=Strict` | Cookie is never sent on cross-site requests, not even top-level navigations (e.g. clicking a link from an email to `bank.com` won't include the cookie on that very first navigation) | Strongest CSRF protection, but can break legitimate flows (e.g. arriving at a logged-in page via an external link may not show you as logged in on that first load) |
| `SameSite=Lax` | Cookie is sent on top-level, "safe" navigations (GET, clicking a link) but withheld on cross-site subresource requests and cross-site POST/PUT/DELETE (e.g. the form-auto-submit attack above) | The modern browser default; blocks the classic form-based CSRF POST while still letting a user click a link from elsewhere and land logged in |
| `SameSite=None` | Cookie is sent on all requests, cross-site included | No CSRF protection from this attribute at all; **requires `Secure`** (HTTPS-only) as a browser-enforced pairing — needed for legitimate cross-site use cases like third-party embedded widgets |

Because `Lax` is the modern browser default when `SameSite` isn't explicitly set, a large share of CSRF risk is mitigated automatically today just by not overriding it — but relying solely on the *default* is fragile (older browsers, or a future spec/browser change) and doesn't cover every request method nuance, so defense-in-depth with a token is still standard practice for anything sensitive.

## Mitigation 2: CSRF tokens (synchronizer token pattern)

The server generates a unique, unpredictable token per session (or per form), embeds it in the page (a hidden form field or a value the client must read and echo back in a custom header), and validates that the token accompanies any state-changing request.

```html
<form action="/transfer" method="POST">
  <input type="hidden" name="csrf_token" value="a1b2c3...unpredictable..." />
  <!-- ... -->
</form>
```

**Why this defeats CSRF:** the attacker's forged form on `evil.com` has no way to know or read the victim's current CSRF token — it isn't ambient like a cookie; it must be explicitly read from the legitimate page (via JS) and included, and cross-origin JS can't read another origin's response body to extract it (blocked by the Same-Origin Policy, independent of CORS — see the CORS theory file for why a fetch's *response* is unreadable cross-origin even if the request itself goes out). The forged request can fire, but it fires without a valid token, and the server rejects it.

## Why both, not either/or

`SameSite=Lax`/`Strict` is a strong default-deny mechanism enforced entirely by the browser with zero server-side code — but it protects the *cookie*, not the *request* in isolation; some legitimate cross-site flows require `SameSite=None`, and older or misconfigured clients can be exceptions. CSRF tokens protect the *request* directly regardless of cookie policy, but require server-side generation/validation plumbing. Using both is standard defense-in-depth: `SameSite=Lax` closes off the vast majority of naive attacks by default, and a token catches anything that slips past (or covers the cases where a cookie has to be `SameSite=None` for legitimate reasons).

## What does NOT protect against CSRF

- **CORS** — a common misconception. CORS controls whether a *script on another origin* can **read the response** of a cross-origin request; it does not stop the browser from *sending* the forged request in the first place (the classic CSRF attack via an auto-submitting `<form>` doesn't even use `fetch`/XHR — a plain HTML form POST is enough, and CORS doesn't apply to plain form submissions at all).
- **Just checking the `Referer`/`Origin` header** — a defense-in-depth signal (and a reasonable secondary check), but not sufficient alone historically, since these headers can be stripped or unreliable in some proxy/client configurations; better used as a supplement to `SameSite` + tokens, not a replacement.

## Interview framing

*"CSRF exploits the browser automatically attaching a domain's cookies to a request regardless of what site initiated it. `SameSite=Lax`/`Strict` fixes this at the cookie layer by telling the browser not to attach the cookie on cross-site state-changing requests. A CSRF token fixes it at the request layer by requiring a value the attacker's page has no way to read or predict. I'd use both — `SameSite` as the default-deny baseline, and a token for anything sensitive or where cookies must be `SameSite=None` for legitimate cross-site use."*
