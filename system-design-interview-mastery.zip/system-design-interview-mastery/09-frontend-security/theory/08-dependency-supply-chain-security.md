# Dependency and Supply-Chain Security Basics

Modern frontend apps pull in hundreds to thousands of transitive `npm` dependencies — code you never reviewed, written by people you don't know, that runs with the full trust of your build process and, once bundled, the full trust of your users' browsers in your origin. Supply-chain security is the practice of managing the risk that any one of those packages is malicious, compromised, or silently vulnerable.

## Where the risk actually enters

1. **A direct or transitive dependency is compromised post-publish.** An attacker gains access to a maintainer's npm publish credentials (via phishing, credential stuffing, or a leaked token) and pushes a new version of a popular package containing malicious code (e.g. exfiltrating environment variables during the build, or injecting a browser-side keylogger/crypto-miner into the bundled output). Because most projects use caret/tilde version ranges (`^1.2.3`), the next `npm install` or CI build can silently pull the compromised version without any code change on your side.
2. **Typosquatting.** An attacker publishes a package with a name deceptively close to a popular one (`reactt`, `lodash-es-` variants) hoping for an accidental `npm install` typo.
3. **A known vulnerability (CVE) exists in a dependency version you're already using** — not malicious by intent, just a bug with security impact (e.g. a ReDoS in a parsing library, a prototype-pollution bug that an attacker can trigger via crafted input flowing through that library).
4. **Build-time compromise.** Malicious `postinstall` scripts (npm packages can run arbitrary shell commands during install) that execute on developer machines and CI runners — a well-known real-world vector, since these scripts run with whatever privileges the install process has, entirely outside the sandboxing a browser would normally provide to the eventual bundled code.

## Practical mitigations

- **Lockfiles, committed and respected (`package-lock.json`/`yarn.lock`/`pnpm-lock.yaml`).** Pin exact resolved versions (including transitive ones) so `npm ci`/equivalent installs the identical dependency tree every time, rather than re-resolving version ranges against whatever the registry currently has — this closes the "silently pulls a compromised new patch version" gap for any install that uses the lockfile.
- **Automated vulnerability scanning** — `npm audit`/`yarn audit`, or a dedicated tool (Snyk, Dependabot, GitHub's native dependency alerts) run in CI, flags known-CVE dependency versions and can auto-open upgrade PRs. This addresses category 3 above specifically — known, disclosed vulnerabilities.
- **Provenance/signature verification** where available — npm's package provenance (Sigstore-based) lets a package assert a verifiable link back to the exact CI build and source commit that produced it, making a stealthily-modified publish (without a matching source change) detectable.
- **Minimize `postinstall` script risk** — some package managers support disabling arbitrary lifecycle scripts by default (`pnpm` disables them unless explicitly allowlisted per-package) or running installs in a more restricted environment/CI sandbox.
- **Review the dependency tree size deliberately, not just its vulnerabilities.** Every transitive dependency is attack surface, whether or not it currently has a known CVE — a library that pulls in 200 transitive packages for a small feature is a materially larger supply-chain surface than one with 3, independent of any specific vulnerability existing today.
- **Subresource Integrity for anything loaded at runtime from a third-party CDN** (as opposed to bundled at build time) — see the dedicated SRI theory file; it's the runtime-loading analog of a lockfile's build-time pinning.
- **Least-privilege CI credentials and 2FA/hardware keys on publish accounts** — from the *maintainer* side (relevant if you publish your own packages): npm supports requiring 2FA for publishing, which meaningfully raises the bar against the credential-theft compromise scenario.

## The frontend-specific angle (not just a general "npm security" topic)

What makes this specifically a *frontend* security concern, not just a generic backend/DevOps one: a compromised frontend dependency ends up **bundled directly into client-side JavaScript that runs in every user's browser**, with the same origin-level trust as your own first-party code — meaning it can read cookies (unless `HttpOnly`), make authenticated `fetch` calls, manipulate the DOM, and exfiltrate data, all without needing to find a separate XSS bug first. A compromised backend dependency is contained to your server infrastructure; a compromised frontend dependency is distributed to every visitor's browser the moment the new bundle ships.

## Interview framing

*"The frontend-specific risk is that any dependency bundled into the client build gets executed with the full trust of your origin in every user's browser — it's not sandboxed the way a browser sandboxes cross-origin content. Mitigations layer at build time (committed lockfiles so installs are deterministic, automated CVE scanning in CI, minimizing/auditing install-time scripts) and at runtime for anything loaded from a CDN rather than bundled (Subresource Integrity). None of these prevent a determined, well-resourced supply-chain attack outright, but together they shrink the window and the blast radius significantly."*
