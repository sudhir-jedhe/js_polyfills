# Secure Cookie Flags: HttpOnly, Secure, SameSite

Cookies are the most common vehicle for session identity on the web, which makes their configuration flags a concentrated, high-leverage security surface. Three flags — `HttpOnly`, `Secure`, and `SameSite` — each close off a distinct attack vector, and interviewers expect you to name which flag stops which attack, not just recite the list.

## `HttpOnly` — blocks JavaScript access, mitigates XSS-driven cookie theft

```
Set-Cookie: session_id=abc123; HttpOnly
```
A cookie marked `HttpOnly` is **inaccessible to `document.cookie`** — client-side JavaScript cannot read it (or write it) at all; it's only ever sent automatically by the browser in the `Cookie` header of matching requests.

**What it protects against:** if an XSS vulnerability exists elsewhere on the page (see the XSS theory file), the injected script's most common goal — reading the session cookie via `document.cookie` and exfiltrating it to an attacker-controlled server — simply fails, because `document.cookie` never exposes an `HttpOnly` cookie's value. It doesn't prevent the XSS itself, and a sufficiently capable attacker can still do plenty of damage via XSS without stealing the cookie directly (e.g. making authenticated requests using the victim's live session, since the browser still attaches the cookie to same-origin requests the injected script triggers) — but it does close off the specific "exfiltrate the raw token and replay it elsewhere/later" attack path.

## `Secure` — cookie only sent over HTTPS

```
Set-Cookie: session_id=abc123; Secure
```
A cookie marked `Secure` is only ever transmitted over an HTTPS connection — the browser will not attach it to a plain `http://` request, even to the same host. This protects against network-level eavesdropping (a man-in-the-middle on an unencrypted connection reading the cookie in transit) — without `Secure`, a session cookie could leak over any accidental or forced plain-HTTP request (e.g. a user typing `http://` explicitly, or an old link), even if the site is HTTPS-only in the common case.

## `SameSite` — controls cross-site sending, mitigates CSRF

Covered in depth in the CSRF theory file — the short version: `Strict`/`Lax` withhold the cookie from cross-site requests (fully, or except top-level safe navigations, respectively), which is the primary browser-enforced CSRF mitigation. `None` sends the cookie on all requests including cross-site ones, and must be paired with `Secure`.

## The full recommended baseline for a session cookie

```
Set-Cookie: session_id=abc123; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=3600
```

| Flag | Defends against |
|---|---|
| `HttpOnly` | XSS-driven cookie exfiltration via `document.cookie` |
| `Secure` | Network eavesdropping on plain HTTP |
| `SameSite=Lax`/`Strict` | CSRF (cross-site ambient credential attachment) |
| `Path`/domain scoping | Limits which routes/subdomains receive the cookie at all, reducing exposure |
| A reasonable `Max-Age`/expiry | Limits the window a stolen/leaked token remains valid |

None of these flags is a substitute for another — each closes a *different* attack vector, and omitting any one leaves that specific vector open regardless of how well the others are configured. A cookie with `Secure` and `SameSite=Strict` but missing `HttpOnly` is still fully readable and stealable by any successful XSS injection on the page.

## `__Host-` and `__Secure-` cookie name prefixes

Browsers enforce extra guarantees for cookies whose *name* is prefixed with `__Host-` or `__Secure-`, which prevents certain cookie-injection/overwrite attacks (e.g. a sibling subdomain, or a non-HTTPS context, setting a same-named cookie that shadows or conflicts with the legitimate one):

- `__Secure-` prefix: browser refuses to accept the `Set-Cookie` unless it also has `Secure` and was set from an HTTPS context.
- `__Host-` prefix: all of the above, **plus** no `Domain` attribute is allowed (so it can't be scoped to a parent domain — it's locked to the exact host) and `Path=/` is required — the strictest, most host-locked cookie form available.

## Interview framing

*"Each flag mitigates a specific, distinct attack: `HttpOnly` stops an XSS payload from reading the cookie via `document.cookie`, `Secure` stops it leaking over an unencrypted connection, and `SameSite` stops the browser from ambiently attaching it to cross-site requests, which is the core CSRF vector. They're not redundant with each other — a session cookie should default to all three (`HttpOnly; Secure; SameSite=Lax` or stricter) because each one closes a door the others don't touch."*
