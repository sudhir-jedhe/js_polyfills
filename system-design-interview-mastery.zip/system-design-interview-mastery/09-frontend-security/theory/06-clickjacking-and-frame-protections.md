# Clickjacking and Frame Protections (X-Frame-Options / frame-ancestors)

Clickjacking tricks a user into clicking something on your site while believing they're clicking something on the attacker's page — done by rendering your site inside an invisible or disguised `<iframe>` layered underneath the attacker's own decoy UI.

## The attack mechanics

1. Attacker builds a page with an enticing decoy button ("Click to win a prize!").
2. Behind that decoy, positioned with `opacity: 0` and precise CSS positioning, they embed the target site in an `<iframe>` — for example, a bank's "confirm transfer" page, or a social network's "follow" button, or a settings page's "grant access" button.
```html
<div style="position: relative; width: 300px; height: 100px;">
  <iframe src="https://victim-bank.com/confirm-transfer?to=attacker&amount=5000"
          style="position: absolute; top: 0; left: 0; width: 300px; height: 100px; opacity: 0;">
  </iframe>
  <button style="position: absolute; top: 0; left: 0;">Click to win a prize!</button>
</div>
```
3. The victim, logged into `victim-bank.com` in the same browser (so the iframe loads their authenticated session), clicks what they believe is the "win a prize" button — but the click actually lands on the invisible, precisely-positioned button inside the iframe, e.g. "Confirm Transfer."
4. Because the iframe is genuinely rendering the real, authenticated `victim-bank.com` page (cookies included, since it's a same-browser navigation to the real origin), the click is a **real, valid, authenticated action** on the victim's account — the site has no way to distinguish it from an intentional click, because from the server's perspective, it's an entirely normal authenticated request.

**The key distinction from CSRF:** CSRF forges a request the browser sends on the victim's behalf without them clicking anything relevant; clickjacking tricks the victim into personally, physically clicking a real button on the real site — the attacker doesn't need to forge the request at all, they just need to control what the user *believes* they're clicking.

## Mitigation 1: `X-Frame-Options` header (legacy, still widely supported)

```
X-Frame-Options: DENY
X-Frame-Options: SAMEORIGIN
```
- `DENY` — the page can never be framed by anyone, including itself.
- `SAMEORIGIN` — the page can only be framed by pages on the same origin.
- (`ALLOW-FROM https://trusted.com` existed but is deprecated/inconsistently supported — not a reliable option in modern browsers.)

**Limitation:** `X-Frame-Options` supports only a single value and can't allowlist multiple specific trusted origins (only same-origin or nobody) — this is the concrete reason `frame-ancestors` superseded it.

## Mitigation 2: CSP `frame-ancestors` directive (modern, preferred)

```
Content-Security-Policy: frame-ancestors 'self' https://trusted-partner.com;
```
`frame-ancestors` is more flexible than `X-Frame-Options` — it accepts a **list** of allowed framing origins, not just same-origin-or-nobody, making it viable for legitimate embedding scenarios (e.g. an app deliberately embeddable by a specific set of trusted partner domains) that `X-Frame-Options` can't express at all.

**Precedence note (a real gotcha):** when both headers are present, browsers that support CSP `frame-ancestors` prioritize it and ignore `X-Frame-Options`. The standard practice is to send **both** — `frame-ancestors` for modern browsers, `X-Frame-Options` as a fallback for older ones that don't parse CSP's framing directive — since sending both is harmless (a modern browser just uses the more expressive one) and maximizes coverage across browser versions.

## Why "frame-busting" JavaScript is not a reliable substitute

An older technique tries to detect and escape framing client-side:
```js
if (window.top !== window.self) {
  window.top.location = window.self.location;
}
```
This is unreliable and should not be relied on as the primary defense: an attacker's framing page can neutralize it (e.g. via the iframe `sandbox` attribute without `allow-top-navigation`, or by intercepting/overriding the navigation attempt), and it only runs *after* the page has already loaded inside the frame — there's a window where the frame is live and clickable before the busting script executes, if it executes at all. The header-based approaches (`X-Frame-Options`/`frame-ancestors`) are enforced by the browser **before** the framed content is even rendered, which is why they're the actual defense and frame-busting scripts are, at best, defense-in-depth.

## Interview framing

*"Clickjacking layers your real, authenticated page invisibly under a decoy UI so a user's genuine click lands on your page's button instead of the decoy — unlike CSRF, it doesn't forge a request, it tricks the user into personally making a real one. The fix is telling the browser not to allow your page to be framed at all, via `X-Frame-Options: DENY`/`SAMEORIGIN` or the more flexible CSP `frame-ancestors` directive, which supports an explicit allowlist of multiple trusted framing origins. I'd send both headers for browser coverage, since `frame-ancestors` takes precedence where supported but older browsers only understand `X-Frame-Options`."*
