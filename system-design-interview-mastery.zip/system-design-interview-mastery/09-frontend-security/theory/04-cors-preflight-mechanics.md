# CORS: The Actual Preflight Mechanics

CORS (Cross-Origin Resource Sharing) is frequently described as "a browser security feature" and left at that, which is exactly the hand-wavy version interviewers want you to go past. The precise mechanics: CORS is a **relaxation mechanism** layered on top of the Same-Origin Policy (SOP) — SOP is the actual default-deny rule (a script on `a.com` cannot read a response from `b.com`), and CORS is the opt-in protocol that lets `b.com`'s server tell browsers "actually, it's fine for `a.com` to read my responses."

## Same-Origin Policy first — what CORS is relaxing

Two URLs are **same-origin** only if scheme, host, and port all match exactly. `https://example.com` and `http://example.com` are different origins (scheme differs); `https://example.com` and `https://api.example.com` are different origins (host differs, subdomains count as different hosts); `https://example.com:443` and `https://example.com:8443` are different origins (port differs).

By default, SOP prevents a script running on origin A from reading the response of a `fetch`/XHR request made to origin B — **the request can still go out and the server can still process it**; what SOP blocks is the browser handing the *response* back to the calling script. This is the single most-missed detail: CORS/SOP is not about preventing the request from being sent (that's what CSRF defenses are for) — it's about preventing the response from being read by unauthorized script code.

## Simple requests vs. requests that trigger a preflight

Not every cross-origin request triggers a preflight. A request qualifies as a **"simple request"** (no preflight) only if it meets all of:
- Method is `GET`, `HEAD`, or `POST`
- Only "CORS-safelisted" headers are set (`Accept`, `Accept-Language`, `Content-Language`, `Content-Type` restricted to `application/x-www-form-urlencoded`, `multipart/form-data`, or `text/plain`)
- No `ReadableStream` used in the request body, and a few other narrow constraints

Anything outside that — a custom header (`Authorization`, `X-Custom-Header`), a `Content-Type: application/json`, or methods like `PUT`/`DELETE`/`PATCH` — is a **"non-simple" request** and triggers a **preflight**.

## The preflight sequence, step by step

1. Before sending the actual request, the browser automatically sends an `OPTIONS` request to the same URL, with no body, containing:
   - `Origin: https://a.com` — where the request is coming from
   - `Access-Control-Request-Method: PUT` — the method the real request will use
   - `Access-Control-Request-Headers: content-type, x-custom-header` — the custom headers the real request will send
2. The server responds to this `OPTIONS` request (typically without even routing it to application logic — most frameworks handle it at a middleware layer) with headers describing what it permits:
   - `Access-Control-Allow-Origin: https://a.com` (or `*`, though `*` cannot be combined with credentialed requests — see below)
   - `Access-Control-Allow-Methods: GET, POST, PUT`
   - `Access-Control-Allow-Headers: content-type, x-custom-header`
   - `Access-Control-Max-Age: 86400` (how long the browser may cache this preflight result, avoiding a repeat `OPTIONS` for subsequent identical requests within that window)
3. The browser checks the actual request's method/headers against what the preflight response allowed. If everything's within the allowed set, it proceeds to send the **real** request (the `PUT`, with the actual body).
4. If the real request's method/headers exceed what was allowed, the browser **never sends the real request at all** — it fails client-side before the network call for the real request goes out.

**A frequently-tested detail:** the preflight `OPTIONS` request carries no cookies/credentials by default and gets no application-level side effects — its sole purpose is asking permission. The server's `OPTIONS` handler should not perform any real work; it just needs to answer with the right CORS headers.

## Credentialed requests

By default, cross-origin `fetch`/XHR requests don't send cookies. To include them (e.g. session cookies for a cross-origin API call), the client must explicitly opt in:
```js
fetch('https://api.example.com/data', { credentials: 'include' });
```
And the server must respond with:
```
Access-Control-Allow-Origin: https://a.com   (must be a specific origin, NOT '*')
Access-Control-Allow-Credentials: true
```
**Critical rule:** `Access-Control-Allow-Origin: *` is explicitly disallowed by the spec (and rejected by browsers) when credentials are involved — the server must echo back a specific, validated origin. This exists precisely to prevent a wildcard CORS policy from accidentally exposing credentialed, authenticated responses to literally any origin on the web.

## Comparison table: what triggers what

| Request shape | Preflight? | Notes |
|---|---|---|
| `GET` with only safelisted headers | No | "Simple" request — sent directly |
| `POST` with `Content-Type: application/x-www-form-urlencoded` | No | Still "simple" |
| `POST` with `Content-Type: application/json` | Yes | `application/json` is not a safelisted content-type |
| `PUT`/`DELETE`/`PATCH`, any content-type | Yes | Method itself isn't in the simple-method list |
| Any request with a custom header (`Authorization`, `X-Api-Key`) | Yes | Custom headers aren't safelisted |

## What CORS is not

- **Not a server-side security boundary on its own** — CORS headers are advisory to *browsers*; a non-browser client (`curl`, a server-to-server call, Postman) ignores CORS entirely and can read whatever the server returns, because CORS enforcement lives in the browser, not the server. The server must still perform real authorization checks — CORS only controls whether a browser-based script is allowed to read the response, not whether the underlying data is protected.
- **Not a CSRF defense** — see the CSRF theory file; CORS governs response-readability for script-initiated cross-origin requests, not whether a plain HTML form can trigger a cross-origin state-changing request with ambient cookies attached (forms aren't subject to CORS preflight checks at all).

## Interview framing

*"CORS is the browser's opt-in relaxation of the Same-Origin Policy — the request always reaches the server, what SOP/CORS actually gates is whether the calling script is allowed to read the response. Non-simple requests — custom headers, non-form content types, methods beyond GET/HEAD/POST — trigger a preflight: the browser sends an OPTIONS request asking permission, the server answers with Allow-Origin/Allow-Methods/Allow-Headers, and only if the real request fits within that does the browser send it. Credentialed cross-origin requests additionally require the server to echo a specific origin, never a wildcard, precisely to stop a permissive CORS policy from exposing authenticated data to arbitrary origins."*
