# Frontend Security

Frontend security interview questions get hand-waved constantly — "XSS is when attackers inject scripts," "CORS is a browser security feature," "use SameSite cookies for CSRF" — without the actual mechanics behind them. This topic goes one level deeper on purpose: the precise distinction between XSS variants (and why the fix differs by variant), the exact browser behavior CSRF exploits and how `SameSite` and tokens each close a different gap, the real CORS preflight request/response sequence, and which CSP directive actually stops an injected script from executing and why. Getting these mechanics right — not just the vocabulary — is what separates a candidate who can debug a real security incident from one reciting a checklist.

## Folder structure

- **[`theory/`](./theory)** — XSS (stored/reflected/DOM-based), CSRF and SameSite cookies, Content Security Policy directives, CORS preflight mechanics, Subresource Integrity, clickjacking and frame protections, secure cookie flags, and dependency/supply-chain security.
- **[`snippets/`](./snippets)** — 5 focused examples: safe vs. unsafe rendering of untrusted data, a CSRF token issue-and-verify flow, a CSP header with a per-request nonce, a full CORS preflight exchange, and a baseline security header set.
- **[`output-based/`](./output-based)** — 5 "given this setup, what happens?" questions: classifying an XSS variant from code, whether a CSRF attempt succeeds under specific `SameSite`/method combinations, whether a request triggers a CORS preflight, what a given CSP policy blocks vs. allows, and SRI hash-mismatch behavior.
- **[`scenarios/`](./scenarios)** — 5 real-world design/fix situations: fixing a reported stored XSS, securing a cross-subdomain API with CORS and cookies, rolling out CSP on a large app without breaking it, allowing controlled framing for an embeddable widget, and responding to a compromised npm dependency already in production.
- **[`interview-qa/`](./interview-qa)** — 3 themed files: XSS/injection fundamentals, CSRF/CORS/cookies, and CSP/SRI/clickjacking/supply chain.
- **[`problems/`](./problems)** — 3 hands-on challenges: build a sanitizing rich-text comment renderer, design a CSRF-protected form flow end to end, and design the full security header set for a multi-tenant SaaS app.
- **[`assets/`](./assets)** — placeholder for diagrams (see `assets/README.md`).

## What's covered

- The precise mechanical distinction between stored, reflected, and DOM-based XSS — where each payload lives, how it's delivered, and why the mitigation differs (DOM-based specifically can't be fixed by server-side output encoding alone)
- Exactly what browser behavior CSRF exploits (automatic, origin-agnostic cookie attachment), and how `SameSite=Lax`/`Strict` and synchronizer tokens close different parts of the gap — including why CORS does **not** protect against CSRF
- The full CORS preflight sequence: what makes a request "simple" vs. preflighted, the actual `OPTIONS` request/response headers exchanged, and why credentialed requests can never use a wildcard origin
- CSP directives with real effect on execution — specifically why `script-src` (without `'unsafe-inline'`/`'unsafe-eval'`) stops an already-injected script from running, and how nonces/hashes allow specific inline scripts without reopening the hole
- Subresource Integrity's exact verification mechanism (content-hash matching, fail-closed on mismatch) and why it requires `crossorigin` to function cross-origin
- Clickjacking's distinct mechanism from CSRF (tricking a real click vs. forging a request), and `X-Frame-Options` vs. the more expressive CSP `frame-ancestors`
- The full secure-cookie-flag baseline (`HttpOnly`/`Secure`/`SameSite`) mapped to the specific attack each flag mitigates
- Dependency/supply-chain risk specific to frontend code — why a compromised bundled dependency reaches every user's browser with full origin trust, and the concrete mitigations (lockfiles, CI scanning, SRI for CDN-loaded resources)
