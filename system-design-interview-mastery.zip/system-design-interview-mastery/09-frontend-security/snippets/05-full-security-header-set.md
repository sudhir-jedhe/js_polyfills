# Snippet: A Reasonable Baseline Security Header Set

```js
// Express middleware setting the core defensive headers for a typical app
app.use((req, res, next) => {
  res.setHeader(
    'Content-Security-Policy',
    "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; " +
    "object-src 'none'; base-uri 'self'; frame-ancestors 'none'; upgrade-insecure-requests"
  );
  res.setHeader('X-Frame-Options', 'DENY');            // fallback for browsers not honoring frame-ancestors
  res.setHeader('X-Content-Type-Options', 'nosniff');  // stops the browser guessing a MIME type differently than declared
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin'); // limits Referer leakage cross-origin
  res.setHeader('Strict-Transport-Security', 'max-age=63072000; includeSubDomains; preload'); // enforce HTTPS
  next();
});
```

```js
// Cookie set with the full recommended flag set for a session token
res.cookie('session_id', sessionToken, {
  httpOnly: true,   // JS can't read it — mitigates XSS-driven token theft
  secure: true,     // HTTPS only — mitigates network eavesdropping
  sameSite: 'lax',  // withheld on cross-site POST/PUT/DELETE — mitigates CSRF
  path: '/',
  maxAge: 60 * 60 * 1000, // 1 hour
});
```

Each header/flag here maps to a distinct attack this repo's theory files cover — `CSP`/`X-Frame-Options` to XSS/clickjacking, `Strict-Transport-Security` to protocol-downgrade eavesdropping, and the cookie flags to XSS-token-theft/eavesdropping/CSRF respectively. None of them substitute for another; a real deployment sets all of them together.
