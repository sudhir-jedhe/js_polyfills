# Snippet: Safe vs Unsafe Rendering of Untrusted Data

```jsx
// UNSAFE — reflects raw user input into the DOM via innerHTML (DOM-based XSS sink)
function CommentUnsafe({ text }) {
  const ref = useRef(null);
  useEffect(() => {
    ref.current.innerHTML = text; // if text contains "<img src=x onerror=...>", it executes
  }, [text]);
  return <div ref={ref} />;
}

// SAFE — React's default JSX text interpolation auto-escapes; no sink involved
function CommentSafe({ text }) {
  return <div>{text}</div>; // "<script>" renders as literal text, not executed markup
}
```

```jsx
// If HTML rendering is genuinely required (e.g. a rich-text field), sanitize before injecting —
// never trust `dangerouslySetInnerHTML` with raw, unsanitized user input.
import DOMPurify from 'dompurify';

function RichComment({ html }) {
  const clean = DOMPurify.sanitize(html); // strips script tags, event handler attrs, javascript: URLs, etc.
  return <div dangerouslySetInnerHTML={{ __html: clean }} />;
}
```

```js
// Manual output encoding for a non-framework (server-rendered template) context:
function escapeHtml(str) {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
// `<p>You searched for: ${escapeHtml(query)}</p>` — the reflected XSS fix from the theory file
```
