# Snippet: CSRF Token Issue-and-Verify Flow

```js
// Server: issue a per-session CSRF token, embedded in the rendered page or an initial API response
app.get('/api/csrf-token', (req, res) => {
  const token = crypto.randomBytes(32).toString('hex');
  req.session.csrfToken = token; // stored server-side, tied to this session
  res.json({ csrfToken: token });
});

// Server: verify the token on every state-changing request
app.post('/api/transfer', (req, res) => {
  const submittedToken = req.headers['x-csrf-token'];
  if (submittedToken !== req.session.csrfToken) {
    return res.status(403).json({ error: 'Invalid CSRF token' });
  }
  // ... process the transfer, token matched
});
```

```js
// Client: fetch the token once, then attach it to every mutating request
const { csrfToken } = await fetch('/api/csrf-token').then(r => r.json());

await fetch('/api/transfer', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'X-CSRF-Token': csrfToken, // an attacker's forged form on evil.com has no way to read/set this
  },
  credentials: 'include', // still relies on SameSite cookie policy for the session itself
  body: JSON.stringify({ to: 'friend-account', amount: 50 }),
});
```

The forged `<form>` on an attacker's site can still trigger a POST to `/api/transfer` with the victim's session cookie ambiently attached (if `SameSite` allowed it) — but it cannot read this page's JS-fetched `csrfToken` value (blocked by the Same-Origin Policy from reading the response of `/api/csrf-token`), so it cannot construct a request the server will accept.
