# Snippet: CORS Server Configuration and a Real Preflight Exchange

```js
// Server: respond to preflight OPTIONS and set headers on the real response
app.use((req, res, next) => {
  const allowedOrigins = ['https://app.example.com'];
  const origin = req.headers.origin;

  if (allowedOrigins.includes(origin)) {
    res.setHeader('Access-Control-Allow-Origin', origin); // echo the specific origin, never '*' with credentials
    res.setHeader('Access-Control-Allow-Credentials', 'true');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-CSRF-Token');
    res.setHeader('Access-Control-Max-Age', '600'); // cache preflight result for 10 minutes
  }

  if (req.method === 'OPTIONS') {
    return res.sendStatus(204); // preflight: no body needed, just the headers above
  }
  next();
});
```

**What the browser actually sends/receives for a non-simple request** (`PUT` with a JSON body from `https://app.example.com` to `https://api.example.com`):

```
# 1. Automatic preflight — browser-generated, no application code involved
OPTIONS /resource/42 HTTP/1.1
Origin: https://app.example.com
Access-Control-Request-Method: PUT
Access-Control-Request-Headers: content-type, x-csrf-token

# 2. Server's preflight response
HTTP/1.1 204 No Content
Access-Control-Allow-Origin: https://app.example.com
Access-Control-Allow-Credentials: true
Access-Control-Allow-Methods: GET, POST, PUT, DELETE
Access-Control-Allow-Headers: Content-Type, X-CSRF-Token
Access-Control-Max-Age: 600

# 3. ONLY NOW does the browser send the real request
PUT /resource/42 HTTP/1.1
Origin: https://app.example.com
Content-Type: application/json
X-CSRF-Token: a1b2c3...
Cookie: session_id=abc123   (sent because credentials: 'include' was set client-side)

{"name": "updated value"}
```
