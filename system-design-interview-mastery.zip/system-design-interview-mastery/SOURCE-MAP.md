# Source Map — js_polyfills/System Design + Frontend System Design → this repo

Note: device staging is still blocked this pass (`untrusted_device` — sign in again in the Claude desktop app
to fix). Nothing was physically copied into `from-your-notes/`/`assets/` this time; the mapping below is
accurate and ready to execute once you're signed back in.

Both source folders are large and deep — this is the richest source material of any repo built so far.

## Mapped from `js_polyfills/System Design/`

| New topic | Source file(s)/folder(s) |
|---|---|
| `01-system-design-fundamentals-scalability` | `fundamentals.md`, `System design interview cheatsheet.md`, `roadmap.md`, `problemList.md`, `System Design Playbook.pdf`, `systemDesign.pdf`, `scalability.pdf` |
| `02-api-design-realtime-communication` | *(see also Frontend System Design/COMMUNICATION/ below)* |
| `05-rate-limiting-load-balancing` | `Design a distributed Rate Limiter service using Redis and the Sliding Window algorithm.md`, `Compare the Token Bucket and Sliding Window Counter algorithms in terms of burst capacity, complexity, and Redis implementation.md` |
| `09-frontend-security` | `JWT security.md`, `Security Best Practices.md`, `What is Web Security?.md`, `built a complete password-based authentication system.md`, `𝗪𝗵𝗮𝘁 𝗥𝗲𝗮𝗹𝗹𝘆 𝗛𝗮𝗽𝗽𝗲𝗻𝘀 𝗪𝗵𝗲𝗻 𝗬𝗼𝘂 𝗦𝗰𝗮𝗻 𝗮𝗻𝗱 𝗣𝗮𝘆?.md` |
| `12-low-level-design-component-patterns` | `LLD/` folder (12 files: SOLID principles, UML, Strategy/Singleton/Observer/Decorator/Factory/Adapter patterns, class diagrams, a Zomato LLD case study), `LowLevelDesign.md`, `custome Editor/` (a real code-editor mini-project), `Pooling/` (a real polling-app mini-project) |
| `13-hld-case-studies` | `instagram/`, `whatsapp/`, `Job Portal/`, `Eccommerge/`, `movie Ticketing/`, `Url Shortner/` — six REAL full-stack reference implementations you already built (frontend + backend + schema for each). These are stronger references than any invented example — read alongside the corresponding case study in `problems/` |
| *(general reference)* | `1.md`, `2.md`, `12 Architecture Concepts.md`, `Backend Architecture Breakdown.md`, `SAGA PATTERN.md`, `Repo.md`, `System design Autocomplete.md`, `𝗥𝗲𝗮𝗰𝘁 𝗣𝗿𝗼𝗳𝗶𝗹𝗲𝗿 𝘃𝘀 𝗟𝗶𝗴𝗵𝘁𝗵𝗼𝘂𝘀𝗲.md`, `How would you build a real-time dashboard displaying live data updates?.md`, `12 Factor/` (a full real 12-factor app example with configs/Dockerfiles/docker-compose), `Spreadsheet/` (a real mini-project) |

## Mapped from `js_polyfills/Frontend System Design/`

| New topic | Source file(s)/folder(s) |
|---|---|
| `02-api-design-realtime-communication` | `COMMUNICATION/` (Long Polling, Short Polling, Server-Sent Events, WebSocket, Webhooks — 5 dedicated files), `Networking/` (REST APIs, communication protocols) |
| `03-caching-strategies` | `Database and Caching/` (API Caching, HTTP Caching, Database Caching, Service Worker Caching, Indexed DB, Cookies, Browser Local Storage Techniques, session-scoped data) |
| `04-database-design-scaling` | `Database and Caching/Database Normalization.md` |
| `06-frontend-architecture-folder-structure` | ` Component Architecture/core architecture.md`, `Scalability & Folder Structure/` (3 files including an ESLint/dependency-cruiser boundary-enforcement guide), `Building a reusable design system.md` |
| `07-frontend-rendering-performance` | `browser rendering pipeline.md`, `Browser Rendering.md`, `Critical Rendering Path.md`, `Html and CSS Parsing.md`, `CSS Box Model.md`, `CSS positioning.md`, `Formatting Contexts.md`, `What is a reflow and a repaint?...md`, `Real DOM and Shadow DOM.md`, `What is real dom versus virtual dom...md`, `Explain how React Fiber works...md`, `Virtualization Techniques.md`, `Web Vital Matrices.md`, `webvital.md`, `Minification vs. Compression.md`, `Tree Shaking and Dead Code Elimination.md`, `tree shaking/` (a real demo project), `Performance/` (5 subfolders: Build Optimization, DOM Rendering Patterns, Network optimization, Performance Monitoring, Performance Tools), `Optimization/1.md`, `Frontend Performance.md`, `code Quality.md`, `cross browser compability.md`, `cdn.md`, `What is a CDN.md` |
| `08-frontend-state-management` | `StateMangement/` (2 files), `design a state management strategy.md` |
| `09-frontend-security` | `security/` (16 files — XSS, CSP, CORS, SSRF, SSJI, SRI, Security Headers, Client-side security, Compliance, iframe security, Permissions Policy, Dependency security, same-origin policy), `Logging and Monitoring/` (Sentry integration, telemetry, alerting) |
| `10-accessibility-at-scale` | `Accessibility/` (8 files — principles, keyboard accessibility, focus management + contrast, screen readers, useDialog hook, contrast-compliant design tokens) |
| `11-offline-support-pwa` | `Offline Support/` (PWA.md, Service Worker.md) |
| `12-low-level-design-component-patterns` | `LLD/` (Config-Driven UI, dynamic form validation, Toast Notification System, Virtualized List, Accessible Autocomplete Search Bar, Accessible Modal with Focus Trapping, Loading Pattern, Multi-language Support, Routing, Shimmer) — a near-exact match to this new topic, worth reading in full |
| `13-hld-case-studies` | `HLD/` (Designing a web-based email client like Gmail.md, 1.md) |
| *(general reference)* | `concept.md`, `interview.md`, `scenario.md`, `FSD.md`, `DOM API.md`, `the DOM and BOM.md`, `Web APIs for Complex UI Patterns.md`, `priorityBased Modal.md`, `Why does CSS block rendering even though it is not JavaScript?.md`, `in-memory-filesystem-library.md`, `Testing/` (7 files — A/B testing, TDD, unit/integration/E2E/security/performance testing, quality coverage targets — worth cross-referencing against the dedicated Testing repo) |

## Real reference implementations worth a manual skim (not auto-processed)

`instagram/`, `whatsapp/`, `Job Portal/`, `Eccommerge/`, `movie Ticketing/`, `Url Shortner/`, `12 Factor/`,
`custome Editor/`, `Pooling/`, `Spreadsheet/`, `tree shaking/` — each is a real, runnable (or near-runnable)
mini-project with frontend + backend + schema. These pair directly with the case studies in
`13-hld-case-studies/problems/` — reading your own implementation alongside the case-study walkthrough is the
single highest-value thing you can do with this repo.

## What wasn't touched

Large PDFs (`scalability.pdf`, `System Design Playbook.pdf`, `systemDesign.pdf`) and images/GIFs — worth a
manual skim, too large for automatic extraction.
