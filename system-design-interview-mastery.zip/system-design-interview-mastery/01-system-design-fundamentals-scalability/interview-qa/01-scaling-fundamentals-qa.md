# Interview Q&A — Scaling Fundamentals

**Q: What's the difference between vertical and horizontal scaling, and which should you default to?**
Vertical scaling adds resources to one machine; horizontal scaling adds more machines and distributes load across them. Neither is a universal default — start vertical while it's simple and cheap, and move to horizontal once you hit a ceiling (cost, physical limits) or need fault tolerance (a single machine is always a single point of failure, no matter how big).

**Q: Why can't a stateful service scale horizontally as easily as a stateless one?**
A stateless service can route any request to any instance because no instance holds data another instance needs. A stateful service (like a database) holding data in one place means new instances either need a full copy of that data or a partition of it — which requires replication or sharding, both of which introduce consistency and coordination problems that a stateless web/app tier simply doesn't have.

**Q: What does "N+2 redundancy" mean and why would a team target it instead of exactly N instances?**
It means provisioning enough capacity to survive losing 2 instances (e.g., one to a bad deploy, one to a hardware failure) without breaching latency/availability targets. Running exactly N instances (the bare minimum for current load) means any single instance failure immediately degrades service — N+2 is a deliberate, quantified margin for real-world failure modes rather than an assumption that nothing ever goes wrong.

**Q: A load balancer uses round-robin. What real-world failure mode can this create that "least connections" avoids?**
Round-robin distributes requests evenly by *count*, not by actual load — if requests have very different durations (a fast cache hit vs. a slow report generation), round-robin can pile several slow requests onto the same instance while others sit idle. "Least connections" routes based on each backend's currently active connection count, which better reflects real-time load for workloads with uneven request durations.

**Q: Why is "modular monolith" a legitimate answer to a system design interview, rather than a cop-out?**
It captures much of the organizational benefit of microservices — clear internal module boundaries, defined ownership, the ability to extract a module later without a rewrite — without paying the distributed-systems tax (network calls, partial failure, distributed transactions) until there's a concrete reason to. For many real systems, especially early or mid-stage ones, it's a more defensible choice than jumping straight to microservices, and naming it shows you're not just pattern-matching to the trendiest architecture.
