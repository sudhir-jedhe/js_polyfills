# Interview Q&A — CAP Theorem and Consistency Models

**Q: State the CAP theorem precisely — what exactly is being traded off, and when?**
In a distributed data store, during a network partition, you must choose between consistency (every read sees the latest write, or an error) and availability (every request gets a non-error response, possibly with stale data). It only applies during an actual partition — outside of one, a well-designed system can offer both. Partition tolerance isn't really optional in a real distributed system, so the practical choice is CP vs. AP.

**Q: Why is it wrong to describe a distributed system as "CA"?**
"CA" implies the system never has to choose, i.e., it never experiences partitions — but any real distributed system spanning more than one node over a real network will experience partitions eventually (a network cable fails, a switch dies, a datacenter link degrades). A system that claims to be CA either isn't truly distributed (it's really one node with no failure mode to trade off) or hasn't yet been tested against the partition it will eventually hit.

**Q: What's the difference between eventual consistency and causal consistency?**
Eventual consistency guarantees replicas converge eventually, with no ordering guarantee about what any given reader sees along the way. Causal consistency adds an ordering guarantee for operations that are causally related (e.g., a reply must be seen after the comment it replies to) while still allowing unrelated, concurrent operations to be observed in different orders by different readers — a middle ground that's cheaper than strong consistency but stronger than plain eventual consistency.

**Q: What's "read-your-writes" consistency, and why is it popular as an add-on to an eventually consistent system?**
It guarantees that a user who just performed a write will see that write reflected in their own subsequent reads, typically by routing their reads to the primary (or a replica verified to be caught up) for a short window after the write, while other users' reads still go to (possibly lagging) replicas. It's popular because it removes the most user-visible symptom of eventual consistency (your own action appearing to have failed or reverted) at a small, targeted cost, without paying for system-wide strong consistency.

**Q: PACELC extends CAP with what additional tradeoff, and why does it matter even when there's no partition?**
PACELC says: if Partitioned, choose Availability or Consistency (that's CAP); Else (normal operation), choose Latency or Consistency. It matters because CAP alone implies "no partition = no tradeoff," which isn't true — even under normal operation, a strongly consistent system pays a latency cost (waiting for quorum/replica acknowledgment) that an eventually consistent system avoids. PACELC captures the tradeoff that exists all the time, not just during failures.
