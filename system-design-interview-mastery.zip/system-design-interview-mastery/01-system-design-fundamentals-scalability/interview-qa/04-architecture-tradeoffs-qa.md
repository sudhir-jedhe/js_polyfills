# Interview Q&A — Architecture Tradeoffs and the Interview Framework

**Q: What are the five stages of the standard system design interview framework?**
Clarify requirements (functional and non-functional) → back-of-envelope estimation → high-level design → deep dive into 1-2 components → identify bottlenecks and discuss tradeoffs. Skipping the first stage (jumping straight to a diagram) is the most common way candidates undermine an otherwise-solid technical answer.

**Q: Why is asking clarifying questions weighted so heavily, even before any technical content is discussed?**
Because a technically excellent design for the wrong problem scores worse than a simpler design for the right problem — "design Twitter" could mean a system supporting 10 users or 500 million, with or without media, with or without real-time delivery, and each answer implies a completely different design. Not asking means you're guessing at the actual requirements, which the interviewer is specifically there to give you if asked.

**Q: What's the practical difference between microservices' fault isolation benefit and just running more replicas of a monolith?**
More monolith replicas protect against a single *instance* dying (hardware failure, one process crashing) — but a bug or resource leak in shared code still affects every replica identically. Microservices' fault isolation is about *logical* isolation: a bug or overload in one service's code doesn't directly crash a different service's process, even running on the same or different hardware — replicating a monolith doesn't buy you that.

**Q: When would you choose NOT to split a monolith even under significant load growth?**
When the actual bottleneck, once profiled, turns out to be addressable with less invasive techniques — connection pooling, read replicas, caching, or vertical scaling of the specific stateful resource that's actually saturated. A split is justified by a *specific*, *diagnosed* reason (a component with a wildly different scaling profile starving shared resources, or an organizational need for independent releases) — not applied preemptively because the traffic number grew.

**Q: In a migration from monolith to microservices, why extract a read-only, non-transactional domain (like recommendations) before a transactional one (like checkout)?**
A read-only domain that doesn't participate in cross-domain transactions is far lower-risk to extract — its failure can be isolated and gracefully degraded (e.g., omit recommendations, keep serving the rest of the app), and it doesn't force the team to solve distributed transactions (sagas, compensating actions) before they've built operational experience running standalone services. Extracting checkout early forces that hard problem immediately, with real financial risk if it's gotten wrong.
