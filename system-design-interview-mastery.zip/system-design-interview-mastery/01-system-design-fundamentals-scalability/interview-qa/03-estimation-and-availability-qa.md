# Interview Q&A — Estimation and Availability

**Q: Why does the specific number you arrive at in a back-of-envelope estimate matter less than the method?**
Interviewers are grading whether you can translate a vague requirement into a number that changes a design decision, and whether your order of magnitude is sane — not whether you computed 38.6 vs. 41 writes/second. What matters is stating assumptions explicitly, rounding sensibly, and then actually using the number (e.g., "since read QPS is 100x write QPS, I'm adding a cache") rather than computing it and never referring to it again.

**Q: What's the difference between availability and reliability?**
Availability is the percentage of time a system is up and responding at all. Reliability is the probability the system does the right thing (returns a correct result) when it is up. A system can be highly available but unreliable (always responds, but often wrong) or reliable but not perfectly available (correct whenever it's up, but down more than the SLA allows) — they're measuring different failure modes and both need to be tracked.

**Q: What's the relationship between MTBF, MTTR, and availability?**
Availability ≈ MTBF / (MTBF + MTTR) — Mean Time Between Failures over the sum of time-up and time-down. This makes explicit that availability can be improved two ways: fail less often (raise MTBF, e.g., better testing, redundancy) or recover faster (lower MTTR, e.g., automated rollback, fast failover) — the second is often cheaper to invest in and easy to overlook if you only think about "preventing failures."

**Q: What is an error budget, and how is it used day-to-day (not just as a compliance number)?**
It's the SLA's downtime allowance converted into a concrete number (e.g., "43.2 minutes/month" for 99.9%), tracked against actual incidents as they occur. Teams use the remaining budget to decide whether a risky change (a migration, a deploy with rollback risk) is safe to ship this period — if the budget is already mostly spent on incidents, further risky changes get deferred; if there's ample budget, calculated risk is acceptable.

**Q: If two services are chained (A calls B, and the request needs both to succeed), how does their combined availability compare to either service alone?**
It's the product of their individual availabilities (e.g., 99.95% × 99.9% ≈ 99.85%), which is always lower than either service individually. This is why deep synchronous call chains erode overall availability even when every individual hop looks acceptable in isolation — it's a strong argument for keeping critical-path call chains short, and for redundancy (parallel, not serial, dependencies) where possible.
