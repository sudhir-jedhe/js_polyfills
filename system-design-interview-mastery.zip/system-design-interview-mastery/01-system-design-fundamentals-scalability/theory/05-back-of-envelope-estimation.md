# Back-of-Envelope Estimation

Estimation is a core, explicitly-graded skill in system design interviews: it proves you can translate a vague product requirement ("build Twitter") into concrete numbers that drive real design decisions (do we need sharding? a CDN? how many app servers?). The exact numbers matter far less than the **method** and **sanity of the order of magnitude**.

## The numbers worth memorizing

| Quantity | Approx. value |
|---|---|
| 1 day | ~86,400 seconds (round to **100,000** for quick mental math) |
| 1 million | 10^6 |
| 1 billion | 10^9 |
| L1 cache reference | ~1 ns |
| RAM read (1 MB) | ~250 μs |
| SSD read (1 MB) | ~1 ms |
| Round trip within same datacenter | ~0.5 ms |
| Round trip cross-continent | ~150 ms |
| Disk seek (HDD) | ~10 ms |

## The four things you're usually estimating

1. **QPS (queries per second)** — traffic volume
2. **Storage** — how much data accumulates over time
3. **Bandwidth** — data transferred per second
4. **Memory / cache size** — how much needs to stay hot for fast access

## Worked example: design a URL shortener

**Assumptions to state out loud** (always state assumptions — the interviewer expects it): 100M new URLs shortened per month, 100:1 read:write ratio, average URL + metadata = 500 bytes, data retained for 5 years.

**Write QPS:**
```
100,000,000 writes / month
≈ 100,000,000 / (30 × 86,400) seconds
≈ 100,000,000 / 2,592,000
≈ 38.6 writes/sec  →  round to ~40 QPS
```

**Read QPS** (100:1 ratio):
```
40 QPS × 100 = 4,000 QPS
```

**Peak QPS** (assume 2x average traffic at peak):
```
Write peak ≈ 80 QPS
Read peak ≈ 8,000 QPS
```

**Storage over 5 years:**
```
100M/month × 12 months × 5 years = 6,000,000,000 (6B) records
6B × 500 bytes ≈ 3,000,000,000,000 bytes ≈ 3 TB
```

**Bandwidth:**
```
Write: 40 QPS × 500 bytes ≈ 20 KB/s
Read:  4,000 QPS × 500 bytes ≈ 2 MB/s
```

**Cache sizing (80/20 rule — cache the hottest 20% of daily traffic):**
```
Daily reads ≈ 4,000 QPS × 86,400s ≈ 345M reads/day
Hot 20% ≈ 69M reads/day, but unique hot *URLs* is what matters for cache size —
if ~20% of unique URLs drive 80% of reads, and there are ~3.3M new URLs/day,
caching ~700K hot URLs × 500 bytes ≈ 350 MB — comfortably fits in a single Redis instance's RAM.
```

## What these numbers tell you (this is the actual point)

- 40-80 write QPS and a few thousand read QPS is **not** a scale that needs sharding or exotic infrastructure — a single well-indexed relational database with a read replica or two, plus a cache in front, comfortably handles this. Jumping straight to "let's shard into 100 partitions" for these numbers would be a red flag, not a strength.
- 3 TB of data over 5 years is easily stored on standard cloud block storage; no need for a distributed file system.
- The read-heavy skew (100:1) is the single number that most directly justifies adding a cache layer — that's the design decision the estimate exists to unlock.

## The interview answer

Always **state your assumptions explicitly**, **round aggressively** (order of magnitude, not precision), and — most importantly — **connect every number back to a design decision** ("since read QPS is ~4,000 and write QPS is ~40, I'm going to add a cache and read replicas rather than optimizing the write path"). An estimate that doesn't change anything about the design that follows is a wasted exercise in the interviewer's eyes.
