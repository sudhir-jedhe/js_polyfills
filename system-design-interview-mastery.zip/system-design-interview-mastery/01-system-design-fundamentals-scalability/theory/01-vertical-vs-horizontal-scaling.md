# Vertical vs. Horizontal Scaling

**Scaling** is how a system handles growth in load (users, requests, data). There are two fundamentally different levers, and interviews expect you to know exactly where each one breaks down.

## Vertical scaling (scale up)

Add more resources — CPU, RAM, faster disks — to a **single machine**.

- **Pros:** no application changes needed, no distributed-systems complexity (no partitioning, no cross-node consistency), simplest to reason about.
- **Cons:** hard physical/cost ceiling (you eventually run out of bigger instances to buy), single point of failure — that one machine going down takes the whole service down, and cost grows faster than linearly as you approach the top of a hardware tier.

## Horizontal scaling (scale out)

Add **more machines** and distribute load across them (via a load balancer).

- **Pros:** near-unbounded scaling ceiling, better fault tolerance (one node dying doesn't take down the service), and commodity hardware is usually cheaper per unit of capacity than the top of the vertical-scaling curve.
- **Cons:** requires the application to be designed for it — statelessness (or externalized state), a load-balancing layer, and if there's shared data, a distributed-data strategy (replication/sharding) that introduces consistency tradeoffs (see the CAP theorem file). Operationally more complex: more moving parts to deploy, monitor, and debug.

## Comparison table

| Dimension | Vertical scaling | Horizontal scaling |
|---|---|---|
| Mechanism | Bigger machine | More machines |
| Ceiling | Hard limit (biggest available instance) | Effectively unbounded |
| Fault tolerance | Single point of failure | Node failures are survivable |
| App changes required | None | Statelessness, load balancing, data partitioning |
| Cost curve | Superlinear near the top tier | Roughly linear (commodity hardware) |
| Operational complexity | Low | Higher (orchestration, consistency, monitoring) |
| Typical use | Early-stage systems, databases that are hard to shard | Web/app tiers at scale, anything past a single machine's ceiling |

## The interview answer

Don't present this as "horizontal is always better." The correct framing: **start vertical because it's simple and cheap at low scale, move to horizontal once you hit a ceiling or need fault tolerance** — and note that even horizontally-scaled systems often vertically scale individual nodes too (the two aren't mutually exclusive). Also flag the classic asymmetry: **stateless tiers (web/app servers) scale horizontally easily; stateful tiers (databases) require deliberate design** (replication, sharding) to scale horizontally, which is why database scaling gets its own dedicated topic.
