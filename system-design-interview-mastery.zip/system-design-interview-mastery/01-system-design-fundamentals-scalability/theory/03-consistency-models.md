# Consistency Models: Strong, Eventual, and Causal

"Consistency" is a spectrum, not a binary. Interviewers want to see that you can pick the *right point* on that spectrum for a given feature, not just default to "strong consistency is safest."

## Strong consistency (linearizability)

Every read returns the most recently **completed** write, system-wide, as if there were only one copy of the data. Achieved via synchronous replication or consensus (e.g., Raft/Paxos quorum writes) — a write isn't acknowledged until enough replicas have it.

- **Cost:** higher write latency (must wait for replica acknowledgment/quorum), reduced availability during partitions (see CAP: this is the "C" in CP).
- **Use when:** correctness of the *immediate* next read matters — bank balances, inventory counts at checkout, leader-election state.

## Eventual consistency

Writes propagate to replicas **asynchronously**. If no new writes occur, all replicas *eventually* converge to the same value — but there's no bound guaranteeing *when*, and a read immediately after a write may return stale data.

- **Cost:** stale reads are possible (replica lag), and conflicting concurrent writes need a resolution strategy (last-write-wins, CRDTs, application merge).
- **Benefit:** low write latency, high availability (a replica doesn't need to coordinate with others to accept a read or write).
- **Use when:** slight staleness is acceptable — social media like/view counts, product review counts, DNS records, most caching layers.

## Causal consistency

A middle ground: writes that are **causally related** (B was made *after seeing* A) are seen by everyone in that same order. Writes with no causal relationship (concurrent, unrelated) may be seen in different orders by different observers.

- **Practical example:** if user A posts a comment and user B replies to it, every viewer must see A's comment before B's reply (they're causally linked) — but two *unrelated* comments posted at the same time can appear in either order to different viewers without breaking anything.
- **Use when:** you want stronger guarantees than plain eventual consistency (no "reply appears before the comment it replies to") without paying the full cost of strong consistency system-wide. Common in collaborative and social applications.

## Comparison table

| Model | Guarantee | Write latency | Availability under partition | Typical use case |
|---|---|---|---|---|
| Strong | Reads always see latest write | Highest | Lower (CP) | Bank balance, checkout inventory |
| Causal | Causally-related ops seen in order; concurrent ops may reorder | Medium | Medium | Comment threads, chat, collaborative docs |
| Eventual | All replicas converge *eventually*, no ordering guarantee | Lowest | Highest (AP) | Like counts, view counts, DNS, CDN cache |

## A related, often-confused term: read-your-writes consistency

A practical special case worth naming in interviews: a system can be eventually consistent *overall* but still guarantee that **the user who made a write always sees their own write** on subsequent reads (routing their reads to the primary or a replica known to be caught up), even while *other* users might still see stale data. This is a cheap, high-value guarantee to add to an otherwise eventually-consistent system, and interviewers like hearing it by name.

## The interview answer

Don't apply one consistency model to an entire system. Different **features within the same product** legitimately warrant different models — e.g., in an e-commerce app: checkout/payment needs strong consistency, "recently viewed" needs only eventual consistency, and comment threads benefit from causal consistency. Naming this per-feature, rather than per-system, is what signals real depth.
