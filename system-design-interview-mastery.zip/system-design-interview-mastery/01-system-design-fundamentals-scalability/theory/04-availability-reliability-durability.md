# Availability, Reliability, and Durability

These three terms get used interchangeably in casual conversation but mean **distinct** things in system design, and conflating them is a common interview mistake.

## Availability

The **percentage of time a system is operational and able to serve requests**, measured over some period. Expressed in "nines":

| Availability | Downtime per year | Downtime per month | Downtime per day |
|---|---|---|---|
| 99% ("two nines") | ~3.65 days | ~7.3 hours | ~14.4 minutes |
| 99.9% ("three nines") | ~8.77 hours | ~43.8 minutes | ~1.44 minutes |
| 99.99% ("four nines") | ~52.6 minutes | ~4.38 minutes | ~8.6 seconds |
| 99.999% ("five nines") | ~5.26 minutes | ~26.3 seconds | ~0.86 seconds |

Availability = `uptime / (uptime + downtime)`. It says nothing about whether the *data* returned is correct — a system can be "available" and still be serving wrong or stale answers.

## Reliability

The probability that a system performs its intended function **correctly**, without failure, over a given period. This is closer to "does it do the right thing when it's up," as opposed to availability's "is it up at all." A system can be highly available (always responding) but unreliable (frequently returning errors or wrong results), and vice versa — a system that's down 0.1% of the time but always correct when up is highly reliable but not perfectly available.

Commonly measured via **MTBF** (Mean Time Between Failures) and **MTTR** (Mean Time To Recovery): `Availability ≈ MTBF / (MTBF + MTTR)`. This formula makes explicit that you can improve availability either by failing less often (higher MTBF) **or** recovering faster (lower MTTR) — the latter is often cheaper and is why fast rollback/failover tooling is a legitimate availability investment, not just a reliability one.

## Durability

The guarantee that **once data is acknowledged as written, it will not be lost**, even in the face of failures (disk crash, power loss, node death). Achieved through replication (multiple copies), and/or persistence to durable storage (disk, not just memory) before acknowledging the write.

- A system can be durable but temporarily unavailable (data is safe on disk, but the node serving it is down).
- A system can be available but not durable (an in-memory cache serving fast reads, but a crash loses everything — acceptable for a cache, unacceptable for a ledger).

## Putting them together

| Property | Answers the question | Improved by |
|---|---|---|
| Availability | "Can I get a response right now?" | Redundancy, failover, load balancing, fast MTTR |
| Reliability | "Is the response correct, and does it stay correct over time?" | Testing, error handling, retries, redundancy |
| Durability | "Will my data still exist after a crash?" | Replication, write-ahead logs, backups, sync-to-disk before ack |

## The interview answer

When asked for a system's non-functional requirements, don't just say "it should be reliable and available" — quantify the target (e.g., "99.9% availability, meaning under ~44 minutes of downtime a month is acceptable") and state which of the three properties matters *most* for the specific data in question (e.g., "payment records need strong durability even if it costs some write latency; the homepage feed needs high availability even if a stale read slips through").
