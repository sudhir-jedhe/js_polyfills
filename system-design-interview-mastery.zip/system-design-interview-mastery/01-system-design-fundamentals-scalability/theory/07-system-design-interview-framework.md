# The System Design Interview Framework

Interviewers are grading your **process** as much as your final diagram. Candidates who jump straight to drawing boxes tend to build the wrong thing efficiently. The standard framework has five stages — allocate your ~45 minutes roughly as shown.

## 1. Clarify requirements (~5 minutes)

Never assume — ask. Split into two buckets:

- **Functional requirements:** what must the system actually do? (e.g., "users can post a tweet, follow others, see a feed" — and just as important, what's explicitly **out of scope**, e.g., "no need to design DMs.")
- **Non-functional requirements:** the "-ilities" — availability, latency, consistency, durability targets. E.g., "read-heavy or write-heavy? Can reads tolerate a few seconds of staleness? What's an acceptable p99 latency?"

Skipping this step is the single most common way candidates fail — they design a technically sound system for the wrong problem.

## 2. Back-of-envelope estimation (~5 minutes)

Convert requirements into numbers: QPS, storage, bandwidth (see the dedicated estimation theory file). This step determines *how* the rest of the design should look — a system serving 100 QPS and a system serving 100K QPS are different designs, not the same design at different sizes.

## 3. High-level design (~10-15 minutes)

Draw the major components and how data flows between them: clients → load balancer → application servers → database/cache → (any async workers/queues). Keep it at the box-and-arrow level first — resist diving into any one component's internals until the shape of the whole system is agreed with the interviewer. State your API design here too (key endpoints, request/response shape) if the product has a clear API surface.

## 4. Deep dive (~15-20 minutes)

The interviewer will usually steer you toward 1-2 components to go deep on — this is where most of the signal is generated. Common deep-dive targets: the data model/schema, how a specific hot-path request flows through the system end to end, how a particular non-functional requirement (e.g., "feed must load in under 200ms") is actually met, or how a specific piece of scale is handled (sharding key choice, cache invalidation strategy). Narrate tradeoffs as you go — every design choice should come with "I chose X over Y because Z," not silence.

## 5. Identify bottlenecks & discuss tradeoffs (~5 minutes)

Proactively point out the weak points of your own design: single points of failure, the component that will need to be re-architected first as scale grows 10x, consistency compromises you made and their blast radius. This step is what separates "built a working diagram" from "understands the system deeply enough to know where it will break."

## The meta-skill: narrate tradeoffs, always

Every stage above rewards the same underlying habit: **say the tradeoff out loud, even when you've already made the choice.** "I'm using a SQL database here because the data is relational and I need transactions, even though it means I'll need to think harder about sharding later" is a stronger answer than silently drawing a database icon — because it proves you know there *was* a choice, and what you gave up.

## Common failure modes to avoid

- Designing for infinite scale from minute one (over-engineering a system that needs to handle 100 QPS).
- Never asking a single clarifying question.
- Picking a component (e.g., "we'll use Kafka") without being able to say what it's *for*.
- Spending 30 minutes on the high-level design and running out of time for the deep dive, where most of the grading signal lives.
