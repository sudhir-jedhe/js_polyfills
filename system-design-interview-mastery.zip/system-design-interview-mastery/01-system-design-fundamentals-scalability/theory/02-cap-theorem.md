# The CAP Theorem

The CAP theorem is one of the most frequently *misquoted* concepts in system design interviews, so precision matters here more than almost anywhere else in this repo.

## The precise claim

In a **distributed data store**, when a **network partition** occurs (nodes can't talk to each other), you must choose between:

- **Consistency (C):** every read receives the most recent write, or an error. All nodes see the same data at the same time.
- **Availability (A):** every request receives a (non-error) response, without the guarantee that it contains the most recent write.

You cannot have both **during a partition**. Note what CAP does *not* say:

- It does **not** say "pick 2 of 3 at all times." Partition tolerance (P) isn't optional in a real distributed system — networks *will* partition — so in practice the choice is really **CP vs. AP**, made specifically for the duration of the partition. When there's no partition, a well-designed system gives you both C and A.
- It says nothing about **latency**, only about the binary availability/consistency tradeoff under partition. (PACELC extends CAP to also cover the latency-vs-consistency tradeoff that exists *even without* a partition — see the note below.)
- "Consistency" here is **linearizability** (strong consistency), not the C in ACID — a different, narrower meaning than the same word in database-transaction contexts.

## CP vs. AP in practice

| Choice | Behavior during a partition | Example systems |
|---|---|---|
| **CP** | Minority-side nodes refuse reads/writes (return errors) to avoid serving stale/conflicting data | ZooKeeper, etcd, HBase, most RDBMSes configured for strong consistency |
| **AP** | Every node keeps serving reads/writes, even if it can't confirm it has the latest data — conflicts get reconciled later | Cassandra, DynamoDB (default mode), Riak |

## Worked example

A 5-node cluster splits into a 3-node majority and a 2-node minority due to a network partition.

- **CP system:** the 2-node minority stops accepting writes (and often reads) because it can't verify it isn't stale — clients hitting those nodes get errors until the partition heals. The 3-node majority keeps operating normally.
- **AP system:** both sides keep accepting writes. Once the partition heals, the system must **reconcile** any conflicting writes that happened on both sides (last-write-wins, vector clocks, CRDTs, or application-level merge logic).

## PACELC (the extension worth knowing)

PACELC says: **if Partitioned**, choose **A**vailability or **C**onsistency; **Else** (normal operation, no partition), choose **L**atency or **C**onsistency. This matters because even without a partition, a strongly-consistent system (e.g., requiring a majority-quorum write) pays a latency cost that an eventually-consistent system doesn't. This is the more complete mental model interviewers who know the theory well are actually listening for.

## The interview answer

Never say "our system is CA." A real distributed system that can't tolerate partitions isn't distributed in any meaningful way. Instead, say which side of **CP vs. AP** you're choosing and *why* — e.g., "This is a payments ledger, so I'm choosing CP: I'd rather reject a request than risk a double-spend," vs. "This is a social media like-count, so I'm choosing AP: a few seconds of staleness is an acceptable tradeoff for never showing an error to the user."
