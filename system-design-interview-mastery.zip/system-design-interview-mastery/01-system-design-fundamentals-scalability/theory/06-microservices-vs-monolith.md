# Microservices vs. Monolith

This is a classic system-design-interview tradeoff question, and the correct answer resists the popular "microservices are modern, monoliths are legacy" framing — most successful companies (including ones famous for microservices) started as, and often still run substantial parts as, monoliths.

## Monolith

A single deployable unit containing all application logic, typically with one shared codebase and one database.

- **Pros:** simple to develop, test, and deploy locally; no network calls between internal modules (function calls are fast and don't fail the way RPCs do); easy to maintain transactional consistency (one database, real ACID transactions across "modules"); lower operational overhead (one thing to deploy, monitor, and scale).
- **Cons:** the entire application scales as one unit even if only one part is hot (can't scale the image-processing code independently of the login code); a bug or resource leak in one module can take down the whole service; large team coordination gets harder as the codebase grows (merge conflicts, slower CI, unclear ownership); a single tech stack for the whole app.

## Microservices

The application is split into independently deployable services, each typically owning its own data store, communicating over the network (REST/gRPC/message queues).

- **Pros:** independent scaling per service (scale the hot path without over-provisioning everything else); independent deployment (teams ship on their own schedule without a global release train); fault isolation (one service crashing doesn't necessarily take down others, if calls are made resilient); teams can pick the best tech stack per service; clear ownership boundaries map to team boundaries (Conway's Law, used deliberately).
- **Cons:** distributed-systems complexity — network calls can fail, timeout, or be slow in ways function calls aren't (must design for partial failure, retries, timeouts, circuit breakers); no free cross-service transactions (need sagas or eventual consistency for multi-service operations); operational overhead multiplies (service discovery, distributed tracing, more things to deploy/monitor/version); data consistency across services is genuinely hard (see consistency-models theory file).

## Comparison table

| Dimension | Monolith | Microservices |
|---|---|---|
| Deployment | One unit | Independent per service |
| Scaling | Whole app scales together | Per-service, matched to actual load |
| Data consistency | Easy (one DB, real transactions) | Hard (distributed transactions/sagas) |
| Failure blast radius | Whole app | Contained to the failing service (if designed well) |
| Team autonomy | Low (shared codebase, shared release) | High (own codebase, own release cadence) |
| Operational overhead | Low | High (service mesh, tracing, more infra) |
| Best for | Small-to-mid teams, early-stage products, workloads with uniform scaling needs | Large orgs, teams needing independent scaling/release, well-understood domain boundaries |

## The interview answer

Frame it around **organizational scale and where the bottleneck actually is**, not technology fashion: "I'd start as a monolith — it's faster to build and has none of the distributed-transaction complexity — and only split out a service once there's a concrete reason: a component with wildly different scaling needs (e.g., video transcoding vs. the rest of the app), a team that needs independent release cadence, or a fault-isolation requirement (one flaky dependency shouldn't take down checkout)." Also mention the middle ground: a **modular monolith** (clear internal module boundaries, one deployable) captures much of microservices' organizational benefit without the network-call cost, and is often the right call before a full split.
