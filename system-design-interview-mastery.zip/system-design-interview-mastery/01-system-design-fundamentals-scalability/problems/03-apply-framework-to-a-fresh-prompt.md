# Problem: Apply the System Design Framework to a Fresh Prompt

## Problem Statement

You're given the prompt: **"Design a ride-sharing driver-matching system"** (given a rider's location, find and assign a nearby available driver). Apply the full 5-stage framework from the theory file, showing your work at each stage — this is a self-contained exercise in running the *process*, not just producing a diagram.

## Constraints

- Show explicit clarifying questions and their assumed answers before any design work.
- Include a numeric estimation stage.
- The high-level design and deep dive should focus specifically on the *matching* problem, not the entire ride-sharing product surface.

## Solution

**1. Clarify requirements:**
- Functional: given a rider's request (pickup location), find the nearest available driver within a reasonable radius, offer them the ride, and handle accept/decline/timeout. Out of scope for this exercise: payments, ratings, route navigation.
- Non-functional: matching latency must be low (a rider waiting more than a few seconds to see *any* match feels broken) — this is the dominant non-functional constraint. Strong consistency isn't required on driver location (a few seconds of staleness in "where is this driver" is tolerable), but a driver must never be double-booked to two rides simultaneously — that specific write needs to be strongly consistent/atomic even though location tracking around it doesn't.

**2. Estimation:**
```
Assume 1M concurrent active drivers reporting location every 4 seconds:
  Location update QPS = 1,000,000 / 4 ≈ 250,000 QPS  → the dominant traffic by far
Assume 100K ride requests/minute at peak:
  Match request QPS ≈ 100,000 / 60 ≈ 1,667 QPS
```
**Conclusion:** location updates outnumber match requests roughly 150:1 — the system's write path is dominated by a high-volume, loosely-consistent stream (location pings), while the actual matching decision is comparatively low-QPS but latency- and correctness-critical. This shapes the whole design: location storage should optimize for high-throughput, approximate/ephemeral writes; the match/assignment step should optimize for correctness (no double-booking) over raw throughput.

**3. High-level design:**
```
Driver app --(location ping every ~4s)--> Location Ingest Service --> Geospatial Index (e.g., geohash-based, in-memory)
Rider app --(ride request)--> Matching Service --queries--> Geospatial Index --> candidate drivers
                                     |
                                     v
                          Assignment/Locking Service (atomic "claim" per driver)
```
- **Geospatial indexing:** drivers' locations are indexed by geohash (or an equivalent, e.g., S2/H3 cells) in an in-memory store, letting the matching service query "drivers within cell X and its neighbors" in roughly constant time rather than scanning all drivers.
- **Location updates are fire-and-forget, eventually consistent** — a driver's position being a few seconds stale doesn't break matching (they're still roughly in the area); this is deliberately *not* on the strong-consistency path.

**4. Deep dive — preventing double-booking (the one place strong consistency is required):**
Once the matching service picks a candidate driver, it must **atomically claim** that driver before offering them the ride, so two simultaneous ride requests can't both be routed to the same driver. This is implemented as a conditional/compare-and-swap write against the driver's status (e.g., `UPDATE drivers SET status='offered', locked_by=$request_id WHERE id=$driver_id AND status='available'` — the row only updates if it was still `available`, and the affected-row-count tells the caller whether the claim succeeded). If the claim fails (0 rows affected — another request beat this one to it), the matching service falls back to the next-nearest candidate. This is a narrow, deliberate island of strong consistency inside an otherwise eventually-consistent system — directly applying the "different consistency needs per feature" principle at the level of a single field (`status`) rather than the whole driver record.

**5. Bottlenecks & tradeoffs:** the geospatial index is an in-memory structure serving 250K QPS of writes — it's a strong horizontal-scaling and sharding candidate (shard by geographic region, since a driver's location naturally confines which shard cares about them), and it's also a single point of staleness risk if the ingest pipeline falls behind — worth explicitly calling out a monitoring/alerting need on ingest lag, since stale location data silently degrades match quality without an obvious hard failure.
