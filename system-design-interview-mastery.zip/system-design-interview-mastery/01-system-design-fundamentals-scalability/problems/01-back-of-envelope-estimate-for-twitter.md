# Problem: Full Back-of-Envelope Estimate for a Twitter-like Service

## Problem Statement

Produce a complete capacity estimate for a Twitter-like service's core "post a tweet, view a timeline" functionality, and use the results to justify at least three concrete architecture decisions.

## Constraints

- State every assumption explicitly before calculating.
- Cover: write QPS, read QPS, storage growth over 1 year, and bandwidth.
- Conclude with specific design decisions the numbers justify (not generic statements).

## Solution

**Assumptions:**
```
300M daily active users (DAU)
Each user posts 0.5 tweets/day on average (not every DAU tweets daily)
Each user views their timeline ~15 times/day, ~20 tweets rendered per view
Average tweet size (text + metadata): 300 bytes
Media attached to 20% of tweets, avg 200 KB per media tweet
Peak traffic = 3x average
```

**Write QPS:**
```
Tweets/day = 300M × 0.5 = 150M tweets/day
Avg write QPS = 150,000,000 / 86,400 ≈ 1,736 QPS
Peak write QPS ≈ 1,736 × 3 ≈ 5,208 QPS
```

**Read QPS (timeline views):**
```
Timeline views/day = 300M × 15 = 4.5B views/day
Avg read QPS = 4,500,000,000 / 86,400 ≈ 52,083 QPS
Peak read QPS ≈ 52,083 × 3 ≈ 156,250 QPS
```
Read:write ratio ≈ 30:1 — strongly read-heavy.

**Storage growth (1 year):**
```
Text: 150M/day × 365 × 300 bytes ≈ 16.4 TB/year
Media: 150M/day × 365 × 20% × 200 KB ≈ 2,190,000,000 KB ≈ ~2.19 PB/year
```
Media dominates storage by roughly 130x over text — an important, easy-to-miss result.

**Bandwidth:**
```
Write (text only, media handled separately via direct-to-object-storage upload):
  1,736 QPS × 300 bytes ≈ 521 KB/s average
Read (timeline text, assuming 20 tweets × 300 bytes per view):
  52,083 QPS × 6,000 bytes ≈ 312 MB/s average — dominant bandwidth cost
```

## Design decisions the numbers justify

1. **Media must live in object storage (e.g., S3) behind a CDN, never in the primary database** — 2.19 PB/year of media vs. 16.4 TB/year of text is not remotely the same storage tier problem, and re-serving media from app servers instead of a CDN would multiply the 312 MB/s+ bandwidth figure many times over.
2. **The 30:1 read:write ratio justifies a dedicated timeline cache** (e.g., pre-computed, fanned-out timelines cached per user, refreshed on new posts from followees) rather than computing each timeline view from a live join across the tweet and follow tables at 156K peak read QPS — that query pattern would never survive this read volume unmaterialized.
3. **5,208 peak write QPS on tweet creation is moderate, not extreme** — a single sharded write path (sharded by user ID or tweet ID) with a handful of shards is sufficient; there's no need for a write-optimized exotic store, since this is nowhere near the QPS that forces one.
4. **Fan-out strategy becomes the real deep-dive topic**, not raw storage or QPS: with 156K peak read QPS on timelines, whether tweets are fanned out to follower timelines at write time ("fan-out on write," cheap reads, expensive/skewed for celebrity accounts with millions of followers) or computed at read time ("fan-out on read," cheap writes, more expensive reads) is the single decision the estimate most directly sets up — a hybrid (fan-out on write for most users, fan-out on read merged in for celebrity accounts) is the standard answer, and the estimate is what justifies needing a hybrid rather than picking one uniformly.
