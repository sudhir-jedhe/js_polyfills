# Problem: Design a Scaling Plan for a Read-Heavy Service

## Problem Statement

An internal analytics dashboard service currently runs on 2 app servers and 1 PostgreSQL database, serving ~200 req/s. Traffic is projected to grow to 8,000 req/s over the next year, with reads outnumbering writes 50:1. You have a fixed engineering budget of roughly 6 "large" pieces of infra work you can land this year. Produce a prioritized, staged scaling plan.

## Constraints

- Must handle 8,000 req/s by year end.
- Reads:writes ≈ 50:1 — the plan should reflect that ratio, not treat reads and writes symmetrically.
- Stage the plan (what ships first, second, etc.) and justify the order.
- At most 6 major infra initiatives.

## Solution

**Stage 1 — Connection pooling (PgBouncer) + basic query optimization (indexes on hot query paths).**
Cheapest possible win, ships in days not weeks, and removes the most common near-term ceiling (connection exhaustion) before any bigger architecture work is needed. This alone typically buys 2-4x headroom on an under-tuned single-database setup with zero application-level changes.

**Stage 2 — Add a read-through cache (Redis) in front of the hottest dashboard queries.**
Given the 50:1 read:write ratio, this is the single highest-leverage lever available: it directly reduces load on the bottleneck resource (the shared database) for the vast majority of traffic. Target the queries with the highest read frequency and lowest write-frequency-to-the-underlying-data (dashboards refreshing hourly/daily aggregates are ideal cache candidates — see the caching-strategies topic for pattern choice).

**Stage 3 — Add 2-3 PostgreSQL read replicas, route all read-only queries to them.**
For the read traffic that still misses cache (cold cache entries, non-cacheable ad hoc queries), read replicas horizontally scale the read path without touching the write path at all — appropriate specifically because of the read-heavy skew; this step would be far less valuable in a write-heavy service.

**Stage 4 — Horizontally scale the app tier behind a load balancer (already stateless — confirm and enforce this, don't assume it).**
App servers are typically the cheapest tier to scale horizontally; ensure nothing has crept into server-local state (in-memory caches, sticky sessions) that would block adding instances freely, then scale the fleet to match projected peak QPS using the estimation method from the theory file.

**Stage 5 — CDN/edge caching for any dashboard assets or fully-public, non-personalized read endpoints.**
If any portion of the dashboard's reads are not user-specific (shared reference data, public aggregate reports), push them to a CDN edge cache — removes that traffic from the origin entirely rather than just from the database.

**Stage 6 (held in reserve, not committed up front) — database sharding, only if Stage 1-5 numbers show the *write* path or an *unshardable-by-cache* read pattern is still the bottleneck after everything else lands.**
Deliberately last and conditional: sharding is the most expensive, highest-risk item on this list (schema changes, resharding complexity, loss of easy cross-shard queries — see the database-design-scaling topic), and at a 50:1 read-heavy ratio it's very likely stages 1-5 absorb the full 8,000 req/s target without it. Committing to it up front, before the cheaper levers are proven insufficient, would be over-engineering against numbers that don't yet demand it.

## Why this ordering, generally

Each stage is ordered by **cost/effort vs. leverage against the actual bottleneck** (a read-heavy system's bottleneck is disproportionately the database's read path), and the most expensive/riskiest architectural change (sharding) is explicitly deferred and made conditional on evidence, rather than scheduled preemptively — mirroring the "scale what's actually breaking" principle from the monolith-scaling scenario.
