# Problem: Classify Consistency Requirements Across Multiple Systems

## Problem Statement

For each of the following five data types within a single large e-commerce platform, state which consistency model (strong, causal, or eventual) is appropriate, and justify it in terms of the concrete cost of being wrong:

1. Product inventory count at checkout (the exact moment "Buy Now" is clicked)
2. Product star rating (average of all reviews) shown on a listing page
3. A comment thread on a product review, including replies
4. A user's shopping cart contents
5. "Customers who viewed this also viewed..." recommendation data

## Constraints

- One model per item, with a one-sentence justification each grounded in "what breaks if this is wrong/stale," not a generic label.
- At least one item should use causal consistency, with a concrete ordering example.

## Solution

**1. Inventory count at checkout — Strong consistency.**
If two customers simultaneously buy the last unit of an item and both see "in stock" due to a stale read, the store oversells — a real, costly, customer-facing failure (a canceled order, an angry customer, potential goodwill/refund cost). The decrement must be an atomic, strongly consistent operation (e.g., `UPDATE inventory SET qty = qty - 1 WHERE product_id = $id AND qty > 0`, checking the affected-row-count to know if the decrement actually succeeded) — the same "conditional atomic claim" pattern used for driver double-booking prevention elsewhere in this topic.

**2. Product star rating average — Eventual consistency.**
A rating recomputed from thousands of reviews doesn't need to reflect a review submitted 10 seconds ago instantly — nothing breaks if two different customers briefly see 4.6 vs. 4.7 stars while an aggregate recompute job catches up. This is exactly the kind of read-heavy, low-cost-of-staleness data eventual consistency (and heavy caching) is built for.

**3. Comment thread with replies — Causal consistency.**
A reply must never be rendered before the comment it's replying to — that's a broken, confusing UI, not just "slightly stale" data. But two *unrelated* top-level comments posted around the same time can legitimately appear in either order to different viewers without anything looking wrong. Concretely: if comment A says "what color options are there?" and comment B (a reply to A) says "there's also navy blue," every viewer must see A before B — that's the causal link that must be preserved, while a separate, unrelated comment C posted at the same time as B has no ordering requirement relative to either.

**4. Shopping cart contents — Strong consistency (read-your-writes at minimum, effectively strong for the acting user).**
If a customer adds an item to their cart and then immediately views the cart, seeing the cart *without* the item they just added is a directly visible, trust-breaking bug from that user's own perspective — this is the case where read-your-writes consistency (routing the cart-owner's own reads to reflect their own most recent write immediately) is non-negotiable, even though it doesn't need to be strongly consistent *across different users* (nobody else reads your cart).

**5. "Customers who also viewed" recommendations — Eventual consistency.**
This data is typically computed by a batch or streaming aggregation job with an inherent processing lag measured in minutes to hours, and there's no meaningful cost to a recommendation reflecting yesterday's browsing patterns rather than the last 30 seconds — it's the least consistency-sensitive data type on this list, and treating it otherwise would mean paying real infrastructure cost for a correctness guarantee nobody benefits from.

## The pattern to extract

Notice the justification for each choice names a **concrete, specific failure** (oversold inventory, a reply appearing before its comment, a cart that appears to have "eaten" an item) rather than an abstract rule — that specificity, tied to what actually goes wrong for a real user, is what the interview is grading, not correctly recalling which label goes with which item.
