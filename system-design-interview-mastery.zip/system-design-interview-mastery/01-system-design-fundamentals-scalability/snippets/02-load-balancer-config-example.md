# Snippet: Load Balancer Config (NGINX)

A minimal NGINX config demonstrating horizontal scaling in practice — one entry point distributing load across multiple stateless app servers.

```nginx
upstream app_servers {
    least_conn;                      # route to the server with fewest active connections
    server 10.0.1.10:3000 weight=3;  # a beefier instance gets more traffic
    server 10.0.1.11:3000 weight=1;
    server 10.0.1.12:3000 weight=1;

    # remove a dead node from rotation after 3 failed health checks within 30s
    server 10.0.1.13:3000 max_fails=3 fail_timeout=30s;
}

server {
    listen 80;

    location /health {
        return 200 'ok';
    }

    location / {
        proxy_pass http://app_servers;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;

        # fail over to the next upstream server if this one times out
        proxy_next_upstream error timeout http_502 http_503;
        proxy_connect_timeout 2s;
    }
}
```

**What this demonstrates:**
- `least_conn` (vs. round-robin) routes new requests to whichever backend currently has the fewest open connections — better than plain round-robin when requests have uneven durations.
- `weight` lets you route proportionally more traffic to more capable instances — useful during a gradual rollout of bigger instance types.
- `max_fails`/`fail_timeout` implement basic **health-check-based failover**: a node that starts erroring gets pulled out of rotation automatically, which is what makes horizontal scaling actually fault-tolerant rather than just throughput-additive.
- This only works because the app servers are **stateless** — any request can go to any server. If session state were held in server memory, this config would break sessions on failover (the fix: externalize session state to Redis, or use sticky sessions as a stopgap).
