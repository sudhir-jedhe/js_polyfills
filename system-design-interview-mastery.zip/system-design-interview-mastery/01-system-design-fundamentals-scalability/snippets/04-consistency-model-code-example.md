# Snippet: Strong vs. Eventual Consistency in Code

Illustrating the practical difference between the two models with the same "like count" feature implemented both ways.

**Strong consistency (synchronous, quorum-style write):**

```js
// every replica acknowledges before the write returns —
// the very next read from ANY replica is guaranteed correct,
// at the cost of higher write latency
async function likePostStrong(postId) {
  const replicas = [primaryDb, replicaA, replicaB];
  await Promise.all(
    replicas.map(db => db.query(
      'UPDATE posts SET like_count = like_count + 1 WHERE id = $1', [postId]
    ))
  ); // write doesn't complete until ALL replicas confirm
  return true;
}
```

**Eventual consistency (asynchronous replication):**

```js
// write to primary only, replicate in the background —
// low write latency, but a read hitting a lagging replica
// right after this call can return a stale count
async function likePostEventual(postId) {
  await primaryDb.query(
    'UPDATE posts SET like_count = like_count + 1 WHERE id = $1', [postId]
  );
  replicationQueue.publish({ type: 'like', postId }); // fire-and-forget, async
  return true; // returns immediately, before replicas are updated
}
```

**Read-your-writes patch on top of the eventual version:**

```js
// route this user's OWN read to the primary right after they write,
// while everyone else keeps reading from (cheaper, possibly stale) replicas
async function getLikeCount(postId, { justWroteAt } = {}) {
  const recentlyWrote = justWroteAt && (Date.now() - justWroteAt < 5000);
  const db = recentlyWrote ? primaryDb : pickReplica();
  const row = await db.query('SELECT like_count FROM posts WHERE id = $1', [postId]);
  return row.like_count;
}
```

**Takeaway:** the eventual version is what almost every real-world "like count" feature actually uses — the tiny window of staleness is invisible to users, and the latency/availability win is worth it. The read-your-writes patch is a cheap, common middle ground: it doesn't make the whole system strongly consistent, it just guarantees the *acting* user never sees their own action appear to fail.
