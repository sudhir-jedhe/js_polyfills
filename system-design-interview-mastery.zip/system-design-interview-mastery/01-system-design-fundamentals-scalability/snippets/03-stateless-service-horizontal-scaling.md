# Snippet: Stateless vs. Stateful Service Design

The single design decision that determines whether a service *can* scale horizontally without extra work.

**Anti-pattern — state held in server memory (breaks horizontal scaling):**

```js
// BAD: in-memory session store — only works if the same server
// handles every request from a given user (sticky sessions required,
// and state is lost entirely if this instance restarts or crashes)
const sessions = new Map();

app.post('/login', (req, res) => {
  const sessionId = generateId();
  sessions.set(sessionId, { userId: req.body.userId, loggedInAt: Date.now() });
  res.cookie('sid', sessionId).send('ok');
});

app.get('/me', (req, res) => {
  const session = sessions.get(req.cookies.sid); // only exists on THIS server
  if (!session) return res.status(401).send('not logged in');
  res.json(session);
});
```

**Fixed — state externalized to shared storage (any server can handle any request):**

```js
// GOOD: session state lives in Redis, not server memory —
// any app server instance can serve any request, so the load
// balancer is free to route purely on load, with no stickiness needed
const redis = require('redis').createClient();

app.post('/login', async (req, res) => {
  const sessionId = generateId();
  await redis.set(`session:${sessionId}`, JSON.stringify({
    userId: req.body.userId,
    loggedInAt: Date.now(),
  }), { EX: 3600 }); // 1 hour TTL
  res.cookie('sid', sessionId).send('ok');
});

app.get('/me', async (req, res) => {
  const raw = await redis.get(`session:${req.cookies.sid}`);
  if (!raw) return res.status(401).send('not logged in');
  res.json(JSON.parse(raw));
});
```

**Why this matters for horizontal scaling:** with state externalized, you can add or remove app server instances at will — a new instance is immediately as capable as any existing one, and killing an instance (deploy, crash, autoscale-down) loses zero session state. This is the concrete, code-level version of "the app tier must be stateless to scale horizontally" from the theory file.
