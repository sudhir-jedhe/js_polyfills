# Snippet: Availability / SLO Budget Calculation

Turning a target availability number into an actionable **error budget** — the practical tool teams use to decide "can we ship this risky change this week?"

```
Target SLA: 99.9% availability, measured monthly

Monthly downtime budget = (1 - 0.999) × 30 days × 24 hours × 60 minutes
                         = 0.001 × 43,200 minutes
                         = 43.2 minutes/month

--- If two dependent services are chained (multiplicative availability) ---
Service A: 99.95% available
Service B: 99.9% available
Combined availability (A calls B, both must be up) = 0.9995 × 0.999 ≈ 99.85%
  → worse than either service alone. This is why deep call chains erode
    overall availability even if every individual hop looks "fine."

--- If a request fans out to N replicas and only needs ONE to succeed ---
Single replica availability: 99% (0.99)
Probability ALL 3 replicas are down simultaneously = (1 - 0.99)^3 = 0.01^3 = 0.000001
Effective availability with 3 redundant replicas ≈ 99.9999%
  → redundancy compounds availability upward, dramatically, even from
    fairly unreliable individual components.
```

**Error budget in practice:**

```
43.2 minutes/month budget, already spent this month:
  - 12 min: a bad deploy that was rolled back
  - 8 min: a dependency outage
  Remaining budget: 43.2 - 20 = 23.2 minutes

Decision: a risky infra migration planned for this week that has an estimated
5-10 minutes of expected downtime is still within budget — greenlit.
A second risky change requesting another 20 minutes would blow the budget —
deferred to next month, or descoped to reduce its downtime risk first.
```

**Why this matters:** an SLA number in isolation ("99.9%") is not actionable. Converting it into a **minutes-per-month budget**, and then tracking spend against it, is what actually drives day-to-day engineering decisions like "can we ship this," "do we need a maintenance window," and "is on-call under-resourced for our reliability target." It's also the mechanism that stops teams from over-investing in reliability well past the point the SLA requires (diminishing returns past your actual target).
