# Snippet: Capacity Estimation Walkthrough (Chat App)

Worked estimation for a chat application, shown as a self-contained calculation you could reproduce on a whiteboard.

```
Assumptions (state these explicitly):
- 50M daily active users (DAU)
- Each user sends 40 messages/day on average
- Average message size: 200 bytes (text + metadata)
- Messages retained for 2 years
- Peak traffic = 3x average (evening peak)

--- Write QPS ---
Total messages/day = 50,000,000 users × 40 msgs = 2,000,000,000 msgs/day
Avg write QPS = 2,000,000,000 / 86,400 sec ≈ 23,148 QPS  →  round to ~23K QPS
Peak write QPS = 23K × 3 ≈ 69K QPS

--- Storage ---
Daily storage = 2,000,000,000 msgs × 200 bytes = 400,000,000,000 bytes ≈ 400 GB/day
2-year storage = 400 GB × 730 days ≈ 292,000 GB ≈ 292 TB

--- Read QPS (assume 5:1 read:write — fetching history, scrollback) ---
Avg read QPS ≈ 23K × 5 ≈ 115K QPS
Peak read QPS ≈ 115K × 3 ≈ 345K QPS

--- Bandwidth ---
Avg write bandwidth = 23K QPS × 200 bytes ≈ 4.6 MB/s
Avg read bandwidth  = 115K QPS × 200 bytes ≈ 23 MB/s
```

**Design implications drawn from these numbers:**
- ~69K peak write QPS on a single database is beyond what one primary can comfortably handle → points toward **sharding** by conversation ID or user ID (see the database-design-scaling topic).
- 292 TB over 2 years rules out keeping everything hot in a single relational instance → points toward a **hot/cold storage split** (recent messages in a fast store, older messages archived to cheaper cold storage).
- The 5:1 read skew justifies a **caching layer** for recent conversation history, since it's re-read far more often than it's written.
