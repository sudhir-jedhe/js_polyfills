# System Design Fundamentals & Scalability

Every system design interview — no matter the specific product (URL shortener, chat app, news feed) — is graded on the same underlying fundamentals: can you reason about scale quantitatively, do you understand the tradeoffs the CAP theorem forces on you, do you know what "consistency" actually means in a distributed system, and do you follow a structured approach instead of jumping straight to a whiteboard diagram. This topic is the toolbox every other system-design topic in this repo (APIs, caching, databases) draws from — skipping it is why candidates can describe a component correctly but fail to justify *why* it's there.

## Folder structure

- **`theory/`** — vertical vs. horizontal scaling, the CAP theorem, consistency models (strong/eventual/causal), availability/reliability/durability definitions, back-of-envelope estimation technique, microservices vs. monolith, and the general system-design-interview framework (requirements → estimation → high-level design → deep dive → bottlenecks).
- **`snippets/`** — 5 practical examples: capacity math worked out, a load balancer config, a stateless service pattern, eventual-consistency code, and an availability/SLO calculation.
- **`output-based/`** — 5 "given this setup, what happens?" analysis questions covering CAP tradeoffs, QPS-to-server estimation, replica lag, monolith bottlenecks, and nines-of-availability math.
- **`scenarios/`** — 5 real-world design/fix scenarios: framework walkthrough for a URL shortener, scaling a monolith 10x, picking a consistency model, capacity planning for a launch, and a monolith-to-microservices migration.
- **`interview-qa/`** — 4 themed Q&A files covering scaling fundamentals, CAP/consistency, estimation/availability, and architecture tradeoffs.
- **`problems/`** — 4 hands-on challenges: a full back-of-envelope estimate, a scaling plan for a read-heavy service, applying the framework to a fresh prompt, and classifying consistency requirements across systems.
- **`assets/`** — placeholder for diagrams/images (see `assets/README.md`).

## What's covered

- Vertical vs. horizontal scaling, and why horizontal is the default answer past a certain scale
- The CAP theorem precisely — what it does and does not claim, and how it plays out during a network partition
- Strong, eventual, and causal consistency, with concrete read/write examples of each
- Availability, reliability, and durability as distinct, non-interchangeable properties
- Back-of-envelope estimation: QPS, storage, bandwidth, and memory math with worked examples
- Microservices vs. monolith tradeoffs, judged on team topology and failure isolation, not hype
- The standard system-design-interview framework: clarify requirements → estimate scale → high-level design → deep dive → identify bottlenecks
