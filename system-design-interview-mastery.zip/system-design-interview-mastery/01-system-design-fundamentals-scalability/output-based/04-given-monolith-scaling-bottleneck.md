# Output: Where a Monolith's Scaling Bottleneck Shows Up First

**Setup:** A single monolithic application handles both (a) a lightweight, extremely high-traffic `GET /product/:id` endpoint (200K req/s at peak, simple cached DB read) and (b) a CPU-heavy `POST /generate-report` endpoint (50 req/s, each taking ~8 seconds of CPU-bound PDF generation). Both run in the same process pool, on the same fleet of instances, scaled together as one unit.

**Question:** What happens to `/product/:id` latency during a burst of report-generation requests? Why, and what's the fix?

**Answer:** During a burst of `/generate-report` calls, worker threads/processes get tied up for ~8 seconds each doing CPU-bound work. Because both endpoints share the **same finite pool of workers** on the **same instances**, a spike in report generation starves the pool available to serve `/product/:id` — even though that endpoint is individually cheap, its requests now queue behind long-running report jobs, and p99 latency on the high-traffic, latency-sensitive endpoint spikes. Scaling the fleet (adding more monolith instances) helps but is inefficient: you're paying to add full replicas of the *entire* application (including all its memory footprint and startup cost) just to buy more headroom for one CPU-heavy endpoint that's used 4000x less often than the other.

**This is the textbook case for splitting a specific piece out of the monolith** — not a wholesale microservices rewrite, but extracting the CPU-heavy report generator into its own service (or even just its own dedicated worker pool/queue within the same deploy), so that:

- `/product/:id` gets its own resource pool, scaled to its own (very different) load profile, unaffected by report-generation spikes.
- The report-generation workload moves to an **async job queue** pattern (client submits a job, gets a job ID, polls or gets notified on completion) rather than blocking a request thread for 8 seconds — which also improves the UX for that endpoint, since a synchronous 8-second HTTP request is fragile (proxy timeouts, client retries causing duplicate work) regardless of the pool-starvation issue.

**The general lesson:** the trigger for splitting a monolith isn't "monoliths are bad at scale" in the abstract — it's specifically when two workloads sharing a resource pool have **very different scaling profiles or resource costs**, so scaling for one wastes resources on (or starves) the other.
