# Output: Downtime Budget From a Nines Target

**Setup:** A team commits to a **99.95%** monthly availability SLA for their API. This month, they've already had two incidents: a 9-minute outage from a bad deploy, and a 6-minute outage from an upstream dependency failing without a fallback.

**Question:** How much downtime budget remains for the rest of the month? If a planned database migration is expected to require a 12-minute maintenance window, does it fit within budget?

**Answer:**

```
Monthly budget = (1 - 0.9995) × 30 days × 24 hr × 60 min
               = 0.0005 × 43,200 minutes
               = 21.6 minutes

Already spent = 9 + 6 = 15 minutes
Remaining budget = 21.6 - 15 = 6.6 minutes
```

The planned 12-minute migration window **does not fit** — it exceeds the remaining 6.6-minute budget by more than 5 minutes, and doing it as planned would breach the SLA for the month (assuming no more incidents occur, which isn't a safe assumption either).

**What this should drive the team to do**, and why an interviewer cares about this beyond the arithmetic:

- **Reduce the migration's actual downtime**, e.g., via an online/zero-downtime migration technique (dual-write to old and new schema, backfill, cut over reads, drop the old path) instead of a blocking maintenance window — turning a 12-minute hard-down window into near-zero perceived downtime.
- **Defer the migration** to next month's budget if it can wait and isn't reducible.
- **Treat this as a signal about reliability investment**, not just a scheduling problem: two incidents costing 15 of 21.6 minutes in the same month suggests the *error budget itself* is being consumed by preventable causes (a deploy without adequate rollback tooling, a dependency with no fallback/circuit breaker) — the right long-term fix is closing those gaps so budget is available for planned, valuable risk (like migrations) rather than being eaten by avoidable incidents.

This is the practical, day-to-day use of an SLA number — not a static compliance target, but a live budget that gates what changes ship this month.
