# Output: Read Result Under Eventual Consistency With Replica Lag

**Setup:** An e-commerce product catalog uses a primary database for writes and 3 read replicas with asynchronous replication (typical lag: 200ms-2s, occasionally spiking to 10s under load). At `t=0`, an admin updates a product's price from $50 to $40 via a write to the primary. At `t=0.5s`, a customer's read request is load-balanced to **Replica B**, which is currently lagging by 3 seconds due to a burst of writes.

**Question:** What price does the customer see? Is this "wrong"?

**Answer:** The customer sees **$50** (the stale price) — Replica B hasn't yet applied the price-update write, since its replication lag (3s) is greater than the time elapsed since the write (0.5s). The customer's request will keep seeing $50 from Replica B until the replica catches up (at roughly `t=3s`, once the 3-second lag clears the write).

**Is it "wrong"?** Not necessarily a bug — it's the expected, designed-for behavior of an eventually consistent read path, and whether it's *acceptable* is a product decision, not a technical one:

- For a product catalog price display, a few seconds of staleness is usually acceptable — the system will converge, and the cost of avoiding it (routing every read to the primary) would tank read throughput for a case that rarely matters.
- **Where it stops being acceptable:** the checkout/payment flow. If the customer proceeds to buy at the stale $50 price shown, that's a real business problem. The fix isn't "make everything strongly consistent" — it's narrower: route the **specific read that gates payment** (the final price check at checkout) to the primary (or a replica with bounded, verified lag), while leaving product-browsing reads on replicas. This is the same "different consistency needs per feature" principle from the consistency-models theory file, applied concretely.
- A secondary mitigation: **replica lag monitoring with automatic exclusion** — if a replica's lag exceeds a threshold (e.g., 5s), the load balancer/proxy stops routing reads to it until it catches up, bounding the worst-case staleness any customer can see.
