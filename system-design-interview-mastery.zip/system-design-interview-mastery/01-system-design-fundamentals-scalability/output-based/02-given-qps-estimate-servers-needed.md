# Output: Estimating Servers Needed From QPS

**Setup:** A service must handle a peak of **20,000 requests/second**. Load testing shows a single application server instance can sustainably handle **800 requests/second** before p99 latency degrades past the SLA. The team wants **N+2 redundancy** (enough spare capacity to lose 2 instances — a bad deploy plus a hardware failure — without breaching the latency SLA).

**Question:** How many server instances are needed?

**Answer:**

```
Baseline instances needed = peak QPS / per-instance capacity
                           = 20,000 / 800
                           = 25 instances

With N+2 redundancy: 25 + 2 = 27 instances
```

**Why it matters, beyond the arithmetic:** this number is what actually drives several downstream design decisions an interviewer is listening for:

- **27 instances behind a single load balancer is fine** — nowhere near the point where you'd need multiple load-balancing tiers or a more exotic traffic-distribution scheme.
- It tells you the app tier is **not** the bottleneck at this scale — 27 commodity instances is cheap and simple. The interesting design work is almost certainly downstream, in the database or cache layer, which is a much harder thing to horizontally scale 27-way.
- The **redundancy margin** (+2, not +0) is what makes this a production-grade estimate rather than a textbook one — it's the direct, numeric expression of "the system should survive losing a couple of instances without users noticing," which ties back to the availability/reliability theory file (MTTR-driven resilience, not just raw uptime).
- If the interviewer then says "traffic grows 10x next year," you can immediately reason: 200,000 QPS / 800 ≈ 250 instances — still just "add more boxes," until *something else* (database connections, a shared cache, a rate-limited downstream dependency) becomes the real ceiling. Estimation's value is in showing you where the *next* bottleneck will actually appear.
