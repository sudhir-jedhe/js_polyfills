# Output: CAP Tradeoff During a Network Partition

**Setup:** A 6-node distributed key-value store is configured with quorum-based writes: a write is only acknowledged after **4 of 6** nodes confirm it (a strict majority-plus quorum). A network partition splits the cluster into a 4-node group and a 2-node group, and they cannot communicate with each other.

**Question:** Can the 2-node group accept writes during the partition? What about the 4-node group? What kind of system is this (CP or AP)?

**Answer:**

- The **2-node group cannot accept writes** — it can never reach the required 4-node quorum on its own (it only has 2 nodes total, let alone 4 confirmations), so any write request to a node in this group must be rejected or returned as an error.
- The **4-node group CAN accept writes** — it can reach the quorum of 4 entirely within itself.
- This is a **CP system**: during the partition, the minority side sacrifices availability (rejecting requests) to preserve consistency (no node ever serves a write that isn't confirmed by a majority, so there's no risk of the two sides diverging and needing reconciliation later).

**Why it matters:** if this were instead configured so *either* side could accept writes independently (no quorum requirement), it would be an AP system — both sides stay available, but now there's a real risk that both sides accept **conflicting** writes to the same key during the partition, requiring a conflict-resolution strategy (last-write-wins, vector clocks) once the partition heals. The quorum requirement (`W ≥ floor(N/2) + 1`) is the specific mechanism that converts an otherwise-AP-capable system into a CP one — it's a *design choice*, not an inherent property of "distributed database" in general. This is also why interviewers ask you to name the **exact quorum numbers** rather than just "we use quorum writes" — the numbers determine which side of CAP you actually land on.
