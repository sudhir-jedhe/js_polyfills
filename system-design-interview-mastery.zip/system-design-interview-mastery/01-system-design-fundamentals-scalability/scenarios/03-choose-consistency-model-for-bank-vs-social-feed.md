# Scenario: Choosing a Consistency Model — Bank Transfer vs. Social Feed

**Scenario:** You're asked, in the same interview, to justify the consistency model for two different features: (a) a funds transfer between two bank accounts, and (b) a social media news feed showing recent posts from people you follow. An interviewer wants to hear that you don't apply the same answer to both.

**Feature A: Funds transfer**

- **Requirement:** after a transfer completes, both accounts' balances must be immediately and universally correct — no reader anywhere should ever see a state where money has left one account but not yet arrived in the other (or worse, appears in neither, or both).
- **Model: strong consistency**, implemented via an ACID transaction: `BEGIN; UPDATE accounts SET balance = balance - 100 WHERE id = A; UPDATE accounts SET balance = balance + 100 WHERE id = B; COMMIT;` — both updates succeed or both roll back, atomically, and once committed, every subsequent read (from the primary; from any replica used for balance checks) must reflect the new balances before being trusted.
- **Why not eventual consistency here:** if account A's debit were visible before B's credit propagated (or vice versa), a concurrent balance check could observe money that has "disappeared" — unacceptable for a ledger. The cost (higher write latency from waiting on the transaction, reduced availability if the primary is unreachable) is explicitly worth paying — this is a CP choice by design, and reduced availability during an outage is preferable to serving an incorrect balance.

**Feature B: Social feed**

- **Requirement:** show recent posts from followed users reasonably promptly. If a post you made 5 seconds ago hasn't yet appeared in a friend's feed, that's a non-event — no one is going to lose money or make a decision based on a 5-second-old feed gap.
- **Model: eventual consistency.** New posts are written to a primary, then asynchronously fanned out to feed caches/read replicas. A feed read might miss the very latest post by a few seconds under load — acceptable.
- **Why not strong consistency here:** synchronizing every feed read across a fan-out to potentially millions of followers before returning would be enormously expensive in latency and infrastructure cost, for a correctness property (immediate global consistency) nobody actually needs for this feature. Optimizing for it would be over-engineering a social feed as if it were a payments ledger.

**The interview point:** the same engineer, same interview, same overall system (imagine both features exist in one banking-app-with-a-social-feed hypothetical) legitimately uses **two different consistency models** for two different pieces of data — because the *cost of being wrong* is wildly different between them. Naming that cost-of-being-wrong explicitly, per feature, is what the interviewer is grading — not memorizing "banking = strong, social = eventual" as a rule to recite.
