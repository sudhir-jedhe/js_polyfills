# Scenario: Capacity Planning for a New Feature Launch

**Scenario:** Product wants to launch a "Stories" feature (24-hour ephemeral photo/video posts, similar to Instagram/Snapchat Stories) to an existing app with 30M daily active users. Marketing expects a big launch-day spike. Engineering is asked: "will our infrastructure handle this, and what do we need to add?"

**Step 1 — estimate adoption and usage, state assumptions explicitly:**
```
Assume 40% of 30M DAU try Stories in the first week → 12M users
Assume each active Story user posts 2 stories/day, views 30 stories/day
Assume launch-day spike = 5x a normal day's traffic (marketing push, press)

Normal day:
  Posts/day = 12M × 2 = 24M posts/day → 24M / 86,400 ≈ 278 write QPS
  Views/day = 12M × 30 = 360M views/day → 360M / 86,400 ≈ 4,167 read QPS

Launch-day peak (5x, concentrated into a few peak hours rather than spread evenly —
assume peak-hour traffic is 3x the daily average within that day):
  Peak write QPS ≈ 278 × 5 × 3 ≈ 4,170 QPS
  Peak read QPS  ≈ 4,167 × 5 × 3 ≈ 62,500 QPS
```

**Step 2 — translate into infrastructure requirements:**
- **Read path is the dominant concern** (~62K peak QPS vs. ~4K writes) — this is squarely a caching and CDN problem, not a database-scaling problem. Story media (images/video) should be served from a CDN/object storage, never re-fetched from the app's origin servers per view.
- **Write path (~4K QPS peak)** is well within a single well-provisioned primary + a message queue absorbing bursts, as long as story creation is decoupled from any slow downstream work (video transcoding, thumbnail generation) via an async job queue rather than blocking the write request.
- **24-hour TTL is a first-class design feature, not an afterthought:** stories that expire are a natural fit for a storage/cache layer with built-in TTL (e.g., Redis `EXPIRE`, or a DB row with an `expires_at` and a background sweep/partition-drop job) — this bounds storage growth automatically, unlike the URL-shortener scenario where data accumulates indefinitely.

**Step 3 — identify what to load/stress-test before launch, not just estimate on paper:** the CDN's cache-hit ratio for freshly-uploaded story media under a cold cache (everything is brand new on day one, so nothing is pre-warmed) is the single riskiest unknown — a synthetic load test simulating the launch-day view pattern against a *cold* CDN cache is worth running specifically because the back-of-envelope math assumes a cache hit rate that hasn't been proven yet for genuinely new content.

**The interview point:** estimation for a *new* feature launch differs from estimating an existing system's steady state in one key way — you're estimating **adoption**, not just traffic, and that assumption (40% of DAU, 5x spike) is far shakier than "our existing traffic is X" — so the answer should explicitly flag which assumptions are load-bearing and recommend instrumenting the actual launch to validate them, rather than treating the estimate as gospel.
