# Scenario: Design a URL Shortener (Full Framework Walkthrough)

**Prompt:** "Design a URL shortener like bit.ly." This is a canonical "apply the framework end to end" prompt — used here to demonstrate the full 5-stage process from the framework theory file, not just to solve the specific problem.

**1. Clarify requirements:**
- Functional: shorten a long URL into a short one; redirect short URL → original URL; optional: custom aliases, expiration, click analytics.
- Non-functional: high availability (redirects should basically never fail), low redirect latency (this is on the critical path of every click), reads vastly outnumber writes, eventual consistency is fine for click-count analytics but the redirect mapping itself must be correct as soon as it's created.

**2. Estimation:** 100M new URLs/month → ~40 write QPS; assume 100:1 read:write → ~4,000 read QPS average, ~8,000 peak. 500 bytes/record × 6B records over 5 years ≈ 3TB. (Full math in the estimation snippet file.) **Conclusion: this is a read-heavy, moderate-write-volume system — a single primary DB with read replicas and a cache in front comfortably covers it; no sharding needed at this scale.**

**3. High-level design:**
```
Client → Load Balancer → App Servers → Cache (Redis) → Primary DB (+ read replicas)
                                            ↑ cache miss falls through to DB
```
- `POST /shorten { longUrl }` → generates a short code, writes `{short_code, long_url, created_at}` to the DB, returns the short URL.
- `GET /:short_code` → look up `long_url` for `short_code` (cache first, DB on miss), respond with an HTTP 301/302 redirect.

**4. Deep dive — short code generation:** Two approaches, worth contrasting:
- **Base62 encoding of an auto-incrementing ID:** simple, guaranteed-unique, but leaks creation order/volume and requires a centralized ID generator (a potential bottleneck/SPOF unless it's itself made redundant, e.g., a range-allocating ID service where each app server reserves a block of IDs to hand out locally).
- **Random string + collision check:** generate a random 7-character base62 string, check for collision in the DB (rare enough at this volume that a single extra lookup on collision is cheap), retry on collision. Simpler operationally (no centralized ID service), avoids leaking sequence information, at the cost of a very occasional extra DB round-trip.
- **Chosen:** random + collision check, for operational simplicity and no sequential-ID SPOF — a defensible choice either way, but the interview signal is in explaining the tradeoff, not which one you pick.

**5. Bottlenecks & tradeoffs:** The cache is a single point of read-latency risk — mitigate with a cache cluster (not one node) and a cache-aside pattern with a sane TTL (see the caching-strategies topic). The redirect endpoint is the highest-QPS, most latency-sensitive path in the whole system — it's the one place worth putting a CDN/edge cache in front of, since short-URL-to-long-URL mappings are immutable once created (perfect cache candidates — no invalidation problem at all).
