# Scenario: Scale a Monolith to Handle 10x Traffic

**Scenario:** A single-server Rails monolith backed by one PostgreSQL instance currently handles 500 req/s comfortably. The business projects traffic will hit 5,000 req/s within 6 months. The team asks: "do we need to rewrite this as microservices?"

**Diagnosis — resist the reflexive "yes, split it up":** a full microservices rewrite in 6 months is a large, risky bet, and 5,000 req/s is not, by itself, a number that requires it — plenty of monoliths comfortably serve far more than that. The right first move is to find out *what actually breaks* at 10x, not to assume the architecture itself is the problem.

**Step 1 — profile, don't guess.** Load-test the current system to find the real bottleneck. In this scenario, profiling reveals: the app servers themselves scale fine horizontally (stateless, already behind a load balancer) — the actual ceiling is the **single PostgreSQL primary**, which starts showing connection exhaustion and slow query times well before 5,000 req/s, because all reads and writes hit one instance.

**Step 2 — address the real bottleneck with the least invasive fix that solves it:**
1. **Connection pooling** (PgBouncer) in front of Postgres — the app servers were opening far more raw connections than the database could efficiently handle; pooling alone recovers meaningful headroom at near-zero engineering cost.
2. **Read replicas** — since the workload is read-heavy (typical for this kind of app), add 2-3 read replicas and route read-only queries to them, leaving the primary to handle writes only. This alone can absorb several times the current read load.
3. **A cache layer (Redis)** in front of the hottest, most-repeated read queries — cuts a large fraction of read traffic from ever reaching the database at all.
4. **Vertical scaling of the primary** as a stopgap where it buys meaningful headroom cheaply (more RAM for a bigger buffer cache, faster disks) — cheap, zero application-code changes, and appropriate precisely because the database is a single stateful resource that's hard to horizontally scale without real work (sharding).

**Step 3 — re-evaluate, don't pre-commit to a rewrite.** With the above in place, re-run the load test. In this scenario, the system now comfortably clears 5,000 req/s with margin. **No microservices split was needed** — the traffic growth was well within reach of standard vertical + read-scaling techniques applied to the actual bottleneck.

**When a split *would* become justified:** if a specific feature (e.g., a reporting/export module) had a wildly different resource profile than the rest of the app and was starving shared capacity (see the monolith-bottleneck output-based file) — that's a targeted-extraction case, not a "rewrite everything as microservices" case. The lesson for the interview: **scale the thing that's actually breaking, and only reach for more architectural complexity once the simpler levers are exhausted and there's a concrete reason** (fault isolation, independent team release cadence, wildly divergent per-component scaling needs) — not as a default reaction to a growth number.
