Diagrams and reference images for system design fundamentals & scalability (e.g. a CAP theorem triangle, a scaling framework flowchart) will be added here.
