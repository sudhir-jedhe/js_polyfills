# Problem: Design a Complete Index Strategy for a Multi-Query Table

## Problem Statement

A `transactions` table (a fintech ledger) has grown to 40 million rows and now serves four distinct, frequent query patterns from different parts of the product. Design a complete indexing strategy — not just one index — covering all four, while explicitly reasoning about the cumulative write-cost tradeoff of adding multiple indexes to one table.

```sql
-- Q1 (very frequent): a user's own transaction history, most recent first
SELECT * FROM transactions WHERE user_id = $1 ORDER BY created_at DESC LIMIT 50;

-- Q2 (frequent): fraud team's review queue — flagged transactions, oldest first
SELECT * FROM transactions WHERE flagged = true ORDER BY created_at ASC;

-- Q3 (frequent): a specific transaction lookup by its external reference ID (e.g., from a support ticket)
SELECT * FROM transactions WHERE external_ref_id = $1;

-- Q4 (moderate): monthly revenue reconciliation — sum of completed transactions in a date range
SELECT SUM(amount_cents) FROM transactions WHERE status = 'completed' AND created_at BETWEEN $1 AND $2;
```

## Constraints

- Each index must be justified by its specific query, not added speculatively.
- Explicitly total the resulting index count and reason about whether it's an acceptable write-cost tradeoff for this table.
- At least one query should be reconsidered for whether an index is even the right fix, versus a different approach.

## Solution

**Index for Q1** — composite, matching filter + sort exactly (per the composite-index reasoning used throughout this topic):
```sql
CREATE INDEX idx_transactions_user_created ON transactions (user_id, created_at DESC);
```

**Index for Q2** — composite on the low-cardinality `flagged` boolean plus the sort column:
```sql
CREATE INDEX idx_transactions_flagged_created ON transactions (flagged, created_at ASC)
WHERE flagged = true;  -- a PARTIAL index: only indexes the (presumably small) flagged subset,
                        -- since flagged=true is rare relative to the full 40M-row table —
                        -- this keeps the index itself small and fast to maintain, avoiding
                        -- the low-cardinality-column concern from the indexing theory file
                        -- by scoping the index to only the selective subset that matters
```

**Index for Q3** — a unique index, since external reference IDs are looked up by exact match and are presumably unique per transaction:
```sql
CREATE UNIQUE INDEX idx_transactions_external_ref ON transactions (external_ref_id);
```

**Q4 reconsidered — an index alone is a weaker fix than it looks; this is really an analytics workload, not a simple filtered lookup.** An index on `(status, created_at)` would help *locate* the relevant rows for a given month, but the query still has to aggregate (`SUM`) over potentially millions of rows within that range every time reconciliation runs — an index speeds up finding the rows, not summing them. Two considerations, in order of applicability:
1. If reconciliation runs infrequently (e.g., once a month) and the date range is bounded (one month's worth of transactions, not the whole table), a supporting index is still worthwhile and sufficient:
```sql
CREATE INDEX idx_transactions_status_created ON transactions (status, created_at);
```
2. If reconciliation needs to run more frequently, or the aggregation itself becomes the bottleneck even with the index (large monthly transaction volume), the better fix is the same one used in the normalize-vs-denormalize analytics scenario: a separate, periodically-updated **denormalized daily/monthly rollup table** (`daily_revenue_summary`), maintained incrementally as transactions complete, so reconciliation reads a handful of pre-aggregated rows instead of summing millions of raw rows on demand — an index optimizes the query as currently shaped, while a rollup table changes what has to be computed at query time at all.

**Total index count and the cumulative write-cost tradeoff, addressed explicitly:** this adds 3 new indexes (Q4's is included; the partial index for Q2 is comparatively cheap since it only covers the flagged subset) to a table that's presumably written to on every transaction — a genuinely high-frequency write path for a fintech ledger. The team's judgment call: each of these 3 indexes serves a **distinct, frequent, product-critical** query (a user's own history, the fraud queue, external lookups for support) — none is speculative — so the added per-write overhead (each `INSERT` now maintains 4 total indexes, including the primary key) is deemed an acceptable, deliberate tradeoff, explicitly reasoned through rather than added without consideration, and monitored post-deployment via write-latency metrics on the transaction-creation path to confirm the assessment held.
