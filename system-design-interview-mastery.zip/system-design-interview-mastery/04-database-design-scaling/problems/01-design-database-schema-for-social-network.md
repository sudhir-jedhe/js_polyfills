# Problem: Design a Database Schema for a Social Network

## Problem Statement

Design the core database schema for a social network supporting: user profiles, an asymmetric follow relationship (like Twitter, not a symmetric friendship), posts, likes, and comments. Specify tables, keys, and at least two indexes justified by a stated access pattern. Address which parts of this schema, if any, warrant denormalization.

## Constraints

- The follow relationship is directional (A follows B doesn't imply B follows A).
- Must support the two most common queries efficiently: "posts in my feed" (from people I follow) and "who does user X follow / who follows user X."
- State explicitly which access pattern each index serves.

## Solution

**Core normalized schema:**
```sql
CREATE TABLE users (
  id           BIGSERIAL PRIMARY KEY,
  username     TEXT NOT NULL UNIQUE,
  display_name TEXT NOT NULL,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE follows (
  follower_id  BIGINT NOT NULL REFERENCES users(id),
  followee_id  BIGINT NOT NULL REFERENCES users(id),
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (follower_id, followee_id)  -- composite PK also serves as an index
);

CREATE TABLE posts (
  id         BIGSERIAL PRIMARY KEY,
  author_id  BIGINT NOT NULL REFERENCES users(id),
  body       TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE likes (
  user_id    BIGINT NOT NULL REFERENCES users(id),
  post_id    BIGINT NOT NULL REFERENCES posts(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, post_id)
);

CREATE TABLE comments (
  id         BIGSERIAL PRIMARY KEY,
  post_id    BIGINT NOT NULL REFERENCES posts(id),
  author_id  BIGINT NOT NULL REFERENCES users(id),
  body       TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
```

**Index 1 — serving "who does user X follow":**
```sql
-- the follows table's PRIMARY KEY (follower_id, followee_id) already serves this:
SELECT followee_id FROM follows WHERE follower_id = $1;
-- follower_id is the leftmost column of the PK, so this is already index-backed.
```

**Index 2 — serving "who follows user X" (the REVERSE lookup — NOT covered by the primary key above, per the leftmost-prefix rule):**
```sql
CREATE INDEX idx_follows_followee ON follows (followee_id);
-- without this, "who follows user X" would require a full scan of `follows`,
-- since followee_id is NOT the leftmost column of the existing composite PK
SELECT follower_id FROM follows WHERE followee_id = $1;
```

**Index 3 — serving "posts by a given author, most recent first" (the raw building block for feed assembly):**
```sql
CREATE INDEX idx_posts_author_created ON posts (author_id, created_at DESC);
```

**Feed query — using the follows table and the posts index together:**
```sql
SELECT p.* FROM posts p
JOIN follows f ON f.followee_id = p.author_id
WHERE f.follower_id = $1
ORDER BY p.created_at DESC
LIMIT 20;
```

## Where denormalization is warranted, and why

**Feed assembly should NOT be computed live via the join above at read time, at any real scale.** This mirrors the fundamentals topic's Twitter estimation problem directly: a live join across `follows` and `posts` for every feed load doesn't scale once follow-counts and post-volume grow large. The denormalized fix: maintain a **materialized per-user feed** (a Redis Sorted Set or a dedicated `feed_entries` table, populated via fan-out-on-write when a followed user posts — see the caching-strategies topic's news-feed problem for the full mechanics) — the normalized schema above remains the source of truth for `posts` and `follows`, while the feed itself is a denormalized, purpose-built read model kept in sync via the write-time fan-out, exactly the "normalized system of record, denormalized read model" pattern from the normalization theory file.

**Likes count on a post is a second denormalization candidate:** rather than running `SELECT COUNT(*) FROM likes WHERE post_id = $1` on every post render (expensive at scale, and likes are read far more often — every feed render — than written), add a denormalized `like_count` column directly on `posts`, incremented/decremented via the write path when a like is added/removed — trading a small amount of write complexity (updating two tables instead of one on each like) for a read that no longer needs to scan or count anything.
