# Problem: Design a Sharding Scheme for Time-Series Sensor Data

## Problem Statement

An IoT platform ingests sensor readings from 200,000 devices, each reporting a value every 10 seconds (~20,000 writes/second platform-wide). The dominant query pattern is "give me device X's readings between timestamp A and B" (for a specific device, over a time range). Design a sharding scheme, explicitly addressing why a naive choice of either pure range-by-timestamp or pure hash-by-reading-id would each fail here.

## Constraints

- Must support high, evenly-distributed write throughput across shards.
- Must keep the dominant read pattern (one device, a time range) efficient — ideally hitting a small number of shards, not the entire cluster.
- Must address the specific rebalancing concern this data shape introduces (see below).

## Solution

**Why pure range-by-timestamp sharding fails:** if shards are partitioned purely by time range (e.g., Shard A holds all readings from this week, Shard B next week), **all 20,000 writes/second land on whichever single shard represents "now"** — every other shard sits idle for writes, and only becomes read-active later once queries target its time range. This is the exact sequential-key hotspot failure mode from the sharding-strategies theory file, and it's especially severe here because *every single write*, from every one of the 200,000 devices, funnels through the one "current" shard simultaneously.

**Why pure hash-by-reading-id (or a random UUID per reading) sharding fails:** distributes writes evenly (fixing the hotspot), but destroys the dominant read pattern — "device X's readings between A and B" would now need to fan out to **every shard** and merge results, since a given device's readings are scattered essentially randomly across the cluster with no relationship between the shard key and the query's filter.

**Chosen scheme: hash the device ID (not the reading ID) for shard placement, and sort within each shard by timestamp.**
```
shard = hash(device_id) % num_shards

-- within a shard, readings are physically stored/indexed as:
CREATE INDEX idx_readings_device_time ON readings (device_id, recorded_at);
```
- **Writes are evenly distributed:** since `device_id` (not a monotonically increasing reading ID or timestamp) drives shard placement, and there are 200,000 distinct, roughly-equal-volume devices, hashing spreads write load evenly across all shards — no single shard absorbs a disproportionate share of the 20,000 writes/second.
- **The dominant read query hits exactly ONE shard:** `hash(device_id)` deterministically identifies a single shard for any given device, so "device X's readings between A and B" is satisfied entirely within that one shard — and within the shard, the `(device_id, recorded_at)` index (a composite index whose trailing column matches the query's range filter, per the schema/index output-based file's reasoning) makes the time-range portion of the query efficient too.

**Rebalancing concern specific to this scheme, addressed via consistent hashing:** as device count grows (more IoT devices onboarded over time) or write volume per device increases, the cluster will eventually need more shards. Plain `hash(device_id) % num_shards` would suffer the same near-total-reshuffle problem the rebalancing theory file warns about — the fix is the same consistent-hashing ring from that file, applied to `device_id` specifically: adding a shard only requires migrating the devices whose hash falls into the new shard's arc, not re-sharding the entire 200,000-device fleet's historical data.

**A secondary, time-based partitioning layer within each shard, worth naming as a scaling refinement:** even within one shard, readings accumulate indefinitely — a common complementary technique is to additionally partition each shard's `readings` table by time range (e.g., monthly partitions), so old, rarely-queried data can be cheaply archived or dropped without touching recent, hot partitions, and so queries scoped to a recent time range don't need to scan through years of old data even within the correct shard. This is a different, complementary axis from the device-based shard key — sharding solves cross-node distribution, time-based partitioning solves within-node data lifecycle management.
