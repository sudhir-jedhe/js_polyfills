# Problem: Design a Replication Topology for a Read-Heavy Application

## Problem Statement

A content platform serves 50,000 read QPS (article views, comments, search) against 300 write QPS (new articles, comments, edits). The platform operates in three regions (US, EU, APAC) with users primarily reading content, but writes can originate from any region (content creators are globally distributed). Design a replication topology, and justify why a master-master setup is or isn't warranted here despite the multi-region requirement.

## Constraints

- Reads must be served with low latency from the region closest to each reader.
- Writes are 150:1 outnumbered by reads — the topology should reflect that skew.
- Must explicitly address whether master-master's conflict-resolution complexity is justified here, not assumed.

## Solution

**Evaluate master-master first, since the multi-region requirement makes it tempting — and reject it, with reasons stated.** Per the replication theory file, master-master is justified specifically when **write latency from multiple regions** is a hard requirement — but here, writes are only 300 QPS platform-wide (a small fraction of total traffic) and content creation/editing is not typically as latency-sensitive as, say, a real-time collaborative editor (per-keystroke sync) — a content creator in the EU experiencing an extra 100-150ms of write latency to reach a single US-based primary is a minor, acceptable cost, not a product-breaking one. Given that, taking on master-master's conflict-resolution complexity (per the replication theory file's own caution) for a write volume and latency-sensitivity this modest is not justified — it would be solving a problem (multi-region write latency) that isn't actually painful enough here to be worth the tradeoff.

**Chosen topology: single primary (in the US, assumed the largest content-creation base) with regional read replica clusters.**
```
                         US Primary (all writes, from ANY region)
                        /         |          \
          US Replicas   EU Replicas    APAC Replicas
          (2-3 nodes)   (2-3 nodes)    (2-3 nodes)
                |              |              |
          US Readers    EU Readers     APAC Readers
```
- **All writes** (300 QPS, globally) route to the single US primary — accepting the added latency for non-US writers as a reasonable tradeoff given the analysis above.
- **Reads** (50,000 QPS) are served from **regional** replica clusters — a reader in the EU is served by an EU-local replica, getting low read latency without needing a multi-primary write topology at all. This directly matches the 150:1 read:write skew: the topology invests its complexity in **read** scaling (trivial to do well with regional replicas) rather than **write** scaling (which would require master-master's added complexity for comparatively little benefit here).

**Addressing replication lag for cross-region replicas specifically** — a EU or APAC replica is physically farther from the US primary than a same-region replica would be, so its replication lag is likely to be somewhat higher on average purely due to network distance. This is judged acceptable for this workload (article views/comments tolerate a few hundred milliseconds to low seconds of staleness fine — nobody's checkout or payment is gated on freshly-published-content visibility down to the millisecond), but the design still applies **read-your-writes routing for the specific case of a content creator viewing their own just-published article or comment** (route that specific read to the primary or a same-region-as-primary replica briefly after their own write) — the same targeted fix used in the replication-lag scenario elsewhere in this topic, rather than solving it system-wide.

**Bottleneck named proactively:** if write volume or write-latency sensitivity grows substantially in the future (e.g., a new real-time collaborative editing feature), this topology's single-US-primary assumption would need to be revisited — the design explicitly notes this as the trigger condition for reconsidering master-master, rather than treating today's decision as permanent regardless of how requirements evolve.
