# Interview Q&A — Sharding and Connection Pooling

**Q: Why does naive modulo-based hash sharding (`hash(key) % num_shards`) rebalance so badly when the shard count changes?**
Because `hash(key) % N` and `hash(key) % (N+1)` agree for only a small fraction of keys by pure chance — adding a single shard to the cluster changes the target shard for almost every key, requiring nearly the entire dataset to be moved for what should be an incremental capacity change. This is exactly the problem consistent hashing is designed to solve.

**Q: How does consistent hashing minimize data movement when a shard is added or removed?**
It maps both shards and keys onto a shared, fixed hash ring — each shard owns the arc of the ring between itself and its neighbor, and a key belongs to the next shard found walking clockwise from the key's position. Adding a shard only requires moving the keys that fall into the new shard's specific arc — roughly `1/(N+1)` of the total data — rather than reshuffling the whole keyspace the way plain modulo hashing does.

**Q: What are "virtual nodes" in a consistent-hashing scheme, and what problem do they solve?**
Placing each physical shard at many scattered positions on the hash ring, rather than just one, so that ring ownership (and therefore load) is spread more evenly. Without virtual nodes, a single physical shard can get unlucky and end up owning a disproportionately large arc of the ring purely by chance, leading to uneven load distribution even though consistent hashing is otherwise designed to distribute load evenly.

**Q: Why can a shard key with high cardinality (many distinct values) still produce a severe hotspot?**
Hash sharding evenly distributes *distinct key values* across shards, but it says nothing about the *volume of data or traffic per key value*. A shard key like `tenant_id` in a multi-tenant system can have thousands of distinct values (high cardinality) while still hotspotting badly if one tenant's traffic volume vastly exceeds a typical tenant's — the fix isn't a different hashing strategy, but a finer-grained key or explicit dedicated placement for the outlier.

**Q: Why can a connection pool look healthy on every individual application instance while the database is still refusing connections under load?**
Because the constraint is the *aggregate* connection count across the entire fleet (`pool size per instance × number of instances`) versus the database's fixed connection ceiling — a per-instance pool utilization metric only shows that one instance's local state, not the fleet-wide total, so the actual bottleneck can be invisible from any single instance's monitoring. This is why connection pool sizing has to be planned at the fleet level, and why an external pooler (like PgBouncer) that caps the real database-side connection count independent of fleet size is a common, more scalable fix.
