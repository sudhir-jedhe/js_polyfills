# Interview Q&A — Database Indexing

**Q: Mechanically, why does a B-tree index turn an O(n) lookup into an O(log n) lookup?**
A B-tree stores indexed values in sorted order across a wide, shallow tree structure — each level narrows the search space by comparing against multiple keys per node, so the tree's height (and thus the number of comparisons needed) grows logarithmically with the number of rows, not linearly. Without an index, finding matching rows requires scanning every row sequentially and checking each one — a linear-time operation regardless of how deep into the table the matches happen to sit.

**Q: What's the leftmost-prefix rule for composite indexes, and why does it matter?**
A composite index on `(A, B)` is sorted first by `A`, then by `B` within each `A` group — so it can efficiently serve queries filtering on `A` alone, or on `A` and `B` together, but generally cannot efficiently serve a query filtering on `B` alone, since the data isn't globally sorted by `B`. This matters because adding a composite index doesn't automatically speed up every query touching those columns — the query's filter has to align with the index's column order, starting from the left.

**Q: Name two concrete costs of adding an index, beyond "it takes disk space."**
Write overhead — every `INSERT`/`UPDATE`/`DELETE` touching the indexed columns must also update the index, so more indexes means slower writes, not just more storage. And query-planner risk on low-cardinality columns — an index on a column with only a few distinct values (e.g., a boolean flag) may not actually get used, or may not meaningfully help, if the matched-row fraction is too large for the index to narrow the search space enough to beat a sequential scan.

**Q: How can a composite index eliminate a query's sort step, not just its scan step?**
If a composite index's trailing columns match the query's `ORDER BY` clause exactly (e.g., an index on `(customer_id, created_at DESC)` for a query filtering on `customer_id` and sorting by `created_at DESC`), the matching rows are already stored in that exact order within the index — the database can walk the index directly without a separate, additional sort operation on the result set, which is a distinct performance win from just avoiding the full scan.

**Q: A candidate proposes adding an index to fix a slow query, but doesn't run `EXPLAIN` first. Why is that a weaker answer, even if the index happens to help?**
`EXPLAIN` (or `EXPLAIN ANALYZE`) reveals the *actual* cost breakdown — e.g., whether the slowness is from a sequential scan, a separate sort step, or something else (a nested loop join gone wrong, for instance) — and a correctly-targeted index depends on knowing which of these is the real bottleneck. Proposing an index without that diagnosis risks fixing only part of the problem (e.g., removing the scan but leaving an expensive sort in place) or adding an index that doesn't actually address the true cost at all.
