# Interview Q&A — Replication and Consistency

**Q: What's the core tradeoff between synchronous and asynchronous replication?**
Synchronous replication waits for a replica to confirm a write before acknowledging it to the client, guaranteeing the replica is never behind at the cost of higher write latency (and reduced write availability if the replica is slow or unreachable). Asynchronous replication acknowledges the write immediately and replicates in the background, giving lower latency but introducing both a staleness window (replica lag) and a durability risk — an acknowledged write can be lost if the primary crashes before it replicates.

**Q: In a master-slave setup with asynchronous replication, what specifically can be lost if the primary crashes and a replica is promoted?**
Any write that was acknowledged by the primary but hadn't yet replicated to the promoted replica at the moment of the crash — the promoted replica has no record of it, and unless the old primary comes back and its un-replicated writes can be safely reconciled, that write is permanently lost. This is a direct, inherent consequence of async replication's design, not a malfunction.

**Q: What's the core challenge master-master replication introduces that master-slave doesn't have?**
Conflict resolution — since multiple nodes can accept writes to the same row concurrently, the system needs an explicit strategy (last-write-wins, application-level merge logic, or CRDTs/vector clocks) to decide the outcome when two nodes' writes to the same data disagree. Master-slave avoids this entirely by having a single node accept all writes, so there's never a concurrent-write conflict to resolve.

**Q: What is "read-your-writes" consistency, and why is it commonly layered on top of an otherwise eventually-consistent, replica-based read setup?**
It guarantees that a user who just performed a write sees that write reflected in their own subsequent reads, typically by routing their reads to the primary (or a confirmed-caught-up replica) for a short window after the write, while other users' reads continue going to possibly-lagging replicas. It's popular because it removes the most visibly broken symptom of replication lag — a user's own action appearing to have silently failed or reverted — without paying the cost of routing all reads to the primary system-wide.

**Q: Why should a lag-based exclusion mechanism (removing a replica from the read pool once its lag exceeds a threshold) be considered alongside read-your-writes routing, rather than as a substitute for it?**
Read-your-writes routing only protects the *acting user's own* subsequent reads — a different user reading the same data from a heavily-lagging replica would still see stale data. Lag-based exclusion protects *all* readers from an excessively stale replica, addressing a different failure mode (a replica falling far behind under load) that read-your-writes routing alone doesn't cover — the two mechanisms are complementary, each closing a gap the other leaves open.
