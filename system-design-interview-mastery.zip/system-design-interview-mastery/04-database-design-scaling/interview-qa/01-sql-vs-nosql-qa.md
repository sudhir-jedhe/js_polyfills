# Interview Q&A — SQL vs. NoSQL

**Q: What's the single strongest signal that a data model should be relational (SQL) rather than NoSQL?**
Whether correctness depends on transactions spanning multiple rows or tables atomically — e.g., a funds transfer touching two account rows, or an order-approval workflow that must update both an order's status and a budget's balance together. Relational databases provide full ACID transactions across arbitrary rows/tables as a standard feature; most NoSQL systems either lack this or offer only a narrower, single-document scope of atomicity.

**Q: "NoSQL" isn't one thing — name the main categories and what each is optimized for.**
Document stores (MongoDB) for schema-flexible, per-record-varying data; key-value stores (Redis, DynamoDB) for simple, extremely fast lookups by a known key; wide-column stores (Cassandra) for very high write throughput at huge scale, often time-series-shaped; graph databases (Neo4j) for relationship-traversal-heavy queries. Treating "NoSQL" as a single alternative to SQL glosses over that these categories solve different problems.

**Q: Why is "NoSQL scales better" an incomplete answer?**
Modern relational databases scale substantially via read replicas, connection pooling, and sharding — the same techniques covered throughout this topic — and many NoSQL systems offer tunable consistency rather than being inherently more scalable by nature. The real differentiator is the data model and transactional needs, not an inherent scalability gap between the two categories.

**Q: Is it reasonable for a single system to use both SQL and NoSQL for different parts of its data? Give an example.**
Yes — this is common and often the correct design: a relational database for the transactional core (orders, payments, anything needing multi-row ACID guarantees) alongside a document store or key-value cache for product catalog browsing or session data, where the shape varies more and simple, fast lookups matter more than relational integrity. Applying one data model uniformly across an entire system, regardless of each piece of data's actual needs, misses the same "per-feature reasoning" principle used for consistency models and caching strategy elsewhere.

**Q: A team argues "we should start with NoSQL since migrating away from SQL later, once we're big, is harder than the reverse." How should this argument be evaluated?**
It inverts the actual decision order — the choice should be driven by the data's relational/transactional requirements *today*, which are usually knowable up front, not by a speculative future migration cost. A team with a genuine multi-row-transaction requirement (e.g., an approval workflow) that picks NoSQL anyway to "future-proof for scale" is giving up a guarantee it needs now for a scale problem it may never actually hit, or could address later via well-understood relational scaling techniques (replication, sharding) instead.
