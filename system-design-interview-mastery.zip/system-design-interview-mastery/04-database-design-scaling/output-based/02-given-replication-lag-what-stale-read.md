# Output: What a Read Returns Given Specific Replication Lag

**Setup:** An asynchronous master-slave setup: 1 primary, 2 replicas (Replica A typically lags ~50ms; Replica B, under heavier read load, typically lags ~4 seconds). A load balancer routes reads round-robin across both replicas with no lag-awareness. At `t=0`, a user updates their display name from "Alex" to "Alexandra" (write goes to the primary). The user's own profile page immediately re-fetches their profile at `t=0.1s`, `t=1s`, and `t=5s`, with each fetch load-balanced to whichever replica is next in the round-robin rotation.

**Question:** Assuming the round-robin happens to send the `t=0.1s` read to Replica B and the `t=1s` read to Replica A, what does the user see at each point, and what's the underlying bug being illustrated?

**Answer:**

- **`t=0.1s` (routed to Replica B, ~4s lag):** Replica B has not yet received the write from `t=0` (it's still 4 seconds behind at this moment) — the user sees their **old name, "Alex"**, immediately after having just changed it. From the user's own perspective, this looks exactly like the save silently failed or reverted.
- **`t=1s` (routed to Replica A, ~50ms lag):** Replica A caught up to the `t=0` write within its typical ~50ms lag window, long before `t=1s` — the user now sees **"Alexandra"**, the correct, updated name.
- **`t=5s`:** by now both replicas have caught up regardless of which one serves the request — **"Alexandra"** either way.

**The underlying bug:** this isn't really "replication lag causing staleness" in the abstract — it's specifically that **the user's own read-after-write isn't being routed with any consistency guarantee at all**, and the round-robin load balancer's lack of lag-awareness means the exact same user, on the exact same page, refreshing twice in a row, can see their change **appear to revert and then reappear**, purely as an artifact of which replica happened to answer each request — a confusing, visibly broken UX, not just an abstract staleness window.

**The fix — read-your-writes routing (from the fundamentals topic's consistency-models theory file, applied concretely here):** route the acting user's own reads to the **primary** (or to a replica confirmed to be caught up past the write's timestamp) for a short window immediately after they perform a write, while other users continue reading from whichever replica the load balancer picks. This doesn't require making the whole system strongly consistent — it specifically closes the "my own action looks like it silently failed" gap, which is the actual user-facing symptom, without paying the cost of routing *all* reads to the primary.

**A secondary, complementary fix:** exclude replicas whose lag exceeds a threshold (e.g., 1 second) from the read-routing pool entirely until they catch up — this wouldn't have fully prevented the `t=0.1s` staleness in this scenario (Replica B's 4s lag was already above a reasonable threshold, so it should arguably not have been in rotation for *any* read at that moment, illustrating that lag-based exclusion is a real, independent mitigation worth having even alongside read-your-writes routing).
