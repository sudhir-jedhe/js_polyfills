# Output: What Happens Under Load, Given This Pool Configuration

**Setup:** An application fleet of 15 instances, each configured with an in-process connection pool `max: 30` (no external pooler). The PostgreSQL database's `max_connections` is set to 300 (the default-ish ceiling, with some reserved for administrative connections, so effectively ~280 usable). At normal traffic, each instance uses on average 8 of its 30 pooled connections. During a traffic spike (a marketing campaign), each instance's actual concurrent connection usage climbs toward its full `max: 30`.

**Question:** What's the theoretical maximum connection count this fleet can generate, and what happens if the spike pushes every instance toward its pool's ceiling simultaneously?

**Answer:**

```
Theoretical max = 15 instances × 30 connections/instance = 450 connections
Database's usable ceiling ≈ 280 connections

450 > 280 — the fleet's aggregate pool capacity EXCEEDS what the database can accept,
even though each individual instance's pool size (30) looks modest in isolation.
```

If the spike pushes most instances toward their full pool utilization simultaneously, the database will refuse new connections once it hits its `max_connections` ceiling — application instances attempting to open a 31st... wait, actually the *281st-and-beyond* connection across the fleet get connection errors (`FATAL: too many connections for role` or similar), even though **individual instances are nowhere near their own configured `max: 30`** — the failure appears seemingly random from any single instance's perspective (some requests succeed, others fail with a connection error), because which instances happen to be under peak load at the exact moment the aggregate ceiling is hit is essentially arbitrary.

**Why this is a particularly nasty failure mode to diagnose:** monitoring any single application instance shows its pool utilization looking healthy (well under its own configured `max: 30`) — the actual constraint (aggregate connections across the *entire fleet* vs. the database's *global* ceiling) isn't visible from any single instance's local metrics at all. A team without fleet-wide connection monitoring can spend significant time looking in the wrong place (assuming it's a per-instance pool misconfiguration) before realizing the real constraint is the aggregate.

**Fix 1 — reduce per-instance pool size, accepting the tradeoff.** Lowering `max: 30` to, say, `max: 15` per instance drops the theoretical ceiling to `15 × 15 = 225`, safely under 280 — but at the cost of less headroom per instance under genuinely uneven load (one busy instance can no longer borrow more connections just because other instances happen to be idle, since pool sizing is fixed per instance rather than shared).

**Fix 2 — introduce an external pooler (PgBouncer) in front of the database**, exactly as covered in the connection-pooling theory file and its snippet — this decouples the fleet's *aggregate* app-side connection count (which can scale freely with fleet size) from the database's *actual* connection count (fixed, e.g., at 25-50 real connections, regardless of how large the app fleet grows). This is the more scalable long-term fix, since it removes the need to keep manually recalculating `(pool size) × (instance count)` against the database's ceiling every time the fleet scales.

**The general lesson:** connection pool sizing is a **fleet-wide** capacity planning problem, not a per-instance tuning knob considered in isolation — the same back-of-envelope-estimation discipline from the fundamentals topic (compute the aggregate, not just the per-unit number) applies directly here.
