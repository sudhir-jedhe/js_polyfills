# Output: Given This Schema and Query Pattern, Which Index Helps?

**Setup:** An `orders` table has columns `id, customer_id, status, created_at, total_cents`, currently with only a primary key index on `id`. The application's dominant query patterns, by frequency:

```sql
-- Q1 (very frequent): a customer's order history, most recent first
SELECT * FROM orders WHERE customer_id = $1 ORDER BY created_at DESC;

-- Q2 (frequent): all pending orders across all customers, for a fulfillment dashboard
SELECT * FROM orders WHERE status = 'pending' ORDER BY created_at ASC;

-- Q3 (rare): looking up a single order by exact total, for fraud investigation
SELECT * FROM orders WHERE total_cents = $1;
```

**Question:** What index (or indexes) should be added, and why does a single composite index serve Q1 particularly well?

**Answer:**

**For Q1:** a composite index on `(customer_id, created_at DESC)`:
```sql
CREATE INDEX idx_orders_customer_created ON orders (customer_id, created_at DESC);
```
This single index serves the **entire** query — the leading column (`customer_id`) narrows to one customer's rows via the leftmost-prefix rule, and because `created_at DESC` is the second column, those rows are *already stored in the exact sort order the query requests* — the database can walk the index directly, avoiding a separate, additional sort step entirely. This is the strongest case in this setup: one index, fully satisfying both the filter and the sort of the highest-frequency query.

**For Q2:** a separate index on `(status, created_at ASC)`:
```sql
CREATE INDEX idx_orders_status_created ON orders (status, created_at);
```
Q2 filters on `status`, a column not covered as a *leading* column by the Q1 index (recall the leftmost-prefix rule: an index on `(customer_id, created_at)` can't efficiently serve a query filtering on `created_at` or `status` alone) — this needs its own index. Worth flagging: `status` is a low-cardinality column (few distinct values: pending/shipped/delivered/cancelled), which the indexing theory file notes can sometimes make an index less valuable — but here it's justified anyway, since the query is additionally filtering to a *specific* value (`'pending'`) that's presumably a small minority of all orders at any given time (most orders aren't perpetually pending), keeping the matched-row fraction low enough for the index to meaningfully help.

**For Q3:** **no index recommended.** This query is rare (a fraud-investigation lookup, not a hot path), and `total_cents` is unlikely to be a highly selective, frequently-filtered column in normal operation — adding a dedicated index here would add permanent write overhead (per the indexing theory file's write-cost tradeoff) to every single order insert, for the benefit of an occasional, low-volume investigative query. If this pattern became frequent, that calculus would change — but as described, the cost doesn't justify the benefit.

**The general lesson:** index decisions should be driven by **actual query frequency and shape**, matching composite index column order to the query's filter-then-sort pattern specifically — not by indexing every column that ever appears in a `WHERE` clause regardless of how often or how selectively it's queried.
