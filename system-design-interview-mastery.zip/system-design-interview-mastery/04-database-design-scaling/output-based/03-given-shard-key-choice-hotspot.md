# Output: Hotspotting From a Poor Shard Key Choice

**Setup:** A multi-tenant SaaS product shards its `events` table (customer usage/audit events) by `tenant_id` using hash-based sharding (`shard = hash(tenant_id) % 8`). The product has 500 customers (tenants) of wildly varying size: one enterprise customer generates 60% of all events platform-wide; the remaining 499 customers together generate the other 40%.

**Question:** Does hash-based sharding solve the load-distribution problem here? What actually happens, and why doesn't the sharding *strategy* choice fix it?

**Answer:** Hash-based sharding evenly distributes **distinct tenant_id values** across the 8 shards — but it does nothing about the fact that the *volume of events per tenant* is wildly unequal. Whichever single shard `hash(enterprise_tenant_id) % 8` happens to land on now receives roughly **60% of all platform write traffic**, while the other 7 shards split the remaining 40% — a severe hotspot, despite hash sharding being specifically chosen (correctly, per the sharding-strategies theory file) to *avoid* the sequential-key hotspotting problem range sharding would have caused.

**Why this isn't a bug in hash sharding, but a mismatch between the shard key and the actual data distribution:** hash sharding guarantees even distribution of **keys**, not even distribution of **load per key** — it assumes each shard key roughly corresponds to a similar amount of data/traffic, an assumption this scenario explicitly violates (one tenant is ~600x more active than a typical one of the remaining 499, if evenly split). No sharding *strategy* choice (range, hash, geo) fixes a fundamentally skewed real-world access pattern by itself — the shard key granularity itself needs to change.

**Fix — shard at a finer granularity than "one tenant = one shard-key value," specifically for the outlier:**

```
Option A: composite shard key, splitting the largest tenant's own data further
  shard = hash(tenant_id + ':' + (event_id % 10)) % 8
  -- the enterprise tenant's events are now spread across a sub-partition,
  -- rather than all colliding on whichever single shard hash(tenant_id) picked

Option B: tenant-tier-aware placement — give large tenants DEDICATED shards
  -- rather than relying purely on a hash function, explicitly route known
  -- high-volume tenants to shards reserved for them, and hash-shard the
  -- remaining 499 "normal" tenants together across the rest
```

**Option B is generally the more operationally common real-world fix** for this specific "one whale, many minnows" tenant-distribution shape — it acknowledges that automatic hashing can't reason about business-level skew it has no visibility into, and instead makes the skew an explicit, deliberately-designed placement decision (dedicated capacity for known-large tenants) rather than trying to force a generic hashing scheme to somehow self-correct for it.

**The general lesson:** a shard key needs to be evaluated against the **actual real-world distribution of load per key value**, not just "does this key have high cardinality" — high cardinality (many distinct tenant IDs) is necessary but not sufficient for even load distribution when the *volume per key* is itself highly skewed.
