# Database Design & Scaling

Database decisions are the hardest to reverse in a system design, and the questions here are asked precisely because they force a candidate to reason about tradeoffs instead of reciting a "best" technology. This topic covers SQL vs. NoSQL selection criteria, normalization vs. denormalization, how B-tree indexes actually work (and when they hurt), replication topologies and their consistency implications, sharding strategies and the rebalancing problem they create, and connection pooling.

## Folder structure

- **`theory/`** — SQL vs. NoSQL tradeoffs, normalization vs. denormalization, B-tree indexing mechanics, replication (master-slave, master-master), sharding strategies (range/hash/geo), the rebalancing problem, and connection pooling.
- **`snippets/`** — 6 practical examples: a normalized schema, a denormalized document, index creation with `EXPLAIN`, a replication config, a hash-based shard-key function, and a connection-pool config.
- **`output-based/`** — 5 "given this setup, what happens?" questions on index selection, replication lag, shard-key hotspots, failover behavior, and connection-pool exhaustion.
- **`scenarios/`** — 6 real-world design/fix scenarios: choosing SQL vs. NoSQL, sharding a multi-tenant SaaS, fixing replication lag, normalize-vs-denormalize for analytics, handling a failover incident, and diagnosing a slow query via indexing.
- **`interview-qa/`** — 4 themed Q&A files: SQL vs. NoSQL, indexing, replication/consistency, and sharding/pooling.
- **`problems/`** — 4 hands-on challenges: a social network schema, a time-series sharding scheme, an index strategy for a slow query, and a replication topology for a read-heavy app.
- **`assets/`** — placeholder for diagrams/images (see `assets/README.md`).

## What's covered

- SQL vs. NoSQL: what each is actually optimized for, and the concrete signals that should drive the choice — not a popularity contest
- Normalization (reducing redundancy, preserving update integrity) vs. denormalization (trading redundancy for read performance) and when each wins
- How B-tree indexes work mechanically, why they speed up equality/range lookups, and when an index actively hurts (write overhead, low-cardinality columns, unindexed leading columns in a composite index)
- Replication topologies (master-slave, master-master) and their direct consistency implications — replica lag, conflict resolution, failover
- Sharding strategies (range, hash, geo-based), and the rebalancing problem every sharding scheme eventually has to solve
- Connection pooling: why raw per-request connections don't scale, and how pool sizing interacts with database capacity
