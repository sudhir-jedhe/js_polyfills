# Scenario: Fix Replication Lag Causing Stale Reads in Production

**Scenario:** A ticket-booking platform routes all reads to a pool of 3 read replicas (round-robin, no lag-awareness) and all writes to the primary. Customer complaints spike during high-demand on-sale events: users report seeing a ticket as "available" moments after it was actually sold to someone else, leading to failed checkout attempts and frustration. Investigation shows replica lag climbs from a normal ~30ms to as much as **8 seconds** during these traffic spikes, because the replicas are under heavy read load at exactly the moment write volume (ticket purchases) is also spiking.

**Diagnosis:** This is a direct instance of the replication-lag output-based file's scenario, surfacing specifically under load — and it's compounded by a design mistake independent of the lag itself: **ticket availability is being read from a replica at all**, for a check that gates an actual purchase decision. This mirrors the fundamentals topic's inventory-at-checkout example almost exactly — availability-at-purchase-time is precisely the kind of read that needs strong consistency, not the eventual-consistency tolerance that's fine for, say, browsing a ticket listing page.

**Fix 1 (immediate, addresses the acute symptom) — route the specific "is this still available" check, at the moment of purchase, to the primary.** Not every ticket-related read needs this — browsing available shows/seating charts can stay on replicas (that data changes far less dynamically and tolerates a few seconds of staleness fine) — but the **final availability check immediately before confirming a purchase** must read from the primary, which is guaranteed to have the current, authoritative state.
```js
async function checkAvailabilityBeforePurchase(seatId) {
  // PRIMARY, not a replica — this gates an actual transaction
  return primaryPool.query('SELECT status FROM seats WHERE id = $1 FOR UPDATE', [seatId]);
}
async function browseAvailableSeats(showId) {
  // replica is fine — browsing tolerates a few seconds of staleness
  return replicaPool.query('SELECT * FROM seats WHERE show_id = $1', [showId]);
}
```

**Fix 2 (addresses the underlying purchase-confirmation correctness, beyond just where the pre-check reads from) — the actual seat reservation must be an atomic, conditional write, not just "check then write" as two separate steps.** Even reading from the primary, a naive "check availability, then separately write a purchase" is still racy if two users' purchase attempts interleave — the fix is the same atomic-claim pattern used in the fundamentals topic's driver-matching problem and the inventory-decrement examples elsewhere in this repo:
```sql
UPDATE seats SET status = 'sold', purchased_by = $1
WHERE id = $2 AND status = 'available';
-- check the AFFECTED ROW COUNT: 1 means this purchase won the race;
-- 0 means someone else's purchase already claimed it a moment earlier
```

**Fix 3 (addresses the root operational cause — why lag spiked to 8s in the first place) — the replicas are overloaded specifically *because* they're serving all read traffic including cacheable, non-urgent reads (browsing, historical order lookups) that don't need real-time replica freshness at all.** Introducing an application cache (per the caching-strategies topic) for genuinely cacheable reads (e.g., show listings, seating chart layouts that rarely change) reduces the read load hitting the replicas directly, which reduces replication lag under load as a side effect — the replicas spend less time processing read queries and can apply the replication stream faster.

**Verification:** after deploying Fixes 1 and 2, failed/oversold-ticket complaints stop immediately (correctness fixed regardless of lag). After Fix 3, monitoring shows replica lag during subsequent high-demand events staying within a much tighter band (well under 1 second even at peak), confirming the root operational cause was meaningfully addressed, not just worked around at the availability-check layer alone.
