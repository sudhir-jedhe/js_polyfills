# Scenario: Normalize vs. Denormalize a Schema for Analytics Reporting

**Scenario:** An e-commerce platform's core transactional schema is fully normalized (`orders`, `order_items`, `products`, `customers`, `categories` — 5+ tables). The data/analytics team needs to run reporting queries like "total revenue by category by month" and "top 20 customers by lifetime spend," and these queries — run against the normalized production schema directly — are both slow (multi-table joins over millions of rows) and, worse, are now competing for resources with the live transactional workload, occasionally causing checkout latency spikes when a heavy report runs.

**Diagnosis:** Two distinct problems are tangled together here: (1) the normalized schema is genuinely suboptimal for this *read pattern* (large aggregations across joined tables), and (2) analytical and transactional workloads are competing for the **same database resources**, which is a separate, structural problem that a schema change alone doesn't fix.

**Fix — don't denormalize the production transactional schema; build a separate denormalized reporting store instead.** This is the exact "normalized system of record, denormalized read model, kept in sync deliberately" pattern from the normalization-vs-denormalization theory file, applied at the scale of an entire reporting subsystem rather than a single cached document:

```
Production DB (normalized, OLTP)          Reporting DB (denormalized, OLAP)
  orders, order_items, products,   -->     fact_sales (one wide, flat row per
  customers, categories                     line-item: date, category, customer_id,
  [ live transactional workload,             customer_lifetime_value_bucket,
    checkout, order creation ]               revenue_cents, quantity, ... ]
                                             [ reporting/analytics queries run here,
                                               completely isolated from checkout traffic ]
```

**How the reporting store stays in sync — an ETL/streaming pipeline, not a live query against production:**
```
Order placed/updated in production --> published as an event (or captured via change-data-capture)
                                    --> a pipeline transforms and flattens it
                                    --> writes/upserts into fact_sales in the reporting DB
```
This can run on a schedule (e.g., hourly batch ETL — acceptable staleness for most business reporting, which rarely needs to-the-second freshness) or near-real-time via change-data-capture/streaming, depending on how fresh the reports actually need to be — a decision made explicitly based on the analytics team's real requirement, not defaulted to "as fast as possible."

**Why this solves both problems simultaneously:**
1. **Query performance:** `fact_sales` is a single flat table purpose-built for the exact aggregations needed ("revenue by category by month" becomes a `GROUP BY` over 2 columns on one table, no joins) — dramatically faster than the equivalent query against the normalized 5-table schema.
2. **Resource contention:** analytics queries now run entirely against a **physically separate database**, so even an expensive, poorly-optimized ad hoc report can no longer degrade checkout latency, regardless of how heavy it is — this is arguably the more important fix of the two, since even a perfectly-indexed normalized-schema query would still compete for the same CPU/IO/connections as live transactional traffic if run against the same instance.

**Bottleneck/tradeoff named explicitly:** the reporting data is now, by design, only as fresh as the ETL/streaming pipeline's lag (minutes to an hour, depending on the chosen approach) — an acceptable, deliberate tradeoff for business reporting, but this store should never be treated as a source of truth or used to gate any real-time transactional decision, which is the same "denormalized data is a read-optimized view, not the system of record" principle from the theory file, now scoped to an entire subsystem rather than one document.
