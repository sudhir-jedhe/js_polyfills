# Scenario: Diagnose and Fix a Slow Query via Indexing

**Scenario:** A support team's internal dashboard, showing "all open tickets assigned to me, sorted by priority then by age," has become unbearably slow — 4-6 seconds to load — as the `tickets` table has grown to several million rows. The query:

```sql
SELECT * FROM tickets
WHERE assigned_to = $1 AND status = 'open'
ORDER BY priority DESC, created_at ASC;
```

**Step 1 — don't guess; run `EXPLAIN ANALYZE` first, per the indexing snippet's methodology.**
```sql
EXPLAIN ANALYZE
SELECT * FROM tickets WHERE assigned_to = 42 AND status = 'open'
ORDER BY priority DESC, created_at ASC;

--                                    QUERY PLAN
-- Sort  (cost=98234.12..98240.55 rows=2571 width=180) (actual time=4821.334..4821.890 rows=38 loops=1)
--   Sort Key: priority DESC, created_at
--   ->  Seq Scan on tickets  (cost=0.00..97812.00 rows=2571 width=180)
--                            (actual time=0.031..4790.221 rows=38 loops=1)
--         Filter: ((assigned_to = 42) AND (status = 'open'))
--         Rows Removed by Filter: 3999962
```
Confirms two distinct costs stacked together: a **sequential scan** discarding ~4 million non-matching rows, followed by an **explicit sort** step on the small result set — both contributing to the total time, and both addressable.

**Step 2 — design the index to match the query's filter-then-sort shape exactly**, applying the composite-index reasoning from the schema/index output-based file:
```sql
CREATE INDEX idx_tickets_assigned_status_priority_created
ON tickets (assigned_to, status, priority DESC, created_at ASC);
```
- `assigned_to` and `status` as the leading columns satisfy the `WHERE` filter via the leftmost-prefix rule.
- `priority DESC, created_at ASC` as the trailing columns means, for a given `(assigned_to, status)` pair, the matching rows are **already stored in exactly the sort order the query needs** — the database can walk the index directly and skip the separate `Sort` step entirely, not just skip the sequential scan.

**Step 3 — re-run `EXPLAIN ANALYZE` to confirm both costs are actually gone, not just the scan:**
```sql
-- Index Scan using idx_tickets_assigned_status_priority_created on tickets
--   (cost=0.42..12.89 rows=38 width=180) (actual time=0.045..0.198 rows=38 loops=1)
--   Index Cond: ((assigned_to = 42) AND (status = 'open'))
-- Planning Time: 0.089 ms
-- Execution Time: 0.241 ms
```
No separate `Sort` node in the plan at all (confirming the index's column order eliminated it), and execution time drops from ~4,821ms to ~0.24ms — roughly a 20,000x improvement, driven by eliminating both the full scan *and* the sort in one purpose-built index.

**Step 4 — check the write-cost tradeoff before shipping, per the indexing theory file's explicit warning.** `tickets` is written to on every status change, priority change, and reassignment — a reasonably high-write table. The team checks: how many *other* indexes already exist on this table (3 others, all serving different, also-frequent query patterns), and estimates the added per-write overhead of a 4th index is acceptable given ticket status changes are not the platform's highest-frequency write path (nowhere near, say, a per-second event-ingestion table) — a judgment call made explicitly, not skipped.

**Step 5 — verify in production, not just in the query planner's estimate.** Dashboard load time monitoring confirms the p95 load time drops from ~5.2s to under 100ms after deployment, and write-latency monitoring on ticket updates shows no measurable regression, confirming the write-cost tradeoff assessment from Step 4 held up under real traffic.

**The interview point:** the fix required reading the `EXPLAIN` output precisely enough to identify **two separate costs** (scan + sort), and designing the index's column order specifically to eliminate both — a shallower answer ("just add an index on `assigned_to`") would have removed the scan but left the sort in place, a meaningfully smaller win than what a properly-ordered composite index achieves.
