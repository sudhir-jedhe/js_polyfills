# Snippet: A Normalized Relational Schema (Orders)

```sql
CREATE TABLE customers (
  id         SERIAL PRIMARY KEY,
  name       TEXT NOT NULL,
  email      TEXT NOT NULL UNIQUE,
  address    TEXT
);

CREATE TABLE products (
  id         SERIAL PRIMARY KEY,
  name       TEXT NOT NULL,
  price_cents INT NOT NULL
);

CREATE TABLE orders (
  id           SERIAL PRIMARY KEY,
  customer_id  INT NOT NULL REFERENCES customers(id),
  status       TEXT NOT NULL DEFAULT 'pending',
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE order_items (
  id         SERIAL PRIMARY KEY,
  order_id   INT NOT NULL REFERENCES orders(id),
  product_id INT NOT NULL REFERENCES products(id),
  quantity   INT NOT NULL,
  -- price is captured HERE, at order time, rather than joined live from `products` —
  -- a deliberate, small denormalization: an order's line-item price should reflect
  -- what the customer actually paid, not today's (possibly since-changed) product price
  unit_price_cents INT NOT NULL
);
```

**Fetching a full order requires joining across all four tables — the direct cost of normalization:**

```sql
SELECT
  o.id AS order_id, o.status, o.created_at,
  c.name AS customer_name, c.email AS customer_email,
  oi.quantity, oi.unit_price_cents, p.name AS product_name
FROM orders o
JOIN customers c ON c.id = o.customer_id
JOIN order_items oi ON oi.order_id = o.id
JOIN products p ON p.id = oi.product_id
WHERE o.id = 501;
```

**Why this is the right default for this data:** a customer's name/email is stored exactly once in `customers` — updating it (e.g., after an email change) automatically reflects correctly for every future join, with zero risk of some rows showing an old email and others a new one. The tradeoff (a 4-table join to render one order) is deliberately accepted here because `orders`/`order_items`/`customers` are the *system of record* — correctness and update integrity matter more than raw read speed for this specific data, per the normalization-vs-denormalization theory file's framing. A read-optimized, denormalized view built *from* this schema (see the companion denormalized-document snippet) is the appropriate place to trade that integrity for read speed, not this table structure itself.
