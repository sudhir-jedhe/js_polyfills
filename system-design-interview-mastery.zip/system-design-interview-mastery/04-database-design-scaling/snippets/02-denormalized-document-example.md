# Snippet: A Denormalized Document (Order Read-Model)

The same order data as the normalized-schema snippet, reshaped as a single denormalized document — the kind of read-optimized view you'd cache, store in a document database, or materialize as a search-index entry.

```json
{
  "orderId": 501,
  "status": "pending",
  "createdAt": "2026-08-20T14:32:00Z",
  "customer": {
    "id": 42,
    "name": "Jordan Lee",
    "email": "jordan@example.com"
  },
  "items": [
    {
      "productId": 9,
      "productName": "Wireless Mouse",
      "quantity": 2,
      "unitPriceCents": 2499
    },
    {
      "productId": 14,
      "productName": "USB-C Hub",
      "quantity": 1,
      "unitPriceCents": 3999
    }
  ],
  "totalCents": 8997
}
```

**Fetching this requires zero joins** — a single lookup by `orderId` returns everything needed to render an order confirmation page or a customer support view, dramatically faster than the 4-table join in the normalized version, especially at read volumes where join cost compounds.

**How this document gets built and kept in sync — the write-side cost denormalization always introduces:**
```js
// built once at order-creation time from the normalized tables, then written
// to a document store / cache as the read-optimized view
async function buildOrderDocument(orderId) {
  const order = await sql.getOrderWithItemsAndCustomer(orderId); // the 4-table join, run ONCE
  const document = {
    orderId: order.id,
    status: order.status,
    createdAt: order.createdAt,
    customer: { id: order.customerId, name: order.customerName, email: order.customerEmail },
    items: order.items.map(i => ({
      productId: i.productId, productName: i.productName,
      quantity: i.quantity, unitPriceCents: i.unitPriceCents,
    })),
    totalCents: order.items.reduce((sum, i) => sum + i.quantity * i.unitPriceCents, 0),
  };
  await documentStore.set(`order:${orderId}`, document);
  return document;
}
```

**The deliberate tradeoff made explicit:** `customer.name` and `customer.email` are frozen into this document at build time — if the customer later changes their email, this document does **not** automatically update (a background job or event-driven rebuild would be needed to refresh it, if that's even desired — see the normalization theory file's point that this "staleness" is often the *correct* point-in-time-snapshot behavior for an order record, not a bug to be fixed).
