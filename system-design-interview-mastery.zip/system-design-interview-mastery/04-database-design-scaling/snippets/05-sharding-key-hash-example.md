# Snippet: Hash-Based Sharding, Including a Consistent-Hashing Router

**Naive modulo-hash sharding (works, but rebalances badly — see the rebalancing theory file):**
```js
function getShardModulo(userId, numShards) {
  const hash = simpleHash(String(userId));
  return hash % numShards; // adding/removing a shard reshuffles almost everything
}
```

**Consistent-hashing router (minimizes data movement when shard count changes):**
```js
const crypto = require('crypto');

class ConsistentHashRing {
  constructor(shards, virtualNodesPerShard = 100) {
    this.ring = []; // sorted array of { position, shardId }
    for (const shardId of shards) {
      for (let v = 0; v < virtualNodesPerShard; v++) {
        const position = this.hashToInt(`${shardId}:vnode:${v}`);
        this.ring.push({ position, shardId });
      }
    }
    this.ring.sort((a, b) => a.position - b.position);
  }

  hashToInt(key) {
    const hash = crypto.createHash('md5').update(key).digest('hex');
    return parseInt(hash.slice(0, 8), 16); // first 32 bits as the ring position
  }

  getShard(key) {
    const keyPosition = this.hashToInt(key);
    // find the first virtual node clockwise from the key's position
    for (const node of this.ring) {
      if (node.position >= keyPosition) return node.shardId;
    }
    return this.ring[0].shardId; // wrap around the ring
  }
}

// usage
const ring = new ConsistentHashRing(['shard-a', 'shard-b', 'shard-c', 'shard-d']);
const targetShard = ring.getShard(`user:42`);

async function getUser(userId) {
  const shard = ring.getShard(`user:${userId}`);
  return shardConnections[shard].query('SELECT * FROM users WHERE id = $1', [userId]);
}
```

**Adding a shard — demonstrating minimal data movement:**
```js
const ringBefore = new ConsistentHashRing(['shard-a', 'shard-b', 'shard-c', 'shard-d']);
const ringAfter  = new ConsistentHashRing(['shard-a', 'shard-b', 'shard-c', 'shard-d', 'shard-e']);

// only keys whose ring position now falls into shard-e's newly-claimed
// arc actually need to move — roughly 1/5th of the total keyspace,
// NOT a near-total reshuffle the way `hash(key) % 4` -> `hash(key) % 5` would cause
for (const userId of allUserIds) {
  const before = ringBefore.getShard(`user:${userId}`);
  const after  = ringAfter.getShard(`user:${userId}`);
  if (before !== after) migrateKey(userId, before, after);
}
```
