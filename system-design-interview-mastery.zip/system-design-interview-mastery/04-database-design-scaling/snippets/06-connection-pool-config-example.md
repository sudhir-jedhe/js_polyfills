# Snippet: Connection Pool Configuration (Node `pg` + PgBouncer)

**Naive, unpooled connection-per-request (the anti-pattern):**
```js
// BAD: opens and closes a fresh TCP connection + auth handshake on EVERY request —
// pays connection-setup latency every time, and N concurrent requests means
// N simultaneous raw connections to the database, with no cap
app.get('/orders/:id', async (req, res) => {
  const client = new Client({ host: 'db.internal', /* ... */ });
  await client.connect();
  const result = await client.query('SELECT * FROM orders WHERE id = $1', [req.params.id]);
  await client.end();
  res.json(result.rows[0]);
});
```

**In-process connection pool (the standard fix at the application level):**
```js
const { Pool } = require('pg');

const pool = new Pool({
  host: 'db.internal',
  max: 20,               // this instance holds at most 20 connections open at once
  idleTimeoutMillis: 30000,     // close an idle connection after 30s of no use
  connectionTimeoutMillis: 2000, // fail fast if no connection is available within 2s,
                                  // rather than queuing requests indefinitely
});

app.get('/orders/:id', async (req, res) => {
  // borrows an already-open connection from the pool; returns it when done
  const result = await pool.query('SELECT * FROM orders WHERE id = $1', [req.params.id]);
  res.json(result.rows[0]);
});
```
With 20 app server instances each running `max: 20`, the database sees up to `20 × 20 = 400` connections at peak — worth explicitly calculating, since it's easy for this number to creep past the database's actual connection ceiling as the fleet scales horizontally.

**External pooler (PgBouncer) — decouples app-fleet scaling from the database's connection ceiling:**
```ini
; pgbouncer.ini
[databases]
orders_db = host=db.internal port=5432 dbname=orders

[pgbouncer]
listen_port = 6432
pool_mode = transaction   ; connections are returned to the pool after each transaction,
                           ; not held for a client's whole session — allows much higher
                           ; effective multiplexing of app connections onto fewer real ones
default_pool_size = 25    ; PgBouncer maintains only 25 REAL connections to Postgres,
                           ; regardless of how many app-side connections it's serving
max_client_conn = 1000    ; but can accept up to 1000 app-side connections
```
```js
// app now points at PgBouncer's port, not the database directly —
// app fleet can scale to any size; PgBouncer keeps the REAL database
// connection count fixed at default_pool_size (25), regardless
const pool = new Pool({ host: 'pgbouncer.internal', port: 6432, max: 20 });
```

**Why `pool_mode = transaction` matters specifically:** it lets PgBouncer serve many more app-side logical connections than real database connections, since a real connection is only "checked out" for the duration of a single transaction rather than an entire client session — the tradeoff is that session-level features requiring a persistent connection (e.g., session-scoped temp tables, `LISTEN`/`NOTIFY` held open) don't work correctly under this mode and need `pool_mode = session` instead for the specific connections that need them.
