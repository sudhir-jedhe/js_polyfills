# Snippet: PostgreSQL Master-Slave Replication Config

**Primary (`postgresql.conf`) — enable write-ahead-log-based streaming replication:**
```conf
wal_level = replica
max_wal_senders = 10          # max number of concurrent replica connections
wal_keep_size = 1GB           # WAL retained on primary for replicas to catch up from
synchronous_commit = on       # see synchronous vs async note below
```

**Primary (`pg_hba.conf`) — allow the replica to connect for replication:**
```conf
host replication replicator 10.0.2.0/24 scram-sha-256
```

**Replica setup (run once, on the replica host, to bootstrap from the primary):**
```bash
pg_basebackup -h primary.internal -D /var/lib/postgresql/data -U replicator -P --wal-method=stream
```

**Replica (`postgresql.conf`):**
```conf
hot_standby = on              # allow read-only queries while replicating
```

**Application-level read/write routing (a simplified connection router):**
```js
const writePool = new Pool({ host: 'primary.internal', ...baseConfig });
const readPool  = new Pool({ host: 'replica.internal',  ...baseConfig });

async function getOrder(orderId) {
  // routine reads go to the replica — offloads the primary
  return readPool.query('SELECT * FROM orders WHERE id = $1', [orderId]);
}

async function createOrder(order) {
  // all writes MUST go to the primary — replicas are read-only
  return writePool.query('INSERT INTO orders (...) VALUES (...)', [...]);
}

async function getOrderImmediatelyAfterWrite(orderId) {
  // read-your-writes: route to the PRIMARY specifically right after this
  // user's own write, since the replica might not have caught up yet
  // (see the fundamentals topic's consistency-models theory file)
  return writePool.query('SELECT * FROM orders WHERE id = $1', [orderId]);
}
```

**Checking replication lag (a critical operational metric):**
```sql
-- run on the PRIMARY — shows how far behind each connected replica is
SELECT client_addr, state,
       pg_wal_lsn_diff(pg_current_wal_lsn(), replay_lsn) AS lag_bytes
FROM pg_stat_replication;
```

**Synchronous vs. asynchronous, illustrated via one config line:**
```conf
# ASYNCHRONOUS (default) — primary acknowledges the write without waiting
# for the replica; lower latency, but the replica can lag, and a primary
# crash can lose the most recent un-replicated writes.
synchronous_standby_names = ''

# SYNCHRONOUS — primary waits for at least one named replica to confirm
# before acknowledging the write to the client; guarantees the replica
# is never behind by even one committed transaction, at the cost of
# write latency (and write availability if that replica is unreachable).
synchronous_standby_names = 'replica_a'
```
