# Snippet: Index Creation and Reading an EXPLAIN Plan (PostgreSQL)

**Before indexing — a full table scan:**
```sql
EXPLAIN ANALYZE
SELECT * FROM orders WHERE customer_id = 42;

--                                    QUERY PLAN
-- Seq Scan on orders  (cost=0.00..18425.00 rows=52 width=64)
--                     (actual time=0.045..142.891 rows=48 loops=1)
--   Filter: (customer_id = 42)
--   Rows Removed by Filter: 999952
-- Planning Time: 0.112 ms
-- Execution Time: 142.937 ms
```
`Seq Scan` (sequential scan) means Postgres read all ~1,000,000 rows and discarded ~999,952 of them to find the 48 matching rows — the `142ms` execution time and `Rows Removed by Filter: 999952` line are the two smoking guns that an index would help here.

**Adding an index:**
```sql
CREATE INDEX idx_orders_customer_id ON orders (customer_id);
```

**After indexing — the same query, now using the index:**
```sql
EXPLAIN ANALYZE
SELECT * FROM orders WHERE customer_id = 42;

--                                    QUERY PLAN
-- Index Scan using idx_orders_customer_id on orders
--   (cost=0.42..8.95 rows=52 width=64)
--   (actual time=0.021..0.089 rows=48 loops=1)
--   Index Cond: (customer_id = 42)
-- Planning Time: 0.098 ms
-- Execution Time: 0.114 ms
```
`Index Scan` confirms the planner used the new index; execution time drops from ~143ms to ~0.1ms — roughly a 1,250x improvement, driven entirely by no longer scanning the ~999,952 non-matching rows.

**A composite index, illustrating the leftmost-prefix rule from the theory file:**
```sql
CREATE INDEX idx_orders_customer_status ON orders (customer_id, status);

-- USES the index (customer_id is the leftmost column):
EXPLAIN SELECT * FROM orders WHERE customer_id = 42 AND status = 'shipped';
--  Index Scan using idx_orders_customer_status ...

-- DOES NOT effectively use this index (status alone, without customer_id, skips the leftmost column):
EXPLAIN SELECT * FROM orders WHERE status = 'shipped';
--  Seq Scan on orders ...   <- falls back to a full scan, or uses a DIFFERENT index on `status` alone, if one exists
```

**Checking existing indexes and their write-cost tradeoff (illustrative — real overhead varies by workload):**
```sql
SELECT indexname, indexdef FROM pg_indexes WHERE tablename = 'orders';

-- Reminder from the theory file: EVERY index added here is also extra work
-- on every INSERT/UPDATE/DELETE touching `orders` — index count is a direct
-- write-latency cost, not a free correctness improvement.
```
