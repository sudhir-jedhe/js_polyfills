# Sharding Strategies: Range, Hash, and Geo-Based

Sharding (horizontal partitioning) splits a dataset **across multiple database instances**, each holding a subset of the data — the mechanism that lets the *write* path scale horizontally, unlike replication (which scales reads by copying the *same* full dataset everywhere). This is the database-scaling technique referenced throughout this repo whenever a design needs to scale past a single primary's write capacity.

## Range-based sharding

Partition by ranges of the shard key's value — e.g., users with IDs 1-1,000,000 on Shard A, 1,000,001-2,000,000 on Shard B.

```
Shard A: user_id 1 - 1,000,000
Shard B: user_id 1,000,001 - 2,000,000
Shard C: user_id 2,000,001 - 3,000,000
```

- **Pro:** range queries (`WHERE user_id BETWEEN 500 AND 600`) can often be satisfied by a single shard, since ranges are contiguous — efficient for range-scan-heavy workloads.
- **Con:** **hotspotting** — if IDs (or whatever the shard key is) are assigned sequentially and recent data is accessed far more than old data (a very common pattern — think "recently created accounts are more active"), the most-recently-created shard absorbs a disproportionate share of traffic while older shards sit comparatively idle.

## Hash-based sharding

Apply a hash function to the shard key and use the hash to determine the shard — e.g., `shard = hash(user_id) % num_shards`.

```
hash(user_id=42)    % 4 shards  --> Shard 2
hash(user_id=43)    % 4 shards  --> Shard 0
hash(user_id=100042) % 4 shards --> Shard 1
```

- **Pro:** distributes load much more evenly than range-based, since a good hash function scatters sequential/related keys across shards essentially at random — directly solves range-based sharding's hotspot problem.
- **Con:** range queries become expensive — a query needing a range of IDs likely has to hit **every shard** (since consecutive IDs hash to unrelated shards) and merge results, losing the single-shard-satisfies-a-range-query benefit range sharding had.

## Geo-based sharding

Partition by a geographic attribute (region, country) — e.g., European users' data lives on a shard physically located in an EU datacenter, US users' data in a US datacenter.

- **Pro:** lower latency for users (data lives physically closer to them) and can directly help satisfy data-residency/regulatory requirements (e.g., GDPR-driven requirements that EU user data stay within the EU).
- **Con:** load is only as balanced as the underlying geographic distribution of users — if the product has a heavily skewed user base (e.g., 80% US), the US shard becomes a de facto hotspot regardless of the sharding scheme's mechanics; also complicates any cross-region query or feature (e.g., a global leaderboard spanning all users).

## Comparison table

| Strategy | Even load distribution | Range query efficiency | Common failure mode | Best fit |
|---|---|---|---|---|
| Range | Poor (hotspots on sequential/recent keys) | Excellent (contiguous) | "Hot" newest shard | Time-series data queried by range, if hotspotting is separately mitigated |
| Hash | Excellent | Poor (fans out to all shards) | Range queries becoming full-cluster scans | General-purpose, point-lookup-dominant workloads |
| Geo | Depends on user distribution | N/A (orthogonal concern) | Skewed geography creates its own hotspot | Regulatory/latency-driven needs, not primarily a load-balancing tool |

## A hybrid worth naming: hashed prefix on an otherwise-range-friendly key

A common real-world compromise for time-series-like data: shard by `hash(some_id) `at the top level to spread load evenly, but within each shard, keep data **sorted by timestamp** so range queries scoped to a single known entity (e.g., "this user's messages between two dates") remain efficient — combining hash sharding's load-distribution benefit with range sharding's benefit for queries that are naturally scoped to one shard anyway (because they're already filtered to one entity's data, which a good shard key choice — e.g., `hash(user_id)`, not `hash(message_id)` — keeps colocated).

## The interview answer

Name the shard key candidate explicitly and reason about it against the **actual query patterns** the system needs to serve well — a shard key that makes writes evenly distributed but forces every read to fan out across all shards is often a worse tradeoff than it looks on paper, especially at high read volume. This decision should always be paired with a discussion of the rebalancing problem it creates (see the dedicated rebalancing theory file) — sharding strategy and rebalancing strategy aren't separable decisions.
