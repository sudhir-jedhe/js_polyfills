# SQL vs. NoSQL Tradeoffs

This is one of the most-asked, and most-frequently-hand-waved, questions in system design interviews. "NoSQL scales better" is not a sufficient answer — both categories can scale; they're optimized for different access patterns and different consistency/flexibility tradeoffs.

## What "SQL" actually commits you to

A relational database (Postgres, MySQL) stores data in tables with a fixed schema, enforces relationships via foreign keys, and provides **ACID transactions** — Atomicity, Consistency, Isolation, Durability — across arbitrary sets of rows and tables in a single operation. It's built around the assumption that data has structure worth enforcing, and that multi-row/multi-table operations need to succeed or fail as a unit.

## What "NoSQL" actually means (it's not one thing)

"NoSQL" is an umbrella covering several genuinely different data models, each suited to different problems:

| NoSQL category | Data model | Example systems | Best fit |
|---|---|---|---|
| Document | Schema-flexible JSON-like documents | MongoDB, Couchbase | Semi-structured data with varying shape per record, rapid iteration on schema |
| Key-value | Simple key → opaque value | Redis, DynamoDB (as KV) | Extremely fast lookups by a single known key, caching, session storage |
| Wide-column | Rows with dynamic, sparse columns, optimized for huge scale | Cassandra, HBase | Very high write throughput, time-series data, huge datasets spread across many nodes |
| Graph | Nodes and edges, optimized for relationship traversal | Neo4j | Deeply relational, traversal-heavy queries (social graphs, recommendation paths) |

## The comparison that actually matters

| Dimension | SQL (relational) | NoSQL (varies by category, generalized) |
|---|---|---|
| Schema | Fixed, enforced at write time | Flexible/schema-less (document), or minimal (key-value, wide-column) |
| Transactions | Full ACID across tables, standard | Often limited to single-document/single-row atomicity; multi-document transactions are newer/weaker where they exist at all |
| Relationships | First-class (foreign keys, joins) | Typically denormalized/embedded instead of joined; some (graph) make relationships first-class instead |
| Horizontal write scaling | Harder — requires deliberate sharding | Often designed for horizontal scale from the ground up (especially wide-column, key-value) |
| Query flexibility | Very high — arbitrary joins, aggregations via SQL | Lower, especially for ad hoc queries not matching the access pattern the schema was designed around |
| Consistency default | Strong (within a single node/cluster) | Varies — often tunable, frequently defaults to eventual consistency in distributed deployments |

## The actual decision framework

Ask, in order:

1. **Does the data have real, enforceable relational structure, and does correctness depend on transactions spanning multiple rows/tables?** (e.g., a bank transfer touching two account rows atomically) → lean SQL.
2. **Is the access pattern known and narrow (mostly "fetch this whole object by its ID"), with a data shape that varies per record or evolves rapidly?** → lean document NoSQL.
3. **Is the dominant requirement raw write throughput and horizontal scale over a huge, mostly-independent dataset (e.g., IoT sensor readings, time-series metrics)?** → lean wide-column NoSQL.
4. **Is the core query pattern relationship-traversal itself (e.g., "friends of friends who like X")?** → lean graph.
5. **Is it a simple, high-speed lookup-by-key with no relational structure at all** (a session, a cache)? → lean key-value.

## The interview answer

Never say "NoSQL for scale, SQL for consistency" as a blanket rule — modern relational databases scale substantially (read replicas, partitioning, and yes, sharding, covered in this topic's other theory files) and many NoSQL systems offer tunable consistency. The strong answer names the **actual access pattern and correctness requirement of the specific data**, the same "per-feature reasoning" principle used throughout this repo — a single real system frequently uses both: Postgres for orders/payments (transactional integrity matters), and a document store or key-value cache for product catalog browsing or session data (flexible shape, simple lookup, less transactional need).
