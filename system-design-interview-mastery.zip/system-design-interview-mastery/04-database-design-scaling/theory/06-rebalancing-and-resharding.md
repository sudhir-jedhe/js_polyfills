# The Rebalancing Problem

Choosing a sharding strategy is only half the problem — the harder, more interview-differentiating half is what happens when the number of shards needs to **change**: a shard outgrows its capacity, or the cluster needs to scale from 4 shards to 8. This is the "rebalancing" or "resharding" problem, and it's where naive sharding schemes fall apart.

## Why naive modulo-hash sharding rebalances catastrophically

```
shard = hash(key) % num_shards
```

If `num_shards` changes from 4 to 5, the modulo result for **almost every key** changes — `hash(key) % 4` and `hash(key) % 5` agree for only a small fraction of keys by pure chance. This means adding a single shard to a 4-shard cluster using plain modulo hashing requires **moving almost the entire dataset** to new shards, not just a proportional 1/5th of it — an enormous, disruptive, and risky operation for what should be an incremental capacity change.

## Consistent hashing — the standard fix

Consistent hashing maps both shards and keys onto the same conceptual **ring** (a fixed circular hash space, e.g., 0 to 2^32-1). Each shard owns the portion of the ring between itself and the next shard clockwise; a key belongs to whichever shard is the next one found walking clockwise from the key's hash position.

```
        Shard A (hash position 10)
       /                          \
Shard D (270)                  Shard B (90)
       \                          /
        Shard C (180)------------

Key with hash(key) = 150 belongs to Shard C (the next shard clockwise from 150).
```

**Why this minimizes data movement on rebalancing:** adding a new shard only requires moving the keys that fall between the new shard's ring position and its immediate counter-clockwise neighbor — **not** the entire dataset. Roughly, adding a shard to an N-shard cluster only moves about `1/(N+1)` of the total data, a dramatic improvement over plain modulo hashing's near-total reshuffle.

**Virtual nodes (a refinement worth naming):** placing each physical shard at multiple, scattered positions on the ring (rather than one) smooths out load distribution further — a single physical shard being unlucky enough to own an unusually large arc of the ring (and thus a disproportionate share of keys) becomes far less likely when its ownership is spread across many small virtual-node positions instead of one large contiguous one.

## The rebalancing process itself, at a high level

1. **Determine the new key-to-shard mapping** (via consistent hashing, or an explicit range-reassignment for range-sharded data).
2. **Copy the affected data** to its new shard location — typically done as a background, low-priority process to avoid degrading live traffic.
3. **Dual-write or a cutover mechanism** during the transition window — writes to a key that's mid-migration need to land correctly regardless of which shard currently "owns" it from the client's perspective, usually handled by a routing layer that knows both the old and new mapping during the migration window.
4. **Cut over reads** to the new shard once migration for that key range is confirmed complete, and clean up the now-redundant copy on the old shard.

## Range-sharded rebalancing (a different, sometimes simpler mechanism)

For range-based sharding, rebalancing is often handled by **splitting** an overloaded range into two (e.g., a shard holding IDs 1-1,000,000 that's grown too large splits into two shards, each holding half that range) rather than remapping the entire keyspace — many range-sharded systems (e.g., many managed NoSQL wide-column stores) automate this splitting process transparently, which is one of range sharding's practical advantages despite its hotspotting downside noted in the sharding-strategies file.

## The interview answer

Rebalancing should be raised **proactively**, not just when asked — proposing a sharding scheme without acknowledging that the shard count will eventually need to change, and how much data movement that requires, is an incomplete answer. Naming consistent hashing (and ideally virtual nodes) as the standard mitigation for hash-sharded systems specifically, and contrasting it with the disruptive alternative (plain modulo hashing), is a strong, concrete signal of depth on this topic.
