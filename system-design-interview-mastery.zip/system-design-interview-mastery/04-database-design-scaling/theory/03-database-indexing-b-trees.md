# Database Indexing: How B-Tree Indexes Work

An index is the single highest-leverage, most commonly under-explained tool for query performance — interviewers specifically probe whether a candidate understands *why* an index helps, not just that "adding an index makes it faster."

## The problem an index solves

Without an index, finding rows matching a condition (`WHERE email = 'x@y.com'`) requires a **full table scan** — reading every row and checking the condition, `O(n)` in the number of rows. An index is a separate, ordered data structure that lets the database jump directly to matching rows without scanning everything.

## How a B-tree index works, mechanically

A B-tree (balanced tree, specifically usually a B+ tree in real database implementations) organizes indexed values in **sorted order**, in a tree structure where:

- Each node holds multiple sorted keys and pointers to child nodes (not just 2 children like a binary tree — a B-tree is wide/shallow, not narrow/deep, minimizing the number of disk reads needed to reach a leaf).
- Leaf nodes contain the actual pointers to the table rows (or, in a "clustered index," the leaf nodes ARE the table rows themselves, physically sorted in index order).
- Leaf nodes are also linked to each other (typically as a linked list), so a **range scan** (`WHERE price BETWEEN 10 AND 50`) can find the starting point via a tree traversal, then walk linearly across leaves without re-traversing the tree for each value.

```
Searching for email = 'm@x.com' in a B-tree index:

                [ f | m | t ]              <- root: which branch has 'm'?
               /    |    |   \
        [...] [ j|l ] [ n|p ] [...]        <- narrow down further
                 |
            [ ...m@x.com... ]              <- leaf: found, pointer to the actual row

Instead of scanning ALL rows (O(n)), the tree's height (typically 3-4 levels even
for millions of rows, since each node holds many keys) means this lookup takes
O(log n) comparisons — a huge difference at scale (log₂(1,000,000) ≈ 20 vs. 1,000,000).
```

## Why this makes equality AND range queries fast, but not everything

- **Equality (`WHERE email = 'x'`)** and **range (`WHERE created_at > '2026-01-01'`)** queries are exactly what a B-tree is built for — sorted order means both a specific value and a contiguous range are found via the same tree-traversal-then-linear-leaf-walk mechanism.
- **An index does NOT help** for a condition that can't exploit sort order on the indexed column — e.g., `WHERE UPPER(email) = 'X@Y.COM'` (a function applied to the column defeats the index unless a matching *functional* index exists), or a `LIKE '%something%'` pattern with a leading wildcard (no way to binary-search for "contains" — a trailing wildcard, `LIKE 'abc%'`, CAN use the index, since that's still a sorted-range lookup).

## Composite (multi-column) indexes and the leftmost-prefix rule

An index on `(last_name, first_name)` is sorted first by `last_name`, then by `first_name` **within** each `last_name`. This means:

- A query filtering on `last_name` alone, or `last_name AND first_name` together, **can** use this index.
- A query filtering on `first_name` **alone** (without `last_name`) generally **cannot** use this index efficiently — the data isn't sorted by `first_name` globally, only within each `last_name` group, so there's no way to binary-search directly to a `first_name` value across the whole table. This is the "leftmost prefix rule" — a composite index can only be used starting from its leftmost column(s).

## When an index actively hurts

- **Write overhead:** every `INSERT`/`UPDATE`/`DELETE` must also update every index on the affected columns — a table with 10 indexes pays that update cost 10 times on every write. Indexes are a **read-speed-for-write-speed** tradeoff, not a free win.
- **Low-cardinality columns** (e.g., a boolean `is_active` column with only 2 possible values): an index here often doesn't help much, because the database's query planner may reasonably decide a full scan is cheaper than jumping through an index that still matches, say, 40% of all rows — an index is most valuable when it narrows the result set down to a small fraction of the table.
- **Storage cost:** every index is a separate structure taking its own disk space, sometimes comparable in size to the table itself for a wide index.

## The interview answer

State the mechanism (sorted tree structure enabling `O(log n)` lookups and efficient range scans) rather than just "indexes make it faster," and proactively name the tradeoff (write overhead, storage, the leftmost-prefix rule for composite indexes) — this combination is what distinguishes genuine understanding from a memorized fact.
