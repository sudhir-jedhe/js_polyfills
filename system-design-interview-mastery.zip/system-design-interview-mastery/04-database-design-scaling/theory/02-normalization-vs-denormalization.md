# Normalization vs. Denormalization

Both are legitimate schema design strategies — the interview mistake is treating normalization as simply "correct" and denormalization as "a shortcut." Each optimizes for a different failure mode.

## Normalization

Organizing data to **eliminate redundancy**, typically by splitting data into multiple related tables connected by foreign keys, following a series of "normal forms" (1NF, 2NF, 3NF being the practically relevant ones). The core idea: each fact is stored **exactly once**.

```sql
-- Normalized: an order's customer info is stored ONCE in `customers`,
-- referenced by foreign key — never duplicated per order
CREATE TABLE customers (id, name, email, address);
CREATE TABLE orders (id, customer_id REFERENCES customers(id), total, created_at);
CREATE TABLE order_items (id, order_id REFERENCES orders(id), product_id, quantity, price);
```

- **Pro:** no update anomalies — changing a customer's address updates exactly one row, and every order automatically reflects it on the next join; no risk of some orders showing the old address and others the new one.
- **Con:** reading a full "order with customer and items" view requires **joining across 3 tables** — more query complexity, and joins have a real performance cost that grows with data volume and join count.

## Denormalization

Deliberately **duplicating data** to avoid joins at read time, trading storage space and write complexity for read speed.

```sql
-- Denormalized: customer name/email duplicated directly onto each order row
CREATE TABLE orders (
  id, customer_id, customer_name, customer_email,  -- duplicated from customers
  total, created_at
);
```

- **Pro:** reading an order requires no join at all — a single-table lookup, which is dramatically faster at scale, especially when this is the dominant, high-frequency read pattern.
- **Con:** an **update anomaly risk** reappears — if a customer changes their email, every order row that duplicated the old email must also be updated (or a background job accepts they'll drift, since it's often acceptable for an order to preserve the email *as of when it was placed*, which is sometimes actually the *correct* business behavior, not a bug).

## The key reframe: denormalization is a read-optimization, and the "staleness" it introduces is often actually desirable

The order example above is a good illustration of a subtlety often missed: a denormalized `customer_email` on an order isn't necessarily "stale data that should be fixed" — for many businesses, an order record is supposed to be a **point-in-time snapshot** of who bought what, at what price, shipped where — and letting historical orders update their customer email retroactively when the customer changes it later would actually be *incorrect* from a business/audit perspective. Denormalization sometimes accidentally implements the *correct* semantics, not just a performance hack.

## Comparison table

| Dimension | Normalized | Denormalized |
|---|---|---|
| Data redundancy | Minimal | Deliberate duplication |
| Update integrity | Strong (single source of truth per fact) | Requires explicit propagation logic, or acceptance of point-in-time snapshots |
| Read performance | Slower (joins) | Faster (single-table reads) |
| Write complexity | Simpler (write once) | More complex (write to multiple places, or accept eventual sync) |
| Storage | Lower | Higher |
| Best fit | Write-heavy, correctness-critical, relationship-rich data (e.g., core transactional records) | Read-heavy, latency-sensitive views; analytical/reporting tables; caching layers |

## The interview answer

Frame the decision around **the dominant access pattern and how costly an update anomaly would actually be**: normalize the system of record for transactional data where correctness and update integrity matter (the actual `customers`, `orders`, `order_items` tables), and denormalize specifically for read-optimized views built *from* that system of record — a search index, a reporting/analytics table, a cache — rather than treating denormalization as replacing normalization system-wide. This is the same pattern as a materialized view or a CQRS-style read model: normalized write model, denormalized read model, kept in sync deliberately (event-based, or a scheduled ETL).
