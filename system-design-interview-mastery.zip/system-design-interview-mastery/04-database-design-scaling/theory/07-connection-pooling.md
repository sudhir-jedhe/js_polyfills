# Connection Pooling

A small, unglamorous piece of infrastructure that shows up as a real production bottleneck surprisingly often — and is a favorite "what's actually going wrong here" detail for interviewers to probe, precisely because it's easy to overlook.

## The problem: opening a database connection is expensive

Establishing a new database connection isn't free — it involves a TCP handshake, authentication, and (for some databases) session/resource setup on the server side, typically costing single-digit to tens of milliseconds. If every incoming application request opens a **brand-new** database connection, does one query, and closes it, that per-request connection overhead can dominate total request latency, especially for otherwise-fast queries.

## The problem: a database has a hard limit on concurrent connections

Every database has a maximum number of concurrent connections it can support (Postgres defaults are often in the low hundreds, tunable but not unlimited — each open connection consumes real server memory and resources). If N application server instances each independently open, say, 50 raw connections at peak, and there are 20 instances, that's 1,000 connections — likely exceeding the database's limit, causing new connection attempts to fail or queue, well before the database's actual query-processing capacity is anywhere near exhausted. **The bottleneck in this failure mode is connection count, not query throughput.**

## The fix: a connection pool

A pool of already-established, reusable connections is maintained (either within each application process, or via an external pooler like PgBouncer sitting between the app and the database) — the application **borrows** a connection from the pool to run a query and **returns** it when done, rather than opening/closing a connection per request.

```
App request 1 --> borrow connection from pool --> run query --> return connection to pool
App request 2 --> borrow connection from pool --> run query --> return connection to pool
                        (same underlying pooled connections reused across many requests)
```

- **Eliminates most per-request connection-setup overhead**, since connections are established once and reused many times.
- **Caps the total number of connections** the database actually has to maintain, since the pool size is a fixed, deliberately-chosen number, regardless of how many concurrent application requests are in flight (requests beyond the pool's capacity queue for a connection to free up, rather than each opening a new one).

## Sizing a connection pool — not "as large as possible"

A larger pool is not simply better — each pooled connection still consumes real database-side memory and resources even when idle, and past a certain point, more concurrent connections **hurt** throughput (more contention for the database's own internal resources — CPU, lock contention, buffer cache) rather than helping. A commonly cited starting-point heuristic (not a universal law) ties pool size to available CPU cores and disk parallelism on the database server, since beyond that point queries queue for CPU time regardless of how many connections are technically available to hand out. In practice, pool size is tuned empirically against real load testing, not derived from a single formula.

## External pooler (e.g., PgBouncer) vs. in-process pooling

- **In-process pooling** (a pool per application server instance) is simpler to set up but means the *effective* total connection count the database sees is `(pool size per instance) × (number of app instances)` — which can still balloon as the app fleet scales horizontally, even if each individual instance's pool looks modest.
- **An external pooler** sitting between the app fleet and the database can multiplex a much larger number of application-side "logical" connections onto a smaller, fixed number of *actual* database connections — decoupling the app fleet's horizontal scaling from the database's hard connection-count ceiling, which is exactly the pattern used in the fundamentals topic's monolith-scaling scenario (PgBouncer as the first, cheapest fix before reaching for read replicas or sharding).

## The interview answer

Connection exhaustion is a concrete, correct answer to "what's the first thing likely to break as we scale the app tier horizontally" — it's cheap to explain, cheap to fix, and is exactly the kind of unglamorous-but-real detail that separates a candidate who's operated a production database from one who's only designed on a whiteboard.
