# Database Replication: Master-Slave and Master-Master

Replication — maintaining multiple copies of the same data across different database nodes — is how a database achieves both read scaling and fault tolerance. The topology chosen has direct, unavoidable consistency implications, which is exactly why this topic sits downstream of the CAP theorem and consistency-models theory in the fundamentals topic.

## Master-slave (primary-replica) replication

One node (the **primary**/master) accepts all writes; one or more **replicas** (slaves) receive a continuous stream of changes from the primary and apply them, serving read traffic.

```
Writes --> Primary --replicates changes--> Replica A
                    --replicates changes--> Replica B
Reads  --> can go to Primary OR any Replica
```

- **Synchronous replication:** the primary waits for the replica(s) to confirm the write before acknowledging it to the client — guarantees replicas are never behind, at the cost of write latency (and reduced availability if a replica is slow/unreachable, since the primary is blocked waiting on it).
- **Asynchronous replication (the common default):** the primary acknowledges the write immediately, and replicas catch up in the background — lower write latency, but replicas can lag behind (replica lag), meaning a read from a replica can return stale data (directly the eventual-consistency scenario from the fundamentals topic's consistency-models file).

**Failover:** if the primary fails, one replica must be promoted to become the new primary. With async replication, this creates a real risk: any writes that hadn't yet replicated to the promoted replica at the moment of failure are **lost** — the new primary doesn't have them, and depending on the failover mechanism, the old primary's un-replicated writes may be irrecoverable if it never comes back, or need careful reconciliation if it does (to avoid two nodes both believing they're the primary — a "split-brain" scenario, which failover tooling must explicitly guard against, typically via a quorum/fencing mechanism).

## Master-master (multi-primary) replication

**Multiple nodes each accept writes**, and changes propagate between them in both directions.

```
Writes --> Node A <--replicates both ways--> Node B <-- Writes
```

- **Pro:** no single write bottleneck, and no single point of failure for writes specifically (either node can keep accepting writes if the other goes down).
- **Con — the hard part: conflict resolution.** If the *same* row is written on both nodes concurrently (before either write has propagated to the other), the two nodes now genuinely disagree, and something must decide the outcome: last-write-wins (simple, but can silently discard a legitimate concurrent write), a custom merge function (application-specific, more correct but more work), or vector clocks/CRDTs (a more principled approach for certain data shapes, e.g., counters or sets that can merge without an explicit "winner"). This is precisely the AP-side conflict-resolution problem named in the CAP theorem theory file, now concrete.

## Comparison table

| Dimension | Master-slave | Master-master |
|---|---|---|
| Write path | Single primary — simple, no conflicts | Multiple nodes — needs conflict resolution |
| Read scaling | Excellent (add replicas) | Also good, but less commonly the primary motivation |
| Write scaling | Limited to one node's capacity | Better, in principle — writes split across nodes |
| Consistency | Simpler to reason about (single source of truth for writes) | Harder — concurrent writes to the same row need explicit resolution |
| Failover complexity | Requires promoting a replica; async replication risks losing un-replicated writes | Any node can already accept writes, but split-brain risk is inherent to the model, not just a failure-mode edge case |
| Common use | The overwhelming default for most applications | Multi-region active-active setups where write latency from every region matters more than the added complexity |

## The interview answer

Master-slave is the correct default for the large majority of designs — it's simpler to reason about and covers read-scaling needs (the dominant scaling need for most applications, per the read-heavy skew seen throughout this repo's estimation examples) without introducing write-conflict resolution. Master-master is justified specifically when **write latency from multiple geographic regions** is a hard requirement (a global app where every region needs low-latency local writes, not just local reads) — and choosing it means explicitly committing to a conflict-resolution strategy, which should be named, not glossed over.
