Diagrams and reference images for database design & scaling (e.g. a B-tree index traversal diagram, a sharding/rebalancing visual) will be added here.
