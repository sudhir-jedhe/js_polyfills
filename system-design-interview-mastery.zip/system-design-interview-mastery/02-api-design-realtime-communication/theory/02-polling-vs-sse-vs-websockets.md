# Short Polling vs. Long Polling vs. Server-Sent Events vs. WebSockets

This comparison is asked, in some form, in nearly every interview touching real-time features (chat, live notifications, dashboards, collaborative editing). Knowing the precise mechanics of each — not just the names — is what separates a memorized answer from a defensible one.

## The four mechanisms

**Short polling:** client sends a request every N seconds regardless of whether anything changed; server responds immediately with current state (or "nothing new").

**Long polling:** client sends a request; server **holds it open** without responding until new data is available (or a timeout elapses), then responds and the client immediately re-opens a new request.

**Server-Sent Events (SSE):** client opens a single HTTP connection (`EventSource`); server keeps it open and streams events to the client over time as plain text (`text/event-stream`). **One-directional**, server → client only.

**WebSockets:** client and server perform an HTTP Upgrade handshake, then communicate over a **full-duplex**, persistent TCP connection outside the request/response model entirely — either side can send a message at any time.

## Comparison table

| Dimension | Short polling | Long polling | SSE | WebSockets |
|---|---|---|---|---|
| Latency | High (bounded by poll interval) | Low (near-instant once data is ready) | Low | Lowest |
| Directionality | Client → Server (client-initiated only) | Client → Server (client-initiated only) | Server → Client only | Full duplex |
| Connection model | New connection per poll | New connection per cycle, held open | One long-lived HTTP connection | One long-lived TCP connection (upgraded) |
| Server complexity | Low (stateless) | Medium (must hold connections, manage timeouts) | Medium (must hold connections, manage reconnects) | High (connection state, often needs a message broker for multi-instance fan-out) |
| Scalability (server-held connections) | High (no held connections) | Lower (many open, mostly-idle connections) | Lower (same issue as long polling) | Lowest per-connection-cost-wise, but justified when bidirectional is actually needed |
| Built-in reconnection | N/A (stateless by nature) | Manual (client re-issues request) | **Automatic**, built into `EventSource` | Manual (must implement reconnect + backoff yourself) |
| Proxy/firewall friendliness | Excellent (plain HTTP) | Excellent (plain HTTP) | Good (plain HTTP, but some proxies buffer streaming responses) | Can be blocked by strict corporate proxies/firewalls that don't support the Upgrade handshake |
| Typical use case | Low-frequency checks where simplicity matters more than latency (e.g., checking a batch job's status every 10s) | Chat/notifications when WebSocket infra isn't justified | Live feeds, stock tickers, live scoreboards, server-push notifications — anything server-to-client only | Chat, multiplayer games, collaborative editing — anything needing low-latency bidirectional messaging |

## Why the directionality distinction is the crux of the choice

The single most important filter question: **does the client ever need to push data to the server on the same channel, in real time?** If updates only flow server → client (a live score, a notification feed, a stock ticker), SSE gives you push-based delivery with dramatically less complexity than WebSockets — built-in reconnection, works over plain HTTP/2 multiplexing, no special infrastructure. WebSockets are the right tool specifically when the client also needs to send low-latency messages back on the same connection (a chat message, a game move, a collaborative-editing keystroke) — using WebSockets purely for a one-directional feed is reaching for more complexity than the problem requires.

## Where long polling still fits

Even with SSE and WebSockets available, long polling remains relevant when the environment or infra can't support persistent connections well (older infrastructure, certain restrictive corporate proxies) or when the update frequency is naturally low enough that the overhead of re-establishing a connection per event isn't a real cost — it's a reasonable fallback/degradation path for SSE or WebSockets, not just a legacy technique.

## Scaling any of these across multiple server instances

Long polling, SSE, and WebSockets all share a hard operational problem once you have more than one server instance: a connection is pinned to whichever instance accepted it, but the event that needs to be pushed might originate on a *different* instance (e.g., another user's action). This requires a **pub/sub or message broker layer** (Redis Pub/Sub, Kafka, a dedicated WebSocket-aware gateway like a managed service) so any instance can publish an event that gets routed to whichever instance holds the relevant client connection — this is the deep-dive detail interviewers listen for once you've picked a transport.
