# Idempotency in APIs

An operation is **idempotent** if performing it multiple times has the exact same effect as performing it once. This property is what makes retries *safe* — and retries are unavoidable in any real distributed system (a client times out and doesn't know if the request succeeded, a network blip drops the response, a mobile client resubmits after an app restart).

## Which HTTP methods are idempotent by definition, and where the gap is

- `GET`, `PUT`, `DELETE` are idempotent by the HTTP spec: calling `DELETE /orders/5` five times has the same end state as calling it once (the order is gone).
- `POST` is **not** idempotent by default — `POST /orders` is typically "create a new order," and calling it twice naively creates two orders. This is precisely the gap that causes real production bugs: a client's request to "charge this card" times out, the client (reasonably) retries, and now the card is charged twice — even though nothing was "wrong" with either individual request.

## Idempotency keys: the standard fix for non-idempotent operations

The client generates a unique key (typically a UUID) **once per logical operation attempt** — not once per HTTP request — and sends it in a header (e.g., `Idempotency-Key: 7d8f...`) with the `POST`. The server:

1. On first receipt of a key, processes the request normally and **stores the result** (response body + status code) keyed by that idempotency key, alongside performing the actual side effect (charging the card, creating the order).
2. On any **subsequent** request with the **same** key, the server does **not** repeat the side effect — it returns the **stored result** from the first successful attempt.
3. Keys are typically scoped (per API credential/account) and expire after some window (e.g., 24 hours) — long enough to cover realistic retry scenarios, short enough not to accumulate unbounded storage.

## The critical implementation detail: the check-and-store must be atomic

A common, subtle bug: checking "has this key been seen?" and then performing the side effect are two separate steps — if two requests with the same *new* key arrive concurrently (a legitimate double-click, or a client retry firing before the first attempt's response even returns), both could pass the "not seen yet" check before either has stored a result, and the side effect runs twice anyway. The fix is to make key registration atomic with a **unique constraint** in the database (`INSERT INTO idempotency_keys (key, status) VALUES ($1, 'processing')` — the second concurrent insert with the same key fails on the unique constraint, and that request either waits for the first to finish and returns its result, or is told to retry shortly).

## Idempotency beyond payments: natural idempotency via request design

Not every non-idempotent operation needs a key — often the fix is to **design the request itself to be naturally idempotent**:
- Instead of `POST /cart/items {productId: 5, action: "increment"}` (not idempotent — repeating it adds more units each time), use `PUT /cart/items/5 {quantity: 3}` (idempotent — repeating it sets the same final quantity regardless of how many times it's sent).
- Instead of `POST /accounts/42/balance {delta: -100}` (not idempotent), use a client-generated, unique transaction ID as part of the request and treat the ledger entry itself as the idempotency key (`INSERT INTO transactions (id, account_id, amount) VALUES ($1, 42, -100)` where `$1` is client-supplied and unique-constrained) — this is really the idempotency-key pattern applied at the domain-model level rather than as generic middleware.

## Interview framing

When a design touches money, inventory, or any operation with a real-world side effect that shouldn't double-fire, proactively raise idempotency — don't wait to be asked. Name the mechanism (idempotency key, stored atomically via a unique constraint) and the specific failure it prevents (a client retry after a timeout causing a double charge), since that's a concrete, production-grade detail interviewers specifically listen for and juniors often miss entirely.
