# The API Gateway Pattern

Once a system is split into multiple services (see the microservices theory file in the fundamentals topic), clients need a single, stable entry point rather than knowing about and calling N different service URLs directly. An **API gateway** sits between clients and the backend services, acting as a reverse proxy with additional cross-cutting responsibilities.

## What a gateway typically does

- **Routing:** maps incoming requests to the correct backend service (`/users/*` → user service, `/orders/*` → order service) based on path, host, or header.
- **Authentication/authorization:** validates tokens (JWT, session) once at the edge, so individual backend services don't each need to reimplement auth logic — they can trust a header the gateway injects (e.g., `X-User-Id`) after verification.
- **Rate limiting & throttling:** enforced centrally at the edge, protecting every backend service uniformly rather than each service needing its own rate-limiting logic.
- **Request/response transformation:** adapting a client-facing contract to whatever shape backend services actually expose (useful when backend services evolve independently of the public API contract).
- **Aggregation (API composition):** for a client request that needs data from multiple services (e.g., a mobile app's "order detail" screen needing order + user + shipping data), the gateway can fan out to multiple services and combine the results into one response — sparing the client multiple round trips.
- **Observability:** a natural single point to log, trace, and monitor all incoming traffic, since every request passes through it.
- **TLS termination, caching, and load balancing** at the edge.

## The tradeoff it introduces

| Benefit | Cost |
|---|---|
| Clients only need to know one endpoint | The gateway becomes a **single point of failure** for the entire system unless it's itself made highly available (redundant instances, its own load balancing) |
| Centralizes cross-cutting concerns (auth, rate limiting) instead of duplicating them per service | Adds a network hop (and thus latency) to every request |
| Backend services can evolve/refactor behind a stable public contract | Can become a bottleneck for development velocity if every route change requires a gateway config change/deploy, or a "God object" that accumulates too much business logic |
| Centralized point for security policy enforcement | Needs careful capacity planning — it now sees 100% of the system's traffic, concentrated |

## Gateway aggregation vs. BFF (Backend-for-Frontend)

A closely related pattern worth distinguishing: a plain API gateway typically exposes one general-purpose API to all clients. A **BFF** takes this further — a dedicated gateway/aggregation layer **per client type** (a mobile-BFF, a web-BFF), each shaped specifically around that client's needs (e.g., mobile might want a smaller, denormalized payload to save bandwidth; the web client might want a richer, more granular one). The BFF pattern trades a bit more infrastructure (multiple gateway variants to maintain) for each client getting an API contract genuinely optimized for its use case, rather than a lowest-common-denominator general API.

## Interview framing

Bring up the API gateway specifically when a design has **more than one backend service and more than one type of client**, or when auth/rate-limiting logic would otherwise be duplicated across services. Always pair it with the honest cost: it's a new critical-path component that must itself be scaled and made redundant — presenting it as a free win, with no downside, misses half of what the interviewer is listening for.
