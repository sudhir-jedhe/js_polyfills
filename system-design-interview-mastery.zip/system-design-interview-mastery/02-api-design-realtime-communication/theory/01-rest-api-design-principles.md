# REST API Design Principles

REST (Representational State Transfer) isn't a protocol or a standard — it's a set of architectural constraints. In interviews, "design a REST API" is really testing whether you produce a consistent, predictable contract, not whether you can recite Roy Fielding's dissertation.

## Resource naming

- **Nouns, not verbs** — resources are things, and HTTP methods are the verbs. `GET /orders/123`, not `GET /getOrder?id=123`.
- **Plural collection names** — `/users`, `/orders`, not `/user`, `/order`. Consistency here matters more than which convention you pick.
- **Nesting reflects real ownership, kept shallow** — `/users/42/orders` (orders belonging to user 42) is fine; `/users/42/orders/7/items/3/reviews` is over-nested — beyond 2 levels, prefer a top-level resource with a filter: `/reviews?item_id=3`.
- **Actions that don't map to CRUD** get modeled as a sub-resource or a verb-like endpoint used sparingly: `POST /orders/123/cancel` (an action, not a field update) is more honest than overloading `PATCH /orders/123 {status: "cancelled"}` when cancellation has side effects (refund, inventory release) beyond a field change.

## HTTP methods and status codes

| Method | Purpose | Idempotent? | Safe (no side effects)? |
|---|---|---|---|
| `GET` | Read a resource | Yes | Yes |
| `POST` | Create a resource / non-idempotent action | No | No |
| `PUT` | Replace a resource entirely | Yes | No |
| `PATCH` | Partially update a resource | Not guaranteed (implementation-dependent) | No |
| `DELETE` | Remove a resource | Yes | No |

**Idempotent** means calling it N times has the same effect as calling it once — critical for retry safety (see the idempotency theory file).

| Status code | Meaning | Common mistake |
|---|---|---|
| `200 OK` | Success, response body present | Using it for errors with an error message body |
| `201 Created` | Resource created (POST), include `Location` header | Returning `200` for creation |
| `204 No Content` | Success, no body (e.g., DELETE) | Returning `200` with an empty body instead |
| `400 Bad Request` | Malformed request (client error, not business logic) | Using it for "not found" or auth failures |
| `401 Unauthorized` | Not authenticated | Confusing with 403 |
| `403 Forbidden` | Authenticated but not permitted | Confusing with 401 |
| `404 Not Found` | Resource doesn't exist | Returning `200` with `{error: "not found"}` |
| `409 Conflict` | State conflict (e.g., duplicate unique key, version mismatch) | Using `400` instead, losing the more specific signal |
| `422 Unprocessable Entity` | Well-formed request, semantically invalid (validation failure) | Conflating with `400` |
| `429 Too Many Requests` | Rate limited | Not including a `Retry-After` header |
| `500 Internal Server Error` | Unhandled server-side failure | Leaking a stack trace in the body |
| `503 Service Unavailable` | Temporarily overloaded/down | Not distinguishing from 500 (503 signals "retry later," 500 doesn't) |

## Versioning

The three common strategies, with tradeoffs:

- **URL path** (`/v1/orders`) — most visible and cache-friendly, but "leaks" into every client URL forever.
- **Header-based** (`Accept: application/vnd.myapi.v2+json`) — keeps URLs stable, but less discoverable/debuggable (you can't just paste a URL in a browser).
- **Query parameter** (`/orders?version=2`) — simplest to add, but easy to forget and less semantically correct (versioning isn't really a filter on the resource).

**Interview answer:** URL-path versioning is the most common real-world default for public APIs because of its discoverability and cache-friendliness, but the deeper point interviewers want is that you have a plan for **backward-compatible evolution** (adding optional fields doesn't need a version bump; removing or changing the meaning of a field does) rather than bumping the version for every change.

## Pagination

Covered in depth in its own snippet, but the core interview-level distinction: **offset-based** (`?page=3&limit=20`) is simple but breaks under concurrent inserts/deletes (items shift between pages, causing skips or duplicates) and gets slower on large offsets (the database still has to scan/skip prior rows). **Cursor-based** (`?after=<opaque_cursor>&limit=20`) uses a stable pointer (typically an encoded ID or timestamp) and stays performant and consistent regardless of concurrent writes — the standard choice for large or high-write-volume collections (social feeds, activity logs).

## Cross-reference

For a full treatment of GraphQL as an alternative to REST (query flexibility, schema, resolvers, N+1 problem, caching implications), see the dedicated GraphQL-focused repo — this repo only covers the REST-vs-GraphQL tradeoff at a summary level (see the GraphQL comparison theory file in this topic).
