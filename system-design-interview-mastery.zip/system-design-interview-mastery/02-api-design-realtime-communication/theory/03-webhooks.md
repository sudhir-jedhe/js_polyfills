# Webhooks

A webhook is the inverse of a normal API call: instead of a client polling a server for updates, the **server calls a URL the client registered in advance**, pushing an event the moment it happens. It's how Stripe notifies you of a payment, how GitHub notifies you of a push, and how most third-party integrations work without requiring the receiver to poll.

## How it works

1. The receiving system registers a callback URL with the sending system (e.g., "POST to `https://myapp.com/webhooks/stripe` when a payment succeeds").
2. When the event occurs, the sender makes an HTTP `POST` to that URL with the event payload.
3. The receiver's endpoint processes the payload and responds with a `2xx` status to acknowledge receipt.
4. If the receiver doesn't respond with `2xx` (times out, errors, is down), the sender **retries** — typically with exponential backoff, for a bounded number of attempts or duration.

## Why "at-least-once" delivery is the default guarantee, and what that implies

Because the sender retries on any non-`2xx` response (including a `2xx` response that the sender simply never received due to a network blip, even if the receiver actually processed it fine), webhook delivery is fundamentally **at-least-once**, not exactly-once. This means:

- **The receiver must be idempotent** — processing the same event twice (same `event_id`) must not double-charge, double-send, or double-anything. The standard fix: every event carries a unique `event_id`; the receiver checks (in a transaction, or via a unique constraint) whether that ID has already been processed before acting on it, and if so, just returns `200` without redoing the side effect.
- **Order is not guaranteed** — retries can interleave with newly-generated events, and different events for the same object might arrive out of order (e.g., `payment.updated` before `payment.created` due to one retry lagging). Receivers should key off the payload's own timestamp/sequence field to detect and discard out-of-order events, rather than assuming arrival order reflects event order.

## Security: verifying the sender

Since a webhook endpoint is a public URL, anyone who discovers it could POST forged payloads to it. The standard mitigation is **signature verification**: the sender computes an HMAC signature of the payload using a shared secret (established when the webhook was registered) and includes it in a header (e.g., `X-Signature`); the receiver recomputes the HMAC over the raw request body using the same secret and rejects the request if it doesn't match. This also implies the receiver must read and verify the **raw, unparsed** request body before any JSON parsing/normalization touches it — normalizing first (e.g., re-serializing) can change the byte sequence and break signature verification even for a legitimate request.

## Delivery guarantees and observability the receiver should build for

- **Timeout fast, process async:** the endpoint should acknowledge receipt (`200`) quickly and do any slow processing (side effects, downstream calls) asynchronously via a queue — holding the sender's request open while doing slow work risks the sender timing out and retrying, creating duplicate-delivery pressure that a fast-ack pattern avoids.
- **A dead-letter path:** after the sender's retry budget is exhausted, most providers offer a way to inspect/replay failed deliveries (a dashboard, an API to list failed events) — a production integration should have a plan for what happens to events that never successfully deliver, not just for the happy path.

## Interview framing

When a design includes a webhook (either as sender or receiver), always name the three things above explicitly: **retries imply at-least-once, so the receiver needs idempotency; signature verification, or the endpoint is spoofable; and fast-ack-then-async-process, to avoid retry storms from a slow handler.** These three points, stated together, are what distinguish "I know what a webhook is" from "I've actually built one that survives production."
