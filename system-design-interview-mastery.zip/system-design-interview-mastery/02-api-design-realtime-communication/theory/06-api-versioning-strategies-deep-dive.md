# API Versioning Strategies — Deep Dive

Building on the brief mention in the REST principles file: versioning isn't just "pick URL path vs. header" — the harder, more interview-relevant question is **how to change an API without breaking existing clients**, since most API changes in a mature system are evolutions, not full version bumps.

## Backward-compatible ("non-breaking") changes — no version bump needed

- Adding a new optional field to a response.
- Adding a new endpoint.
- Adding a new optional request parameter with a sensible default.
- Making a previously-required field optional (relaxing a constraint is safe; tightening one isn't).

Clients that don't know about the new field/endpoint are unaffected — this is why treating every backward-compatible addition as a new version is unnecessary churn; it forces clients to migrate for changes that shouldn't have required it.

## Breaking changes — these require a real versioning strategy

- Removing or renaming a field.
- Changing a field's type or meaning (e.g., `status` changing from a string enum to a numeric code).
- Changing required-ness (making an optional field required).
- Changing an endpoint's URL structure or its authentication requirements.

## The three mechanisms, revisited with tradeoffs that matter at scale

| Strategy | Example | Pro | Con |
|---|---|---|---|
| URL path | `/v1/orders`, `/v2/orders` | Maximally explicit and cache-friendly (different URL = different cache key naturally); trivially discoverable in logs/docs | Version proliferates through every client integration permanently; awkward for resources that logically span versions |
| Header (media type) | `Accept: application/vnd.api.v2+json` | Keeps a single canonical URL per resource; feels more "correct" per REST's resource-identity principle | Harder to test/debug ad hoc (can't just paste a URL); some caches/proxies don't vary cache keys on arbitrary headers by default |
| Query parameter | `/orders?version=2` | Easiest to add on top of an existing unversioned API | Easy for clients to omit accidentally (silently falls back to a default); conceptually versioning isn't really a "filter" |

## Deprecation as a first-class process, not an afterthought

A mature versioning strategy includes a **deprecation policy**: announce a version's end-of-life date well in advance, surface it to clients proactively (a `Deprecation` and `Sunset` HTTP header on responses from the deprecated version, per RFC 8594, is the standards-based way to do this machine-readably), and monitor actual traffic on the deprecated version before removing it — removing a version that's still receiving meaningful traffic breaks real clients, regardless of how much advance notice was given in documentation nobody read.

## Internal (service-to-service) vs. public API versioning differ in practice

For a public API with third-party consumers, versions must be supported for a long time (breaking a paying customer's integration is costly) — favoring the URL-path strategy's explicitness and long-lived parallel-version support. For internal service-to-service APIs within one organization, teams often favor **contract testing** (consumer-driven contracts, schema compatibility checks in CI) over formal versioning at all — since both sides of the API are deployed by teams who can coordinate a rollout, a strict versioning scheme is sometimes more overhead than it's worth; the discipline shifts from "support N versions forever" to "never merge a breaking change without checking who depends on this contract."

## Interview framing

Don't stop at naming a versioning mechanism — the stronger answer distinguishes backward-compatible changes (no bump needed) from breaking ones (need the mechanism), and mentions a concrete deprecation/sunset process. That combination signals you've thought about the API's entire lifecycle, not just its initial shape.
