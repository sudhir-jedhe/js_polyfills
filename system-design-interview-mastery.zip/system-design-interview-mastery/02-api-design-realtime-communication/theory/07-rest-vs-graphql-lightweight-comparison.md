# REST vs. GraphQL — Lightweight Comparison

This file intentionally stays high-level: a full treatment of GraphQL (schema design, resolvers, the N+1 query problem and DataLoader, subscriptions, caching strategy) belongs in — and is covered by — the dedicated GraphQL-focused repo. What's useful here is the **comparison an interviewer expects you to be able to state** when justifying a REST choice (or a GraphQL one) at the architecture level.

## The core difference

- **REST:** the server defines fixed-shape resources at fixed endpoints (`GET /users/5` always returns the same shape). The client takes what the endpoint gives it, or the server adds query params for limited flexibility (`?fields=name,email`).
- **GraphQL:** the client sends a **query describing exactly the fields it needs**, potentially across multiple related resources in a single request, and the server returns exactly that shape — no more, no less.

## Comparison table

| Dimension | REST | GraphQL |
|---|---|---|
| Response shape | Fixed per endpoint (server-defined) | Client-defined per query |
| Over-fetching / under-fetching | Common (endpoint returns more fields than needed, or requires multiple calls to assemble a full view) | Solved by design — client asks for exactly what it needs |
| Number of round trips for related data | Often multiple (one per resource, unless a bespoke aggregation endpoint exists) | Typically one (nested query resolves relationships server-side) |
| Caching | Simple and mature — HTTP caching (`Cache-Control`, ETag) works naturally per-URL | Harder — most requests are `POST` to a single `/graphql` endpoint, so URL-based HTTP caching doesn't apply; needs client-side normalized caching (e.g., Apollo/Relay) instead |
| Learning curve / tooling | Lower; ubiquitous tooling, simple mental model | Higher; schema, resolvers, N+1 problem to manage server-side |
| Versioning | Explicit (URL/header versioning, as covered above) | Typically version-free — the schema evolves by deprecating fields, not by versioning the whole API |
| Best fit | Simple, resource-oriented CRUD APIs; public APIs where HTTP caching matters | Complex, deeply nested/related data; multiple client types with very different data needs (mobile vs. web) that would otherwise need many bespoke REST endpoints |

## The interview-level tradeoff to actually state

The honest framing isn't "GraphQL is strictly better because it's more flexible" — flexibility on the client side pushes real complexity onto the server (resolver design, the N+1 problem, query cost analysis to prevent a malicious/accidental expensive nested query from overloading the backend) and gives up REST's simple, well-understood HTTP caching model. A defensible interview answer: **choose REST by default for straightforward resource CRUD, especially public APIs that benefit from HTTP caching; consider GraphQL specifically when multiple client types need very different, deeply related data shapes from the same backend, and the team is prepared to invest in resolver-level performance work (batching/caching via DataLoader-style patterns) to avoid the N+1 problem.**

For the full mechanics — schema definition language, resolver implementation, subscriptions for real-time GraphQL, and how caching is actually solved in practice — see the dedicated GraphQL repo.
