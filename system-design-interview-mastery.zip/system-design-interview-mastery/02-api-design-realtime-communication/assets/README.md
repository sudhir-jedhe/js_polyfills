Diagrams and reference images for API design & real-time communication (e.g. a polling/SSE/WebSocket sequence-diagram comparison) will be added here.
