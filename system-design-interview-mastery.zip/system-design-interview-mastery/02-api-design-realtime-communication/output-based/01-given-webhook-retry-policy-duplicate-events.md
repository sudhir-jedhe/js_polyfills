# Output: Webhook Retry Policy and Duplicate Events

**Setup:** A payment provider sends a webhook `POST` to `https://shop.example.com/webhooks/payment` when a payment succeeds. Their retry policy: retry on any non-`2xx` response or timeout, with exponential backoff, up to 5 attempts over 24 hours. The receiving endpoint processes the payload (marks the order as paid, sends a confirmation email) and takes 6 seconds to complete due to a slow email-sending call in the request path — but the sender's timeout is 5 seconds.

**Question:** What happens on the first delivery attempt, and what's the downstream effect?

**Answer:** The sender's request times out at 5 seconds because the receiver hasn't responded yet (it's still waiting on the slow email call at the 5-second mark) — from the sender's point of view, this looks like a failed delivery, even though the receiver's handler is still running and **will** complete the order-marking and email successfully a second later. The sender's retry logic kicks in and re-delivers the same event a short time later. If the receiving endpoint isn't idempotent (no check for "have I already processed this `event_id`?"), the retry causes the order to be marked paid again (harmless if it's just a status field re-set to the same value) — but the confirmation **email gets sent a second time**, a directly visible, unprofessional bug from the customer's perspective, caused entirely by a timing mismatch, not any actual delivery failure.

**Fix:**
1. **Acknowledge fast, process async:** the handler should validate the payload, enqueue the actual processing (order update, email) to a background job/queue, and return `200` immediately — well under the sender's 5-second timeout — decoupling "did we receive this" from "have we finished acting on it."
2. **Idempotency via `event_id`:** regardless of the async fix, the handler must check whether `event_id` has already been processed (a unique constraint on an `event_id` column, checked before enqueuing the side effects) — this makes the endpoint safe against retries caused by *any* cause (timeout, network blip, sender-side bug), not just this specific slow-email scenario.

**The general lesson:** at-least-once delivery means a "failed" delivery from the sender's perspective doesn't necessarily mean the receiver didn't process it — the two facts (delivery success and processing success) can diverge, and a correct webhook receiver must be idempotent regardless of how fast or slow it responds.
