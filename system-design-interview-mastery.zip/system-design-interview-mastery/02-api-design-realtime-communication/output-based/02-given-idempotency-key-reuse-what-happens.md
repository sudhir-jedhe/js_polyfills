# Output: Idempotency Key Reuse With a Different Payload

**Setup:** A client sends `POST /payments` with `Idempotency-Key: abc-123` and body `{ "amount": 5000, "cardToken": "tok_1" }`. The server processes it, charges $50.00, and stores the response keyed by `abc-123`. Due to a client-side bug, the same client later sends **another** request reusing `Idempotency-Key: abc-123`, but this time with a **different** body: `{ "amount": 9900, "cardToken": "tok_1" }`.

**Question:** Using the idempotency-key middleware pattern shown in the snippets file (which keys purely on the `Idempotency-Key` header, not the request body), what does the server return for the second request? Is that correct behavior?

**Answer:** The server returns the **stored result from the first request** — a successful charge of **$50.00** — completely ignoring the second request's `$99.00` body, because the middleware's logic is "if this key has been seen before, replay the original stored response" without ever comparing the new request's payload to the original. The client's bug (accidentally reusing a key across two logically different charge attempts) silently produces the wrong outcome: the customer is charged $50 when the client intended (due to its own bug) to charge $99 — and worse, the response the client receives looks entirely successful, so nothing about this failure is visible without deeper investigation.

**Why this happens:** basic idempotency-key implementations only key on the header value, treating it purely as "have I done this before" — which is correct **only if the client guarantees the key is unique per logical operation**, an assumption the client violated here.

**The more robust fix — fingerprint the request body alongside the key:**
```sql
-- store a hash of the normalized request body alongside the key
INSERT INTO idempotency_keys (key, request_hash, status, ...)
VALUES ($1, $2, 'processing', ...)
```
On a key collision, compare the **new request's body hash** to the stored one:
- If they match → safe to replay the stored response (this is a legitimate retry of the same logical request).
- If they **don't** match → this is a client error (key reuse across different requests), and the server should reject it with `422 Unprocessable Entity` (or `409 Conflict`) rather than silently serving a stale, mismatched response.

**The interview point:** a naive idempotency-key implementation prevents double-*execution* but doesn't protect against key *misuse* — a request-body fingerprint check is the detail that closes that gap, and it's exactly the kind of edge case interviewers probe for after a candidate has already correctly described the basic pattern, to check whether the understanding is genuinely load-bearing or just memorized.
