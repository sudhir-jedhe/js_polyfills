# Output: WebSocket Connection Drop and Message Loss

**Setup:** A live chat client is connected via WebSocket. The user's phone briefly loses network connectivity (walks into an elevator) for 12 seconds. During that window, two chat messages are sent to the room by other users. The client's `onclose` handler triggers a reconnect with exponential backoff, as shown in the WebSocket snippet file.

**Question:** After the client reconnects, does it see the two messages sent while it was disconnected? What has to be true for the answer to be "yes"?

**Answer:** **Not automatically — and by default, no.** A raw WebSocket connection carries no memory of what happened while it was closed; when the client reconnects, it establishes a brand-new connection and only receives messages broadcast **after** that new connection is established. The two messages sent during the 12-second gap are simply never delivered to this client unless something explicit compensates for the gap.

**What has to be added to actually recover those messages** (this is the deep-dive detail interviewers are listening for beyond "just reconnect"):
1. **The client must track the last message it successfully received** (a timestamp, sequence number, or message ID).
2. **On reconnect, before resuming the live stream, the client fetches anything it missed via a separate REST call** — e.g., `GET /rooms/42/messages?after=<last_seen_id>` — a catch-up mechanism that's independent of the WebSocket connection itself.
3. Only after the catch-up fetch completes does the client trust the live WebSocket stream going forward, to avoid a race where a live message arrives before the catch-up fetch, potentially causing a duplicate or an ordering gap — the catch-up response and the live stream need to be reconciled (e.g., dedupe by message ID) rather than naively concatenated.

**Contrast with SSE:** this is one of the concrete advantages SSE has over raw WebSockets for server-to-client-only use cases — the `EventSource` API automatically sends a `Last-Event-ID` header on reconnect (if the server included `id:` fields on prior events), letting a well-implemented server resume the stream from that point natively, without the client needing to hand-roll a separate catch-up REST call. WebSockets provide no equivalent mechanism — reconnection recovery is entirely the application's responsibility to design and implement.

**The general lesson:** "the client reconnects" is necessary but not sufficient for a real-time feature to be reliable across network blips — a design that doesn't separately address **gap recovery** (what happened between disconnect and reconnect) has a silent data-loss bug that won't show up in a demo but will show up constantly in real mobile usage.
