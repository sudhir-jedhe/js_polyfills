# Snippet: Cursor-Based vs. Offset-Based Pagination

**Offset-based (simple, but breaks under concurrent writes and gets slow on large offsets):**

```js
// GET /posts?page=3&limit=20
app.get('/posts', async (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 20;
  const offset = (page - 1) * limit;

  // the database still has to scan/skip `offset` rows before returning the page —
  // gets slower as `offset` grows, even though `limit` stays constant
  const posts = await db.query(
    'SELECT * FROM posts ORDER BY created_at DESC LIMIT $1 OFFSET $2',
    [limit, offset]
  );
  res.json({ posts, page, limit });
});
```

**The concurrency bug offset pagination has:** if a new post is inserted while a user is paging through results ordered by `created_at DESC`, everything shifts down by one — the user can see the same post twice (it moved from page 2 to page 3 while they were between requests) or miss one entirely.

**Cursor-based (stable under concurrent writes, and avoids the OFFSET scan cost):**

```js
// GET /posts?after=<opaque_cursor>&limit=20
app.get('/posts', async (req, res) => {
  const limit = parseInt(req.query.limit) || 20;
  const after = req.query.after ? decodeCursor(req.query.after) : null;
  // decodeCursor returns { createdAt, id } from the opaque base64 string

  const posts = after
    ? await db.query(
        `SELECT * FROM posts
         WHERE (created_at, id) < ($1, $2)   -- tuple comparison: stable tiebreak on id
         ORDER BY created_at DESC, id DESC
         LIMIT $3`,
        [after.createdAt, after.id, limit]
      )
    : await db.query(
        'SELECT * FROM posts ORDER BY created_at DESC, id DESC LIMIT $1', [limit]
      );

  const nextCursor = posts.length
    ? encodeCursor({ createdAt: posts[posts.length - 1].created_at, id: posts[posts.length - 1].id })
    : null;

  res.json({ posts, nextCursor });
});

function encodeCursor(obj) {
  return Buffer.from(JSON.stringify(obj)).toString('base64');
}
function decodeCursor(str) {
  return JSON.parse(Buffer.from(str, 'base64').toString('utf8'));
}
```

**Why the tuple comparison `(created_at, id) < ($1, $2)` matters:** `created_at` alone isn't guaranteed unique (two posts can share a timestamp), so pagination on `created_at` alone can skip or duplicate rows at a tie. Including `id` as a secondary, always-unique tiebreaker makes the cursor position exact regardless of timestamp collisions — this detail is exactly the kind of thing that separates a textbook cursor implementation from one that actually holds up under real data.
