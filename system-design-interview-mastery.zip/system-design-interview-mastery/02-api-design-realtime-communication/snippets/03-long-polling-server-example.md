# Snippet: Long Polling Server (Node/Express)

```js
const express = require('express');
const app = express();

// in-memory event store, keyed by channel — in production this would be
// backed by Redis Pub/Sub so multiple server instances share events
const pendingWaiters = new Map(); // channel -> [{ resolve, timeoutId }]
const channelEvents = new Map();  // channel -> latest event

app.get('/poll/:channel', (req, res) => {
  const { channel } = req.params;
  const since = parseInt(req.query.since) || 0; // client's last-known event timestamp

  const latest = channelEvents.get(channel);

  // if there's already a newer event than what the client has seen, respond immediately
  if (latest && latest.timestamp > since) {
    return res.json({ event: latest, timestamp: latest.timestamp });
  }

  // otherwise, HOLD the request open — this is what makes it "long" polling
  const timeoutMs = 30_000; // give up and respond empty after 30s, client re-polls
  const timeoutId = setTimeout(() => {
    removeWaiter(channel, waiter);
    res.status(204).end(); // "no new events" — client should immediately re-poll
  }, timeoutMs);

  const waiter = {
    resolve: (event) => {
      clearTimeout(timeoutId);
      res.json({ event, timestamp: event.timestamp });
    },
  };

  if (!pendingWaiters.has(channel)) pendingWaiters.set(channel, []);
  pendingWaiters.get(channel).push(waiter);

  // clean up if the client disconnects before either resolving or timing out
  req.on('close', () => removeWaiter(channel, waiter));
});

function removeWaiter(channel, waiter) {
  const list = pendingWaiters.get(channel) || [];
  pendingWaiters.set(channel, list.filter(w => w !== waiter));
}

// called elsewhere when a new event happens (e.g., a new chat message)
function publishEvent(channel, event) {
  event.timestamp = Date.now();
  channelEvents.set(channel, event);
  const waiters = pendingWaiters.get(channel) || [];
  waiters.forEach(w => w.resolve(event));
  pendingWaiters.set(channel, []);
}
```

**Client side — must immediately re-issue the request after each response:**

```js
async function pollLoop(channel, sinceRef, onEvent) {
  while (true) {
    const res = await fetch(`/poll/${channel}?since=${sinceRef.value}`);
    if (res.status === 200) {
      const { event, timestamp } = await res.json();
      sinceRef.value = timestamp;
      onEvent(event);
    }
    // status 204 (timeout, no new event) or 200 (got an event) — either way, loop again immediately
  }
}
```

**Key implementation details worth noting:** the server must handle client disconnects (`req.on('close', ...)`) to avoid leaking waiter references, and the timeout (30s here) bounds how long any single connection is held — long enough to avoid excessive re-polling overhead, short enough to avoid load balancers/proxies timing out the connection themselves first.
