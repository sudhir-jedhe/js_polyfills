# Snippet: Idempotency-Key Middleware (Node/Express + Postgres)

```js
async function idempotencyMiddleware(req, res, next) {
  const key = req.header('Idempotency-Key');
  if (!key) return next(); // idempotency key is optional; only enforced when provided

  // atomic insert — the unique constraint on `key` is what prevents a race
  // between two concurrent requests carrying the same key
  const inserted = await db.query(
    `INSERT INTO idempotency_keys (key, status, created_at)
     VALUES ($1, 'processing', now())
     ON CONFLICT (key) DO NOTHING
     RETURNING key`,
    [key]
  );

  if (inserted.rows.length === 0) {
    // key already exists — either still processing, or already completed
    const existing = await db.query(
      'SELECT status, response_body, response_status FROM idempotency_keys WHERE key = $1',
      [key]
    );
    const row = existing.rows[0];

    if (row.status === 'completed') {
      // return the ORIGINAL result, without re-running the side effect
      return res.status(row.response_status).json(JSON.parse(row.response_body));
    }
    // still processing (a concurrent request with the same key is mid-flight) —
    // tell the client to retry shortly rather than double-executing
    return res.status(409).json({ error: 'request with this idempotency key is already in progress' });
  }

  // first time seeing this key — capture the response so it can be stored
  // once the actual route handler finishes
  const originalJson = res.json.bind(res);
  res.json = async (body) => {
    await db.query(
      `UPDATE idempotency_keys
       SET status = 'completed', response_body = $1, response_status = $2
       WHERE key = $3`,
      [JSON.stringify(body), res.statusCode, key]
    );
    return originalJson(body);
  };

  next();
}

// usage — apply to any non-idempotent, side-effecting endpoint
app.post('/payments', idempotencyMiddleware, async (req, res) => {
  const charge = await chargeCard(req.body.cardToken, req.body.amount);
  res.status(201).json({ chargeId: charge.id, status: 'succeeded' });
});
```

**Schema:**

```sql
CREATE TABLE idempotency_keys (
  key             TEXT PRIMARY KEY,
  status          TEXT NOT NULL DEFAULT 'processing', -- 'processing' | 'completed'
  response_body   TEXT,
  response_status INT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
-- a periodic job should delete rows older than the retention window (e.g., 24h)
```

**What makes this safe under concurrency:** the `INSERT ... ON CONFLICT DO NOTHING ... RETURNING key` is a single atomic database operation — exactly one of two concurrent requests with the same brand-new key will get a row back from `RETURNING`; the other gets zero rows and falls into the "already exists" branch, correctly told to wait/retry rather than being allowed to also execute `chargeCard`.
