# Snippet: REST Resource Naming — Good vs. Bad

```
BAD                                    GOOD
GET  /getUser?id=5                     GET    /users/5
POST /createUser                       POST   /users
POST /updateUser?id=5                  PATCH  /users/5
POST /deleteUser?id=5                  DELETE /users/5
GET  /users/5/getOrders                GET    /users/5/orders
POST /orders/7/doCancel                POST   /orders/7/cancel
GET  /orders?status=shipped&userId=5   GET    /users/5/orders?status=shipped
POST /user/updateEmail                 PATCH  /users/5   { "email": "new@x.com" }
```

**Filtering, sorting, and field selection as query params (not part of the path):**

```
GET /orders?status=pending&sort=-created_at&limit=20
GET /orders?fields=id,total,status        # sparse fieldset — return only these
GET /orders?created_after=2026-01-01
```

**Nested resources — only nest one level deep for real ownership; flatten beyond that:**

```
GOOD (one level, clear ownership):
GET /users/5/orders

AVOID (over-nested):
GET /users/5/orders/7/items/3/reviews

PREFER (flattened with a filter):
GET /reviews?order_id=7&item_id=3
```

**Action endpoints for operations that aren't a plain field update:**

```
POST /orders/7/cancel      # has side effects: refund, inventory release — not just status="cancelled"
POST /orders/7/refund
POST /invoices/12/send
```

Each of these represents a **business action with side effects**, which is why they're modeled as a `POST` to a verb-like sub-resource rather than a `PATCH` on a status field — a `PATCH {status: "cancelled"}` implies "just set this field," which understates what the operation actually does.
