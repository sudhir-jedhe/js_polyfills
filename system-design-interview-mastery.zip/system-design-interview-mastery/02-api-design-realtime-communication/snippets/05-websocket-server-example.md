# Snippet: WebSocket Server (Node, `ws` library) — Bidirectional Chat

```js
const WebSocket = require('ws');
const wss = new WebSocket.Server({ port: 8080 });

const rooms = new Map(); // roomId -> Set<WebSocket>

wss.on('connection', (socket, req) => {
  let currentRoom = null;

  socket.on('message', (raw) => {
    const msg = JSON.parse(raw);

    if (msg.type === 'join') {
      currentRoom = msg.roomId;
      if (!rooms.has(currentRoom)) rooms.set(currentRoom, new Set());
      rooms.get(currentRoom).add(socket);
      return;
    }

    if (msg.type === 'chat-message' && currentRoom) {
      const payload = JSON.stringify({
        type: 'chat-message',
        userId: msg.userId,
        text: msg.text,
        timestamp: Date.now(),
      });
      // broadcast to every OTHER client in the room — this is the
      // bidirectional, low-latency piece SSE/long-polling can't do:
      // the server received a client-originated message on the SAME connection
      for (const client of rooms.get(currentRoom)) {
        if (client !== socket && client.readyState === WebSocket.OPEN) {
          client.send(payload);
        }
      }
    }
  });

  // heartbeat/ping to detect dead connections that didn't send a clean close
  socket.isAlive = true;
  socket.on('pong', () => { socket.isAlive = true; });

  socket.on('close', () => {
    if (currentRoom) rooms.get(currentRoom)?.delete(socket);
  });
});

// server-side liveness check, every 30s — WebSockets don't reliably
// detect a half-dead TCP connection without this
setInterval(() => {
  wss.clients.forEach((socket) => {
    if (!socket.isAlive) return socket.terminate();
    socket.isAlive = false;
    socket.ping();
  });
}, 30_000);
```

**Client — must implement reconnection manually (unlike `EventSource`):**

```js
function connect(roomId, userId) {
  const socket = new WebSocket('wss://chat.example.com');
  let reconnectDelay = 1000;

  socket.onopen = () => {
    reconnectDelay = 1000; // reset backoff on successful connect
    socket.send(JSON.stringify({ type: 'join', roomId }));
  };

  socket.onmessage = (e) => {
    const msg = JSON.parse(e.data);
    if (msg.type === 'chat-message') renderMessage(msg);
  };

  socket.onclose = () => {
    // exponential backoff reconnect — WebSockets give you no automatic
    // reconnection, this must be hand-rolled
    setTimeout(() => connect(roomId, userId), reconnectDelay);
    reconnectDelay = Math.min(reconnectDelay * 2, 30_000);
  };

  return socket;
}
```

**Why this needs a message broker at multi-instance scale:** `rooms` here is an in-memory `Map` local to one server process. With multiple server instances behind a load balancer, two users in the same room could be connected to different instances — a message from one wouldn't reach the other. The production fix is publishing each message to Redis Pub/Sub (or similar), with every instance subscribed and forwarding to its own locally-connected clients — the exact "cross-instance fan-out" problem named in the theory file.
