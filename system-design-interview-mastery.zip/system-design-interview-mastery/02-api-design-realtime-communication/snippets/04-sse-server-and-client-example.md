# Snippet: Server-Sent Events (SSE) — Server and Client

**Server (Node/Express) — one persistent HTTP connection per client, server pushes events:**

```js
const express = require('express');
const app = express();

const clients = new Set(); // active SSE response objects

app.get('/events', (req, res) => {
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
  });
  res.write('\n'); // flush headers to establish the stream immediately

  clients.add(res);
  req.on('close', () => clients.delete(res)); // clean up on disconnect

  // optional: send a heartbeat comment every 15s to keep intermediary
  // proxies from timing out the idle connection
  const heartbeat = setInterval(() => res.write(': heartbeat\n\n'), 15_000);
  req.on('close', () => clearInterval(heartbeat));
});

// called elsewhere when a new event should be pushed to all connected clients
function broadcastEvent(eventName, data) {
  const payload = `event: ${eventName}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const client of clients) client.write(payload);
}

// example: broadcastEvent('price-update', { symbol: 'AAPL', price: 234.12 });
```

**Client — the browser's built-in `EventSource` handles reconnection automatically:**

```js
const source = new EventSource('/events');

source.addEventListener('price-update', (e) => {
  const data = JSON.parse(e.data);
  updateTicker(data.symbol, data.price);
});

source.onerror = () => {
  // EventSource automatically retries the connection on error/drop —
  // no manual reconnect logic needed, unlike raw WebSockets
  console.log('connection lost, browser is auto-reconnecting...');
};
```

**Why this is a good fit for a "live ticker" use case specifically:** the data flow is purely server → client (the browser never needs to send anything back over this channel), so SSE's one-directional model isn't a limitation here — and the built-in automatic reconnection (with the `Last-Event-ID` header, which the browser sends automatically on reconnect so the server can resume from where the client left off, if implemented) removes a meaningful chunk of the client-side complexity a WebSocket implementation would otherwise require by hand.
