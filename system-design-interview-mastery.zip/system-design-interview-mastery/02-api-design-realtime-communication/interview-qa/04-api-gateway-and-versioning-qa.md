# Interview Q&A — API Gateway and Versioning

**Q: What are the core responsibilities of an API gateway, beyond simple request routing?**
Authentication/authorization (validated once at the edge, so backend services trust an injected header rather than re-implementing auth), rate limiting, request/response transformation, aggregation (fanning a client request out to multiple backend services and combining results), centralized observability/logging, and TLS termination — routing is the most visible responsibility, but centralizing these cross-cutting concerns is usually the bigger architectural win.

**Q: What's the main risk introduced by adding an API gateway, and how is it mitigated?**
It becomes a single point of failure and a concentration point for 100% of the system's traffic — if it goes down or becomes a bottleneck, every backend service becomes unreachable regardless of its own health. It's mitigated the same way any other critical-path component is: running multiple gateway instances behind their own load balancer, with capacity planned for full system traffic, not treated as an afterthought.

**Q: What's the difference between an API gateway and a Backend-for-Frontend (BFF)?**
A plain API gateway typically exposes one general-purpose contract to all client types. A BFF is a dedicated aggregation layer *per client type* (mobile-BFF, web-BFF), each shaped specifically around that client's data needs — trading more infrastructure to maintain for each client getting a genuinely optimized API contract rather than a lowest-common-denominator general one.

**Q: What changes don't require an API version bump, and why does that distinction matter?**
Backward-compatible additions — a new optional response field, a new endpoint, a new optional request parameter with a sane default — don't require a version bump, because existing clients unaware of the addition are unaffected. The distinction matters because treating every change as version-worthy creates unnecessary churn and forces clients to migrate for changes that were never actually breaking, while genuinely breaking changes (removing/renaming a field, changing a field's type or required-ness) do need a real versioning mechanism.

**Q: Why might an internal, service-to-service API favor contract testing over formal versioning, while a public third-party-facing API would not?**
Internal APIs are consumed by teams within the same organization who can coordinate a rollout together — consumer-driven contract tests in CI can catch a breaking change before it merges, making a heavyweight versioning scheme often more overhead than it's worth. A public API's consumers are external, uncoordinated, and often can't be forced to migrate on a short timeline, so it needs the more durable guarantee that formal versioning (and a real deprecation/sunset process) provides.
