# Interview Q&A — Webhooks and Idempotency

**Q: Why is webhook delivery inherently "at-least-once" rather than "exactly-once"?**
Because the sender retries whenever it doesn't receive a clean success response — including cases where the receiver actually processed the event fine but the acknowledgment itself was lost (a network blip, a timeout on a slow-but-successful handler). The sender can't distinguish "receiver never got it" from "receiver got it but I didn't hear back," so it must retry in both cases to avoid ever silently dropping an event — which means the receiver may legitimately see the same event more than once.

**Q: What two things must a production webhook receiver implement, beyond just handling the payload?**
Idempotency (checking a unique `event_id` before acting, since retries will resend the same event) and fast-ack-then-async-processing (returning `200` quickly and doing slow side effects — emails, downstream calls — via a background job/queue), since a slow synchronous handler is often what causes the sender's timeout-triggered retries in the first place.

**Q: How does webhook signature verification work, and what's the most common implementation mistake?**
The sender computes an HMAC of the raw request body using a shared secret and sends it in a header; the receiver recomputes the same HMAC over the raw body and compares. The most common mistake is verifying the signature *after* parsing/re-serializing the body (e.g., via a JSON body-parser middleware that runs first) — any change to whitespace or key ordering during parsing changes the byte sequence, breaking a legitimate signature. The raw body must be captured and verified before any parsing.

**Q: Why must an idempotency-key check-and-store be a single atomic database operation, rather than a check followed by a separate write?**
Because two requests carrying the same key can arrive concurrently — if "check whether this key exists" and "store the new key" are separate steps, both requests can pass the check before either has stored anything, and the non-idempotent side effect (e.g., a charge) runs twice anyway. An atomic operation, such as an `INSERT ... ON CONFLICT DO NOTHING` relying on a unique constraint, guarantees only one of the two concurrent requests can "win" the insert.

**Q: If an idempotency key is reused across two requests with genuinely different payloads, what should the correct behavior be, and why is naively replaying the first result wrong?**
The server should detect the mismatch (typically by comparing a hash of the new request body to a stored fingerprint of the original) and reject the second request with an error (e.g., `422`), rather than silently returning the first request's stored response. Naively replaying is wrong because it makes the second request appear to succeed while doing something the client never actually intended (e.g., returning a $50 charge confirmation for what was meant to be a $99 charge) — a silent, hard-to-debug correctness failure rather than a visible one.
