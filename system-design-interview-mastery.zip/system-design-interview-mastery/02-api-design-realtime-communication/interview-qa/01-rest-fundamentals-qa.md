# Interview Q&A — REST Fundamentals

**Q: What does it mean for an HTTP method to be idempotent, and which standard methods are idempotent by spec?**
Idempotent means calling the operation N times produces the same end state as calling it once. `GET`, `PUT`, and `DELETE` are idempotent by the HTTP spec; `POST` is not — a repeated `POST /orders` naively creates multiple orders, which is why non-idempotent create-with-side-effects operations often need an explicit idempotency-key mechanism.

**Q: What's the difference between `401 Unauthorized` and `403 Forbidden`, precisely?**
`401` means the request lacks valid authentication entirely (no token, or an invalid/expired one) — the client should authenticate and retry. `403` means the request *is* authenticated, but the authenticated identity doesn't have permission for this action — retrying with the same credentials will never succeed; the client needs different credentials or permissions, not just to log in.

**Q: Why is offset-based pagination (`?page=3&limit=20`) problematic for a frequently-updated collection?**
Two issues: correctness and performance. Correctness: if rows are inserted or deleted between page requests, results shift — a user can see the same item twice or skip one entirely. Performance: the database still has to scan and discard `OFFSET` rows before returning the page, so deep pages (high offsets) get progressively slower even though the page size stays constant. Cursor-based pagination (a stable pointer, like the last-seen row's ID) avoids both problems.

**Q: When should you version an API via the URL path vs. a request header?**
URL-path versioning (`/v1/orders`) is more discoverable and cache-friendly (different URLs are naturally different cache keys) and is the common default for public APIs. Header-based versioning keeps a single canonical resource URL but is harder to test ad hoc and can complicate caching, since most caches don't vary on arbitrary headers by default. Neither is "more correct" in isolation — the choice is a tradeoff between discoverability/cacheability and URL stability.

**Q: What's the practical difference between a `400` and a `422` response, and is the distinction always worth making?**
`400` signals the request itself is malformed at the protocol/syntax level (invalid JSON, missing a required field entirely). `422` signals the request is syntactically well-formed but semantically invalid (a field has the wrong value, fails a business-rule validation). The distinction is worth making when clients or monitoring systems act differently on the two (e.g., flagging `400`s as likely client bugs vs. `422`s as expected validation feedback) — in APIs where no consumer distinguishes them, using `400` for both consistently is a defensible simplification, as long as it's applied consistently rather than arbitrarily.
