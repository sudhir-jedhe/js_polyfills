# Interview Q&A — Real-Time Transports

**Q: What's the single most important question to ask when choosing between SSE and WebSockets?**
Whether the client ever needs to send data back to the server in real time over the same channel. If the data flow is purely server-to-client (a live feed, a notification stream, a dashboard), SSE provides push-based delivery with far less complexity — automatic reconnection, plain HTTP, no special infrastructure. WebSockets are justified specifically when low-latency, bidirectional messaging is required (chat, multiplayer games, collaborative editing).

**Q: Why is long polling still relevant when SSE and WebSockets exist?**
It works in restrictive network environments that block persistent connections or the WebSocket upgrade handshake, requires no special client API support beyond plain HTTP, and is a reasonable choice or fallback when update frequency is low enough that per-request overhead isn't a real cost. It's also commonly used as an automatic fallback transport (e.g., by libraries like Socket.IO) when a WebSocket connection can't be established.

**Q: How does `EventSource` (SSE) handle reconnection, and why does that matter operationally?**
`EventSource` automatically reconnects when the connection drops, and if the server includes `id:` fields on events, the browser sends the last-received ID back via a `Last-Event-ID` header on reconnect, letting a well-implemented server resume the stream rather than starting over. WebSockets provide no equivalent — reconnection and any gap-recovery logic must be implemented entirely by hand on the client, including exponential backoff to avoid hammering the server after a widespread outage.

**Q: Why do WebSockets, long polling, and SSE all require a pub/sub layer once you scale past one server instance?**
Because a client's connection is pinned to whichever server instance accepted it, but the event that needs to reach that client might originate on a different instance (e.g., another user's action, or a backend job). Without a shared layer (Redis Pub/Sub, Kafka, etc.) that any instance can publish to and every instance subscribes to, an instance has no way to deliver an event to a connection it doesn't itself hold.

**Q: A WebSocket connection can silently die (half-open TCP) without either side receiving a clean close event. How do servers typically detect this?**
Via a periodic ping/pong heartbeat: the server sends a `ping` frame at a fixed interval and expects a `pong` in response; if a connection fails to respond within a timeout window, the server terminates it and cleans up its resources. Without this, a server can accumulate connections it believes are alive but that are actually dead, wasting memory/file-descriptor resources and, for broadcast use cases, silently failing to deliver messages to those dead connections.
