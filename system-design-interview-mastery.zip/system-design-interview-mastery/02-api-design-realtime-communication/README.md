# API Design & Real-Time Communication

Designing an API well — and choosing the right transport for real-time features — is one of the most consistently tested parts of system design interviews, because it's where abstract architecture meets concrete contracts that other engineers (and client teams) actually build against. This topic covers REST API design principles, the full spectrum of client-server communication patterns (short polling, long polling, SSE, WebSockets — a critical comparison every interviewer expects you to have memorized), webhooks, idempotency, and the API gateway pattern.

## Folder structure

- **`theory/`** — REST design principles, polling vs. SSE vs. WebSockets, webhooks, idempotency, the API gateway pattern, API versioning strategies, and a light-touch GraphQL-vs-REST comparison (cross-referencing the dedicated GraphQL repo for depth).
- **`snippets/`** — 6 practical examples: resource naming, cursor vs. offset pagination, a long-polling server, an SSE server/client, a WebSocket server, and an idempotency-key middleware.
- **`output-based/`** — 5 "given this setup, what happens?" questions covering webhook retries, idempotency-key reuse, WebSocket reconnects, status-code-driven client behavior, and SSE-vs-WebSocket proxy behavior.
- **`scenarios/`** — 5 real-world design/fix scenarios: a real-time notification system, choosing a transport for a live dashboard, an idempotent payment API, an API gateway migration, and debugging duplicate webhook processing.
- **`interview-qa/`** — 4 themed Q&A files: REST fundamentals, real-time transports, webhooks/idempotency, and gateway/versioning.
- **`problems/`** — 4 hands-on challenges: a full REST API design, an idempotency-key middleware implementation, a real-time chat transport design, and a webhook delivery system with retries.
- **`assets/`** — placeholder for diagrams/images (see `assets/README.md`).

## What's covered

- Resource naming, HTTP status code semantics, versioning strategies, and pagination (cursor vs. offset)
- Short polling, long polling, Server-Sent Events, and WebSockets — precisely compared on latency, complexity, scalability, and use case
- Webhooks: delivery guarantees, retries, and the security/verification concerns they introduce
- Idempotency: why it matters for APIs handling retries (especially payments), and how idempotency keys work end to end
- The API gateway pattern: routing, auth, rate limiting, and aggregation at the edge of a microservices architecture
- A light-touch REST vs. GraphQL comparison, deferring to the dedicated GraphQL repo for full depth
