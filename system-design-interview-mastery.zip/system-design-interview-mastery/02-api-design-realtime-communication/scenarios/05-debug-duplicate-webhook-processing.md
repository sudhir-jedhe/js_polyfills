# Scenario: Debug Duplicate Webhook Processing in Production

**Scenario:** An e-commerce platform receives shipping-status webhooks from a logistics provider (`package.delivered`, `package.delayed`, etc.) and forwards a customer-facing SMS notification for each. Customer support starts receiving complaints: some customers get the **same** "your package was delivered" SMS 2-3 times. The webhook handler code:

```js
app.post('/webhooks/shipping', async (req, res) => {
  const event = req.body;
  await sendSmsToCustomer(event.customerId, event.message); // side effect
  res.status(200).send('ok');
});
```

**Step 1 — confirm the delivery pattern, don't assume the cause.** Checking the logistics provider's webhook logs/dashboard shows exactly what the theory file predicts: several deliveries for the same `event_id` were retried because the receiving endpoint occasionally took longer than the provider's timeout to respond (the `sendSmsToCustomer` call itself has variable latency, occasionally exceeding it) — this is at-least-once delivery behaving exactly as documented, not a provider-side bug.

**Step 2 — identify the two independent problems in the handler code, both from the theory file's checklist:**
1. **No idempotency check** — every delivery of the same event, retried or not, unconditionally re-sends the SMS. This is the direct cause of the duplicate messages.
2. **Slow synchronous processing inside the request** — `await sendSmsToCustomer(...)` runs (and can be slow) before the `200` is returned, which is *why* the provider's timeout is being hit in the first place, causing the retries that then collide with problem #1.

**Step 3 — fix both, in the correct order (fixing only #1 leaves the root cause of the retries in place; fixing only #2 reduces retry frequency but doesn't eliminate the risk):**

```js
app.post('/webhooks/shipping', async (req, res) => {
  const event = req.body;

  // atomic idempotency check FIRST — the unique constraint prevents a race
  // between overlapping retries even if they arrive nearly simultaneously
  const inserted = await db.query(
    `INSERT INTO processed_webhook_events (event_id, received_at)
     VALUES ($1, now()) ON CONFLICT (event_id) DO NOTHING RETURNING event_id`,
    [event.event_id]
  );

  if (inserted.rows.length === 0) {
    // already processed (or a duplicate delivery currently in flight) — ack without resending
    return res.status(200).send('ok');
  }

  // enqueue the actual SMS send as an async job instead of awaiting it inline —
  // this lets the handler ack well under the provider's timeout, every time
  await smsQueue.enqueue({ customerId: event.customerId, message: event.message });
  res.status(200).send('ok');
});
```

**Step 4 — verify the fix.** After deployment: duplicate-SMS complaints stop; monitoring on `processed_webhook_events` shows the expected small percentage of `event_id`s receiving multiple delivery attempts (confirming retries are still happening, as expected under at-least-once delivery) while the SMS side effect fires exactly once per `event_id`, visible by cross-referencing the queue's job count against the distinct `event_id` count rather than the raw webhook-delivery count.

**The interview point:** the bug wasn't "the webhook provider is misbehaving" — it was the receiving endpoint missing the two structural requirements (idempotency + fast-ack-then-async) that the webhooks theory file names as non-negotiable for any production webhook receiver, and both needed to be fixed together since they're causally connected (the missing idempotency check turned an unavoidable retry into a customer-visible bug).
