# Scenario: Choosing a Transport for a Live Operations Dashboard

**Scenario:** An internal ops dashboard shows live infrastructure metrics (request rate, error rate, latency percentiles) refreshed every second, viewed by ~50 engineers at once during an incident, on a corporate network with a moderately strict proxy. The team's first instinct is "let's use WebSockets, it's the most real-time option."

**Pushback — walk through the actual requirements before defaulting to WebSockets:**
- **Directionality:** does the dashboard ever need to send data back to the server in real time? No — it's purely a display of metrics computed elsewhere (a metrics pipeline, not user input). This immediately makes WebSockets' bidirectional capability unused overhead, not a requirement.
- **Update frequency:** once per second, for ~50 concurrent viewers — a low, entirely predictable load, nowhere near a scale where connection-holding cost is a real concern regardless of transport chosen.
- **Network environment:** a corporate network with a "moderately strict" proxy — exactly the environment where WebSocket upgrade handshakes are more likely to be blocked or degraded (see the SSE-vs-WebSocket proxy output-based file), an availability risk for a tool specifically meant to be reliable *during incidents*, the worst possible time for it to silently stop updating.

**Decision: SSE.** It matches the one-directional data flow exactly, needs no special corporate-proxy accommodation (plain HTTP streaming), and its automatic reconnection (critical during an incident, when network conditions are often already degraded — the exact moment you can't afford a dashboard that silently stops updating and requires a manual refresh) is a meaningful reliability win over hand-rolling WebSocket reconnect logic for zero directional benefit.

**Implementation sketch:**
```
Metrics pipeline --(every 1s)--> aggregator --publishes--> SSE broadcast layer --> connected dashboard clients
```
Each client opens one `EventSource` connection; the server holds 50 connections (trivial at this scale) and pushes a JSON event once per second per metric batch. If a client's connection drops (a proxy hiccup mid-incident), `EventSource` reconnects on its own with no dashboard code needed to handle it.

**What would change the answer:** if a future requirement emerged where an engineer needed to **acknowledge an alert or annotate the dashboard in real time**, seen live by every other viewer on the same channel, that introduces a genuine bidirectional need — at that point, WebSockets (or a hybrid: SSE for the metric stream, a separate low-volume REST/WebSocket path for annotations) would become the justified choice. The lesson for the interview: **the directionality of the actual data flow, not "which is more real-time-sounding," is the deciding factor**, and re-litigating the transport choice is warranted specifically when the requirements change, not preemptively.
