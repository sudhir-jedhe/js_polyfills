# Scenario: Design an Idempotent Payment API

**Scenario:** A checkout service calls an internal `POST /payments/charge` endpoint to charge a customer's card. In production, customers occasionally report being **double-charged**. Investigation shows the root cause: the checkout service's HTTP client has a 3-second timeout and automatically retries on timeout, but some charges legitimately take longer than 3 seconds to process at the payment processor — the original request eventually succeeds server-side, but the client, having already timed out and retried, has no way to know that.

**Diagnosis:** This is exactly the "POST is not idempotent by default" problem from the theory file, made concrete: the client's retry-on-timeout behavior is reasonable and necessary (network calls do fail transiently, and not retrying at all would mean legitimate transient failures go unrecovered) — but without an idempotency mechanism, "reasonable retry behavior" and "double-charging a customer" become the same code path.

**Fix — idempotency keys, generated once per checkout attempt, not per HTTP request:**

```
Checkout service generates idempotencyKey = uuid() ONCE, when the user clicks "Pay" —
NOT regenerated on each retry attempt.

Attempt 1: POST /payments/charge
  Idempotency-Key: 9f2e-...
  { amount: 4999, cardToken: "tok_1" }
  --> times out after 3s (charge is actually still processing server-side)

Attempt 2 (automatic retry, SAME key):
  POST /payments/charge
  Idempotency-Key: 9f2e-...   <-- same key as attempt 1
  { amount: 4999, cardToken: "tok_1" }
  --> server recognizes the key, sees attempt 1 already completed (or is mid-flight),
      returns the ORIGINAL result rather than charging again
```

The payment endpoint implements the idempotency-key middleware pattern from the snippets file, with one important addition specific to payments: while the original request is still **in-flight** (not yet completed) when the retry arrives, the server must not simply reject or silently ignore the retry — it should either **block/wait briefly** for the in-flight attempt to finish and then return its result, or return a `409` explicitly signaling "still processing, retry after a short delay" — never silently succeed with a *new* charge attempt just because the first hadn't finished yet.

**Additional layer — request-body fingerprinting** (see the idempotency-key-reuse output-based file): store a hash of the charge amount + card token alongside the key, and reject (rather than blindly replay) any request reusing a key with a **different** amount — protecting against a client-side bug accidentally reusing a stale key across two different checkout attempts.

**Verification this actually fixes the bug:** after deployment, the double-charge reports stop, and monitoring on the `idempotency_keys` table shows the expected pattern — a small percentage of keys receiving 2 requests (the timeout+retry case), correctly resulting in exactly one actual charge each, visible as one `completed` row per key regardless of how many requests referenced it.

**The interview point:** the fix isn't "don't retry" (retries are necessary for a resilient system) and isn't "increase the timeout" (doesn't eliminate the race, just makes it rarer) — it's making the *operation itself* safe to repeat, which is the only fix that closes the gap for every future timing scenario, not just the specific 3-second one observed.
