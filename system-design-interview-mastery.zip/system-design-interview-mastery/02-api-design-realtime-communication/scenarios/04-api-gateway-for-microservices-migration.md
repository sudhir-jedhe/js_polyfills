# Scenario: Introducing an API Gateway During a Microservices Migration

**Scenario:** A company is mid-migration from a monolith to microservices (see the fundamentals topic's migration scenario for the extraction strategy). Two services have been extracted so far (recommendations, notifications), with the rest still living in the monolith. Mobile and web clients currently call the monolith directly for most things, but now also need to call the two new services directly — client code has started accumulating conditional logic like "if this is a recommendations call, hit `recs.internal.company.com`; otherwise hit the monolith's URL," and each service has independently implemented its own auth-token validation.

**Diagnosis:** This is the exact pain the API gateway pattern exists to solve, appearing right on schedule as the migration proceeds — clients are being forced to know about the system's internal service topology (which should be an implementation detail, not a client-facing contract), and auth logic is being duplicated across services rather than centralized, meaning a future auth-policy change (e.g., adding a new required scope check) has to be replicated correctly in N places.

**Fix — introduce a gateway as the single client-facing entry point:**
```
Before:
  Client -----> monolith.company.com  (most traffic)
  Client -----> recs.internal.company.com
  Client -----> notifications.internal.company.com

After:
  Client -----> api.company.com (gateway)
                    |
                    +--> routes /recommendations/* --> recs service
                    +--> routes /notifications/* --> notifications service
                    +--> routes everything else --> monolith
```

**Migration steps, staged to avoid a risky big-bang cutover:**
1. Deploy the gateway routing **100% of traffic straight through to the monolith**, unchanged — this validates the gateway's own reliability and latency overhead in production before it's doing anything more than passthrough, with zero behavior change for clients.
2. Move auth-token validation **into the gateway**, injecting a trusted `X-User-Id` header downstream — each service can now drop its own duplicated auth-validation code and trust the header, since only the gateway can reach them directly (enforced via network policy — the individual services should not be publicly reachable at all once this lands).
3. Add routing rules for the two already-extracted services (`/recommendations/*`, `/notifications/*`) so clients switch to calling `api.company.com` exclusively — clients no longer need to know these services exist as separate deployments at all.
4. As future services get extracted from the monolith, adding their route to the gateway becomes a small, low-risk config change — the client-facing contract (one base URL) never needs to change again for the rest of the migration, which is the actual point: the gateway decouples the pace and shape of the *backend* migration from any client-visible change.

**Bottleneck called out proactively:** the gateway now sees 100% of the system's traffic and is a new single point of failure if not itself made redundant — the plan explicitly includes running multiple gateway instances behind their own load balancer from day one (step 1), not as an afterthought once traffic grows.

**The interview point:** introducing a gateway mid-migration, staged as passthrough-first, is a materially better answer than either "add it all on day one before any service exists" (nothing to route to yet) or "wait until the migration is fully done" (clients accumulate exactly the topology-leaking, auth-duplicating mess described in this scenario in the meantime) — the gateway should be introduced as soon as there's more than one backend a client needs to reach.
