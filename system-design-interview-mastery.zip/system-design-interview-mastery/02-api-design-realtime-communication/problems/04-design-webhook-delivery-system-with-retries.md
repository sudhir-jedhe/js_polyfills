# Problem: Design a Webhook Delivery System (Sender Side) With Retries

## Problem Statement

Design the **sending** side of a webhook system for a SaaS platform: when an event occurs (e.g., `invoice.paid`), deliver it via `POST` to each subscribing customer's registered callback URL, with retries on failure, signature-based authenticity, and a way for customers to inspect/replay failed deliveries.

## Constraints

- Must not let one slow or dead customer endpoint block delivery to others.
- Must implement bounded retries with backoff, not infinite or immediate retries.
- Must let a customer verify a delivery genuinely came from this platform.
- Must expose delivery history/replay for debugging.

## Solution

**High-level flow:**
```
Event occurs (e.g., invoice.paid) --> written to `webhook_deliveries` table (one row per subscriber per event)
                                              |
                                      Delivery Worker Pool (async, decoupled from the event's originating request)
                                              |
                                  POST to subscriber's URL, with HMAC signature header
                                              |
                              2xx? --> mark 'delivered'
                              non-2xx / timeout? --> mark 'failed', schedule retry with backoff
```

**Why delivery must be decoupled from the triggering event (async worker pool, not inline):**
If invoice payment processing directly, synchronously, called out to every subscriber's webhook URL before responding to the original request, one slow or dead customer endpoint would add latency (or outright block, at a timeout) to the core `invoice.paid` business flow for everyone — an unrelated customer's broken webhook endpoint should never be able to degrade the platform's own core functionality. Writing a durable delivery record and processing it via an independent worker pool fully isolates the two.

**Schema:**
```sql
CREATE TABLE webhook_deliveries (
  id              UUID PRIMARY KEY,
  subscriber_id   UUID NOT NULL,
  event_id        UUID NOT NULL,       -- unique per business event; sent as part of the payload for receiver-side idempotency
  event_type      TEXT NOT NULL,
  payload         JSONB NOT NULL,
  url             TEXT NOT NULL,
  status          TEXT NOT NULL DEFAULT 'pending', -- pending | delivered | failed | exhausted
  attempt_count   INT NOT NULL DEFAULT 0,
  next_attempt_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_error      TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_webhook_deliveries_pending ON webhook_deliveries (next_attempt_at) WHERE status IN ('pending', 'failed');
```

**Retry logic (exponential backoff, bounded attempts):**
```js
const BACKOFF_SCHEDULE_SECONDS = [30, 300, 1800, 7200, 21600]; // 30s, 5m, 30m, 2h, 6h — 5 attempts total

async function attemptDelivery(delivery) {
  const signature = signPayload(delivery.payload, subscriberSecret(delivery.subscriber_id));
  try {
    const res = await httpPost(delivery.url, delivery.payload, {
      headers: { 'X-Signature': signature, 'X-Event-Id': delivery.event_id },
      timeoutMs: 5000,
    });
    if (res.status >= 200 && res.status < 300) {
      return markDelivered(delivery.id);
    }
    throw new Error(`non-2xx status: ${res.status}`);
  } catch (err) {
    const nextAttempt = delivery.attempt_count + 1;
    if (nextAttempt >= BACKOFF_SCHEDULE_SECONDS.length) {
      return markExhausted(delivery.id, err.message); // give up, surface in dashboard for manual replay
    }
    return scheduleRetry(delivery.id, nextAttempt, BACKOFF_SCHEDULE_SECONDS[nextAttempt], err.message);
  }
}
```

**Signature generation, so subscribers can verify authenticity:**
```js
const crypto = require('crypto');
function signPayload(payload, secret) {
  const raw = JSON.stringify(payload); // subscribers must verify against this exact raw serialization
  return crypto.createHmac('sha256', secret).update(raw).digest('hex');
}
```

**Isolation between subscribers:** since each subscriber has its own row(s) in `webhook_deliveries` and its own retry schedule, a slow or permanently-broken endpoint for Subscriber A only ever affects Subscriber A's delivery queue — Subscriber B's deliveries are picked up and processed independently by the worker pool, satisfying the "one dead endpoint can't block others" constraint directly through the data model, not just through async processing.

**Replay/debugging surface:** a `GET /webhook-deliveries?subscriberId=...&status=exhausted` endpoint (or dashboard) lets a customer see failed/exhausted deliveries with `last_error`, and a `POST /webhook-deliveries/:id/replay` endpoint resets `status` to `pending` and `next_attempt_at` to now, re-queuing it for one more attempt — giving customers a self-service recovery path after fixing whatever was wrong with their endpoint, without needing platform support intervention.

## Bottlenecks & tradeoffs

The `webhook_deliveries` table is a natural candidate for time-based partitioning/archival once delivered rows accumulate (they're append-mostly, read-rarely once `delivered`) — flagged proactively as a future scaling concern rather than solved on day one, since it doesn't block correctness at moderate scale.
