# Problem: Design a REST API for E-Commerce Orders

## Problem Statement

Design the REST API surface for an e-commerce order management system covering: creating an order, viewing an order, listing a customer's orders (paginated), cancelling an order, and issuing a partial refund. Specify endpoints, methods, status codes, and request/response shapes.

## Constraints

- Must correctly distinguish idempotent from non-idempotent operations and handle retries safely where needed.
- Pagination must be stable under concurrent order creation (i.e., cursor-based).
- Cancellation and refund are business actions with side effects, not plain field updates.

## Solution

**Create an order — `POST /orders`** (not idempotent by default; requires an idempotency key since this is a side-effecting, payment-adjacent action):
```
POST /orders
Idempotency-Key: 7d8f2a...
{
  "customerId": "cust_42",
  "items": [{ "productId": "prod_9", "quantity": 2 }],
  "shippingAddressId": "addr_3"
}

--> 201 Created
Location: /orders/ord_501
{ "id": "ord_501", "status": "pending", "total": 4998, "createdAt": "..." }
```

**View a single order — `GET /orders/:id`** (safe, idempotent):
```
GET /orders/ord_501
--> 200 OK  { "id": "ord_501", "status": "pending", "items": [...], "total": 4998 }
--> 404 Not Found  { "error": "order not found" }   (if it doesn't exist or belongs to another customer)
```

**List a customer's orders, cursor-paginated — `GET /orders`:**
```
GET /orders?customerId=cust_42&after=<cursor>&limit=20
--> 200 OK
{
  "orders": [ { "id": "ord_501", "status": "pending", "total": 4998 }, ... ],
  "nextCursor": "eyJjcmVhdGVkQXQiOi4uLn0="
}
```
Cursor-based (not offset) because orders are created continuously — offset pagination would risk showing duplicate or skipped orders to a customer scrolling their order history while new orders are placed (see the cursor-vs-offset snippet for the underlying mechanism).

**Cancel an order — `POST /orders/:id/cancel`** (modeled as an action endpoint, not `PATCH {status: "cancelled"}`, because cancellation has side effects — refund initiation, inventory release — beyond a field update; naturally idempotent by design since cancelling an already-cancelled order is a no-op, not a new event):
```
POST /orders/ord_501/cancel
--> 200 OK  { "id": "ord_501", "status": "cancelled" }
--> 409 Conflict  { "error": "cannot cancel an order that has already shipped" }
```
`409` here correctly signals a state conflict (the request was valid, but current order state forbids this transition) — distinct from `400`, so a client/monitoring system can tell "user tried something invalid given current state" apart from "malformed request."

**Partial refund — `POST /orders/:id/refund`** (a financial side effect; requires an idempotency key for the same reason order creation does):
```
POST /orders/ord_501/refund
Idempotency-Key: a1b2c3...
{ "amount": 1500, "reason": "damaged_item" }

--> 201 Created  { "refundId": "ref_88", "amount": 1500, "status": "processed" }
--> 422 Unprocessable Entity  { "error": "refund amount exceeds order total" }
```

## Why each design choice was made

- **Idempotency keys on `POST /orders` and `POST /orders/:id/refund`** specifically, not on every endpoint — these are the two operations with a real, costly double-execution risk (duplicate order, duplicate refund); `GET` is naturally idempotent and `POST /orders/:id/cancel` is naturally idempotent by its own state-machine semantics (cancelling twice has the same end state as cancelling once), so a key isn't strictly required there, though including one is harmless.
- **Cursor pagination** on the list endpoint specifically because it's a live, continuously-growing collection — a low-write, rarely-changing collection could reasonably use simpler offset pagination without the same correctness risk.
- **Distinct 404 / 409 / 422** rather than collapsing failures into `400`, so automated retry/monitoring logic downstream (a mobile app, an internal dashboard) can react correctly per failure type, per the status-code output-based file's reasoning.
