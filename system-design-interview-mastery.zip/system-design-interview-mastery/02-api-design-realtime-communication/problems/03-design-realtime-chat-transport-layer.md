# Problem: Design the Real-Time Transport Layer for a Chat Application

## Problem Statement

Design the transport layer for a group chat feature supporting: sending/receiving messages in real time, typing indicators, read receipts, and reliable message delivery across brief disconnects (mobile network switches, backgrounding). Justify the transport choice and address multi-instance fan-out.

## Constraints

- Must support bidirectional real-time data (messages sent by the client, not just received).
- Must not lose messages sent while a client was briefly disconnected.
- Must work across multiple server instances (assume a fleet behind a load balancer).

## Solution

**Transport choice: WebSockets.** Unlike the live-dashboard and notification scenarios elsewhere in this topic, chat has a genuine bidirectional real-time requirement — a client both *receives* other users' messages and *sends* its own messages and typing indicators over the same low-latency channel. This is precisely the case the polling/SSE/WebSocket comparison theory file identifies as justifying WebSockets' extra complexity over SSE.

**Connection and room model:**
```
Client --(WS upgrade)--> Gateway/LB --> App instance holds the live socket
                                            |
Client sends: { type: "message", roomId, text }
                                            |
                                    App instance --> validate, persist to DB, publish to Redis Pub/Sub channel "room:<roomId>"
                                            |
                          Every app instance subscribed to "room:<roomId>" --> forwards to its own locally-connected
                          members of that room over their held WebSocket connections
```

**Deep dive — reliable delivery across brief disconnects (the hardest requirement here):**
1. **Every message is durably persisted to the database first**, before (or atomically alongside) being published for real-time delivery — the WebSocket push is a delivery optimization, not the source of truth, exactly mirroring the notification-system scenario's design.
2. **Each message gets a monotonically increasing, per-room sequence number** (or a `(created_at, id)` tuple, as in the cursor-pagination pattern) at write time.
3. **On reconnect**, the client sends the last sequence number it successfully processed; the server responds with a catch-up batch (`GET /rooms/:id/messages?after=<lastSeq>`) **before** re-subscribing the client to the live stream, and the client reconciles by sequence number (discarding anything it already has) to avoid duplicating a message that arrives via both the catch-up fetch and a near-simultaneous live push.

**Deep dive — typing indicators are deliberately NOT durably persisted:**
Unlike messages, typing indicators are ephemeral, low-stakes, and extremely high-frequency (fired on every keystroke, debounced client-side) — persisting them to the database would be pure waste. They're published directly to the room's Pub/Sub channel and forwarded live, with no catch-up/replay on reconnect (a missed typing indicator has zero lasting impact, unlike a missed message) — an intentional, explicitly justified asymmetry in durability requirements between two features on the same transport.

**Deep dive — read receipts** sit in between: they matter enough to persist (so "seen" state survives a reconnect and is visible to other room members later) but don't need the strict ordering guarantees messages do — a `PUT /rooms/:id/read-receipt {lastReadMessageId}` (idempotent by design — setting the same value twice is a no-op) is written to the DB and broadcast via the same Pub/Sub mechanism as messages, but without needing the sequence-number reconciliation messages require.

## Bottlenecks & tradeoffs

The Redis Pub/Sub layer becomes a hard dependency for cross-instance delivery — its own availability now gates real-time chat delivery system-wide, worth calling out explicitly rather than treating it as a free add-on. The per-instance WebSocket connection count is the primary horizontal-scaling axis for the app tier here (very different from a typical stateless request/response service, since each held connection has a real, ongoing memory/file-descriptor cost) — capacity planning for this tier should be driven by concurrent-connection count, not request throughput.
