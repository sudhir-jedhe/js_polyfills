# Problem: Implement Idempotency-Key Middleware From Scratch

## Problem Statement

Implement idempotency-key middleware for an Express-based API that: (1) safely handles concurrent requests sharing a new key, (2) replays the original response for a repeated key, (3) detects and rejects key reuse across requests with different payloads, and (4) expires old keys after 24 hours.

## Constraints

- Must be correct under concurrency (no double-execution race).
- Must not require every endpoint to opt in manually with bespoke code — a single reusable middleware.
- Include the schema and an expiry/cleanup mechanism.

## Solution

**Schema:**
```sql
CREATE TABLE idempotency_keys (
  key             TEXT PRIMARY KEY,
  request_hash    TEXT NOT NULL,
  status          TEXT NOT NULL DEFAULT 'processing', -- 'processing' | 'completed'
  response_status INT,
  response_body   TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_idempotency_keys_created_at ON idempotency_keys (created_at);
```

**Middleware:**
```js
const crypto = require('crypto');

function hashBody(body) {
  return crypto.createHash('sha256').update(JSON.stringify(body)).digest('hex');
}

async function idempotencyMiddleware(req, res, next) {
  const key = req.header('Idempotency-Key');
  if (!key) return next();

  const requestHash = hashBody(req.body);

  const inserted = await db.query(
    `INSERT INTO idempotency_keys (key, request_hash, status)
     VALUES ($1, $2, 'processing')
     ON CONFLICT (key) DO NOTHING
     RETURNING key`,
    [key, requestHash]
  );

  if (inserted.rows.length === 0) {
    // key already exists — inspect it
    const { rows } = await db.query(
      'SELECT request_hash, status, response_status, response_body FROM idempotency_keys WHERE key = $1',
      [key]
    );
    const existing = rows[0];

    if (existing.request_hash !== requestHash) {
      // same key, different payload — client bug, do NOT replay a mismatched response
      return res.status(422).json({
        error: 'Idempotency-Key was reused with a different request payload',
      });
    }

    if (existing.status === 'completed') {
      return res.status(existing.response_status).json(JSON.parse(existing.response_body));
    }

    // still processing (a concurrent duplicate request) — tell the client to back off briefly
    return res.status(409).json({ error: 'a request with this idempotency key is already in progress' });
  }

  // first time seeing this exact key+payload combination — wrap res.json to persist the result
  const originalJson = res.json.bind(res);
  res.json = async (body) => {
    await db.query(
      `UPDATE idempotency_keys SET status = 'completed', response_status = $1, response_body = $2 WHERE key = $3`,
      [res.statusCode, JSON.stringify(body), key]
    );
    return originalJson(body);
  };

  next();
}

module.exports = idempotencyMiddleware;
```

**Expiry/cleanup — a scheduled job, not inline per-request logic (keeps the hot request path simple):**
```js
// run e.g. hourly via a cron job / scheduled task
async function cleanupExpiredIdempotencyKeys() {
  await db.query(
    `DELETE FROM idempotency_keys WHERE created_at < now() - interval '24 hours'`
  );
}
```

## Why each piece is necessary

- **The `INSERT ... ON CONFLICT DO NOTHING ... RETURNING` is the linchpin** for concurrency safety — it's a single atomic database statement, so of two concurrent requests with a brand-new identical key, exactly one gets a returned row (and proceeds to execute the handler) and the other correctly falls into the "already exists" branch.
- **`request_hash` comparison** closes the key-reuse-with-different-payload gap (see the corresponding output-based file) — without it, a client bug silently returns a stale, mismatched response instead of surfacing the error.
- **A separate `status: 'processing'` state**, distinct from `'completed'`, lets the middleware correctly tell a genuinely-concurrent in-flight duplicate ("come back shortly") apart from an already-finished one ("here's your original result") — collapsing these into one state would either double-execute the handler or incorrectly reject a request that should have succeeded.
- **A scheduled cleanup job**, not per-request expiry checks, keeps the request-handling code path free of extra latency and lets the retention window (24h) be tuned independently of request volume.
