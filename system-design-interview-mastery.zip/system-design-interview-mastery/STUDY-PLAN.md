# Suggested Study Plan

A 4-week plan, ~60 min/day (system design needs longer, unhurried sessions more than quick drills).

## Week 1 — Backend/distributed fundamentals

- Day 1–2: `01-system-design-fundamentals-scalability` (the estimation framework — practice it until it's
  automatic, you'll use it in every case study)
- Day 3–4: `02-api-design-realtime-communication`
- Day 5–6: `03-caching-strategies`
- Day 7: `04-database-design-scaling`

## Week 2 — Scaling mechanics & frontend architecture

- Day 1–2: `05-rate-limiting-load-balancing` (the token bucket vs sliding window deep-dive comes up a lot)
- Day 3–4: `06-frontend-architecture-folder-structure`
- Day 5–7: `07-frontend-rendering-performance` (the biggest frontend topic — Core Web Vitals, critical
  rendering path, virtualization)

## Week 3 — Frontend-specific concerns

- Day 1–2: `08-frontend-state-management`
- Day 3–4: `09-frontend-security`
- Day 5: `10-accessibility-at-scale`
- Day 6–7: `11-offline-support-pwa`

## Week 4 — Component design & full case studies

- Day 1–2: `12-low-level-design-component-patterns` (practice designing the component API out loud, not just
  reading — this is exactly the LLD interview format)
- Day 3–7: `13-hld-case-studies` — one full case study per day, talked through out loud as if in an
  interview, then compared against your own real implementation (see `SOURCE-MAP.md`)

## Interview-week fast pass

1. Redo the estimation framework from `01-system-design-fundamentals-scalability/theory/` from memory
2. Pick 2 case studies from `13-hld-case-studies/problems/` you haven't done recently and do them cold, timed
3. `scenarios/` for `03-caching-strategies`, `05-rate-limiting-load-balancing`, `07-frontend-rendering-performance`
4. Comparison tables across the repo — SQL vs NoSQL, polling vs SSE vs WebSockets, token bucket vs sliding
   window, local vs global vs server state
