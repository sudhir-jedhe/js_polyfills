# Interview Q&A — HTTP Caching

**Q: What's the precise difference between `Cache-Control: no-cache` and `Cache-Control: no-store`?**
`no-cache` still permits storing the response, but requires revalidation with the origin before every reuse — it's not "don't cache," it's "cache, but always check first." `no-store` is the strict directive meaning the response must not be stored anywhere at all, used for genuinely sensitive data like banking pages. Confusing the two is a common and consequential mistake — `no-cache` alone doesn't protect sensitive data the way `no-store` does.

**Q: How do `max-age` and `s-maxage` differ, and why would you ever set both?**
`max-age` applies to any cache, including a private browser cache; `s-maxage` applies specifically to shared caches (a CDN, a proxy) and overrides `max-age` for them when both are present. Setting both lets an origin give a different freshness window to browsers than to CDN edges — e.g., a short `max-age` so each individual user always revalidates for personalization purposes, alongside a longer `s-maxage` so the CDN can still cache the shared, non-personalized parts efficiently.

**Q: What does `ETag`-based conditional revalidation actually save, and what does it NOT save?**
It saves re-transferring the full response body when the content hasn't changed — the origin responds `304 Not Modified` with an empty body instead of `200` with the full payload. It does NOT save the request itself — a conditional request still requires a full round trip to the origin (or the shared cache serving as origin for that check); ETag only reduces the transfer size of that round trip's response, not whether the round trip happens at all.

**Q: Why is `ETag` generally preferred over `Last-Modified` when both are available?**
`ETag` (typically a content hash) changes if and only if the content actually changed, giving precise change detection. `Last-Modified` only has second-level granularity and can miss a change that happens within the same second, or falsely signal a change when a file is re-saved with identical content but a new modification timestamp — `ETag` avoids both failure modes.

**Q: What does `stale-while-revalidate` actually guarantee, and what's the one-reload lag it introduces?**
It guarantees that once `max-age` expires, the client is served the (now-stale) cached response immediately, without waiting on a network round trip, while a background request silently refreshes the cache. The lag: the client that triggers the background refresh doesn't itself see the refreshed content — it sees the stale version and the refresh happens after that response is sent — so the *next* reload after a background revalidation is the first one to actually show updated content, not the reload that triggered it.
