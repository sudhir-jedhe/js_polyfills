# Interview Q&A — Redis and Database Caching

**Q: What makes a query or dataset a good candidate for caching, precisely — beyond "it's read often"?**
A favorable read-to-write ratio for that *specific* piece of data — reading it far more often than it changes. High read volume alone isn't sufficient: data that's read once and rarely again gains nothing from caching (it wastes cache memory), and data that changes on nearly every write (if invalidated per-write) can produce a near-100% cache miss rate, adding overhead with no real benefit.

**Q: Why is consistent, entity-scoped Redis key naming (e.g., `user:42:profile`) more than a style preference?**
It makes bulk invalidation for a single entity feasible (a pattern scan/delete over `user:42:*` when needed) and makes debugging and monitoring tractable — without a convention, it becomes very difficult to reason about which keys correspond to which underlying data, or to safely invalidate everything related to one entity when it changes.

**Q: When should you reach for a Redis Sorted Set instead of a plain string for a cached value?**
When the cached data is naturally ordered and range-queryable — a leaderboard, or a cached activity feed/timeline where the score is a timestamp and members are item IDs — a Sorted Set lets you efficiently fetch "the top N" or "everything after timestamp X" directly from Redis without deserializing and re-sorting a full blob on every read.

**Q: Beyond avoiding a database round trip, what's another common reason to cache a value?**
Caching the result of an expensive *computation* — an aggregation across multiple rows/tables, a call to a slow third-party API, a complex join — not just a raw row lookup. Framing caching this way (avoiding recomputation, not just avoiding I/O) is relevant because the "cost" being saved, and therefore the right TTL and invalidation strategy, is different for a cheap key-value lookup versus an expensive multi-second aggregate.

**Q: Why should a cache generally not be treated as a system's source of truth?**
Because caches are optimized for speed and eviction, not durability or correctness — most caches (Redis included, unless specifically configured with persistence and replication for that purpose) can lose data on a crash or restart, and cache-aside's whole design assumes the database is always the authoritative fallback. Treating a cache as authoritative removes the safety net that makes cache outages a performance problem rather than a data-loss problem.
