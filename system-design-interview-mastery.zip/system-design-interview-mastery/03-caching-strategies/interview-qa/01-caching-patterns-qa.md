# Interview Q&A — Caching Patterns

**Q: In cache-aside, why do you delete the cache key on a write instead of updating it with the new value directly?**
Updating the cache directly on write introduces a race condition: a concurrent read that started before the write can finish reading the old value from the database *after* the write's cache-update, silently overwriting the correct new value with a stale one. Deleting the key instead is simpler and self-healing — the next read is guaranteed to miss, re-read the current database value, and repopulate the cache correctly.

**Q: What's the durability risk specific to write-behind caching, and when is it an acceptable tradeoff?**
Write-behind acknowledges a write as soon as it hits the cache, deferring the database write to an async batch flush — if the cache crashes before that flush completes, the write is lost permanently, since it never existed anywhere else. It's an acceptable tradeoff for high-volume, loss-tolerant data like view counters or analytics events, where losing a small window of writes on a rare crash has negligible real-world cost — it's not acceptable for data like inventory counts or financial ledgers, where a lost write causes a real correctness failure.

**Q: When would write-around be the better choice over cache-aside for the write side?**
When data is written much more frequently than it's read, or newly-written data has low likelihood of being read again soon — write-around avoids populating the cache with data on write, keeping cache space reserved for data that's actually likely to be re-read, at the cost of the first read after a write always being a cache miss.

**Q: A cache-aside setup shows the cache and database disagreeing after a period of normal operation, despite invalidation logic appearing correct on review. What's a common cause worth checking?**
A straddling-read race condition: a read that started before a write can finish (reading the pre-write value from the database) and then complete its own cache-populate step *after* the write's invalidation, overwriting the correctly-cleared cache with a stale value. This is a known, narrow race in cache-aside — mitigations include a short TTL as a bound, a delayed second delete after the write's initial invalidation, or a versioned-write check.

**Q: Why is choosing "cache-aside vs. write-through vs. write-behind vs. write-around" a per-feature decision rather than a single system-wide choice?**
Because different data within the same system has different staleness tolerance and write-loss tolerance — an inventory decrement gating an actual sale needs write-through's guaranteed consistency, while a view counter can safely use write-behind's lower latency despite its durability risk. Picking one pattern uniformly for an entire system either over-pays for consistency on data that doesn't need it, or under-protects data that does.
