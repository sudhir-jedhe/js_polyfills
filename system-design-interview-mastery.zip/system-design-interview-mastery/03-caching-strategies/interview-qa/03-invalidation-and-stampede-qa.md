# Interview Q&A — Invalidation and Cache Stampede

**Q: Why should TTL-based invalidation and event-based invalidation be used together rather than either alone?**
Event-based invalidation (deleting a cache key immediately on write) gives a tight staleness bound but depends on the write path correctly identifying every affected cache key — a missed key (e.g., a derived aggregate that a write should have invalidated but didn't) leaves stale data with no other correction mechanism. A TTL, layered on top, guarantees an absolute upper bound on staleness even when event-based invalidation fails or misses a key — the two are complementary, not redundant.

**Q: What's the most common real-world invalidation bug, specifically?**
Missing a "derived" cache key on write — a write to one entity (e.g., a product's price) correctly invalidates that entity's own cache key, but fails to invalidate other cache entries computed *from* it (a category listing, a search results page, an aggregate report that includes that product). The write path has to know the full set of cache keys a change affects, which grows harder to track correctly as more derived views accumulate.

**Q: Define cache stampede (thundering herd) precisely — what exactly happens, and why does it hurt more than the equivalent steady-state traffic would?**
When a hot cache key expires or is invalidated, every concurrent request that misses it independently falls through to recompute/refetch the same value at the same time — a burst of redundant, identical work hitting the backend simultaneously. It hurts more than steady-state traffic because it's *correlated* — N requests doing the same expensive work in the same instant, rather than the same total work spread out over time, which is what backend capacity is normally provisioned for.

**Q: How does a distributed lock prevent a stampede, and what happens to the requests that don't get the lock?**
The first request to miss acquires a short-lived lock (e.g., a Redis `SET key NX EX ttl`) and proceeds to recompute the value; every other concurrent request sees the lock already held and does NOT also recompute — instead it waits briefly and re-reads the cache (now populated by the lock-holder), or falls back to computing it itself only as a last resort if the wait times out. This collapses N redundant computations down to effectively 1, regardless of how large the concurrent burst is.

**Q: Besides locking, name two other stampede mitigations and what each specifically protects against.**
Jittered TTLs (randomizing each key's expiry slightly, e.g., ±10%) protect against a *correlated wave* of many different keys expiring at the same synchronized instant, which a single-key lock doesn't address. Proactive/pre-emptive background refresh (recomputing a hot key's value before its TTL naturally expires, e.g., at 90% of TTL) avoids the miss window — and therefore the stampede risk — entirely for keys known in advance to be hot, at the cost of some refresh work that's occasionally wasted if the key falls out of popularity before the natural expiry would have hit.
