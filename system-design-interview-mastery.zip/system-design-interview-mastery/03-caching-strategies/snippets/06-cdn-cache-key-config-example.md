# Snippet: CDN Cache-Key Normalization Config

A representative CDN edge config (syntax generalized/illustrative — the exact config language varies by provider, but the concepts apply broadly) demonstrating query-parameter normalization to avoid accidentally fragmenting the cache.

```yaml
# Without normalization, EVERY distinct combination of query params is a
# separate cache entry — a marketing campaign appending tracking params
# can silently multiply cache misses for otherwise-identical content:
#   /products/5?utm_source=email
#   /products/5?utm_source=email&utm_campaign=summer
#   /products/5                          <- these should ALL be one cache entry

cache_rules:
  - match: "/products/*"
    cache_key:
      # only these params affect the actual response content —
      # everything else (utm_*, fbclid, gclid, session-ish params) is stripped
      # from the cache key entirely, so they don't fragment the cache
      include_query_params: ["variant", "currency"]
    ttl: 300s
    stale_while_revalidate: 600s

  - match: "/static/*"
    cache_key:
      include_query_params: []   # static assets ignore query params entirely for caching
    ttl: 31536000s               # 1 year — paired with content-hashed filenames
    immutable: true

  - match: "/api/user/*"
    cache_key:
      vary_by_header: ["Authorization"]  # per-user content — must not be shared across users
    ttl: 0                              # effectively uncacheable at the edge; passthrough to origin
```

**Purge on deploy/content-change:**

```bash
# targeted purge — invalidate a specific path across all edge locations
curl -X POST "https://cdn.example.com/api/purge" \
  -H "Authorization: Bearer $CDN_API_TOKEN" \
  -d '{"paths": ["/products/5"]}'

# NOTE: purge propagation is NOT instantaneous — expect a delay (seconds to
# a couple of minutes depending on provider) before every edge location
# reflects the purge. For urgent corrections (legal takedown, pricing error),
# don't rely on purge speed alone — pair with a short TTL as the real safety net.
```

**Why stripping tracking params from the cache key matters at scale:** for a product page that's otherwise perfectly cacheable, uncontrolled query-param proliferation can drop the effective cache hit rate from ~95% to under 50% during a marketing push, silently multiplying origin load exactly when traffic (and thus origin cost/risk) is highest — this is a real, commonly-hit production issue, not a theoretical edge case.
