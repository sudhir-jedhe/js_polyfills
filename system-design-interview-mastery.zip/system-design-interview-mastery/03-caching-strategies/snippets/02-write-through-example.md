# Snippet: Write-Through Cache (Node)

```js
async function updateUserSettings(userId, settings) {
  const cacheKey = `user:${userId}:settings`;

  // write to BOTH the cache and the DB before acknowledging the caller —
  // this is what makes it "write-through" rather than cache-aside's
  // "write to DB, then just delete the cache key"
  await Promise.all([
    redis.set(cacheKey, JSON.stringify(settings), { EX: 3600 }),
    db.query(
      'UPDATE user_settings SET data = $1 WHERE user_id = $2',
      [JSON.stringify(settings), userId]
    ),
  ]);

  // caller only gets an ack once BOTH writes have succeeded —
  // if either fails, treat the whole operation as failed (don't leave
  // the cache and DB disagreeing)
}

async function getUserSettings(userId) {
  const cacheKey = `user:${userId}:settings`;
  const cached = await redis.get(cacheKey);
  if (cached) return JSON.parse(cached);

  // this path should be rare under write-through (only hit after a TTL
  // expiry or a cache eviction, never right after a write) — the cache
  // should already be warm from the write path above
  const row = await db.query('SELECT data FROM user_settings WHERE user_id = $1', [userId]);
  if (row) await redis.set(cacheKey, JSON.stringify(row.data), { EX: 3600 });
  return row?.data ?? null;
}
```

**Contrast with cache-aside's write path:** cache-aside's `updateProduct` (previous snippet) only touches the DB on write and lets the cache miss naturally on the next read. This write-through version pays extra latency on every write (two synchronous writes, not one) specifically to guarantee the cache is *never* stale, even for a fraction of a second — the right tradeoff when `getUserSettings` is called immediately after almost every settings update (e.g., a settings page that re-renders from a fresh fetch right after saving) and that read-after-write path needs to always be a cache hit.
