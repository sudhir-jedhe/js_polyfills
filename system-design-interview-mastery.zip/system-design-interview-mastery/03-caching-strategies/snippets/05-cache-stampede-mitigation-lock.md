# Snippet: Cache Stampede Mitigation via Distributed Lock

```js
const redis = require('redis').createClient();

async function getWithStampedeProtection(key, fetchFn, ttlSeconds = 300) {
  const cached = await redis.get(key);
  if (cached) return JSON.parse(cached);

  // cache miss — try to acquire a short-lived lock so only ONE caller
  // actually recomputes the value; NX = only set if not already set
  const lockKey = `lock:${key}`;
  const gotLock = await redis.set(lockKey, '1', { NX: true, EX: 10 }); // 10s lock TTL

  if (gotLock) {
    try {
      const value = await fetchFn(); // the expensive DB query / computation
      await redis.set(key, JSON.stringify(value), { EX: ttlSeconds });
      return value;
    } finally {
      await redis.del(lockKey); // release promptly so the next expiry isn't blocked unnecessarily
    }
  }

  // did NOT get the lock — someone else is already recomputing this key.
  // Wait briefly and retry reading the cache, rather than also hitting the DB.
  await sleep(50);
  const retried = await redis.get(key);
  if (retried) return JSON.parse(retried);

  // still not there after a short wait (rare — the lock-holder is slow or crashed) —
  // fall through to computing it ourselves as a last resort, rather than waiting forever
  return fetchFn();
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
```

**What this achieves under a stampede:** if 500 concurrent requests all miss the same expired key at once, exactly **one** of them wins the `SET ... NX` lock and performs the expensive `fetchFn()` (e.g., a slow aggregate query); the other 499 either wait ~50ms and pick up the freshly-cached result from the winner, or — only in the unlikely case the winner is still slow after that wait — fall back to computing it themselves individually, bounding the worst case without letting all 500 hit the database simultaneously as the default outcome.

**Jittered TTL, applied alongside the lock (belt-and-suspenders — protects against many *different* keys expiring in a correlated wave, which a per-key lock alone doesn't address):**

```js
function ttlWithJitter(baseSeconds, jitterSeconds) {
  const jitter = Math.floor(Math.random() * jitterSeconds * 2) - jitterSeconds; // ± jitterSeconds
  return baseSeconds + jitter;
}
// e.g., ttlWithJitter(300, 30) => somewhere between 270s and 330s, chosen per-key at cache time
```
