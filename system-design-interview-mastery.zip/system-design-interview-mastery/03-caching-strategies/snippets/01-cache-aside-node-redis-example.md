# Snippet: Cache-Aside With Redis (Node)

```js
const redis = require('redis').createClient();

async function getProduct(productId) {
  const cacheKey = `product:${productId}`;

  // 1. try the cache first
  const cached = await redis.get(cacheKey);
  if (cached) {
    return JSON.parse(cached); // cache hit — DB never touched
  }

  // 2. cache miss — read from the database
  const product = await db.query('SELECT * FROM products WHERE id = $1', [productId]);
  if (!product) return null;

  // 3. populate the cache for next time, with a TTL as a safety-net backstop
  await redis.set(cacheKey, JSON.stringify(product), { EX: 300 }); // 5 min TTL

  return product;
}

async function updateProduct(productId, updates) {
  // 1. write to the database (source of truth) FIRST
  await db.query('UPDATE products SET price = $1 WHERE id = $2', [updates.price, productId]);

  // 2. invalidate — DELETE the cache key, don't overwrite it with the new value.
  //    The next read will miss, re-read the DB, and repopulate correctly.
  //    (See the theory file for why delete-on-write is safer than update-on-write.)
  await redis.del(`product:${productId}`);
}
```

**Why the write happens to the DB before the cache delete, not after:** if the order were reversed (delete cache, then write DB) and a read for the same key raced in between the two steps, that read would miss the (now-deleted) cache, read the **old** value from the DB (the write hasn't landed yet), and re-populate the cache with the stale value — which then sits there until the next write or TTL expiry. Writing to the DB first minimizes (though doesn't perfectly eliminate — see the cache-aside-race output-based file for the residual race) this window.
