# Snippet: Implementing ETag-Based Conditional Requests (Node/Express)

```js
const crypto = require('crypto');

function computeETag(payload) {
  // a content hash — changes IF AND ONLY IF the actual content changes,
  // unlike Last-Modified's second-granularity timestamp
  const hash = crypto.createHash('sha1').update(JSON.stringify(payload)).digest('hex');
  return `"${hash}"`;
}

app.get('/api/products/:id', async (req, res) => {
  const product = await getProduct(req.params.id);
  const etag = computeETag(product);

  // compare the client's If-None-Match header against the CURRENT resource's ETag
  const clientETag = req.header('If-None-Match');
  if (clientETag === etag) {
    // content hasn't changed since the client last fetched it —
    // respond with an empty body, saving the full payload transfer
    return res.status(304).end();
  }

  res.set('ETag', etag);
  res.set('Cache-Control', 'public, max-age=0, must-revalidate'); // always revalidate, but cheaply via ETag
  res.json(product);
});
```

**Client-side (fetch automatically handles this in browsers, but shown explicitly for clarity):**

```js
async function fetchProductWithCache(id, cachedEtag) {
  const res = await fetch(`/api/products/${id}`, {
    headers: cachedEtag ? { 'If-None-Match': cachedEtag } : {},
  });

  if (res.status === 304) {
    return getFromLocalCache(id); // use the previously-cached body — server confirmed no change
  }

  const data = await res.json();
  const newEtag = res.headers.get('ETag');
  saveToLocalCache(id, data, newEtag);
  return data;
}
```

**Why `must-revalidate` is paired with `max-age=0` here:** this endpoint's data (a product's price/stock) can change at any time, so the response is treated as immediately stale — but pairing that with ETag-based conditional requests means "stale" doesn't mean "must re-download everything," just "must ask the server if anything actually changed," which is nearly as cheap as a full cache hit when the answer is usually "no."
