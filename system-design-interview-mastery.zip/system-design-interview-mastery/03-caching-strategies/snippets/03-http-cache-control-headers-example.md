# Snippet: HTTP Cache-Control Headers by Content Type

**Content-hashed static asset — cache forever, since a content change always produces a new URL:**
```
GET /static/app.a3f9c2.js
--> 200 OK
Cache-Control: public, max-age=31536000, immutable
```

**A public, frequently-viewed but not-hyper-urgent page (e.g., a blog post) — cache at both browser and CDN, allow serving stale briefly while revalidating:**
```
GET /blog/how-caching-works
--> 200 OK
Cache-Control: public, max-age=300, stale-while-revalidate=3600
```
For up to 300s, served instantly from cache with zero network request. For up to an additional 3600s after that, still served instantly from cache (now technically stale) while a background request silently refreshes it for the next visitor — nobody waits on a full round trip except the very first request after the full window lapses.

**API response with a shared CDN cache but per-user personalization at the edge/app layer (a product page's shell is public, but includes user-specific pricing/inventory bits added client-side) — different TTL for browsers vs. shared caches:**
```
GET /api/products/5
--> 200 OK
Cache-Control: public, max-age=0, s-maxage=60
```
Browsers treat this as immediately stale (`max-age=0`, must revalidate before reuse) — appropriate since the browser is a private cache serving one specific user, and personalized bits might attach downstream. The CDN (a shared cache) is allowed to cache the shared, non-personalized response for 60s per `s-maxage`, since it's serving many different users the same underlying data.

**Sensitive, must-never-be-cached response (auth token issuance, a banking balance):**
```
GET /api/account/balance
--> 200 OK
Cache-Control: no-store
```
`no-store` is the strict directive — nothing about this response may be persisted anywhere, not even for a conditional-revalidation check later. (`no-cache`, despite the name, would still allow storage with mandatory revalidation — the wrong choice for genuinely sensitive data.)

**Conditional revalidation in action, once a cached response's `max-age` has elapsed:**
```
GET /api/products/5
If-None-Match: "a1b2c3d4"

--> 304 Not Modified          (if unchanged — no body sent, saves bandwidth)
   or
--> 200 OK  ETag: "e5f6g7h8"  (if changed — full new body + new ETag)
```
