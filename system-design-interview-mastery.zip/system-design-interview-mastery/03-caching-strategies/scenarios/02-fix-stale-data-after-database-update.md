# Scenario: Fix Stale Data Complaints After Database Updates

**Scenario:** A SaaS admin panel lets account admins update a team member's role (e.g., promote to "manager"). Support starts receiving tickets: "I changed a teammate's role, but the change doesn't show up anywhere in the app for several minutes — sometimes the old role is even still enforced for permission checks, which is a real security concern, not just a UI annoyance."

**Step 1 — locate where the role data is cached and how.** Investigation finds the app caches a user's full permission profile (`user:42:permissions`) with a 10-minute TTL, populated on cache-aside miss, used both for UI display **and** for actual authorization checks on protected actions. The role-update endpoint writes the new role to the database but has **no cache invalidation step at all** — a pure TTL-only setup, the same design flaw examined in the TTL-staleness output-based file.

**Step 2 — recognize this is more than a staleness bug; it's an authorization bug.** The theory file distinguishes "acceptable staleness" (a like count, a view count) from "unacceptable staleness" (anything gating a real decision) — a permission check using a stale, more-privileged cached role for up to 10 minutes after a demotion is a legitimate security issue: a demoted user retains their old access for the full TTL window. This reframes the fix from "nice to have" to "must ship promptly."

**Step 3 — fix with event-based invalidation on the write path, immediately.**
```js
async function updateUserRole(userId, newRole) {
  await db.query('UPDATE team_members SET role = $1 WHERE user_id = $2', [newRole, userId]);
  await redis.del(`user:${userId}:permissions`); // invalidate immediately on write
}
```
This collapses the staleness window from "up to 10 minutes" to "effectively zero" (bounded only by DB write latency + cache delete latency, both sub-second) — the same "event-based invalidation as primary mechanism, TTL as backstop" pattern from the theory file, now correctly applied where it was previously missing.

**Step 4 — decide whether the permission-check path should even use the cache at all, given the stakes.** Even with immediate invalidation on write, there's a residual, much narrower race (the same cache-aside race from the corresponding output-based file — a straddling read populating stale data right after a write's invalidation). For **UI display purposes**, this residual, rare, self-healing-on-next-write race is an acceptable risk. For the **actual authorization check gating a protected action**, the team makes the deliberate choice to **bypass the cache entirely** and read the role directly from the database on every permission check — trading a small amount of extra DB load for eliminating the residual race entirely on the one path where being wrong has security consequences. This mirrors the fundamentals topic's "different consistency needs per feature" principle, applied here as "different caching needs for the same data depending on what it's gating."

**Step 5 — verify.** After deployment: role-change tickets stop; a permission-check audit log shows every check now reflects the current DB role with zero lag, confirmed by testing an immediate demotion-then-action sequence in staging.

**The interview point:** the fix required recognizing that **not every consumer of a cached value has the same staleness tolerance**, even when they're reading the exact same cached key — display and authorization are different consumers with different acceptable-risk profiles, and conflating them into one caching policy is what caused the security-relevant bug here.
