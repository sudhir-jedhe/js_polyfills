# Scenario: Design a Cache Layer for a Read-Heavy Product API

**Scenario:** A product catalog API (`GET /products/:id`, `GET /products?category=X`) serves 15,000 read QPS against a PostgreSQL database that's starting to show latency degradation. Writes (price/inventory updates from an admin tool) happen at roughly 20 QPS. Design a caching layer.

**Step 1 — confirm this is a good caching candidate before reaching for one.** Read:write ratio is ~750:1 — strongly favorable for caching (per the database-caching theory file's "favorable read:write ratio" criterion). Individual product data is also naturally keyable (`product:5`) and doesn't require session-specific personalization for the base catalog data — a clean fit.

**Step 2 — pick the pattern: cache-aside.** Given the read-heavy, moderate-write workload and no strict requirement that a write be *instantly* reflected to every reader (a few seconds of staleness on a price update is acceptable — this isn't the checkout-time inventory-check case from the fundamentals topic, which does need strong consistency), cache-aside is the right default: simple, and if Redis has an outage, the app degrades to hitting Postgres directly rather than failing outright.

```
GET /products/5 --> Redis GET product:5
                       hit  --> return
                       miss --> DB query --> Redis SET product:5 (TTL 300s) --> return

Admin updates product 5 --> DB UPDATE --> Redis DEL product:5
```

**Step 3 — handle the category-listing case specifically, since it's a derived, multi-product view.** `GET /products?category=electronics` is a different cache key (`category:electronics:page:1`) whose value is derived from *many* underlying products — a naive design that only invalidates `product:5` on a price update would leave `category:electronics:page:1` stale if product 5 is in that category (exactly the "missing a derived key" failure mode called out in the invalidation theory file). Fix: maintain a lightweight reverse index (`product:5:affected-lists = ["category:electronics:page:1", "category:electronics:page:2"]`) updated whenever a product's category/listing membership is known, and invalidate all of them on a relevant write — or, more simply given the acceptable staleness tolerance here, give category-listing caches a **short, independent TTL** (e.g., 60s) rather than chasing exact invalidation for every derived view, accepting a small bounded staleness window in exchange for much simpler invalidation logic.

**Step 4 — protect the hottest keys against stampede.** A small number of "featured" products likely receive disproportionate traffic — apply the lock-based stampede mitigation (see the snippets file) specifically to keys expected to be very hot, since a naive TTL expiry on a viral/featured product could otherwise cause the exact thundering-herd failure described in the corresponding output-based file.

**Bottlenecks & tradeoffs:** Redis itself becomes a new critical-path dependency for performance (not correctness, given the cache-aside fallback) — it should run as a small cluster (not a single instance) for its own availability, and its memory sizing should be estimated the same way as the fundamentals topic's back-of-envelope method (hot-key working set × average serialized size), not provisioned arbitrarily.
