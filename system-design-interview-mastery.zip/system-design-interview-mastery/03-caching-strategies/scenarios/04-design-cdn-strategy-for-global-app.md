# Scenario: Design a CDN Strategy for a Globally-Distributed App

**Scenario:** A media/news app has users across North America, Europe, and Asia, all currently served from a single origin region in the US. European and Asian users report noticeably slower page loads than US users. Design a CDN strategy to address this, covering both static assets and dynamic (but non-personalized) content.

**Step 1 — separate the content into tiers by cacheability, since each needs a different strategy.**

1. **Static assets** (JS/CSS bundles, images, fonts) — content-hashed filenames, effectively immutable.
2. **Public, non-personalized dynamic content** — an article's base HTML/JSON (headline, body, publish date), identical for every viewer.
3. **Personalized content** — a logged-in user's "for you" feed, comments they've posted, account state — genuinely different per user, not CDN-cacheable in the traditional sense.

**Step 2 — static assets: maximally aggressive edge caching.**
```
Cache-Control: public, max-age=31536000, immutable
```
Served from every edge location worldwide with an effectively infinite TTL, since a content change always ships under a new hashed URL — this alone should eliminate the bulk of the latency gap for asset-loading, since assets are typically the largest share of a page's total transferred bytes and were previously always fetched from the single US origin regardless of viewer location.

**Step 3 — public dynamic content: short-TTL edge caching with `stale-while-revalidate`.**
```
Cache-Control: public, max-age=60, s-maxage=120, stale-while-revalidate=600
```
An article's content is cached at each regional edge location independently (a European user's request is served from a European edge, populated on that edge's first miss — not necessarily synchronized with the US edge's cache state) — the first European reader after a deploy/edit pays one full round trip to origin; every subsequent European reader for the next ~120s+600s hits the European edge directly, at European-to-edge latency rather than European-to-US-origin latency. This is the single highest-leverage fix for the reported latency gap, since article content dominates perceived "page load" for a news app.

**Step 4 — personalized content: don't force it through the CDN; instead, minimize its critical-path weight.** Rather than trying to CDN-cache personalized data (a wrong approach — see the browser-storage theory file's note that a strict-correctness read should never rely on a shared cache), the design should ensure the **page shell and public content** (steps 2-3) can render and become interactive without waiting on the personalized data — personalization loads as a secondary, asynchronous request after the initial paint. This doesn't make the personalized-data round trip to the US origin any faster, but it removes it from the *critical rendering path*, which is what the user actually perceives as "slow."

**Step 5 — consider origin shielding / regional origin replicas for the true cache-miss path.** For content that inevitably has to reach an origin at least once per edge location (a brand-new article, right after publish, hitting each region's edge for the first time), a single **shield** origin location (or true multi-region origin replicas, if budget and consistency requirements allow) reduces the worst-case first-request latency for non-US regions, rather than every regional edge's first miss travelling all the way back to the sole US origin individually.

**Bottlenecks & tradeoffs called out proactively:** purge propagation across globally-distributed edges is not instantaneous (per the CDN theory file) — for time-sensitive corrections (a legal takedown, a factual correction to a live news article), the short `max-age`/`s-maxage` chosen in Step 3 is deliberately the primary safety net, not reliance on purge speed across every global edge location.
