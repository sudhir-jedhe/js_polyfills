# Scenario: Mitigate a Cache Stampede on Viral Content

**Scenario:** A short-video app caches each video's metadata (view count, caption, engagement stats) with cache-aside and a flat 5-minute TTL for every video, regardless of popularity. A video unexpectedly goes viral overnight, spiking from ~50 views/hour to ~200,000 requests/minute for its metadata. Every 5 minutes, when the cache key expires, the site's monitoring shows a sharp, recurring database CPU spike, each one closely followed by a burst of slow-request alerts — then things return to normal until the next 5-minute mark.

**Diagnosis:** This is the thundering herd pattern from the output-based file, occurring on a real, predictable cadence (every TTL expiry) rather than a one-time event — the periodicity in the monitoring graph (a spike exactly every 5 minutes) is itself the diagnostic signature of a stampede, and should be recognized as such immediately rather than investigated as a mysterious recurring incident. At 200,000 req/min (~3,333 req/s) all missing simultaneously at each expiry, even a normally-fast metadata query becomes a significant, synchronized burst of redundant load.

**Fix 1 — request coalescing via a lock (addresses this specific hot key directly):**
```
Cache miss on the hot video's key --> attempt to acquire lock:video:9182
  Winner: fetches fresh data, repopulates cache, releases lock
  Everyone else: waits ~50ms, re-reads cache (now populated by the winner)
```
This alone collapses the ~3,333 simultaneous redundant queries at each expiry down to effectively 1, regardless of how viral the video gets — the fix scales with popularity for free, since it's coordinating *concurrent* misses, not capping total traffic.

**Fix 2 — popularity-aware TTL, layered on top rather than as a replacement.** A flat 5-minute TTL for every video treats a video with 50 views/hour identically to one with 3,333 req/s — but the *cost* of a stampede scales with request volume at expiry, not with the TTL itself. A better design: track request rate per key (a lightweight counter, or infer it from cache-hit telemetry) and **extend the TTL for currently-hot keys** (e.g., a video sustaining over some threshold req/s gets a 30-minute TTL instead of 5) — fewer expiry events for the exact keys where an expiry event is most expensive, while low-traffic videos keep the shorter TTL (where staleness matters less and a stampede risk barely exists at their volume anyway).

**Fix 3 — proactive background refresh for currently-hot keys, avoiding the miss window entirely.** For keys identified as hot (same signal as Fix 2), a background job refreshes the cache entry at, say, 90% of its TTL, proactively — by the time the TTL would naturally expire, the value is already fresh and the "expiry moment" never actually produces a miss for real user traffic at all, since the cache was updated slightly ahead of it.

**Chosen approach:** Fix 1 (locking) ships first — it's the smallest change, directly stops the redundant-query multiplication regardless of *why* a key got hot, and requires no new popularity-tracking infrastructure. Fixes 2 and 3 are follow-up hardening, valuable for reducing unnecessary cache churn/staleness on predictably-hot content, but not required to resolve the immediate incident.

**Verification:** after deploying the lock, the periodic database CPU spikes at each 5-minute mark disappear from monitoring, and Redis's lock-related metrics show the expected pattern — one lock acquisition per key-expiry event, with a queue of waiters resolved within the ~50ms retry window rather than each falling through to the database independently.
