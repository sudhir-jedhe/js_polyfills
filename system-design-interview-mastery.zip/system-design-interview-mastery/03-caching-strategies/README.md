# Caching Strategies

"There are only two hard things in Computer Science: cache invalidation and naming things" is a joke because it's true — caching looks simple (store a copy, serve it fast) until you have to decide *when the copy stops being correct*, and that question shows up at every layer of a real system: the browser, the CDN, the application, and the database. This topic covers the four core caching write/read patterns, precise HTTP caching semantics, CDN and database caching, and — the part interviews probe hardest — invalidation strategies, including cache stampede and its mitigations.

## Folder structure

- **`theory/`** — cache-aside/write-through/write-behind/write-around patterns, HTTP caching semantics (`Cache-Control`, `ETag`, `Last-Modified`), CDN caching, database caching with Redis patterns, browser storage as a cache (light touch), and cache invalidation strategies (TTL, event-based, stampede mitigation).
- **`snippets/`** — 6 practical examples: cache-aside with Redis, write-through, HTTP cache headers, ETag conditional requests, a stampede-mitigation lock, and a CDN cache-key config.
- **`output-based/`** — 5 "given this setup, what happens?" questions on stale headers, TTL vs. write pattern staleness, ETag/304 behavior, cache-aside races, and thundering herd.
- **`scenarios/`** — 5 real-world design/fix scenarios: a cache layer for a read-heavy API, fixing stale data after a DB update, mitigating a stampede on viral content, a CDN strategy for a global app, and choosing write-through vs. write-behind for inventory.
- **`interview-qa/`** — 4 themed Q&A files: caching patterns, HTTP caching, invalidation/stampede, and Redis/DB caching.
- **`problems/`** — 4 hands-on challenges: a multi-layer cache for a news feed, cache-aside implementation, cache invalidation for a product catalog, and an HTTP caching strategy for mixed content.
- **`assets/`** — placeholder for diagrams/images (see `assets/README.md`).

## What's covered

- The four core patterns — cache-aside, write-through, write-behind, write-around — and when each is the right (or wrong) fit
- Precise HTTP caching semantics: the difference between `no-cache` and `no-store`, how `ETag`/`Last-Modified` conditional requests avoid re-transferring unchanged data, and `max-age` vs. `stale-while-revalidate`
- CDN caching: cache keys, edge vs. origin, purging
- Database caching with Redis: common key-design patterns, TTLs, and when a cache saves a query vs. when it just moves the problem
- Browser storage as a cache (localStorage, IndexedDB, Service Worker cache) — light touch, cross-referencing frontend-focused repos for depth
- Cache invalidation: TTL-based, event-based, and the cache stampede / thundering herd problem with concrete mitigations (locking, request coalescing, jittered TTLs)
