# HTTP Caching Semantics: Cache-Control, ETag, and Last-Modified

HTTP caching is precisely specified, and interviewers who know it well will notice imprecise answers (e.g., conflating `no-cache` with `no-store`, which mean nearly opposite things). This file covers the exact semantics.

## `Cache-Control` directives

| Directive | Meaning |
|---|---|
| `max-age=<seconds>` | The response is considered **fresh** (usable without revalidation) for this many seconds from when it was received. |
| `no-cache` | The response **can** be stored, but **must be revalidated with the origin server before each use** — commonly confused with `no-store`, but this still allows caching, just not *unconditional* reuse. |
| `no-store` | The response **must not be stored at all**, anywhere — the strict "don't cache this" directive (used for sensitive data like banking pages). |
| `private` | May be cached only by the end user's browser (a private cache), not by shared/intermediate caches (a CDN, a corporate proxy) — used for user-specific responses. |
| `public` | May be cached by any cache, including shared ones — appropriate for responses that are identical for all users. |
| `s-maxage=<seconds>` | Like `max-age`, but applies specifically to **shared caches** (CDN, proxy) and overrides `max-age` for them — lets an origin set a different freshness window for CDN edge caches vs. browsers. |
| `stale-while-revalidate=<seconds>` | After `max-age` expires, the cache may still serve the (now stale) response for up to this many additional seconds **while asynchronously revalidating in the background** — trades a small staleness window for the client never having to wait on a full round trip. |
| `immutable` | Tells the browser the response will never change for the duration it's fresh — skips even a conditional revalidation check on page reload (used for versioned/hashed static assets, e.g., `app.a3f9c2.js`). |

## Validators: `ETag` and `Last-Modified` — conditional requests

Once a cached response's `max-age` expires, the cache doesn't necessarily have to re-download the full resource — it can ask the origin "has this changed since I last saw it?" via a **conditional request**, and if the answer is no, the origin can respond with a tiny `304 Not Modified` (no body) instead of re-sending the full payload.

- **`ETag`** — an opaque identifier (often a hash of the content) the origin sends with a response (`ETag: "33a64df5"`). On the next request, the cache sends `If-None-Match: "33a64df5"`; if the current resource still has that same ETag, the origin responds `304 Not Modified`; if it changed, `200 OK` with the new body and new ETag.
- **`Last-Modified`** — a timestamp the origin sends (`Last-Modified: Tue, 15 Jul 2025 10:00:00 GMT`). The cache sends `If-Modified-Since` with that timestamp on the next request; the origin compares it to the resource's actual last-modified time and responds `304` or `200` accordingly.
- **`ETag` is generally preferred** where available — it detects content changes precisely (a hash-based ETag changes if and only if the content actually changed), whereas `Last-Modified` only has second-level granularity and can miss a change that happens within the same second, or falsely trigger on a file that was re-saved with identical content but a new mtime.

## Putting it together — the full lifecycle of a cached resource

```
1. Client requests /style.css
2. Origin responds: 200 OK, Cache-Control: max-age=3600, ETag: "abc123"
3. For the next 3600s, the browser serves /style.css from cache with ZERO network requests — "fresh"
4. After 3600s, the resource is "stale" — the browser makes a conditional request:
     GET /style.css
     If-None-Match: "abc123"
5a. If unchanged: origin responds 304 Not Modified (no body) — browser resets freshness for another max-age window
5b. If changed: origin responds 200 OK with new body + new ETag — browser caches the new version
```

## The interview-level distinction that matters most

`max-age` (or lack thereof) determines whether a request is made **at all**; `ETag`/`Last-Modified` determine, when a request *is* made, whether the **full response body** needs to be re-transferred. Confusing these two mechanisms — e.g., saying "ETag prevents requests" — is a precision mistake worth explicitly avoiding: ETag prevents re-**transferring the body**, not the request itself.
