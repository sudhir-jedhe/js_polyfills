# CDN Caching

A CDN (Content Delivery Network) caches content at **edge locations** geographically distributed close to end users, so a response can be served without a round trip all the way back to the origin server — reducing both latency (physically shorter network path) and origin load (the origin is never even contacted on a cache hit).

## How a CDN decides what to cache and for how long

The CDN respects the origin's `Cache-Control` headers by default (`max-age`, `s-maxage` specifically for shared caches like a CDN, `public`/`private`), the same mechanics as browser caching — a CDN is, architecturally, just another HTTP cache sitting in the request path, obeying the same standard. Most CDN providers also let you override this with edge-specific configuration (a CDN-level TTL that differs from what's sent to browsers), useful when you want content to stay fresh at the edge sooner/later than in individual users' browsers.

## Cache key — what makes two requests "the same" for caching purposes

By default, a CDN typically caches per exact URL (path + query string). This has real implications:

- `/products?id=5` and `/products?id=5&utm_source=email` are, by default, **different cache keys** — a marketing campaign appending tracking parameters can silently multiply your effective cache miss rate, since every unique query string variant is cached separately (or not cached/deduped at all, depending on config) even though the actual response content is identical. The fix is configuring the CDN to **normalize or strip specific query parameters** (ignore `utm_*`, sort remaining params) before computing the cache key.
- Some CDNs allow caching to additionally vary by request header (mirroring HTTP's `Vary` header, e.g., `Vary: Accept-Encoding` so gzip and non-gzip responses aren't conflated) — necessary when the same URL genuinely produces different responses based on a header, but each additional `Vary` dimension multiplies the number of distinct cached variants, diluting cache efficiency.

## Static vs. dynamic content at the edge

- **Static assets** (JS/CSS bundles, images, fonts) are the classic, easy CDN case — especially when filenames are content-hashed (`app.a3f9c2.js`), which lets them be cached with `Cache-Control: immutable` and an effectively infinite TTL, since a content change always produces a *new* URL rather than invalidating the old one.
- **Dynamic, personalized content** (a logged-in user's dashboard) is generally not CDN-cacheable at all (`Cache-Control: private, no-store` or similar) — but **dynamic, non-personalized** content (a product page's base HTML, before any user-specific overlay) can still benefit from short-TTL edge caching, sometimes combined with `stale-while-revalidate` so the edge serves a slightly-stale page instantly while fetching a fresh one in the background.

## Purging (invalidation) — the CDN-specific hard part

Since edge nodes are geographically distributed, invalidating a cached object means **propagating a purge request to every edge location** that might hold it — this is not instantaneous, and different providers offer different propagation-time guarantees (from seconds to a couple of minutes for a global purge). This has a direct design implication: if a piece of content might need to be corrected/removed urgently (e.g., a legal takedown, a pricing error), relying on a CDN purge alone introduces a real propagation-delay window — a shorter TTL for content with any urgency-of-correction requirement is often a more robust safety net than depending on purge speed.

## Interview framing

CDN caching is usually the first, highest-leverage layer to mention for anything static or broadly shared (assets, public pages, media) — it removes load from every downstream layer (origin servers, application cache, database) simultaneously, at essentially zero query cost to serve a hit. The nuance worth demonstrating: cache-key normalization (query param handling) and the purge-propagation-delay tradeoff are the two details that separate "I know CDNs exist" from having actually operated one.
