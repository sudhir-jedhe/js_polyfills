# Cache Invalidation Strategies

"There are only two hard things in Computer Science: cache invalidation and naming things." The joke lands because invalidation genuinely is hard — not because deleting a key is technically difficult, but because **knowing precisely when a cached value has become wrong, and doing something about it before anyone reads it, is a distributed-systems coordination problem in disguise.**

## TTL-based invalidation (time-based expiry)

Set an expiration on every cached entry; once it passes, the entry is either evicted or treated as stale on next access.

- **Pro:** simple, self-healing (guarantees an upper bound on staleness even if every other invalidation mechanism fails), requires no coordination between the writer and the cache.
- **Con:** a blunt instrument — data can be stale for up to the full TTL window even when it changed the instant after being cached, and choosing the TTL is a direct tradeoff (shorter = fresher but more DB load; longer = better hit rate but staler worst case).
- **Use as:** the baseline safety net under every cache, even when a more precise mechanism (below) is also in place.

## Event-based (active) invalidation

The system that performs a write explicitly deletes (or updates) the affected cache key(s) as part of the write path — this is the cache-aside write path described in its own theory file, generalized: any write-triggered event (a DB trigger, an application-level call, a message published to a queue that a cache-invalidation worker consumes) that proactively clears stale entries **the moment they become stale**, rather than waiting for a TTL.

- **Pro:** much tighter staleness bound than TTL alone — often near-zero, if the invalidation happens synchronously with the write.
- **Con:** requires the write path to *know* exactly which cache keys are affected — easy to get right for a simple "one entity, one key" cache, much harder when a single write affects many derived/aggregated cache entries (e.g., updating a product's price should invalidate not just `product:5`, but also any cached category listing or search-result page that includes that product's price) — **missing one of these derived keys is the single most common real-world invalidation bug.**
- **Use as:** the primary mechanism for data with real staleness sensitivity, always paired with a TTL as a backstop against a missed invalidation.

## Write-through / write-behind as implicit invalidation

As covered in their own theory file, these patterns sidestep the "invalidate after write" problem entirely by keeping the cache updated **as part of** the write itself — there's no window where the cache holds a stale value at all (write-through) or the window is bounded by the async flush delay (write-behind).

## Cache stampede / thundering herd — the invalidation failure mode interviews probe hardest

**The problem:** a single, very hot cache key expires (TTL-based) or is invalidated. In the instant before it's repopulated, a large burst of concurrent requests all miss the cache **simultaneously**, and — without protection — **all of them** fall through to the database at once, trying to recompute/refetch the same value in parallel. For a sufficiently hot key, this burst can be large enough to overwhelm the database, even though steady-state load on that same data was completely fine.

**Mitigations, from simplest to most robust:**

1. **Locking / mutex on cache-miss (request coalescing):** the first request to miss acquires a short-lived lock (e.g., `SET lock:key NX EX 5` in Redis — only succeeds if the lock doesn't already exist) and proceeds to recompute/refetch; every other concurrent request that misses the *same* key, seeing the lock already held, either waits briefly and retries the cache read (the winner will have populated it by then) or is served a slightly-stale previous value if one's available — either way, only **one** request actually hits the database, not N.
2. **Jittered TTLs:** instead of a fixed TTL (e.g., exactly 300s for every key), add randomized jitter (e.g., 300s ± 30s) so that a batch of keys cached at the same time don't all expire at the exact same instant — spreading out what would otherwise be a synchronized, correlated wave of expirations across many *different* keys, not just protecting one hot key.
3. **`stale-while-revalidate`-style serving:** continue serving the (now-expired) cached value to incoming requests while exactly one background request refreshes it — nobody-facing request ever waits on, or triggers redundant load against, the database; this is the same idea as the HTTP `stale-while-revalidate` directive, applied at the application cache layer.
4. **Pre-emptive/proactive refresh:** for known-hot, predictable keys, refresh the cache **before** it expires (a background job that recomputes a key at, say, 90% of its TTL) — avoids the miss window entirely for the highest-value keys, at the cost of doing some refresh work that might occasionally be wasted (if the key stops being read before the natural TTL would have expired it).

## Interview framing

Cache stampede is the specific scenario most likely to come up as a deep-dive follow-up after a candidate proposes "just add a cache with a TTL" — proactively naming it, and naming **request coalescing via a short-lived lock** as the standard fix, is a strong, concrete signal of hands-on caching experience rather than textbook familiarity.
