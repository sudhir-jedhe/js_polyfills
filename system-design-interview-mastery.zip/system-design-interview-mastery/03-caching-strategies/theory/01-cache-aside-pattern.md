# The Cache-Aside (Lazy-Loading) Pattern

Cache-aside is the most common caching pattern in practice, and the default answer when an interviewer asks "how would you add caching here?" — but its exact read/write flow, and the specific failure mode it's prone to, need to be stated precisely.

## How it works

**Read path:**
1. Application checks the cache for the key.
2. **Cache hit:** return the cached value directly — the database is never touched.
3. **Cache miss:** read from the database, **write the result into the cache** (so the next read hits), then return it to the caller.

**Write path:**
1. Application writes directly to the **database**.
2. The application then either **invalidates** (deletes) the corresponding cache key, or does nothing and lets the stale entry expire via TTL.

```
Read:  App --miss--> Cache --miss--> DB --> App writes result back to Cache --> returns to caller
Write: App --> DB (write) --> App --> Cache.delete(key)   [invalidate, don't update]
```

## Why invalidate (delete) on write, rather than update the cache directly

It's tempting to write the new value straight into the cache on a write, to "keep it warm" — but this is a well-known race-condition trap: if two writes happen close together, or a write races with an in-flight cache-miss read that's about to write its own (now-stale) result back into the cache, the cache can end up holding an **older** value than the database, indefinitely, with no future write ever correcting it (see the cache-aside-race output-based file for a concrete walkthrough). Deleting the key on write is simpler and self-healing: the next read is guaranteed to be a cache miss, which re-reads the current DB value and repopulates the cache correctly.

## Characteristics

| Property | Behavior |
|---|---|
| Who manages the cache | The application (explicit read/write-through logic in app code) |
| First read after a write | Cache miss (since the key was invalidated) — pays a DB read once |
| Cache failure behavior | Application falls back to the DB directly — cache is not on the critical path for correctness, only for performance |
| Data not read is never cached | Yes — "lazy" loading means unread keys never occupy cache space |
| Risk | Stale reads if a write's invalidation is missed or delayed; a "cache stampede" if a hot key expires and many concurrent requests all miss simultaneously |

## When it's the right choice

Cache-aside is the default for **read-heavy workloads where the cache being briefly unavailable shouldn't take down the application** — since the app always has a DB fallback path, a cache outage degrades performance, not correctness. It fits naturally with most web/API request patterns, where "read a resource that might already be cached" is the dominant access pattern. It's the pattern implicitly assumed unless a design explicitly needs write-through/write-behind's different guarantees (see that theory file for the contrast).
