# Database Caching: Redis Patterns

An in-memory cache (Redis being the most common in interviews) sits between the application and the database, absorbing read load for data that's expensive to compute or query repeatedly. This file covers the practical patterns beyond the abstract cache-aside/write-through theory.

## Key design

A clear, consistent key naming convention is a real operational concern, not bikeshedding — it determines how easy invalidation and debugging are later:

```
user:42:profile                    -- single object
user:42:orders:recent              -- a derived/computed view
product:catalog:category:electronics:page:2   -- paginated, filterable data
session:9f3e2a...                  -- session token as key
rate-limit:api:user:42:window:2026-08-22T14   -- time-windowed counter
```

Namespacing by entity type and ID (`user:42:*`) makes it possible to invalidate all cached data related to a single entity via a **pattern-based scan and delete** when needed, though this should be used sparingly — `KEYS`/`SCAN` over a large keyspace is itself a non-trivial cost, so a better long-term design tracks the specific keys that need invalidation explicitly (e.g., a small index of "which cache keys does user 42's profile touch") rather than relying on pattern matching as the primary invalidation mechanism.

## Common Redis data structures used for caching, matched to their use case

| Structure | Use case |
|---|---|
| String (with `SET ... EX <ttl>`) | Simple cached objects — a serialized JSON blob for a single entity |
| Hash | A cached object where you want to read/update individual fields without deserializing the whole blob (e.g., `HGET user:42 email`) |
| Sorted Set (`ZADD`/`ZRANGE`) | Leaderboards, and — usefully — a cached, ordered feed/timeline (score = timestamp, member = post ID) |
| List | A bounded recent-items cache (`LPUSH` + `LTRIM` to cap size) — e.g., "last 20 notifications" |

## TTL strategy

- **A TTL is the baseline safety net against invalidation bugs** — even with correct explicit invalidation logic, a TTL guarantees a cache entry can't remain stale forever if an invalidation event is ever missed (a bug, a message queue outage, a race condition). Treat TTL and event-based invalidation as complementary, not either/or (see the invalidation theory file).
- **TTL length is a direct tradeoff between staleness tolerance and cache hit rate** — a shorter TTL means fresher data but more cache misses (more DB load); a longer TTL means better hit rate but a longer worst-case staleness window if invalidation fails.

## When a cache doesn't actually help — a common interview trap

A cache only helps when the same key is read **repeatedly** relative to how often it's written/changes. Caching a value that's read once and never again (write-around's exact concern) wastes cache memory for zero benefit. Caching a value that changes on nearly every write (a live view counter incrementing every second, if invalidated on every write) can create a cache with a near-100% miss rate at write time — effectively adding a second write path for no read-side benefit. Recognizing **which specific queries have a favorable read:write ratio** — not "should we add a cache" as a blanket yes/no — is the actual design skill being tested.

## Cache as a source of computation offload, not just storage

Redis caching isn't only about avoiding a database round-trip — it's often used to **cache the result of an expensive computation** (an aggregation, a join across multiple tables, a call to a slow third-party API) rather than a raw row lookup. Framing the cache this way in an interview ("this avoids recomputing an expensive aggregate on every request, not just avoiding a simple key lookup") signals a more precise understanding of what's actually being saved.
