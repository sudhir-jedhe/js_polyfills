# Browser Storage as a Cache (Light Touch)

This file covers browser-side caching at a system-design-interview level of depth — enough to reason about where client-side storage fits in an overall caching strategy. For deep frontend implementation details (API specifics, quota behavior, Service Worker lifecycle), see the dedicated frontend-focused repos in this collection.

## The three mechanisms, briefly

| Mechanism | Typical size limit | Persistence | Sync vs. async API | Best fit as a cache |
|---|---|---|---|---|
| `localStorage` | ~5-10 MB | Persists until explicitly cleared | Synchronous (can block the main thread on large reads/writes) | Small, simple key-value data — user preferences, a small auth token, feature flags |
| `IndexedDB` | Much larger (often hundreds of MB+, browser-dependent) | Persists until explicitly cleared | Asynchronous | Larger structured datasets — an offline-capable app's local data store, cached API responses with querying needs |
| Service Worker Cache API | Similar to IndexedDB, browser-dependent | Persists until explicitly cleared or evicted | Asynchronous, integrates with `fetch` interception | Caching actual HTTP request/response pairs — static assets, API responses, enabling offline support |

## Why this matters at the system-design level

The interview-relevant point isn't the API details — it's that client-side caching is the **outermost layer** of a full caching stack, and it changes what "a request" even means from the server's perspective:

```
Browser cache (Service Worker / HTTP cache) --miss--> CDN edge cache --miss--> Application cache (Redis) --miss--> Database
```

A well-designed cache hierarchy pushes as much traffic as possible to resolve at the **outermost** layer that can correctly serve it, since each layer further out is cheaper (in latency and infrastructure cost) than the one behind it — a request resolved entirely in the browser never even reaches the network.

## Where each fits, in system-design terms

- **`localStorage`** is effectively an application-level key-value cache confined to one browser/device — useful for avoiding a re-fetch of small, slow-changing data (e.g., a user's feature-flag configuration) on every page load, at the cost of it not syncing across devices or tabs automatically (a plain `storage` event fires cross-tab, but there's no cross-device sync without an explicit server round-trip).
- **`IndexedDB`** is the client-side analog of a small local database — appropriate when an app needs offline capability with actual querying/filtering over cached data, not just simple key lookups.
- **Service Worker Cache API** is what enables true **offline-first** behavior: it intercepts network requests and can serve a cached response even with zero connectivity, which none of the server-side caching layers (CDN, Redis) can do, since they all still require *some* network path to reach.

## The interview-level caveat worth naming

Client-side caches are the **least controllable** layer from the server's perspective — the server can set `Cache-Control` headers as a strong hint, but ultimately the client (and its cache implementation) decides what to honor, and a client-side cache bug or a user's browser settings can produce staleness the server has no visibility into or ability to force-correct (unlike a CDN purge or a Redis key delete, which the server fully controls). This is why anything with a strict correctness requirement (an account balance, an inventory count) should never rely on a long-lived client-side cache as its source of truth — it should always be revalidated against the server on any action with real consequences.
