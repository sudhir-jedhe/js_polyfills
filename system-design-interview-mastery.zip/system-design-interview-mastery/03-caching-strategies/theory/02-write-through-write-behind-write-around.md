# Write-Through, Write-Behind, and Write-Around Caching

Beyond cache-aside (the read-triggered default), three other patterns govern specifically how **writes** interact with the cache — each with a different latency/consistency/durability tradeoff.

## Write-through

Every write goes to the **cache first, synchronously, then to the database** (or to both simultaneously, with the write only considered complete once both succeed) — the cache is never stale relative to the database because they're updated together, atomically from the caller's perspective.

```
App --> Cache.set(key, value) --> DB.write(value) --> ack to caller (only after BOTH succeed)
```

- **Pro:** cache is always consistent with the DB; a subsequent read is guaranteed to hit a fresh cache entry.
- **Con:** every write pays the latency cost of writing to *two* systems synchronously — slower writes than cache-aside (which only writes to the DB, then just deletes a cache key).
- **Use when:** read-after-write consistency matters and the write volume is low-to-moderate enough that the extra latency is acceptable — e.g., user profile settings, configuration data that's written rarely and read constantly.

## Write-behind (write-back)

Writes go to the **cache first and are acknowledged immediately**; the write to the database happens **asynchronously**, batched or delayed, in the background.

```
App --> Cache.set(key, value) --> ack to caller IMMEDIATELY
                 |
                 +--(async, batched)--> DB.write(value)   [happens later]
```

- **Pro:** lowest write latency of any pattern — the caller never waits on the database at all.
- **Con:** a real **durability risk** — if the cache crashes before the async write to the DB completes, that write is lost permanently, since the cache was the only place it existed. Also more complex to implement correctly (write batching, retry-on-failure for the async DB write, ordering guarantees if multiple writes hit the same key before flushing).
- **Use when:** write volume is very high and some risk of data loss on a cache crash is an acceptable tradeoff for latency — e.g., high-frequency metrics/analytics counters, view counts, where losing a small window of writes on a rare crash is tolerable and the alternative (synchronous DB writes at that volume) would be prohibitively expensive.

## Write-around

Writes go **directly to the database, bypassing the cache entirely** — the cache is only populated later, on a subsequent **read** (cache-aside's miss path).

```
App --> DB.write(value)   [cache is not touched at all]
...later...
App --(read, cache miss)--> DB.read(value) --> Cache.set(key, value)
```

- **Pro:** avoids filling the cache with data that's written but may never be read again (e.g., a bulk import or infrequently-accessed record) — keeps the cache's limited space reserved for actually-hot data.
- **Con:** the **first read** after a write is always a cache miss (slower than write-through's immediately-warm cache), and if the same data is read again very soon after writing, that first read pays full DB latency needlessly.
- **Use when:** writes are much more frequent than reads for the same data, or written data has a low likelihood of being read again soon — e.g., write-heavy logging/audit data, bulk data ingestion.

## Comparison table

| Pattern | Write latency | Read-after-write | Durability risk | Best fit |
|---|---|---|---|---|
| Write-through | Higher (writes to 2 systems synchronously) | Always fresh | None (both writes confirmed) | Low-write-volume, consistency-sensitive data |
| Write-behind | Lowest (cache only, async DB flush) | Fresh (cache has it) | **Real risk** — cache crash can lose unflushed writes | Very high write volume, some loss tolerance |
| Write-around | Same as writing straight to DB | Miss (cache not populated on write) | None | Write-heavy, rarely-re-read data |
| Cache-aside (write side) | Same as DB write + a cache delete | Miss (invalidated, next read repopulates) | None | General-purpose default |

## The interview answer

Never present one of these as universally "the best" — the correct answer names the write-volume and consistency-sensitivity of the *specific data* in question and picks accordingly, the same "per-feature, not per-system" reasoning used for consistency models in the fundamentals topic. A single real system commonly uses different patterns for different data types (e.g., write-through for account settings, write-behind for view counters, cache-aside as the general default elsewhere).
