# Problem: Design a Multi-Layer Cache for a Social News Feed

## Problem Statement

Design the full caching stack (browser → CDN → application cache → database) for a social app's news feed (posts from people you follow, reverse-chronological or ranked). Address what's cacheable at each layer, TTLs, and invalidation, given that feed content is per-user (not globally shared) but individual posts within feeds are shared across many users' feeds.

## Constraints

- Feeds are personalized per user — a naive "cache the whole feed response at the CDN" approach doesn't work since it's not shared content.
- Individual posts ARE shared across many feeds (a popular post appears in thousands of followers' feeds).
- New posts should appear in a follower's feed within a few seconds, not minutes.

## Solution

**Layer 1 — Browser/client cache: minimal, short-lived.** The feed response itself (`GET /feed`) is personalized and changes frequently — `Cache-Control: private, no-store` (or a very short `max-age` with mandatory revalidation) is appropriate; there's little value in caching a rapidly-changing, per-user payload client-side. Static assets referenced within feed items (post images, avatars) are separately, aggressively cached (`immutable`, content-hashed URLs) — these dominate transferred bytes and are the highest-value client-cacheable content in this design.

**Layer 2 — CDN: only for the genuinely shared, non-personalized pieces.** The feed *response* itself is not CDN-cacheable (it's per-user). What IS CDN-cacheable: post media (images/video), served from object storage through the CDN with long TTLs, exactly as in the CDN theory file's static-asset guidance — this is the layer doing the most work here, since media dominates feed payload size.

**Layer 3 — Application cache (Redis): the core of this design, split into two distinct cached shapes.**

1. **Individual post objects** (`post:9182` → caption, media refs, like count, author) — cached with cache-aside, since posts are read by many different users' feeds but written once (by the author) and updated rarely (edits, or a like-count refresh). High read:write ratio — an ideal cache-aside candidate.
2. **Per-user feed *indices*** (`feed:user:42` → an ordered list of post IDs, via a Redis Sorted Set scored by recency/rank) — NOT the full post content, just references. Fetching a feed becomes: read the ordered ID list from `feed:user:42`, then batch-fetch the referenced posts from the `post:*` cache (mostly hits, since popular posts are read across many users' feeds and stay warm).

**Why splitting feed-index from post-content matters:** if the full feed (with embedded post content) were cached as one blob per user, a single post edit (e.g., a caption correction) would require finding and invalidating that post's cached copy inside *every follower's* cached feed blob — an intractable fan-out. By storing feeds as ID references and posts separately, editing a post only requires invalidating `post:9182` once — every feed that references it automatically picks up the correction on its next read, since the ID-list lookup and the post-content lookup are decoupled.

**New post delivery (the "within a few seconds" requirement) — write path:**
```
New post created --> write to DB, populate post:<id> cache (write-through, since it needs to be
                      immediately correct for the many feeds about to reference it)
                  --> fan-out: for each follower, ZADD their feed:user:<followerId> sorted set
                      with the new post ID, scored by timestamp
                      (mirrors the fan-out-on-write strategy discussed in the fundamentals
                      topic's Twitter estimation problem, for typical-follower-count users;
                      celebrity accounts merge in via fan-out-on-read instead)
```

## Bottlenecks & tradeoffs

The per-user feed Sorted Sets are the write-amplification cost of this design (one post creation fans out to potentially many followers' sets) — exactly the scaling concern the fundamentals topic's Twitter estimation flags as needing a hybrid fan-out strategy for high-follower-count accounts, to avoid a single post write turning into millions of Redis writes.
