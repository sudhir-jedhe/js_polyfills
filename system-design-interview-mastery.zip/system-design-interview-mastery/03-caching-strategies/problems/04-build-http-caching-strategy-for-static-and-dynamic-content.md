# Problem: Build a Complete HTTP Caching Strategy for a Mixed Content Site

## Problem Statement

A documentation site serves: (1) versioned, content-hashed JS/CSS bundles, (2) markdown-rendered doc pages (public, identical for all viewers, edited occasionally via a CMS), (3) a live "was this page helpful?" vote count shown on each doc page, and (4) a logged-in-only "my saved pages" list. Specify the exact `Cache-Control` (and validator) strategy for each, and justify why a single blanket policy across the whole site would be wrong.

## Constraints

- Each content type's correct policy must be derived from its actual change frequency and personalization, not assigned uniformly.
- At least one content type should use ETag-based conditional revalidation explicitly.
- Explain what breaks if any two of the four are accidentally given the same policy.

## Solution

**1. Content-hashed JS/CSS bundles:**
```
Cache-Control: public, max-age=31536000, immutable
```
Justification: the URL itself (`app.a3f9c2.js`) encodes the content — a change always produces a new URL, so the old URL's content can genuinely never change. `immutable` additionally tells the browser to skip even a conditional revalidation check on reload, since there's nothing to check. Effectively infinite, maximally aggressive caching is correct here specifically because staleness is *structurally impossible*, not just unlikely.

**2. Doc pages (public, edited occasionally):**
```
Cache-Control: public, max-age=120, stale-while-revalidate=3600
ETag: "<content-hash-of-rendered-markdown>"
```
Justification: identical for every viewer (safe to cache in shared/CDN caches, `public`), but edited unpredictably via the CMS — a short `max-age` bounds staleness after an edit to 2 minutes, and `stale-while-revalidate` means visitors never wait on a full round trip once that window passes, at the cost of occasionally seeing a version up to ~1 hour stale in the worst case (the trailing edge of the `stale-while-revalidate` window) before a background refresh catches up. The `ETag` (ideally computed from the rendered content, not the raw CMS record, so unrelated CMS metadata changes don't spuriously bust it) makes each revalidation cheap — most revalidations after a 2-minute `max-age` expiry will find nothing actually changed and get a `304`.

**3. "Was this page helpful?" vote count:**
```
Cache-Control: no-cache
```
Justification: this is a small, frequently-changing number, but not sensitive — `no-cache` (not `no-store`) is correct: it can still be cached, but must always be revalidated before reuse, which is appropriate given its low, unpredictable change frequency and small payload size (revalidation cost is trivial even if it happens on every load). Critically, this is served as a **separate resource/endpoint** from the doc page content itself (`GET /docs/xyz/votes`, distinct from `GET /docs/xyz`) — embedding it directly in the doc page's response would force the *entire page's* cache policy down to match the vote count's volatility, destroying the long, safe caching the doc content itself deserves. This split mirrors the ETag-scope reasoning from the caching output-based file, applied at the HTTP-resource-boundary level instead of the ETag-field level.

**4. "My saved pages" list (logged-in, personalized):**
```
Cache-Control: private, no-store
```
Justification: personalized, per-user data with real correctness expectations (a user who just saved a page should always see it reflected) — `private` alone would still permit some caching in the user's own browser, but `no-store` is chosen here to keep this simple and unambiguously correct rather than relying on the browser to always revalidate perfectly; the endpoint is cheap enough (small, infrequently-hit list) that paying a full network request every time is a non-issue.

## What breaks if policies are swapped or merged

- If (2) and (3) were merged into one response with (2)'s long `max-age`, vote counts would appear frozen for up to an hour after every vote — visibly broken, and exactly why splitting volatile sub-content into its own resource (rather than embedding it) is the correct fix rather than picking a compromise TTL for the combined response.
- If (1)'s `immutable, max-age=31536000` were mistakenly applied to (2) (doc pages), a content edit would never be visible to any cached visitor until the browser's cache was manually cleared — a severe, hard-to-diagnose staleness bug, since nothing about the URL changes to force a refresh the way it does for hashed assets.
- If (4) used (2)'s `public, max-age=120`, a shared/CDN cache could serve **one user's saved-pages list to a different user** — not just a staleness bug but a data-leak/privacy bug, underscoring why `private`/`no-store` on personalized data isn't optional or tunable the way TTL length is for the other content types.
