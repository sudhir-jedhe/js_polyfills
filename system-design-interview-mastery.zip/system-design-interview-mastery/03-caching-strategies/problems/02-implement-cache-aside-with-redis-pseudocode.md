# Problem: Implement a Generic, Reusable Cache-Aside Helper

## Problem Statement

Rather than hand-writing the cache-aside get/miss/populate logic at every call site (error-prone and inconsistent), implement a single reusable helper function that any part of the codebase can use, including built-in stampede protection and TTL jitter.

## Constraints

- Must work for any cacheable computation (not hardcoded to one query).
- Must include stampede protection (locking) as a default, not opt-in.
- Must include TTL jitter to avoid correlated expiry waves.
- Must fail open (fall back to the underlying fetch) if Redis itself is unavailable — a cache outage should degrade performance, not break the app.

## Solution

```js
const redis = require('redis').createClient();

async function cached(key, fetchFn, { ttlSeconds = 300, jitterSeconds = 30, lockTtlSeconds = 10 } = {}) {
  // fail-open: if Redis itself is down, skip caching entirely rather than erroring out
  let cachedValue;
  try {
    cachedValue = await redis.get(key);
  } catch (err) {
    console.warn(`cache read failed for ${key}, falling back to source:`, err.message);
    return fetchFn();
  }

  if (cachedValue !== null) {
    return JSON.parse(cachedValue);
  }

  // cache miss — attempt stampede-protection lock
  const lockKey = `lock:${key}`;
  let gotLock = false;
  try {
    gotLock = await redis.set(lockKey, '1', { NX: true, EX: lockTtlSeconds });
  } catch (err) {
    // lock acquisition itself failed (Redis flaky) — proceed without
    // coordination rather than blocking the request indefinitely
    return fetchFn();
  }

  if (gotLock) {
    try {
      const value = await fetchFn();
      const jitteredTtl = ttlSeconds + Math.floor((Math.random() * 2 - 1) * jitterSeconds);
      await redis.set(key, JSON.stringify(value), { EX: jitteredTtl }).catch(() => {}); // best-effort populate
      return value;
    } finally {
      await redis.del(lockKey).catch(() => {});
    }
  }

  // didn't get the lock — someone else is fetching; wait briefly, then retry cache read once
  await sleep(50);
  try {
    const retried = await redis.get(key);
    if (retried !== null) return JSON.parse(retried);
  } catch { /* fall through */ }

  // last resort: compute it ourselves rather than waiting indefinitely
  return fetchFn();
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

module.exports = { cached };
```

**Usage — call sites become a single, consistent line, instead of hand-rolled logic per feature:**
```js
async function getProduct(id) {
  return cached(`product:${id}`, () => db.query('SELECT * FROM products WHERE id = $1', [id]));
}

async function getCategoryPage(category, page) {
  return cached(
    `category:${category}:page:${page}`,
    () => computeCategoryPage(category, page),
    { ttlSeconds: 60, jitterSeconds: 10 } // shorter TTL for a more dynamic derived view
  );
}
```

## Why each design choice is present

- **Every Redis call is wrapped in error handling that falls back to `fetchFn()`** — this is the "fail open" requirement: if Redis is degraded or unreachable, the application keeps working (slower, hitting the database directly) rather than erroring out, which is the entire point of using cache-aside over write-through for general-purpose caching (per the cache-aside theory file's reasoning about cache-outage tolerance).
- **The lock is itself wrapped in a try/catch with a `fetchFn()` fallback** — stampede protection shouldn't become a new single point of failure; if locking is unavailable, the system degrades to "no stampede protection this one time" rather than blocking indefinitely.
- **TTL jitter is baked into every cached call by default**, not something each call site has to remember to add — removing a common source of bugs where someone caches a batch of related keys with the exact same fixed TTL, unknowingly setting up a future correlated-expiry stampede.
