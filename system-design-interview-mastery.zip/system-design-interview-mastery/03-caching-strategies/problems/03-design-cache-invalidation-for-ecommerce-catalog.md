# Problem: Design Cache Invalidation for an E-Commerce Product Catalog

## Problem Statement

An e-commerce catalog has products, categories (a product belongs to 1+ categories), and search results (a full-text/filtered search index). All three are cached. Design the invalidation logic that fires when a product's price changes, covering every cache entry that could be affected — not just the product's own cache key.

## Constraints

- Must explicitly identify every derived cache entry a product write can affect, not just the direct one.
- Must not require a full cache flush on every product update (too coarse — would tank the hit rate for unrelated, unaffected data).
- Should include a TTL backstop for anything not explicitly covered.

## Solution

**Step 1 — enumerate everything a single product's price change can affect, since this is exactly the "derived key" failure mode called out in the invalidation theory file:**

1. `product:<id>` — the product's own cached detail view. Directly affected, easy to invalidate.
2. `category:<categoryId>:page:<n>` — any cached category-listing page that includes this product. Indirectly affected — the listing page's cached response embeds this product's price.
3. `search:<queryHash>` — any cached search-results page whose result set includes this product with an embedded/sortable price (e.g., if search results are sortable by price, or show price inline). Indirectly affected, and the hardest to enumerate exhaustively (a product can appear in many different search queries).
4. `cart:<userId>` (if carts cache a snapshot of item prices at add-time for display) — arguably should NOT be affected; a cart typically should reflect the price at add-time or re-validate at checkout, not silently update — worth explicitly deciding as a product/business rule, not just a caching default.

**Step 2 — maintain an explicit reverse-index for the entries that CAN be enumerated (product → category listings), rather than relying on pattern-matching or a full flush:**
```sql
-- maintained whenever a product's category membership changes (rare, not on every price update)
CREATE TABLE product_category_index (
  product_id   TEXT NOT NULL,
  category_id  TEXT NOT NULL,
  PRIMARY KEY (product_id, category_id)
);
```
```js
async function onProductPriceChanged(productId, newPrice) {
  await db.query('UPDATE products SET price = $1 WHERE id = $2', [newPrice, productId]);

  // 1. direct invalidation
  await redis.del(`product:${productId}`);

  // 2. derived: category listing pages, via the reverse index (bounded, enumerable)
  const categories = await db.query(
    'SELECT category_id FROM product_category_index WHERE product_id = $1', [productId]
  );
  for (const { category_id } of categories) {
    // invalidate ALL cached pages for this category, since we don't track which
    // page number this product landed on (acceptable — category page count is small)
    const keys = await redis.keys(`category:${category_id}:page:*`);
    if (keys.length) await redis.del(keys);
  }

  // 3. search results — NOT explicitly invalidated (see Step 3)
}
```

**Step 3 — for search results specifically, accept a short TTL instead of exhaustive invalidation, as a deliberate design tradeoff.** Enumerating every search query whose cached result includes a given product is impractical (an unbounded, effectively unenumerable set of possible queries) — the design deliberately gives search-result caches a **short TTL (e.g., 60 seconds)** and no event-based invalidation at all, accepting up to 60 seconds of price staleness in search results specifically, in exchange for not needing an intractable reverse index for this one case. This mirrors the cache-layer-for-read-heavy-API scenario's category-listing decision — not every derived cache needs precise invalidation; some are better served by a short, bounded TTL as the *primary* mechanism rather than the backstop.

**Step 4 — TTL as backstop everywhere, including the explicitly-invalidated entries.** `product:<id>` and `category:*` entries still carry a TTL (e.g., 10 minutes) despite having event-based invalidation — protecting against a missed invalidation (a bug, a `product_category_index` row that's out of sync) from causing unbounded staleness.

## The design principle this demonstrates

Not every derived cache entry needs (or can practically have) precise event-based invalidation — the design should **explicitly enumerate what's tractable to invalidate directly** (product, category listings, via a maintained index) and **deliberately choose a bounded-staleness TTL fallback** for what isn't (search results), rather than either pretending a full solution exists or reaching for a blunt full-cache-flush that would hurt the hit rate for everything unrelated to this one product.
