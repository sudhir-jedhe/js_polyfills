Diagrams and reference images for caching strategies (e.g. a cache-aside vs. write-through sequence diagram, an HTTP caching decision tree) will be added here.
