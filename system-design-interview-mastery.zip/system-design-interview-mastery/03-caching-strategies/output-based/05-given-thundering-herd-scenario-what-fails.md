# Output: What Fails During a Thundering Herd, Precisely

**Setup:** A news site caches a rendered homepage fragment under a single key `homepage:top-stories` with a 60-second TTL and **no stampede protection** (no lock, no `stale-while-revalidate`). The underlying query that rebuilds this fragment (joining recent articles, ranking by engagement) takes **800ms** to execute and is moderately expensive on the database (a multi-table join with sorting). The homepage receives a steady **2,000 requests/second**. The database's connection pool has a maximum of **100 connections**.

**Question:** Walk through what happens the instant `homepage:top-stories` expires. What specifically fails, and why does a database that handles normal traffic fine suddenly fall over?

**Answer:**

```
t=0 (TTL expiry instant): the cache key is now gone.
t=0 to t=0.8s (while the query is still running): at 2,000 req/s, roughly
  2,000 × 0.8 = ~1,600 requests arrive DURING this single 800ms window.
  With NO stampede protection, EVERY one of these ~1,600 requests independently
  sees a cache miss and independently issues the SAME expensive 800ms query
  to the database.
```

The database's connection pool caps at 100 concurrent connections — the first 100 of those ~1,600 requests acquire a connection and start executing the query; the remaining **~1,500 requests queue, waiting for a connection to free up**. Since each in-flight query takes 800ms, connections free up far slower than new requests are arriving (2,000/s in, at most ~125/s freed given the 800ms-per-query floor) — the queue **grows faster than it drains**, request latency for the homepage spikes from its normal sub-100ms to several seconds (or outright request timeouts), and — critically — this database load spike, **entirely self-inflicted by 1,600 redundant copies of the identical query**, can be severe enough to also degrade *other*, unrelated queries competing for the same connection pool, turning one hot cache key's expiry into a site-wide incident.

**What actually failed:** not the database's raw capacity for the *real* underlying workload (it handles the query fine when asked once) — the failure is entirely an artifact of **redundant, uncoordinated work**: ~1,600 requests doing the same 800ms computation instead of 1 request doing it once and 1,599 reusing that one result.

**The fix (from the stampede-mitigation snippet):** a short-lived lock (`SET lock:homepage:top-stories NX EX 5`) ensures only the *first* of the ~1,600 requests actually issues the query; the rest either wait ~50ms and read the freshly-populated cache, or (better here, given this is public, non-personalized content) are served the **stale** previous fragment immediately via a `stale-while-revalidate`-style approach while the one winning request refreshes it in the background — collapsing ~1,600 redundant queries down to exactly 1, regardless of how large the request burst during the miss window turns out to be.

**The general lesson:** thundering herd isn't a capacity problem solvable by scaling the database bigger — a 10x larger database pool would still see the same ~16x redundant-query multiplication problem at 10x the traffic; it's fundamentally a **coordination problem**, and the fix has to be coordination (a lock, request coalescing), not raw capacity.
