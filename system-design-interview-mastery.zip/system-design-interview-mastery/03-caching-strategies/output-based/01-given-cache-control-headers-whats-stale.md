# Output: What's Stale, Given These Cache-Control Headers

**Setup:** An article page is served with:
```
Cache-Control: public, max-age=60, stale-while-revalidate=300
```
A user loads the page at `t=0`. The article's content is edited by an author at `t=30`. The same user (same browser tab, same cache entry) reloads the page at `t=90`, `t=200`, and `t=400`.

**Question:** For each reload, is the user served a cached (possibly stale) response or a fresh network response? At what point does the user actually see the edited content?

**Answer:**

- **`t=90`:** `max-age=60` expired at `t=60`, so the cached entry is stale — but it's within the `stale-while-revalidate=300` window (valid until `t=60+300=360`). The browser serves the **stale cached response immediately** (still showing the pre-edit content from `t=0`) while triggering a background revalidation request. The user sees stale content at this reload, but a background fetch is now in flight.
- **`t=200`:** by this point, the background revalidation triggered at `t=90` has long since completed and updated the cache with the edited content (from the `t=30` edit) — the *previous* `stale-while-revalidate` cycle already refreshed it. This reload is well within a fresh `max-age=60` window from that `t=90` revalidation (fresh until `t=90+60=150`)... but `t=200` is past that too, so this reload again serves the (now-correctly-edited) cached content stale-while-revalidating again, triggering another background refresh. Either way, the content shown is now the correct, edited version — the staleness only ever affected which timestamp's *snapshot* is shown, not whether it's ever wrong forever.
- **`t=400`:** past the full `stale-while-revalidate` window from any of the earlier reloads — a normal synchronous fetch happens, and the user waits on a fresh network response before seeing anything.

**The key insight:** the user actually saw the **stale (pre-edit)** content specifically at `t=90` — the first reload after the edit but still within the stale-serving window — and the correct content from `t=200` onward, because the `t=90` reload's *background* revalidation is what actually pulled in the edit; the user just didn't see it until the *next* reload after that background fetch completed. `stale-while-revalidate` guarantees the user is never made to *wait* on a network round trip once `max-age` expires, but it does not guarantee the very next reload after an edit shows the edit — there's a one-reload lag baked into the mechanism by design.
