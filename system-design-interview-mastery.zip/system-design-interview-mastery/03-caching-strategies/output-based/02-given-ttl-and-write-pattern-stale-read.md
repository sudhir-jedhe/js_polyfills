# Output: TTL and Write Pattern — When Is a Read Stale?

**Setup:** A product's price is cached with **cache-aside** and a **10-minute TTL**, with **no event-based invalidation** (the write path updates the DB but doesn't delete the cache key — a design mistake, examined here deliberately). At `t=0`, the price is cached at $50 (a customer viewed the product, causing a cache-aside miss-then-populate). At `t=3min`, an admin updates the price to $40 in the database. A different customer views the product at `t=5min`, `t=12min`, and `t=15min`.

**Question:** What price does each customer see, and when does the system self-correct?

**Answer:**

- **`t=5min`:** cache entry (cached at `t=0`, TTL 10min, so valid until `t=10min`) is still within its TTL — the customer sees the **stale $50 price**, even though the DB has held $40 since `t=3min`. This is the direct, expected consequence of TTL-only invalidation with no event-based delete on write: the cache has no way to know the underlying data changed until the TTL naturally expires.
- **`t=12min`:** the `t=0`-cached entry expired at `t=10min`. This read is a cache miss, falls through to the DB, correctly reads **$40**, and repopulates the cache (now valid until `t=22min`). The customer sees the correct price.
- **`t=15min`:** within the newly-refreshed cache window (valid until `t=22min`) — sees the correct **$40**, cached from the `t=12min` repopulation.

**Total staleness window:** from `t=3min` (the actual DB write) to `t=10min` (TTL expiry) — a full **7 minutes** where any customer viewing this product saw a stale, incorrect price. If the TTL were shorter, this window would shrink but at the cost of a lower cache hit rate system-wide; if longer, worse staleness but better hit rate.

**The fix, and why it matters more than tuning the TTL:** add event-based invalidation on the write path — `redis.del('product:5:price')` immediately after the DB write at `t=3min` — which collapses the staleness window to effectively zero (bounded only by replication lag, if any, between the write and the next read) **without needing to shrink the TTL at all**. The TTL then serves purely as a backstop against a missed/failed invalidation, not as the primary staleness-bounding mechanism — exactly the "TTL + event-based, not TTL alone" guidance from the invalidation theory file, demonstrated concretely: TTL-only caching of frequently-updated data is a design smell precisely because the staleness window is bounded by the *TTL*, not by *how quickly the data actually changed*.
