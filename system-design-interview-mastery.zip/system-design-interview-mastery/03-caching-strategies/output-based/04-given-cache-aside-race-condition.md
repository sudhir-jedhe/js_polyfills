# Output: The Cache-Aside Race Condition, Step by Step

**Setup:** A cache-aside setup where writes go: `1) write DB, 2) delete cache key`. A product's price is $50 in both DB and cache. The following sequence occurs, with precise interleaving (a classic read-write race):

```
t=0:  Request A (a READ for product 5) starts, cache MISSES (key expired naturally moments earlier)
t=1:  Request A begins reading the current price from the DB --> reads $50 (the write below hasn't happened yet)
t=2:  Request B (an ADMIN WRITE) updates the DB price to $40
t=3:  Request B deletes the cache key for product 5 (its invalidation step) --> cache is now empty
t=4:  Request A finishes: writes its (now-stale) $50 read into the cache, since it read $50 back at t=1
```

**Question:** What's in the cache after `t=4`? Is this a bug, and how long does it persist?

**Answer:** The cache now holds **$50** — stale, since the DB has held $40 since `t=2` — and it will **persist indefinitely**, until the cache's own TTL eventually expires it (not until the next write, since no further write is coming in this scenario). This is a genuine, well-known cache-aside race condition: Request A's DB read (`t=1`) and cache write (`t=4`) straddle Request B's write-and-invalidate (`t=2`-`t=3`) — A's cache-populate step happens to land **after** B's delete, silently overwriting the correctly-empty cache with a stale value that B had specifically tried to clear.

**Why this is hard to catch in testing:** it requires a specific, narrow timing interleaving (a concurrent read's DB fetch straddling a write's DB-update-and-invalidate) — rare enough that it often doesn't show up until real production concurrency, and even then it self-heals once the TTL expires, so it can look like a transient blip rather than a systematic bug, delaying diagnosis.

**Mitigations, in order of how directly they address the root cause:**
1. **A short TTL as a bound** — doesn't prevent the race, but caps how long the staleness persists (this is the TTL-as-backstop principle from the invalidation theory file, doing real work here).
2. **Delayed double-delete:** after the write's initial cache delete (`t=3`), schedule a **second** delete of the same key a few hundred milliseconds later — long enough to cover the realistic window for a straddling read like Request A to finish its stale write, cleaning up after it.
3. **Versioned cache writes:** have the cache-populate step (Request A's `t=4` write) include a version/timestamp read alongside the value at `t=1`, and have the write path (Request B) bump a version marker on write; the populate step only commits its write if the version it read matches the current version — otherwise it detects it's about to write stale data and skips the cache-populate step entirely. More complex to implement, but closes the race precisely rather than just bounding its damage.

**The interview point:** this is exactly why the cache-aside theory file frames invalidation as "self-healing on the *next* write" rather than "instant and airtight" — the pattern is simple and good enough for the overwhelming majority of cases, but a rigorous answer acknowledges this specific race exists and names at least one concrete mitigation, rather than presenting cache-aside as a fully race-free pattern.
