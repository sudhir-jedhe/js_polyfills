Diagrams and reference images for frontend state management (e.g. a visual "which kind of state is this?" decision tree, a client/server state ownership diagram) will be added here.
