# Server-State Caching: React Query / SWR Patterns

This file goes one level deeper than the local/global/server classification: given that server state needs a *caching* layer rather than a generic store, what does that caching layer actually do, and what are the core concepts (shared by React Query and SWR, and any equivalent library) that interviewers expect you to know by name?

## The core mental model: cache keys

Both libraries index cached data by a **key** that uniquely identifies the request — typically an array combining the resource name and its parameters:

```js
useQuery({ queryKey: ['product', productId], queryFn: () => fetchProduct(productId) }); // React Query
useSWR(['product', productId], () => fetchProduct(productId));                          // SWR
```

Two components requesting the same key share the same cache entry and the same in-flight request — if both mount in the same tick, only **one** network request fires (request deduplication), and both components re-render when the shared result resolves.

## `staleTime` vs `cacheTime`/`gcTime` — the distinction interviewers probe

| Concept | Meaning | Effect |
|---|---|---|
| **`staleTime`** | How long data is considered "fresh" after fetching | While fresh, no automatic refetch happens on mount/refocus. Once stale, the *cached* value is still shown immediately (no loading spinner) while a background refetch happens. |
| **`cacheTime` / `gcTime`** | How long an *unused* (no active subscribers) cache entry is kept in memory before being garbage-collected | After a component unmounts, its data stays cached for this duration — remounting within that window shows cached data instantly, with no network request needed at all if it's also still within `staleTime`. |

Confusing these two is the single most common mistake: `staleTime: 0` (the default) means data is refetched aggressively on every refocus/remount, while a **high `cacheTime` with low `staleTime`** means the *stale-while-revalidate* pattern — instant display of cached (possibly outdated) data, silently updated in the background.

## Stale-while-revalidate, spelled out

This is the defining pattern of both libraries (SWR is even named after it):

1. On mount, if a cache entry exists (even if stale), render it **immediately** — no spinner.
2. If the entry is stale (or a refetch trigger fires), kick off a background refetch.
3. When the background refetch resolves, silently swap in the new data (component re-renders with fresh data, no loading state shown for this transition).

This is different from a naive fetch-on-mount approach, which shows a loading spinner every single time a component mounts, even if the data was fetched 3 seconds ago and almost certainly hasn't changed.

## Background refetch triggers

Both libraries refetch automatically on these signals by default (configurable per-query):

- **Window refocus** — user tabs away and back; a common source of "why did my network tab show an extra request" confusion in interviews if you don't know this is intentional, not a bug.
- **Network reconnect** — device goes offline then back online.
- **Interval polling** — opt-in, for near-real-time data without a WebSocket (`refetchInterval`).
- **Mount** — if the cached data is stale per `staleTime`.

## Invalidation — the other half of the picture

After a mutation (e.g. creating a new todo), the corresponding query cache entries are usually **invalidated** rather than manually patched, telling the library "this data may now be wrong, refetch it":

```js
const queryClient = useQueryClient();
useMutation({
  mutationFn: createTodo,
  onSuccess: () => queryClient.invalidateQueries({ queryKey: ['todos'] }),
});
```
Invalidation marks matching queries stale and triggers a refetch for any currently-mounted subscriber; it's the standard way to keep the cache consistent after a write, and it composes with optimistic updates (apply optimistically for instant feedback, then invalidate on settle to reconcile with server truth — see the optimistic-updates theory file).

## Why this is not "just state with extra steps"

A hand-rolled `useEffect` + `useState` fetch reimplements, badly, everything above: you'd need your own key-based cache, your own in-flight deduplication, your own stale/fresh distinction, your own refocus/reconnect listeners, and your own invalidation bookkeeping. That's the concrete argument for "server state isn't really state in the traditional sense" — it comes with a whole request lifecycle and caching contract that generic state containers don't model at all, and re-implementing it by hand is both a lot of code and a common source of subtle bugs (stale closures in `useEffect`, race conditions between overlapping fetches, no dedup).

## Interview framing

*"I'd reach for React Query or SWR for anything server-derived rather than modeling it with `useEffect`+`useState` or pushing it into Redux — they give cache-key-based deduplication, a stale-while-revalidate render path, automatic background refetch on refocus/reconnect, and invalidation hooks after mutations, all of which I'd otherwise be re-implementing by hand and likely getting wrong on edge cases like overlapping requests."*
