# Local vs Global vs Server State

"State" is not one thing — treating it as one thing is the single biggest reason state management in large apps turns into a mess. The first move in any state-management interview question is to classify what kind of state you're actually dealing with, because each kind has a different owner, a different lifetime, and a different tool that fits it well.

## The three (really four) categories

| Category | Who owns the source of truth | Lifetime | Example |
|---|---|---|---|
| **Local (UI) state** | A single component | Mounts/unmounts with the component | Is this dropdown open? Input field value mid-typing |
| **Global (client) state** | The app, shared across distant components | App session | Logged-in user preferences, theme, feature flags, shopping cart contents (client-authoritative) |
| **Server (cache) state** | The server/database — the client only holds a *cached copy* | Unowned by the client; can go stale at any time | A list of products, a user's profile fetched from `/api/user` |
| **URL state** | The browser's address bar | Survives refresh/share/back-button | Current page, filters, selected tab, search query |

The classification that trips people up in interviews is **server state**, so it deserves its own emphasis below. URL state gets its own theory file because it's frequently forgotten as a state category at all.

## Why local state is not "state management" at all

Local state — `useState`/`useReducer` scoped to one component — needs no library, no context, no store. If only the component that owns a value (and maybe its direct children via props) ever reads or writes it, it should stay local. The most common state-management anti-pattern in real codebases is promoting local state to global *prematurely*, "just in case another component needs it later." This has a real cost: every consumer of a global store re-renders (or must be memoized) on updates that don't concern it, and the mental model of "where does this value live and who can change it" gets harder to trace as the store grows.

## Why global client state is legitimately different from server state

Global client state is data the **client itself owns and is authoritative for** — it didn't come from a fetch, and there's no server copy that can silently drift out of sync with it. Theme preference, whether a sidebar is collapsed, an in-progress multi-step form before submission, feature flags resolved at boot — these live entirely in the browser tab. A general-purpose store (Zustand, Jotai, Context, or Redux if the project already uses it) is the right tool, because the client is the single source of truth and there's no network lifecycle to model.

## Why server state is fundamentally not the same problem

Server state is **not really "state" in the traditional client sense** — it's a local, temporary, possibly-stale cache of data whose actual source of truth lives on a server you don't control and that other clients/users can also mutate. That distinction matters because server state has requirements that generic state containers (Redux, Context, plain `useState`) were never designed to solve well:

- **Staleness** — the value can become wrong the instant another user or process changes it server-side; the client needs a strategy (polling, revalidation, invalidation, subscriptions) to reconcile.
- **Caching** — the same data (e.g. "user #42") might be requested from five different components; you want one shared cache entry, not five independent fetches.
- **Deduplication** — two components mounting in the same tick and both requesting the same resource should trigger one network request, not two.
- **Background refetching** — refetch on window refocus, on network reconnect, or on an interval, without the component tree needing to know any of that is happening.
- **Request lifecycle** — loading, error, success, retry-with-backoff — this is inherent to *any* server data, so it's boilerplate every single time you hand-roll it with `useEffect` + `useState`.

This is precisely the problem **React Query (TanStack Query) and SWR** solve — they are not general state managers, they're **server-state caching layers** with a fetch function as input and stale-time/cache-time semantics baked in. (This repo covers Redux/general state managers separately — the point here is narrower: don't reach for Redux, Zustand, or Context to hold server data. Model it as a cache with its own libraries, and keep the general store for state the client actually owns.)

## Quick classification test

Ask three questions about a piece of data:

1. **Does it come from an API call?** → It's server state. Model it with a cache-aware fetch layer (React Query/SWR), not a global store.
2. **Does more than one distant component need to read or write it, and is the client the source of truth?** → Global client state. Use a store/Context.
3. **Is it only relevant to one component's rendering, transiently?** → Local state. Keep it in `useState`/`useReducer` right where it's used.

A value can also legitimately be **URL state** if it should survive a refresh, be shareable via link, or interact with browser back/forward — see the dedicated theory file on that.

## Common misclassification in interviews

A frequent trap: "store the fetched user list in Redux so multiple pages can access it." This conflates global client state with server state — you *can* do it, but you then have to hand-roll cache invalidation, loading/error tracking, refetch-on-focus, and staleness handling yourself, all of which a server-state library gives you for free. The stronger answer in a system design interview is: keep Redux/Zustand/Context for client-owned state, and put a caching layer (React Query/SWR, or a hand-rolled equivalent with the same responsibilities) in front of anything that originates from the network.
