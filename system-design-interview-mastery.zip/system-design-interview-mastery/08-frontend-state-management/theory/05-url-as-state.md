# URL as State

The URL is a state container that's easy to forget precisely because it's not a JavaScript object — it's the address bar. But any state that should be **shareable, bookmarkable, or survive a page refresh / browser back-forward navigation** belongs in the URL, not in `useState`, Context, or a global store's in-memory state.

## What belongs in the URL

- **Route/page identity** — which screen is showing (`/products/42`)
- **Filters and search parameters** — `?category=shoes&sort=price_asc`
- **Pagination** — `?page=3`
- **Selected tab / view mode** — `?view=grid` or `/settings/billing`
- **Search query text** — `?q=running+shoes`

The test: *"if a user copies this URL and sends it to a colleague, or hits refresh, should they land in the same view?"* If yes, that value is URL state, full stop — no amount of clever in-memory state management substitutes for it, because in-memory state is gone on reload and isn't part of a shared link.

## Two places URL state can live: path vs query string

| Mechanism | Use for | Example |
|---|---|---|
| **Path segments** | Resource identity — what "page" this fundamentally is | `/products/42`, `/users/:id/settings` |
| **Query string** | Modifiers to a view that don't change *what* resource is shown, just how it's filtered/sorted/paginated | `/products?category=shoes&page=2` |
| **Hash fragment** | Rarely used for app state today (mostly legacy pre-History-API SPAs, or same-page anchor scrolling); occasionally used for state that should NOT trigger a server request even on direct navigation (some static hosts) | `#section-2` |

A common mistake is putting everything into component state and mirroring it to the URL only for the "shareable" parts as an afterthought — better to treat the URL as the primary source of truth for that state category and derive component state from it (via the router's params/search-params APIs), not the other way around.

## URL state and the back/forward button

Because the URL is what the browser's history stack tracks, using it for filter/pagination state gets back-button support **for free**: pressing back after changing a filter naturally reverts the filter, because it's a different URL / history entry. Reproducing that behavior with in-memory state alone would require manually pushing custom history entries — solvable, but it's solving a problem the URL already solves natively.

```jsx
// React Router v6 example
function ProductList() {
  const [searchParams, setSearchParams] = useSearchParams();
  const category = searchParams.get('category') ?? 'all';
  const page = Number(searchParams.get('page') ?? 1);

  const setCategory = (next) => {
    setSearchParams(prev => {
      prev.set('category', next);
      prev.set('page', '1'); // reset pagination when filter changes
      return prev;
    });
  };
  // ...
}
```

## Trade-off: URL state vs replace vs push

Every URL update is either a **push** (new history entry — back button reverts it) or a **replace** (overwrites the current history entry — back button skips it). A common refinement: push on meaningful navigation (changing category), but replace on rapid, low-significance changes (live-typing into a search box) so the user doesn't have to hit "back" 15 times to undo 15 keystrokes. Most routers expose this as an option (`replace: true`).

## URL state and server-state caching interact

When a filter lives in the URL and the filtered data comes from the server, the URL params typically become part of the **cache key** for the server-state library (e.g. a React Query key like `['products', { category, page }]`). This means navigating to a URL you've already visited in this session can serve instantly from cache instead of re-fetching, and two different filter combinations are cached independently.

## What should NOT go in the URL

- Sensitive data (tokens, PII) — URLs get logged (browser history, server access logs, `Referer` headers, analytics) and are visible in the address bar.
- Large payloads — URL length limits (practically ~2000 characters is a safe cross-browser ceiling) make it unsuitable for arbitrary blobs of state.
- Highly transient UI state with no shareability value — e.g. "is this dropdown menu currently open" doesn't need to survive a refresh or be shareable, so keep it local.

## Interview framing

*"Anything a user should be able to bookmark, refresh, or share belongs in the URL — filters, pagination, the active tab, the search query. I'd treat the URL as the source of truth for that slice of state and derive local UI state from it, rather than keeping it in component state and trying to sync it to the URL as an afterthought."*
