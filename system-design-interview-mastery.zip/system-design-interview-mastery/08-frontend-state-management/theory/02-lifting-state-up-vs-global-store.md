# Lifting State Up vs Reaching for a Global Store

Once a piece of state is needed by more than one component, there are really three escalating options, and picking the *smallest* one that solves the problem is the skill being tested. Reaching for Redux/Zustand the moment two components need to share a value is a common junior-to-mid-level mistake; refusing to ever use a global store and threading props through eight layers is the opposite mistake.

## Option 1: Lift state up to the nearest common ancestor

If two (or a handful of) components that need to share state live close together in the tree, move the state to their nearest common ancestor and pass it down via props (the value and, if needed, a setter/callback).

```jsx
function Parent() {
  const [selectedId, setSelectedId] = useState(null);
  return (
    <>
      <List selectedId={selectedId} onSelect={setSelectedId} />
      <Details selectedId={selectedId} />
    </>
  );
}
```

**When it's the right call:** the sharing components are structurally close (siblings, or a couple of levels apart), and the state doesn't need to be read by anything far away in the tree.

**When it breaks down:** "prop drilling" — passing a prop through 4-5 intermediate components that don't use it themselves, just to get it from the ancestor to the descendant. Beyond ~2-3 levels of pure pass-through, drilling becomes a maintenance and refactoring cost (renaming a prop means touching every intermediate component's signature).

## Option 2: React Context

Context solves the *drilling* problem without introducing a full external state library — it lets a value be read directly by any descendant without threading it through every level.

```jsx
const SelectionContext = createContext(null);

function Parent() {
  const [selectedId, setSelectedId] = useState(null);
  return (
    <SelectionContext.Provider value={{ selectedId, setSelectedId }}>
      <List />
      <Details />
    </SelectionContext.Provider>
  );
}

function Details() {
  const { selectedId } = useContext(SelectionContext);
  // ...
}
```

**The catch — Context is not a performance-optimized store.** Every component that consumes a Context re-renders whenever the Provider's `value` changes, even if the consumer only cares about a slice of it that didn't change. This is fine for state that changes infrequently (theme, locale, authenticated user) but a poor fit for state that changes rapidly and has many consumers (e.g. a global "current mouse position" or a large, frequently-updating form), because every consumer re-renders on every change with no built-in slicing/selector mechanism. Splitting into multiple, narrowly-scoped Contexts (rather than one giant "AppContext") mitigates this.

## Option 3: A dedicated global store (Redux, Zustand, Jotai, Recoil, etc.)

**When Context isn't enough**, the differentiator is usually **selective subscription** — a real store lets a component subscribe to only the slice of state it cares about, so unrelated state changes elsewhere in the store don't cause that component to re-render. This matters when:

- State updates are frequent and many unrelated components read from the same store.
- You need derived/computed state (selectors) that's memoized and only recomputes when its inputs change.
- You want state changes to be traceable/debuggable (Redux DevTools time-travel, action logs) — valuable in large teams where "who changed this and why" needs to be answerable.
- Middleware is needed — logging, persistence to `localStorage`, undo/redo, syncing across tabs.

This repo treats Redux specifically as covered elsewhere; the point that's testable here is the *decision framework*, not any one library's API.

## Decision framework

| Question | If yes → |
|---|---|
| Only one component needs it? | Local `useState` |
| A small number of nearby components need it? | Lift state to common ancestor |
| Many components across the tree need it, but it changes rarely? | Context |
| Many components need it, it changes often, and re-render cost matters? | Dedicated store with selectors |
| It's fetched from a server? | Neither — see the server-state theory file; use a cache library |
| It should survive refresh / be shareable via link? | URL state, not any of the above |

## The interview framing

A strong answer walks the escalation path explicitly rather than jumping straight to "I'd use Redux": *"First I'd ask whether this state can just live in the nearest common parent. If prop drilling becomes painful, I'd reach for Context — but only if update frequency is low, since Context re-renders every consumer on every value change. If we need selective subscriptions or the update frequency is high with many consumers, that's when a dedicated store earns its cost."* This shows you understand the trade-offs rather than defaulting to the heaviest tool out of habit.
