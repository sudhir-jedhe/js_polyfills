# Optimistic Updates and Rollback Handling

An **optimistic update** applies the *expected* result of a mutation to the UI immediately, before the server confirms it succeeded, rather than showing a loading spinner and waiting for the round trip. It makes an app feel instant — liking a post, checking off a to-do, sending a chat message all flip state locally the moment the user acts. The hard part, and what interviewers actually probe, is the **rollback path** for when the server rejects or fails.

## The three-phase lifecycle

1. **Apply immediately** — before the request even goes out, mutate the local (client or cached server) state as if the mutation already succeeded, and snapshot the previous value so it can be restored.
2. **Fire the request** — send the mutation to the server in the background.
3. **Reconcile** — on success, optionally replace the optimistic value with the server's authoritative response (in case the server computed something slightly different, e.g. a generated ID or a server-side timestamp); on failure, **roll back** to the snapshotted previous value and surface an error to the user.

```js
async function likePost(postId) {
  const previous = getPost(postId); // snapshot BEFORE mutating
  setPost(postId, { ...previous, liked: true, likeCount: previous.likeCount + 1 }); // 1. optimistic apply

  try {
    const serverPost = await api.likePost(postId); // 2. fire request
    setPost(postId, serverPost); // 3a. reconcile with authoritative response
  } catch (err) {
    setPost(postId, previous); // 3b. rollback to snapshot
    showToast('Could not like post — please try again.');
  }
}
```

## Why the snapshot matters more than it looks like it should

The naive rollback mistake is hardcoding what "before" looked like (e.g. `likeCount - 1`) instead of snapshotting the actual prior state. That breaks the moment two optimistic updates can be in flight concurrently — if a second like/unlike happens before the first request resolves, a hardcoded `-1` rollback can under- or over-correct the count. Always **capture the real previous value at the moment you apply the optimistic update**, and roll back to that captured value specifically, not to a recomputed guess.

## Concurrent mutations and race conditions

If a user can trigger the same optimistic mutation twice in quick succession (double-click a "like" button, or edit the same field twice before the first save returns), naive optimistic code can roll back the *second* optimistic update using the *first* request's snapshot, undoing a change the user made after the snapshot was taken. Two common mitigations:

- **Request cancellation / superseding** — cancel (via `AbortController`) or ignore the result of an in-flight request if a newer one for the same resource has since started; only the latest request's outcome is allowed to write to state.
- **Sequence/version tagging** — tag each optimistic update with an incrementing version number; when a response comes back, only apply it (success or rollback) if its version is still the latest known for that resource, otherwise discard it as stale.

## Optimistic updates with a server-state cache library

React Query and SWR both have first-class support for this pattern because it's such a common need:

```js
// React Query
const mutation = useMutation({
  mutationFn: (newTodo) => api.updateTodo(newTodo),
  onMutate: async (newTodo) => {
    await queryClient.cancelQueries({ queryKey: ['todos'] }); // avoid an in-flight refetch clobbering the optimistic value
    const previous = queryClient.getQueryData(['todos']);      // snapshot
    queryClient.setQueryData(['todos'], (old) => old.map(t => t.id === newTodo.id ? newTodo : t)); // optimistic apply
    return { previous }; // passed to onError as context
  },
  onError: (err, newTodo, context) => {
    queryClient.setQueryData(['todos'], context.previous); // rollback
  },
  onSettled: () => {
    queryClient.invalidateQueries({ queryKey: ['todos'] }); // reconcile with server truth either way
  },
});
```
The `cancelQueries` call matters: without it, a background refetch that was already in flight when the mutation started could resolve *after* the optimistic update and silently overwrite it with stale pre-mutation data.

## When NOT to use optimistic updates

- **The mutation's outcome is genuinely uncertain and consequential** — e.g. submitting a payment. Showing "Payment successful" optimistically and then rolling back to "actually, it failed" is a worse experience than a brief, honest loading state, because the user may have already acted on the false-positive confirmation (closed the tab, told someone, walked away).
- **The server computes something the client can't predict** — e.g. a price that depends on server-side tax/discount logic. Guessing wrong and flashing an incorrect number, then correcting it, can be more confusing than a short wait.
- **Failure is common/expected, not exceptional** — if a mutation fails often (e.g. due to real-time conflicts on shared data), constant flicker between optimistic and rolled-back states is worse UX than a normal loading indicator.

## Interview framing

*"Optimistic updates need three things to be correct, not just fast: a snapshot of the true previous state taken at the moment of the update (never a recomputed guess), a rollback path that restores exactly that snapshot on failure, and a strategy for concurrent/overlapping mutations so a late response can't roll back a newer optimistic change. I'd only apply the pattern where a wrong-then-corrected UI is an acceptable trade for perceived speed — not for high-stakes or high-failure-rate mutations."*
