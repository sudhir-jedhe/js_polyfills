# Designing a State Management Strategy for a Large App

This is the classic "how would you architect state for X app" frontend system design question (a dashboard, an e-commerce site, a chat app). Interviewers are not looking for "I'd use Redux for everything" — they're testing whether you can **decompose state by category first, then pick a tool per category**, and articulate the trade-offs of your choices. This file is the synthesis of the other theory files into a repeatable framework.

## Step 1 — Inventory the state, don't pick tools yet

Before naming a single library, list out the actual pieces of state the app needs and classify each one using the categories from the local/global/server theory file:

| State | Category |
|---|---|
| Is the nav sidebar collapsed | Local/global client (UI preference) |
| Current logged-in user's profile | Server state (fetched, can change) |
| List of products on a listing page | Server state |
| Current page number, active filters | URL state |
| Items in the shopping cart | Global client state (client-authoritative until checkout) — or server state if carts are synced server-side per user |
| Contents of a multi-step checkout form, before submit | Local to the checkout flow (colocated), possibly lifted to the flow's root, not global-app-wide |
| Theme (light/dark) | Global client state, often persisted to `localStorage` |
| WebSocket-delivered live notifications | Server state, but push-based rather than pull-based — still "cache of server-owned truth" |

Doing this inventory out loud in an interview signals the categorical thinking they're testing for, before any tool name comes up.

## Step 2 — Assign one tool family per category, not one tool for everything

| Category | Typical tool | Why |
|---|---|---|
| Local UI state | `useState`/`useReducer` | No sharing needed, zero setup cost |
| Global client state | Context (low churn) or Zustand/Redux (high churn / needs selectors) | Client is authoritative, no network lifecycle |
| Server state | React Query / SWR | Handles caching, staleness, refetch, dedup for free |
| URL state | Router state (`useSearchParams`, route params) | Native shareability/back-button support |
| Cross-tab / persisted client state | Store + `localStorage` sync (or BroadcastChannel for live cross-tab sync) | Survives reload, optionally syncs across tabs |

The architectural point to make explicit: **using a single tool (e.g. Redux) for all five rows is exactly the anti-pattern this framework avoids** — you'd end up re-implementing cache invalidation and staleness tracking for server data inside Redux by hand, and re-implementing shareable-URL semantics for filters that the router already gives you.

## Step 3 — Define ownership boundaries and colocate within them

Once tools are assigned, structure the global store (if one exists) by feature/domain slice, not as one flat object — see the colocation theory file. A large app's state architecture should mirror its feature boundaries: `cartSlice`, `authSlice`, `notificationsSlice`, each owned by the team that owns that feature, each independently testable.

## Step 4 — Plan the boundaries explicitly (a good answer names these trade-offs)

- **Where does server-state caching live relative to routing?** — e.g. React Query keys often incorporate route params, so navigating away and back can either reuse the cache (if `staleTime` hasn't elapsed) or refetch.
- **What happens to global client state on logout?** — a store needs an explicit reset action; forgetting this is a common real bug (next user briefly sees the previous user's cached state).
- **How does optimistic UI (see the dedicated theory file) interact with the server-state cache?** — an optimistic update mutates the local cache before the server confirms; the strategy must define the rollback path.
- **Does state need to persist across a full reload?** — if yes (e.g. cart), a middleware/sync layer to `localStorage` is part of the architecture, and needs a size/PII policy (never persist auth tokens or sensitive data unencrypted).
- **How is state kept out of components that don't need it?** — via colocation and, in a store, via selector-based subscriptions rather than subscribing to the entire store.

## A model answer structure (interview delivery)

1. *"First I'd inventory the state and bucket it into local/global-client/server/URL — because each has a different tool that fits well, and using one tool for all of them creates avoidable complexity."*
2. *"For server data I'd use React Query/SWR rather than pushing fetched data into the global store, since that gives caching, dedup, and staleness handling for free."*
3. *"For global client state I'd default to Context for low-churn values and a lightweight selector-based store for anything with many consumers or frequent updates, structured as feature slices rather than one flat object."*
4. *"Anything that should be shareable via link or survive a refresh — filters, pagination, selected tab — goes in the URL, not component state."*
5. *"I'd colocate everything else locally by default, and only hoist a piece of state when two non-adjacent components genuinely need to share it."*

This structure — categorize, assign per-category tools, then colocate within each — is what separates a strong system-design answer from a name-drop of a library.
