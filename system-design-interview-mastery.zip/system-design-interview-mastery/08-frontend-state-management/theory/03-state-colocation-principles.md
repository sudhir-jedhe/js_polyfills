# State Colocation Principles

**State colocation** means keeping a piece of state as close as possible to the components that actually use it — the opposite instinct of "when in doubt, put it in global state." It's one of the highest-leverage, lowest-effort architectural habits for keeping a large app's state manageable, and it's a favorite "what would you fix in this codebase" interview probe.

## The core principle

> Every piece of state should live at the lowest common ancestor of the components that need it — no higher.

If only `SearchInput` reads and writes the search text before submission, that text belongs in `SearchInput`'s own local state, not in a global store, even if the *submitted* query eventually needs to be global (e.g. reflected in the URL and used by a results-fetching component elsewhere).

## Why over-hoisting state is a real cost, not just a style nitpick

1. **Unnecessary re-renders.** State in a global store (or a high-level Context/parent) re-renders every subscriber when it changes. If a value only affects one small subtree, hoisting it means components far outside that subtree potentially re-render (or the team has to add memoization to compensate) for a change nothing else needed to know about.
2. **Harder to trace.** When state is colocated, "where is this value set and read" has an obvious, local answer. When it's hoisted to a global store "just in case," a developer has to search the whole app to find every reader/writer, and it becomes unclear whether a given piece of global state is even still used by anything.
3. **False shared-ness.** Two components can *look* like they need the same state, but they actually need independent copies. A classic bug: hoisting a form field's "is this field focused" state to a shared parent because "the form needs to know," when in reality only the field itself needs it and the form only needed the *submitted value*, not the transient UI state along the way.

## A worked colocation refactor

**Before (over-hoisted):**
```jsx
function ProductPage() {
  const [isDescriptionExpanded, setIsDescriptionExpanded] = useState(false); // only used by Description
  const [quantity, setQuantity] = useState(1); // only used by AddToCart
  const [product, setProduct] = useState(null); // server data, needed by multiple children

  useEffect(() => { fetchProduct().then(setProduct); }, []);

  return (
    <>
      <Description product={product} isExpanded={isDescriptionExpanded} onToggle={setIsDescriptionExpanded} />
      <AddToCart product={product} quantity={quantity} onQuantityChange={setQuantity} />
    </>
  );
}
```
Every keystroke/click inside `Description` or `AddToCart` re-renders `ProductPage`, and by extension anything else `ProductPage` renders (e.g. a sibling `Reviews` component), even though `Reviews` cares about neither piece of UI state.

**After (colocated):**
```jsx
function ProductPage() {
  const { data: product } = useProductQuery(); // server state, see the server-state theory file
  return (
    <>
      <Description product={product} />   {/* owns isExpanded itself now */}
      <AddToCart product={product} />      {/* owns quantity itself now */}
    </>
  );
}

function Description({ product }) {
  const [isExpanded, setIsExpanded] = useState(false); // moved down — colocated
  // ...
}
```
Now toggling the description only re-renders `Description`, and changing quantity only re-renders `AddToCart`. `ProductPage` only re-renders when `product` itself changes.

## Colocation applies to global stores too

Colocation isn't just "local vs global" — it also means, *within* a global store, grouping state by the feature/domain that owns it rather than one flat/global blob. A Redux store organized as `state.cart`, `state.auth`, `state.search` (feature slices) is colocated at the store level; a single undifferentiated `state` object with 200 top-level keys is not, even though both are "global state" technically.

## When to deliberately NOT colocate

Colocation is a default, not an absolute rule. Deliberately hoist state when:

- Two components that are *not* structurally close both need to read/write the same value (colocating would force one of them to own it and the other to prop-drill or duplicate it).
- The value needs to survive the unmount of the component that "naturally" owns it (e.g. a multi-step wizard's step 1 data must survive navigating to step 2's component tree).
- The value must be shared with something entirely outside the component tree (analytics, a service worker, another framework mounted alongside React).

## Interview framing

A good answer names the failure mode explicitly: *"The smell to look for is a component re-rendering on state changes it doesn't read — that's the signal state was hoisted higher than it needed to be. The fix is almost always moving the `useState` down to the smallest subtree that needs it, not adding `memo()` everywhere to paper over the re-renders."*
