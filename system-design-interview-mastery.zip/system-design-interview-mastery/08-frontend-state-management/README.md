# Frontend State Management

State management interviews go wrong in a predictable way: candidates default to naming a library (usually Redux) instead of first classifying *what kind* of state they're dealing with. This topic treats that classification — local, global client, server, and URL state — as the foundation, then builds up to the two questions that actually separate strong answers from weak ones: "how would you architect state for a large app," and "how do you handle optimistic updates and their rollback." Redux itself is covered in its own topic elsewhere in this repo; here the focus is the decision framework and the modern server-state distinction (React Query/SWR-style caching) that a Redux-only mental model misses entirely.

## Folder structure

- **[`theory/`](./theory)** — local vs. global vs. server state, lifting state up vs. a global store, colocation principles, designing a state strategy for a large app, URL as state, optimistic updates and rollback, and server-state caching mechanics (React Query/SWR patterns).
- **[`snippets/`](./snippets)** — 6 focused examples: colocated local state, Context for low-churn global state, URL-driven filters/pagination, an optimistic toggle with manual rollback, a React Query fetch+mutate+invalidate flow, and a selector-based store.
- **[`output-based/`](./output-based)** — 5 "given this code, what happens?" questions: an unmemoized Context value causing extra re-renders, a stale-closure race in a hand-rolled fetch effect, an unmemoized Redux selector, `staleTime` vs `gcTime` on remount, and a fragile relative-delta optimistic rollback.
- **[`scenarios/`](./scenarios)** — 5 real-world design/fix situations: architecting state for a dashboard, fixing a prop-drilled checkout flow, migrating server data out of Redux into React Query, optimistic drag-and-drop for a Kanban board, and de-duplicating filter state shared by five widgets.
- **[`interview-qa/`](./interview-qa)** — 3 themed files: state classification fundamentals, server state/caching patterns, and architecture decisions/optimistic UI.
- **[`problems/`](./problems)** — 3 hands-on challenges: build a reusable optimistic-mutation hook, design the state architecture for a collaborative doc editor, and implement a minimal cache-key-aware fetch hook (dedup + cache + invalidate) from scratch.
- **[`assets/`](./assets)** — placeholder for diagrams (see `assets/README.md`).

## What's covered

- Why server state "isn't really state in the traditional sense" — it's a client-side cache of server-owned truth, requiring staleness tracking, deduplication, and background refetching that generic state containers don't provide on their own
- The escalation path for shared state: colocate → lift to common ancestor → Context (low churn) → dedicated store with selectors (high churn / many consumers)
- URL state as the source of truth for anything shareable, bookmarkable, or expected to survive a refresh — and how it composes with server-state cache keys
- A repeatable framework for the "architect state for a large app" interview question: inventory state by category first, assign one tool family per category, then colocate within each
- Optimistic updates: the snapshot-apply-reconcile lifecycle, why rollback must restore an actual snapshot (not a recomputed guess), and how concurrent/overlapping mutations are guarded against races
- Core React Query/SWR mechanics: cache keys, `staleTime` vs `gcTime`, stale-while-revalidate, background refetch triggers, and invalidation after mutations
