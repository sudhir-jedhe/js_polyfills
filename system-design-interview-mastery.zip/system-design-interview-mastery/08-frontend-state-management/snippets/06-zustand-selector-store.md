# Snippet: A Minimal Selector-Based Store (Zustand-Style)

```js
const useCartStore = create((set, get) => ({
  items: [],
  addItem: (item) => set(state => ({ items: [...state.items, item] })),
  removeItem: (id) => set(state => ({ items: state.items.filter(i => i.id !== id) })),
  total: () => get().items.reduce((sum, i) => sum + i.price * i.qty, 0),
}));
```

```jsx
// Selective subscription — this component ONLY re-renders when items.length changes,
// not when unrelated slices of the store (if any existed) change.
function CartBadge() {
  const itemCount = useCartStore(state => state.items.length);
  return <span className="badge">{itemCount}</span>;
}

// A different consumer subscribes to a totally different slice/derivation —
// re-renders independently of CartBadge.
function CartTotal() {
  const total = useCartStore(state => state.total());
  return <span>${total.toFixed(2)}</span>;
}
```

This is the concrete difference from Context: a Context consumer re-renders on *any* Provider `value` change, but `useCartStore(selector)` only re-renders when the **selected slice's** reference/value actually changes — adding an item updates `items.length` (re-renders `CartBadge`) and `total()` (re-renders `CartTotal`), but a hypothetical unrelated field on the same store (e.g. `isCartDrawerOpen`) changing would re-render neither.
