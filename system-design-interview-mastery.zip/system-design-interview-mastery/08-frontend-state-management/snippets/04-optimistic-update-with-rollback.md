# Snippet: Optimistic Toggle with Manual Rollback

```jsx
function TodoItem({ todo }) {
  const [localTodo, setLocalTodo] = useState(todo);
  const [error, setError] = useState(null);

  async function toggleComplete() {
    const previous = localTodo;             // snapshot BEFORE mutating
    const optimistic = { ...previous, completed: !previous.completed };

    setLocalTodo(optimistic);                // 1. apply immediately
    setError(null);

    try {
      const saved = await api.updateTodo(optimistic); // 2. fire request
      setLocalTodo(saved);                             // 3a. reconcile with server truth
    } catch (err) {
      setLocalTodo(previous);                          // 3b. rollback to exact snapshot
      setError('Could not save — reverted.');
    }
  }

  return (
    <div>
      <label>
        <input type="checkbox" checked={localTodo.completed} onChange={toggleComplete} />
        {localTodo.text}
      </label>
      {error && <span role="alert">{error}</span>}
    </div>
  );
}
```

The rollback restores `previous` — the object captured at the moment of the optimistic apply — rather than recomputing `!optimistic.completed`. If a second toggle fires before the first request resolves, each toggle captures its own accurate snapshot, so a failure correctly reverts to whatever state actually preceded it, not a guessed inverse.
