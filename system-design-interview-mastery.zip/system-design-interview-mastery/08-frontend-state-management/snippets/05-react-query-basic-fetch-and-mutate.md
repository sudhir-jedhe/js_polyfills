# Snippet: React Query — Fetch + Mutate + Invalidate

```jsx
function TodoList() {
  const queryClient = useQueryClient();

  // Server state: cached, deduplicated, auto-refetched on refocus
  const { data: todos, isLoading, isError } = useQuery({
    queryKey: ['todos'],
    queryFn: () => api.fetchTodos(),
    staleTime: 30_000, // treat data as fresh for 30s — no refetch storm on rapid remounts
  });

  const addTodo = useMutation({
    mutationFn: (text) => api.createTodo({ text, completed: false }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['todos'] }); // server truth wins — refetch after write
    },
  });

  if (isLoading) return <Spinner />;
  if (isError) return <ErrorBanner />;

  return (
    <>
      <ul>{todos.map(t => <li key={t.id}>{t.text}</li>)}</ul>
      <button onClick={() => addTodo.mutate('New task')} disabled={addTodo.isPending}>
        Add
      </button>
    </>
  );
}
```

Mounting `TodoList` twice on the same page (e.g. in a sidebar and a modal simultaneously) triggers exactly **one** network request for `['todos']` — both instances share the cache entry and re-render together when it resolves.
