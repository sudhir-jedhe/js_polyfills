# Snippet: Filters and Pagination as URL State

```jsx
// React Router v6 — filters/pagination live in the URL, not component state
function ProductListPage() {
  const [searchParams, setSearchParams] = useSearchParams();

  const category = searchParams.get('category') ?? 'all';
  const page = Number(searchParams.get('page') ?? '1');

  const { data, isLoading } = useQuery({
    queryKey: ['products', { category, page }], // URL params double as the cache key
    queryFn: () => fetchProducts({ category, page }),
  });

  function setCategory(next) {
    setSearchParams(prev => {
      const params = new URLSearchParams(prev);
      params.set('category', next);
      params.set('page', '1'); // reset pagination on filter change
      return params;
    });
  }

  function setPage(next) {
    setSearchParams(prev => {
      const params = new URLSearchParams(prev);
      params.set('page', String(next));
      return params;
    }, { replace: true }); // page clicks replace, not push — avoids a bloated back-button history
  }

  return isLoading ? <Spinner /> : (
    <>
      <CategoryFilter value={category} onChange={setCategory} />
      <ProductGrid products={data.items} />
      <Pagination page={page} totalPages={data.totalPages} onPageChange={setPage} />
    </>
  );
}
```

Visiting `/products?category=shoes&page=2` directly (a shared link, or hitting refresh) reproduces the exact same view — nothing was lost because none of this lived in memory-only state.
