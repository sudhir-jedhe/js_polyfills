# Snippet: Local State, Colocated

```jsx
// A toggle that only this component cares about — stays local, no store needed.
function Accordion({ title, children }) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div>
      <button onClick={() => setIsOpen(o => !o)} aria-expanded={isOpen}>
        {title}
      </button>
      {isOpen && <div>{children}</div>}
    </div>
  );
}
```

Nothing outside `Accordion` needs `isOpen`, so hoisting it to a parent, Context, or a global store would only add re-render surface with zero benefit. Ten `<Accordion>` instances on a page each manage their own `isOpen` independently — no coordination needed.

```jsx
// Contrast: state that LOOKS local but actually needs to be shared —
// lift it only as far as the components that need it, not further.
function FilterableList({ items }) {
  const [query, setQuery] = useState(''); // shared by SearchBox (writes) and List (reads) — lifted to their common parent
  const filtered = items.filter(i => i.name.includes(query));

  return (
    <>
      <SearchBox value={query} onChange={setQuery} />
      <List items={filtered} />
    </>
  );
}
```
