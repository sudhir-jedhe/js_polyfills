# Snippet: Context for Low-Churn Global State

```jsx
const ThemeContext = createContext(null);

function ThemeProvider({ children }) {
  const [theme, setTheme] = useState('light');
  const value = useMemo(() => ({ theme, setTheme }), [theme]); // memoize so identity is stable unless theme changes

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error('useTheme must be used within ThemeProvider');
  return ctx;
}

// Any descendant, however deep, reads it directly — no prop drilling:
function ThemeToggle() {
  const { theme, setTheme } = useTheme();
  return (
    <button onClick={() => setTheme(t => t === 'light' ? 'dark' : 'light')}>
      Switch to {theme === 'light' ? 'dark' : 'light'} mode
    </button>
  );
}
```

Two details that matter in production code, not just demos:

1. **`useMemo` on the Provider's `value`** — without it, every re-render of `ThemeProvider` creates a brand-new object, which forces every consumer to re-render even when `theme` itself hasn't changed (referential equality check fails on the new object every time).
2. **Splitting into `ThemeContext` + `useTheme` hook** with a null-check — surfaces a clear error if someone consumes the context outside its provider, rather than silently getting `undefined`.

This pattern is appropriate here because theme changes are infrequent (a handful of times per session at most) and the number of consumers, while potentially large, doesn't cause a meaningful re-render cost at this update frequency.
