# Interview Q&A — State Classification Fundamentals

**Q: What are the main categories of frontend state, and why does the distinction matter?**
Local (component-scoped UI state), global client state (client-owned, shared across the app), server state (a cached copy of data owned by the server), and URL state (anything that should be shareable/bookmarkable/survive refresh). It matters because each category has different requirements — a solution that's great for one (e.g. a generic store for client-owned state) is a poor fit for another (e.g. that same store re-implementing cache invalidation for server data by hand).

**Q: Why do people say "server state isn't really state in the traditional sense"?**
Because the client doesn't own the source of truth — the server does, and other users/processes can change it at any time without the client knowing. That means server state inherently needs staleness tracking, caching, deduplication, and background refetching — a request *lifecycle* — which generic state containers like `useState` or Redux don't model at all unless you hand-build it.

**Q: When should you lift state up vs. use Context vs. use a dedicated store?**
Lift state to the nearest common ancestor when a small number of nearby components share it. Reach for Context when prop drilling through several structurally distant components becomes painful, but only if the value changes infrequently, since every Context consumer re-renders on any value change. Reach for a dedicated store when you need selective (slice-based) subscriptions — many consumers, frequent updates, or a need for middleware/devtools.

**Q: What is state colocation, and what's the concrete cost of skipping it?**
Colocation means keeping state as close as possible to the components that use it — the lowest common ancestor, not higher. Skipping it (over-hoisting state "just in case") causes components that don't even read the hoisted value to still be affected by wider re-render trees rooted higher up, and makes it harder to trace where a value is actually read/written since it's not obviously scoped to the components that use it.

**Q: Give an example of state that looks local but should actually be global (or vice versa).**
Looks local but isn't: a shopping cart's contents — it looks like it could live in one `Cart` component, but the header badge, the checkout page, and a mini-cart dropdown all need to read it, so it needs to be lifted or centralized. Looks global but isn't: "is this specific accordion panel expanded" — even if there are many accordions on a page, each one's expanded state is independent and belongs locally to that instance, not in a shared store keyed by ID (which would just be a worse, more error-prone version of local state).

**Q: How does URL state relate to the other three categories?**
It's orthogonal to them — the same piece of "global-feeling" state (e.g. active filters) should live in the URL specifically *because* it needs to be shareable and survive refresh, which neither local state, Context, nor an in-memory store gives you on their own. The URL is effectively the persistence + shareability layer; component/store state is usually derived from it, not the other way around.
