# Interview Q&A — Server State and Caching Patterns

**Q: What problem do React Query / SWR actually solve that `useEffect` + `useState` doesn't?**
Cache-key-based deduplication (two components requesting the same resource share one request and one cache entry), staleness tracking (`staleTime`), stale-while-revalidate rendering (show cached data instantly, refresh in background), automatic refetch on window refocus/reconnect, and invalidation hooks after mutations. Hand-rolled `useEffect` fetching has none of this by default and tends to accumulate race conditions (see the stale-closure output-based question) as an app grows.

**Q: Explain the difference between `staleTime` and `gcTime`/`cacheTime`.**
`staleTime` controls how long data is considered fresh enough to skip an automatic background refetch. `gcTime` (formerly `cacheTime`) controls how long an unused cache entry is kept in memory at all before eviction. Data can be stale but still cached (shown instantly, then silently refreshed), or evicted entirely (shown as a fresh loading state on remount) — these are two independent knobs, not one sliding scale.

**Q: What does "stale-while-revalidate" mean concretely?**
On a request, if cached data exists, show it immediately with no loading spinner, then fire a background request; when that resolves, silently swap in the fresh data. This avoids a loading flicker on every mount/refocus for data that's very likely still correct, while still eventually correcting itself if it wasn't.

**Q: Why would a query automatically refetch just because the user switched browser tabs and came back?**
Refetch-on-window-refocus is a deliberate default in both libraries — the assumption is that time away from the tab is exactly when server data is most likely to have changed (someone else edited it, a background job ran), so refocus is treated as a signal worth revalidating on. It's configurable per query if it's not appropriate for a given resource (e.g. rarely-changing reference data).

**Q: How should a mutation update the UI after it succeeds — patch the cache manually, or invalidate and refetch?**
Both are valid depending on the situation. Invalidating (`invalidateQueries`) is simpler and guarantees consistency with server truth, at the cost of an extra round trip. Manually patching the cache (`setQueryData`) avoids the round trip and can be combined with optimistic updates for instant feedback, but requires the client to correctly predict/apply the server's resulting shape — worth it for high-frequency mutations (likes, toggles), often not worth the complexity for infrequent ones (a settings save).

**Q: If two components mount at the same time and both request the same resource, how many network requests fire?**
One. Both `useQuery` calls resolve to the same cache-key entry; the library deduplicates in-flight requests for the same key so only one actual network call is made, and both components receive the shared result when it resolves.
