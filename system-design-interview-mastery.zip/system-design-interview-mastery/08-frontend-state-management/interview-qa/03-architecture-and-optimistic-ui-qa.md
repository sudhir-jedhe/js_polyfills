# Interview Q&A — Architecture Decisions and Optimistic UI

**Q: You're asked "how would you architect state for a large app" — what's the strongest way to open your answer?**
Don't name a library first. Open by saying you'd inventory the actual pieces of state and classify each as local, global-client, server, or URL — because the categorization drives the tool choice, and defaulting to one tool (usually Redux) for everything is the anti-pattern the question is testing for.

**Q: What goes wrong if you put fetched server data directly into Redux (or any generic store) without a caching layer?**
You end up hand-implementing, per-feature and often inconsistently, everything a server-state library gives for free: loading/error tracking, deduplication of concurrent requests for the same resource, staleness/refetch logic, and cache invalidation after writes. This typically shows up as real bugs — stale data after navigating away and back, duplicate requests, no refetch after tab refocus.

**Q: What are the three phases of an optimistic update, and what does each require?**
(1) Apply immediately — mutate local/cached state to the expected result, after snapshotting the true previous value. (2) Fire the request in the background. (3) Reconcile — on success, optionally replace with the server's authoritative response; on failure, roll back to the exact snapshot from step 1, not a recomputed guess.

**Q: Why is snapshotting the previous value better than computing a rollback as the inverse of the optimistic change?**
Because a relative/computed rollback (e.g. `count - 1`) assumes no other update has touched the value in between, which breaks under concurrent/overlapping mutations to the same piece of state. A snapshot captures the actual state at the exact moment of that specific update, so rolling back to it is correct regardless of what else happened concurrently, as long as updates and their rollbacks are properly ordered/versioned.

**Q: When would you deliberately avoid optimistic updates?**
When the outcome is genuinely uncertain and consequential (e.g. payment submission) — a false-positive "success" the user might act on before a rollback is worse than a brief honest loading state. Also when the server computes a value the client can't predict (tax, discounts) or when failures are common enough that constant optimistic-then-rollback flicker would itself be a bad experience.

**Q: How do you decide whether shared state across several sibling components should live in Context, a store, or the URL?**
Ask whether it needs to be shareable/bookmarkable/refresh-survivable — if yes, URL first. If not, and it changes infrequently, Context. If it changes frequently and/or has many consumers where re-render cost matters, a store with selector-based subscriptions. The mistake to avoid is skipping straight to a store without checking whether the value actually belonged in the URL, since a store doesn't give you shareability or back-button support for free.

**Q: What's a concrete symptom that tells you state was hoisted higher than it needed to be?**
A component re-renders when a state value changes that it doesn't actually read/display — that's the signal. The fix is moving the state down (colocating it to the smallest subtree that needs it), not reaching for `memo()`/`useMemo()` everywhere to suppress the symptom while leaving the state at the wrong level.
