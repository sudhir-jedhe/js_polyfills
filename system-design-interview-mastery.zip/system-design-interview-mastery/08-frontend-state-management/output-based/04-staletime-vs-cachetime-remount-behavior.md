# Output: staleTime vs gcTime on Remount

```jsx
useQuery({
  queryKey: ['product', 42],
  queryFn: () => fetchProduct(42),
  staleTime: 10_000, // 10s
  gcTime: 5 * 60_000, // 5 min (React Query v5 name; v4 called this cacheTime)
});
```

Timeline:
- `t=0s`: `<ProductPage productId={42} />` mounts, fetch fires, data cached.
- `t=3s`: component unmounts (user navigates away).
- `t=8s`: component remounts with the same `productId`.
- `t=20s`: component remounts again (still same `productId`), after having stayed unmounted since `t=8s`... (assume it unmounted again at `t=10s`).

**Question:** At `t=8s`, does a network request fire? At `t=20s`?

**Answer:** At `t=8s` — no request fires, cached data renders instantly. At `t=20s` — a request DOES fire, but the previously cached data still renders instantly first, then gets silently replaced when the fetch resolves (stale-while-revalidate), *provided* the cache entry wasn't garbage-collected in between.

**Why:**
- At `t=8s` (8 seconds after the original fetch), the cache entry is still within `staleTime` (10s), so it's considered fresh — the query returns the cached value with no background refetch at all.
- At `t=20s` (20 seconds after the original fetch), the entry is well past `staleTime` (10s) — it's stale. But it's still within `gcTime` (5 minutes) since it was last "in use," so it hasn't been garbage-collected from memory. The stale-but-present cached value renders **immediately** (no spinner), and a background refetch is triggered because the data is stale; when that resolves, the UI silently updates to the fresh value.
- If the remount instead happened at `t=6min` — past `gcTime` — the cache entry would have been evicted entirely, and the query would show a loading state from scratch, exactly like a first-ever mount.

**The distinction interviewers are checking for:** `staleTime` controls whether a *background* refetch happens; `gcTime` controls whether the cached value exists **at all** to be shown instantly while that background refetch (if any) happens. Setting `staleTime: Infinity` with a short `gcTime` would mean the cache never triggers automatic background refetches, but still gets evicted from memory once unused for `gcTime` — the two knobs are independent.
