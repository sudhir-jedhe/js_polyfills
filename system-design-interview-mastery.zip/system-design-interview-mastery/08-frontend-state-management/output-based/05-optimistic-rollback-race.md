# Output: Optimistic Rollback Using a Recomputed Guess Instead of a Snapshot

```jsx
function LikeButton({ post }) {
  const [likeCount, setLikeCount] = useState(post.likeCount);

  async function handleLike() {
    setLikeCount(c => c + 1); // optimistic apply

    try {
      await api.likePost(post.id);
    } catch {
      setLikeCount(c => c - 1); // "rollback" — but is this correct?
    }
  }

  return <button onClick={handleLike}>{likeCount} likes</button>;
}
```

The user double-clicks fast: `handleLike` fires twice before either request resolves. `likeCount` starts at `10`. Both optimistic applies run (`10 → 11 → 12`). The **first** request then fails; the **second** succeeds.

**Question:** What does `likeCount` show once both requests have settled?

**Answer:** `11` — which happens to be numerically "acceptable" here by coincidence, but the same code pattern produces a genuinely wrong result if the failure/success order were reversed or if a third overlapping click occurred. Walk it through: after both optimistic applies, `likeCount = 12`. The first request fails → `c => c - 1` runs → `11`. The second request succeeds (no rollback needed) → stays `11`. Final: `11`, but only one like actually succeeded server-side, so `11` (started at 10, +1 for the successful like) is *correct only by luck of which one failed*.

**Why this is fragile, not actually correct in general:** the rollback uses `c => c - 1` — a relative decrement based on whatever `likeCount` happens to be **at rollback time**, not a snapshot of what it was before *that specific* optimistic update. If instead the **second** click's request had failed and the **first** succeeded, the same relative-decrement code would still land on `11` by coincidence of arithmetic (since both are just +1/-1 on a shared counter) — but as soon as the two concurrent optimistic updates apply *different* deltas (e.g. one is `+1` like, the other is an edit that recalculates `likeCount` to an arbitrary server-derived number), a relative rollback silently corrupts state because it has no idea what value existed before its specific update.

**Fix:** snapshot the actual prior value per-update (see the optimistic-updates theory file and its snippet) rather than expressing rollback as a relative delta — `setLikeCount(previousSnapshot)` instead of `setLikeCount(c => c - 1)` — and/or serialize concurrent mutations to the same resource (disable the button while a request is in flight, or use request versioning) so overlapping optimistic updates to the same field can't interleave at all.
