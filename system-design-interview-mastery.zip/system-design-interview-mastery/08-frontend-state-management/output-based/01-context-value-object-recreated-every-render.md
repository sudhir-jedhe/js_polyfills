# Output: Context Value Recreated Every Render

```jsx
function AppProvider({ children }) {
  const [count, setCount] = useState(0);

  return (
    <CountContext.Provider value={{ count, setCount }}>
      {children}
    </CountContext.Provider>
  );
}

function DisplayA() {
  const { count } = useContext(CountContext);
  console.log('DisplayA render');
  return <div>{count}</div>;
}

function DisplayB() {
  useContext(CountContext); // consumes context but doesn't render count
  console.log('DisplayB render');
  return <div>Static B</div>;
}
```

Parent `App` re-renders once for an unrelated reason (e.g. a sibling state change causes `AppProvider` itself to re-render), with `count` unchanged.

**Question:** Do `DisplayA` and `DisplayB` re-render?

**Answer:** Yes, both re-render, even though `count`'s *value* didn't change.

**Why:** `value={{ count, setCount }}` creates a brand-new object literal on every render of `AppProvider`. Context consumers compare the Provider's `value` by reference (`Object.is`), not deep-equal — a new object reference on every render means every consumer re-renders on every `AppProvider` render, regardless of whether the actual data inside changed. `DisplayB` re-renders too, even though it never reads `count` from the object, because Context has no field-level subscription — consuming the context at all subscribes to the whole `value` object's identity.

**Fix:** Wrap the value in `useMemo(() => ({ count, setCount }), [count])` so the object reference only changes when `count` itself changes — `AppProvider` re-rendering for unrelated reasons would then produce the same memoized value reference, and neither consumer would re-render.
