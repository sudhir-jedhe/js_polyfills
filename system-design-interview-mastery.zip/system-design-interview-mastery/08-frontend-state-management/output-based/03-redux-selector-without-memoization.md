# Output: Unmemoized Selector Causes Extra Re-renders

```jsx
// store shape: { todos: [...], ui: { theme: 'light' } }

function TodoCount() {
  // selector returns a NEW array every call via .filter()
  const incompleteTodos = useSelector(state => state.todos.filter(t => !t.completed));
  console.log('TodoCount render');
  return <div>{incompleteTodos.length} left</div>;
}
```

The user toggles the theme (`state.ui.theme` changes from `'light'` to `'dark'`); `state.todos` is completely unchanged.

**Question:** Does `TodoCount` re-render?

**Answer:** Yes — unnecessarily.

**Why:** `useSelector` (Redux) re-runs the selector function on every store update and re-renders the component if the **new** return value is not reference-equal (`===`) to the previous return value (by default, using strict equality). `state.todos.filter(...)` creates a brand-new array on every single call, regardless of whether `state.todos` itself changed — so even though the *contents* are logically identical, the reference is always different, and the component re-renders on every store update, including ones (like the theme toggle) that have nothing to do with todos.

**Fix options:**
1. **Memoized selector (Reselect / `createSelector`):**
```js
const selectIncompleteTodos = createSelector(
  state => state.todos,
  todos => todos.filter(t => !t.completed) // only recomputes when state.todos reference changes
);
```
2. **Shallow-equality comparator** passed to `useSelector` (`useSelector(selector, shallowEqual)`) if the selector must return a new object/array shape but its *contents* are what matters.
3. Select only primitive/stable values directly when possible (`state.todos.length`) rather than deriving a new array, if the derivation doesn't need to be an array at all.

This is the general lesson behind "selective subscription" tools (Redux, Zustand): the subscription mechanism only helps if the selector itself returns a stable reference for unchanged logical output — an unmemoized derived-array selector defeats it.
