# Output: Stale Closure in a Hand-Rolled Fetch Effect

```jsx
function UserProfile({ userId }) {
  const [user, setUser] = useState(null);

  useEffect(() => {
    fetchUser(userId).then((data) => {
      setUser(data); // no guard
    });
  }, [userId]);

  return <div>{user?.name}</div>;
}
```

The parent quickly changes `userId` from `1` to `2` (e.g. the user clicks through a list fast). The request for `userId=1` is slower to resolve than the request for `userId=2`.

**Question:** Which user's data ends up displayed?

**Answer:** User `1`'s data — the wrong one — even though `userId` is now `2` in the UI (e.g. the URL/route already shows profile 2).

**Why:** Both effect runs fire their `fetch` calls; there is no cancellation and no check for "is this response still relevant." The request for `userId=2` resolves first and calls `setUser(user2Data)`. Then the slower request for `userId=1` resolves and calls `setUser(user1Data)`, unconditionally overwriting the correct value with stale data from a request that's no longer relevant. `setUser` inside the `.then()` doesn't know which `userId` it was originally requested for versus what's now current — it's a **race condition**, not a stale closure in the classic "captured old variable" sense, but it stems from the same root cause: the effect has no way to know a newer render has superseded it.

**Fix options:**
1. **Cleanup-based guard:**
```jsx
useEffect(() => {
  let cancelled = false;
  fetchUser(userId).then((data) => {
    if (!cancelled) setUser(data);
  });
  return () => { cancelled = true; }; // runs before the next effect, or on unmount
}, [userId]);
```
2. **`AbortController`** to actually cancel the in-flight request, not just ignore its result.
3. **Use a server-state library** (React Query/SWR) — this exact race condition is handled internally by query-key-based request superseding, which is one of the concrete reasons to prefer them over hand-rolled `useEffect` fetching for anything beyond a trivial one-off.
