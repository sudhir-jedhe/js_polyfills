# Problem: Build a Minimal `useOptimisticMutation` Hook

## Problem Statement

Implement a reusable React hook `useOptimisticMutation(currentValue, setValue, mutateFn)` that:

1. Applies an optimistic value immediately.
2. Calls `mutateFn(optimisticValue)` (an async function representing the network call).
3. On success, replaces the value with the server's response.
4. On failure, rolls back to the exact value that existed **before** the optimistic apply, and exposes an `error` the caller can render.
5. Correctly handles a second call starting before the first one has resolved: only the *latest* call's outcome should be allowed to write into state.

## Constraints

- No external libraries — plain React (`useState`, `useRef`).
- The hook returns `{ run, error, isPending }`, where `run(optimisticValue)` triggers the flow.
- Must not use a relative/computed rollback (see the optimistic-updates theory file for why that's unsafe) — must snapshot.

## Solution

```jsx
function useOptimisticMutation(currentValue, setValue, mutateFn) {
  const [error, setError] = useState(null);
  const [isPending, setIsPending] = useState(false);
  const requestIdRef = useRef(0); // guards against out-of-order responses

  async function run(optimisticValue) {
    const previous = currentValue;      // snapshot BEFORE mutating — not a computed inverse
    const thisRequestId = ++requestIdRef.current;

    setValue(optimisticValue);          // 1. apply immediately
    setError(null);
    setIsPending(true);

    try {
      const serverValue = await mutateFn(optimisticValue); // 2. fire request

      if (requestIdRef.current !== thisRequestId) return; // a newer call superseded this one — discard

      setValue(serverValue);              // 3a. reconcile with authoritative response
    } catch (err) {
      if (requestIdRef.current !== thisRequestId) return; // superseded — don't roll back over a newer update

      setValue(previous);                 // 3b. rollback to the exact snapshot
      setError(err);
    } finally {
      if (requestIdRef.current === thisRequestId) setIsPending(false);
    }
  }

  return { run, error, isPending };
}
```

**Usage:**
```jsx
function LikeButton({ post }) {
  const [likeState, setLikeState] = useState(post);
  const { run, error } = useOptimisticMutation(likeState, setLikeState, (optimistic) =>
    api.likePost(optimistic.id, optimistic.liked)
  );

  return (
    <>
      <button onClick={() => run({ ...likeState, liked: !likeState.liked, likeCount: likeState.likeCount + (likeState.liked ? -1 : 1) })}>
        {likeState.likeCount} likes
      </button>
      {error && <span role="alert">Could not update — reverted.</span>}
    </>
  );
}
```

**Why the `requestIdRef` guard matters:** without it, if `run` is called twice quickly (double-click) and the *first* call's request resolves *after* the second, the first call's success/failure handler would overwrite state set by the second, more recent call — discarding the user's latest action. Tagging each call with an incrementing id and checking it's still current before writing to state (in both the success and failure branches) ensures only the most recent call can ever mutate state, regardless of response ordering.

**Edge case worth calling out in an interview:** this hook snapshots `currentValue` fresh on every `run()` call, so two rapid calls each capture their own accurate "before" state — a genuine fix for the race condition shown in the optimistic-rollback output-based question, not just a superficial one.
