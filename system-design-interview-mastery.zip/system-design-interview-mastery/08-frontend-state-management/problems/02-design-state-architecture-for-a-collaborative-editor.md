# Problem: Design the State Architecture for a Collaborative Doc Editor

## Problem Statement

Design (at the architecture level — no need for full code) the frontend state management strategy for a Google-Docs-style collaborative text editor: multiple users can edit the same document simultaneously, changes should appear near-instantly for the typing user and propagate to other viewers within ~1 second, the document must autosave, and users can see who else is currently viewing/editing (presence).

## Constraints

- State categories to explicitly account for: the document content itself, cursor/selection position (per user), presence (who's online), save status, and document metadata (title, sharing settings).
- Must explain how local edits avoid waiting on a round trip before appearing (i.e., don't make every keystroke feel laggy).
- Must explain how conflicting edits from two users are reconciled at the state-management level (not asking for a full CRDT/OT implementation — just where that logic plugs into the state architecture).

## Solution

**1. Classify each piece of state first:**

| State | Category | Notes |
|---|---|---|
| Document content | Hybrid: locally-owned buffer, continuously synced to server | Not pure server state (too latency-sensitive to round-trip on every keystroke) and not pure client state (must converge with other users) |
| This user's cursor/selection | Local, but broadcast outward | Purely local to render locally; also pushed to others as presence data |
| Other users' cursors/presence | Server-pushed (WebSocket) state | Received, not owned locally |
| Save status (saved/saving/offline) | Local/global client state | Derived from the sync layer's own status, not fetched |
| Document metadata (title, sharing) | Server state | Standard fetch/cache/mutate — infrequent changes |

**2. Document content: local-first buffer, async-reconciled, not naive optimistic-update-and-rollback.** Unlike a "like button," a text edit can't be cleanly "rolled back" if the server rejects it — rejecting a keystroke mid-typing is not a viable UX. Instead, the standard architecture is a **local-first editable buffer** (e.g. backed by a CRDT or OT document model) that:
   - Applies every local keystroke to the local buffer instantly (no network round trip gates typing at all).
   - Streams ops/deltas to the server (and other clients) asynchronously in the background.
   - Merges incoming remote ops into the local buffer using the CRDT/OT merge algorithm, which is specifically designed so concurrent edits from multiple users converge to the same final document without needing a "reject and roll back" step — this is the state-architecture-level answer to the conflict question: **the merge logic itself is the reconciliation mechanism**, not a snapshot/rollback pattern like a simple optimistic mutation.

**3. Presence and remote cursors: WebSocket-driven ephemeral state, not part of the document's persisted content.** Presence (who's online, where their cursor is) is high-frequency, ephemeral, and doesn't need persistence — model it as a separate lightweight store keyed by `userId`, updated on each incoming presence message, and cleared on disconnect (with a heartbeat/timeout so a dropped connection doesn't leave a stale "ghost cursor" forever).

**4. Save status is derived state from the sync layer, not independently tracked.** Rather than a component manually setting `isSaving`/`isSaved` around each op send, the sync layer (the thing streaming ops to the server) exposes its own connection/flush state (`synced | syncing | offline`), and the UI subscribes to that directly — avoids a whole class of bugs where the UI's save indicator and the actual sync layer's real status drift apart.

**5. Document metadata is ordinary server state.** Title and sharing settings change infrequently and tolerate normal request latency — model with a standard query-caching library, completely separate from the high-frequency content-sync path. Don't route metadata edits through the same op-stream as content — they have different consistency and latency requirements.

**6. Autosave is a property of the sync layer, not a separate feature bolted on.** Because content is continuously streamed as ops rather than saved in discrete "Save" actions, autosave is inherent to the architecture rather than a periodic `setInterval(save, 5000)` layered on top — the latter would reintroduce the round-trip-blocks-typing problem the local-first buffer was designed to avoid.

**Why this architecture, stated for an interviewer:** *"The key realization is that document content here isn't a good fit for the optimistic-update-plus-rollback pattern used elsewhere in the app — you can't roll back a keystroke. So content gets a local-first buffer with a convergent merge algorithm doing reconciliation, while everything else (presence, save status, metadata) gets modeled with the state category it actually belongs to: presence as ephemeral push state, metadata as ordinary cached server state, save status as derived from the sync layer rather than tracked independently."*
