# Problem: Implement a Minimal Cache-Key-Aware `useResource` Hook

## Problem Statement

Without using React Query/SWR, implement a `useResource(key, fetchFn)` hook that demonstrates you understand the core mechanics those libraries provide:

1. **Deduplication** — if two components call `useResource('products', fetchProducts)` while a request for `'products'` is already in flight, only one network call fires; both components resolve from the same promise.
2. **Caching** — once resolved, subsequent mounts with the same key return the cached value instantly (no new request), unless explicitly invalidated.
3. **Manual invalidation** — expose a way to mark a key stale so the next mount/read refetches.

## Constraints

- Module-level cache (shared across all hook instances in the app) — a `Map` is fine.
- Don't worry about `staleTime`/background refetch/refocus — just dedup + cache + manual invalidate.
- Must work correctly if two components mount in the same render pass requesting the same key.

## Solution

```jsx
const cache = new Map();       // key -> { status: 'pending' | 'success' | 'error', data, error, promise }
const listeners = new Map();   // key -> Set of setState-like callbacks to notify on resolution

function useResource(key, fetchFn) {
  const [, forceRender] = useReducer(x => x + 1, 0);

  useEffect(() => {
    let entry = cache.get(key);

    if (!entry) {
      // Nothing cached and nothing in flight — start the ONE request for this key.
      const promise = fetchFn()
        .then((data) => {
          cache.set(key, { status: 'success', data });
          notify(key);
        })
        .catch((error) => {
          cache.set(key, { status: 'error', error });
          notify(key);
        });

      entry = { status: 'pending', promise };
      cache.set(key, entry);
    }

    // Subscribe this component instance to re-render when the key resolves.
    if (!listeners.has(key)) listeners.set(key, new Set());
    listeners.get(key).add(forceRender);

    return () => {
      listeners.get(key)?.delete(forceRender);
    };
  }, [key, fetchFn]);

  function notify(k) {
    listeners.get(k)?.forEach((fn) => fn());
  }

  const entry = cache.get(key);
  return {
    data: entry?.status === 'success' ? entry.data : undefined,
    error: entry?.status === 'error' ? entry.error : undefined,
    isLoading: !entry || entry.status === 'pending',
  };
}

function invalidateResource(key) {
  cache.delete(key);
  listeners.get(key)?.forEach((fn) => fn()); // trigger a re-render; effect re-runs since entry is now missing... 
  // NOTE: forceRender alone won't re-trigger the effect (key/fetchFn deps unchanged) — see the caveat below.
}
```

**Why deduplication works here:** the very first component to call `useResource('products', ...)` for an as-yet-uncached key is the one that creates the cache entry (synchronously, inside the effect, before any `await`/microtask yields control). Any other component whose effect for the same key runs afterward — even in the same batch of effects — sees `cache.get(key)` already populated with a `pending` entry and does **not** start a second `fetchFn()` call; it just subscribes as a listener and waits for the existing promise to resolve.

**A real caveat worth naming out loud (this is the kind of gap interviewers want you to catch yourself):** `invalidateResource` deletes the cache entry and notifies listeners to re-render, but a plain `forceRender` doesn't make the `useEffect` (whose dependency array is `[key, fetchFn]`, both unchanged) run again — so the effect that actually kicks off a refetch won't fire. A correct fix adds a `version` piece of state bumped by invalidation and included as an effect dependency (or the effect body re-checks `cache.get(key)` unconditionally on every render rather than only on mount/key-change) — calling this out explicitly is a good signal of understanding the subtlety that real libraries handle for you, rather than presenting a solution that silently has the same bug.

**What this exercise demonstrates:** implementing even the dedup+cache subset by hand exposes how much state-machine bookkeeping (pending/success/error, per-key subscriber sets, invalidation triggering an actual refetch and not just a re-render) a "just fetch it yourself" approach quietly needs — which is the concrete case for reaching for React Query/SWR in real applications rather than hand-rolling this repeatedly per feature.
