# Scenario: Fixing an Over-Drilled Legacy Checkout Flow

**Scenario:** A multi-step checkout (`Cart → Shipping → Payment → Review`) passes `cartItems`, `shippingAddress`, `paymentMethod`, `discountCode`, and six callback props through every intermediate component, several of which don't use most of these props themselves — they just forward them. Adding a new field to the checkout means touching 8 files. You're asked to fix the architecture without a full rewrite.

**Approach:**

**1. Diagnose: this is prop drilling through structurally distant components, not a case that needs a heavyweight global store.** The checkout flow's state genuinely is shared across the whole flow (every step reads/writes some subset of it), and the tree is deep — this is exactly the shape Context (or a scoped store) is meant for, not evidence that everything needs to go into the app-wide Redux store.

**2. Scope the fix to the checkout flow specifically — don't promote checkout state to the global app store.** Checkout state has a clear lifetime: it starts when the user enters the flow and should be cleared when they leave it (complete or abandon). A `CheckoutProvider` wrapping just the checkout route subtree keeps that lifetime explicit and prevents checkout data from leaking into global state that outlives the flow (a common bug: stale cart/payment data lingering in a global store after checkout completes, briefly visible if the user starts a second checkout later).

```jsx
function CheckoutFlow() {
  return (
    <CheckoutProvider>
      <Routes>
        <Route path="cart" element={<Cart />} />
        <Route path="shipping" element={<Shipping />} />
        <Route path="payment" element={<Payment />} />
        <Route path="review" element={<Review />} />
      </Routes>
    </CheckoutProvider>
  );
}

function Payment() {
  const { paymentMethod, setPaymentMethod } = useCheckout(); // reads directly, no drilling
  // ...
}
```

**3. Split into more than one Context if update frequency differs across fields.** `discountCode` might change once; `shippingAddress` form fields could update on every keystroke while the user types. If they're bundled into one Context object, keystroke-level updates re-render every consumer of the whole checkout context, including components that only care about `paymentMethod`. Splitting into `CheckoutDataContext` (relatively stable, committed values) and a locally-owned form state per step (see colocation) avoids that: the address *form* stays local to `Shipping` while typing, and only the *committed* address (on "Continue") gets written into the shared context.

**4. Adding a new field now touches one file, not eight.** A new `giftMessage` field is added to the `CheckoutProvider`'s state shape and consumed directly wherever it's needed — no signature changes cascade through intermediate components that don't care about it.

**5. What NOT to do:** don't jump straight to Redux for this. The state is genuinely scoped to one flow with a clear start/end lifecycle — a scoped Context (or a store instance created and torn down with the flow, if update frequency truly demands selector-based subscriptions) solves the drilling problem without introducing global state that outlives its natural scope or requires manual cleanup on flow exit.

**Why this is the right level of fix:** *"The actual problem was drilling through distance, not a need for app-wide shared state — so I scoped the fix to a Context provider wrapping just the checkout subtree, split it by update frequency to avoid over-rendering, and kept transient per-step form state colocated locally rather than pushing every keystroke into the shared context."*
