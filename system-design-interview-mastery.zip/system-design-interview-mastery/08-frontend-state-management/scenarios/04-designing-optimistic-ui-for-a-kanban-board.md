# Scenario: Optimistic Drag-and-Drop for a Kanban Board

**Scenario:** You're building a Trello-style Kanban board where dragging a card between columns should feel instant. The move is persisted via `PATCH /cards/:id` (new column + position). The network can be slow, and two users can be editing the same board concurrently (another user might move/delete the same card at nearly the same time). Design the state update flow.

**Approach:**

**1. Apply the move optimistically on drag-drop, before the request resolves.** The instant the user drops the card, update the local/cached board state to reflect the new column and position — the card visually moves immediately, with no spinner or delay.

**2. Snapshot the true previous state, not a computed inverse.** Before mutating, capture the card's exact prior `{ columnId, position }` (and, more robustly, the entire prior ordering of both the source and destination columns, since a reorder affects the position of other cards too, not just the moved one).

```js
function moveCard(cardId, toColumnId, toIndex) {
  const previousBoard = cloneBoardState(board); // full snapshot — a move can shift many cards' positions
  const optimisticBoard = computeMovedBoard(board, cardId, toColumnId, toIndex);
  setBoard(optimisticBoard);

  api.moveCard(cardId, { columnId: toColumnId, position: toIndex })
    .then((serverBoard) => setBoard(serverBoard)) // reconcile with authoritative ordering
    .catch(() => {
      setBoard(previousBoard); // rollback the whole snapshot, not just the one card
      showToast('Move failed — card restored to its previous column.');
    });
}
```
Snapshotting the *whole board region* (not just the single card) matters because moving a card shifts the position of every other card after it in both the source and destination columns — a partial rollback would desync those siblings' positions from the server.

**3. Handle the concurrent-edit case explicitly — this is the crux of the scenario.** If another user deletes the card (or moves it) between this user's optimistic apply and the server's response, the `PATCH` can fail (404, or a conflict response) or the eventual reconciling fetch can show a board state where the card no longer exists as expected. The design must define: on conflict, prefer the server's authoritative state and surface a non-blocking notice ("This card was moved by someone else") rather than silently either keeping the now-incorrect optimistic state or hard-erroring the whole board.

**4. Use short-lived request identifiers to guard against out-of-order responses.** If the user drags the same card twice in quick succession (changes their mind mid-flow), tag each request with an incrementing version and only apply a response (success or rollback) if it's still the latest request for that card — otherwise a slow first response arriving after a faster second one could stomp the more recent, correct state.

**5. Prefer periodic reconciliation over pure trust in optimistic state for a multi-user board.** Because this is a collaborative surface, layer in either a WebSocket subscription for live moves from other users, or a periodic background refetch — optimistic updates handle *this user's own* action feeling instant, but they don't substitute for learning about *other users'* concurrent changes, which is a separate server-state freshness problem (see the server-state-caching theory file).

**Why this design holds up under the "what if two people edit it at once" follow-up:** *"Optimistic updates make this user's own action feel instant and get rolled back cleanly with a full snapshot on failure. Concurrent edits from other users are a different problem — server-state freshness — solved by pushing live updates over a socket or reconciling periodically, and treating the server's response as authoritative on any conflict rather than assuming the optimistic guess was correct."*
