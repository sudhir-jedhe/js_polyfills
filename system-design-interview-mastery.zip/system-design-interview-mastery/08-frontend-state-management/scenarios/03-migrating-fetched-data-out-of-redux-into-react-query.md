# Scenario: Migrating Server Data Out of Redux Into React Query

**Scenario:** A large existing app stores everything — including all server-fetched data (product lists, user profiles, order history) — in Redux, using `createAsyncThunk` for every fetch, with hand-written `loading`/`error`/`data` reducers duplicated across a dozen slices. Bugs keep surfacing: stale data shown after navigating away and back, duplicate requests when two components mount at once, and no automatic refetch after the tab regains focus. You're asked to propose a fix without a big-bang rewrite.

**Approach:**

**1. Name the root cause precisely.** Redux is a generic state container; it has no built-in concept of staleness, cache keys, deduplication, or refetch-on-focus — every one of those behaviors was (or wasn't) hand-implemented per slice, inconsistently, which is exactly why bugs differ by feature. This is the textbook case for the "server state isn't really state in the traditional sense" distinction: the team used a general-purpose tool for a problem (network cache lifecycle) that has purpose-built tools.

**2. Propose an incremental migration, not a rewrite.** React Query (or SWR) can run **alongside** Redux — Redux keeps ownership of genuinely client-owned global state (auth session, UI prefs, cart-before-checkout), while server-derived data is migrated feature-by-feature into `useQuery`/`useMutation` calls, deleting the corresponding thunk + slice as each migrates.

```jsx
// Before: Redux thunk + slice boilerplate per resource
const fetchProducts = createAsyncThunk('products/fetch', () => api.getProducts());
// + a reducer with pending/fulfilled/rejected cases, loading flags, error strings...

// After: one hook call replaces the thunk, the slice, and the loading/error boilerplate
function useProducts() {
  return useQuery({ queryKey: ['products'], queryFn: api.getProducts, staleTime: 60_000 });
}
```

**3. Address each named bug directly, and show it's a structural fix, not a patch:**
- *Stale data after navigating away and back* — solved by `staleTime`/cache semantics: within `staleTime`, cached data shows instantly; beyond it, stale-while-revalidate refreshes it in the background automatically, with no per-feature code needed.
- *Duplicate requests on simultaneous mount* — solved by cache-key-based request deduplication, which is automatic, not something each feature team needs to remember to implement.
- *No refetch on refocus* — a config default in the query client, applied globally in one place, rather than a feature developers had to opt into per-thunk (and evidently didn't, consistently).

**4. Migration order — pick low-risk, high-symptom features first.** Migrate the resources with the worst reported staleness/duplication bugs first, both because it delivers visible value early and because it validates the pattern (query client setup, error boundary integration, existing component prop contracts) before touching more critical flows like checkout.

**5. Keep Redux DevTools-style observability if the team relies on it.** React Query has its own devtools (query inspector showing cache state, staleness, fetch status per key) — call this out explicitly, since "we'll lose the ability to debug state" is a common objection to migrating off Redux, and it's not actually true for the server-state slice being migrated.

**Why this is the stronger answer over "rewrite everything":** *"I'd migrate feature-by-feature, letting Redux keep the state it's actually good at — client-owned global state — while server-derived data moves into a caching library purpose-built for the request lifecycle. Every symptom the team is hitting (staleness, duplication, no refetch-on-focus) is a known gap in hand-rolled Redux-for-server-data, not a set of unrelated bugs, so the fix is structural and applies to the next fetch the team adds too, not just the ones we patch today."*
