# Scenario: A Filter Panel Shared by Five Independent Widgets

**Scenario:** A dashboard page renders five independent chart widgets, each fetching its own data, but all five must respect the same set of global filters (date range, region, product line) set from one filter panel at the top of the page. Currently each widget duplicates its own copy of the filter state via separate `useState` calls synced clumsily with `useEffect`, and filters drift out of sync between widgets. Fix the architecture.

**Approach:**

**1. Identify the actual bug class: state that should be single-sourced is instead duplicated per-consumer.** Five independent `useState` calls for what is conceptually one shared value is guaranteed to drift, because there's no single source of truth being read — each widget's copy can update independently and nothing keeps them synchronized except manually-written `useEffect` sync code, which is exactly the kind of code that has edge cases (order-of-updates, missed dependencies) leading to drift bugs.

**2. This is a textbook "lift state up" situation, not necessarily a case for a heavyweight store — but check the tree shape first.** If all five widgets are siblings under one page component, the filters can lift to that common ancestor and pass down as props, or — since there are five distinct consumers reading the same values with no drilling issue if they're direct children — Context is a reasonable middle ground:

```jsx
function DashboardPage() {
  const [filters, setFilters] = useState({ dateRange: 'last30d', region: 'all', productLine: 'all' });

  return (
    <FiltersContext.Provider value={useMemo(() => ({ filters, setFilters }), [filters])}>
      <FilterPanel /> {/* writes filters */}
      <RevenueWidget /> <ChurnWidget /> <ActiveUsersWidget /> <ConversionWidget /> <RegionalWidget /> {/* all read filters */}
    </FiltersContext.Provider>
  );
}
```

**3. Decide whether URL state is actually the better single source of truth here.** Since dashboard filters are exactly the kind of state that should be shareable/bookmarkable/survive-refresh (see the URL-as-state theory file), the stronger fix routes `filters` through the URL's query params instead of (or in addition to) Context — `FiltersContext` can simply read from `useSearchParams()` under the hood, giving both "single source of truth across widgets" AND "shareable filtered view" in one decision.

**4. Each widget's server-state fetch keys off `filters` directly, not off a locally duplicated copy.**
```jsx
function RevenueWidget() {
  const { filters } = useFilters(); // reads the ONE shared value
  const { data } = useQuery({
    queryKey: ['revenue', filters], // filters is part of the cache key — no manual sync needed
    queryFn: () => fetchRevenue(filters),
  });
  // ...
}
```
Because `filters` is read from one place (URL/Context) rather than duplicated, all five widgets' query keys change in lockstep the instant the shared value changes — there's no window where one widget has updated and another hasn't, because there's no longer a second copy to fall out of sync.

**5. Remove the `useEffect`-based sync code entirely.** The bug wasn't that the sync `useEffect`s were buggy in isolation — it's that duplicated state plus manual syncing is structurally prone to drift no matter how carefully the effects are written. Deleting the duplication removes the entire bug class, not just the specific instance encountered so far.

**Why this diagnosis is the key insight:** *"The recurring drift wasn't really five separate bugs — it was one structural problem: state that should have a single owner had five owners kept in sync by hand. The fix isn't to write better sync code, it's to remove the duplication by lifting to one shared source (and here, since the value should be shareable/bookmarkable too, the URL is actually the best single source, with Context or props as the read path down to each widget)."*
