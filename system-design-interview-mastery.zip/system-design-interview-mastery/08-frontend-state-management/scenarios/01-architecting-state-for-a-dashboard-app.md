# Scenario: Architecting State for an Analytics Dashboard

**Scenario:** You're designing the frontend architecture for a B2B analytics dashboard: a sidebar of saved reports, a main chart area with filterable date ranges and metric selectors, a live-updating "active users right now" counter (via WebSocket), user account settings, and the ability to share a fully-configured view via link. How do you architect the state?

**Approach:**

**1. Inventory and classify first.**

| State | Category |
|---|---|
| List of saved reports | Server state |
| Currently selected report + its config (date range, metrics, chart type) | URL state (must be shareable/bookmarkable per the requirement) |
| Chart data for the current config | Server state, keyed by the URL params |
| Live active-user count | Server state, but push-delivered (WebSocket) instead of pull-fetched |
| Sidebar collapsed/expanded | Local/global client UI state |
| User account settings (name, email, notification prefs) | Server state (fetched + mutated via forms) |
| In-progress "create new report" form before save | Local, colocated to the report-creation flow |

**2. URL as the backbone for the "shareable view" requirement.** Since the whole point is that a configured view must be shareable, the selected report ID, date range, and metric selection all live in query params (`?report=q3-revenue&from=2026-01-01&to=2026-03-31&metrics=mrr,churn`), not in a global store. This single decision satisfies "share a fully-configured view via link" for free — no custom share-link generation logic needed, because the URL already *is* the full state.

**3. Server state via a query-caching library, keyed off the URL.** Chart data fetching uses the URL params directly as the cache key: `['chartData', { report, from, to, metrics }]`. Changing the date range picker updates the URL (which updates the cache key), and React Query/SWR handles the fetch, loading state, and caching — including instantly re-showing cached data if the user flips back to a date range they'd already viewed this session.

**4. WebSocket-delivered live state gets its own small store, not shoved into the query cache.** The active-user counter doesn't fit the pull/refetch model — it's pushed. A minimal store (or even local state in the one component that displays it, if nothing else needs it) subscribes to the socket and updates on each message. If other parts of the dashboard eventually need the same live value, promote it to a small dedicated store rather than wiring every consumer to the socket directly.

**5. Sidebar/UI chrome state is local or a lightweight global store — not URL, not server.** Sidebar collapsed state doesn't need to be shareable (a colleague opening your shared link doesn't need your sidebar preference) and doesn't come from the server — it's a pure client UI preference, so `useState` plus maybe `localStorage` persistence (so it survives a reload) is enough.

**6. Account settings — server state with an explicit mutation + optimistic pattern for quick-toggle prefs (e.g. "email notifications on/off"), but a plain submit-and-wait flow for the profile form (name/email), since a rollback-visible flicker on identity fields is more confusing than a brief save-in-progress state.**

**Why this decomposition, stated as the interview answer:** *"I split state by category rather than picking one tool for everything: URL owns anything that defines 'what view is this,' a query-caching library owns anything fetched from the server (keyed by the URL params so navigation and caching compose naturally), a small dedicated store handles the one piece of push-delivered live data, and everything else — UI chrome, in-progress form state — stays local or lightly persisted. That keeps the shareable-link requirement essentially free, and keeps each piece of state's lifecycle matched to the tool actually built for that lifecycle."*
