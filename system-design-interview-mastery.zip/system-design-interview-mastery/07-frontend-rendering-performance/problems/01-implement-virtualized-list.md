# Problem: Implement a Virtualized List Component

## Problem Statement

Implement a reusable `VirtualizedList` React component that renders only the DOM nodes needed for the currently visible viewport (plus a small buffer), given a large array of fixed-height items, so that mounted DOM node count stays roughly constant regardless of the array's length.

## Constraints

- Must support at least 50,000 items without a noticeable drop in scroll frame rate.
- Must keep the scrollbar's size/position behaving as if all items were really rendered.
- DOM node count actually mounted at any time should not scale with total item count.
- Must handle scroll events efficiently (not recomputing more than necessary per scroll event).

## Approach

Compute the visible index range from `scrollTop` and `itemHeight` (`startIndex = floor(scrollTop / itemHeight)`), render only that slice plus a buffer, and use an outer spacer element sized to the full virtual height so the scrollbar behaves correctly. See `snippets/02-windowed-list-implementation.md` for the base mechanism; this problem extends it with overscan tuning and a resize-safe viewport height.

## Solution

```jsx
import { useState, useRef, useMemo, useCallback, useEffect } from "react";

function VirtualizedList({ items, itemHeight, renderItem, overscan = 5 }) {
  const containerRef = useRef(null);
  const [scrollTop, setScrollTop] = useState(0);
  const [viewportHeight, setViewportHeight] = useState(0);

  // measure the actual rendered viewport height (handles resizable containers)
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const observer = new ResizeObserver((entries) => {
      setViewportHeight(entries[0].contentRect.height);
    });
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  const totalHeight = items.length * itemHeight;

  const { startIndex, endIndex } = useMemo(() => {
    const visibleCount = Math.ceil(viewportHeight / itemHeight);
    const start = Math.max(0, Math.floor(scrollTop / itemHeight) - overscan);
    const end = Math.min(items.length, start + visibleCount + overscan * 2);
    return { startIndex: start, endIndex: end };
  }, [scrollTop, viewportHeight, itemHeight, items.length, overscan]);

  // throttle scroll handling to animation frames — avoids redundant state updates
  // for scroll events firing faster than the display can paint
  const rafId = useRef(null);
  const handleScroll = useCallback((e) => {
    const newScrollTop = e.currentTarget.scrollTop;
    if (rafId.current) return;
    rafId.current = requestAnimationFrame(() => {
      setScrollTop(newScrollTop);
      rafId.current = null;
    });
  }, []);

  const visibleItems = items.slice(startIndex, endIndex);

  return (
    <div
      ref={containerRef}
      onScroll={handleScroll}
      style={{ height: "100%", overflowY: "auto", position: "relative" }}
    >
      <div style={{ height: totalHeight, position: "relative" }}>
        {visibleItems.map((item, i) => {
          const index = startIndex + i;
          return (
            <div
              key={index}
              style={{ position: "absolute", top: index * itemHeight, height: itemHeight, width: "100%" }}
            >
              {renderItem(item, index)}
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default VirtualizedList;
```

## Verification

```jsx
const items = Array.from({ length: 50000 }, (_, i) => ({ id: i, name: `Item ${i}` }));

function App() {
  return (
    <div style={{ height: 600 }}>
      <VirtualizedList
        items={items}
        itemHeight={40}
        overscan={5}
        renderItem={(item) => <div style={{ padding: 8, borderBottom: "1px solid #eee" }}>{item.name}</div>}
      />
    </div>
  );
}
// Verify in DevTools: document.querySelectorAll('[style*="position: absolute"]').length
// stays around 20-25 regardless of items.length being 500 or 50,000.
```

## Complexity

- **Time per scroll update:** `O(overscan + viewportHeight/itemHeight)` — constant relative to total item count, not `O(n)`.
- **Space (mounted DOM nodes):** `O(viewport size)`, constant regardless of `items.length`.
- **`requestAnimationFrame` throttling** ensures at most one state update (and thus one re-render) per animation frame, even if `scroll` events fire more frequently than the display refresh rate — avoiding wasted render work beyond what can ever actually be painted.
