# Problem: Diagnose and Fix a CLS Regression from Real Metrics

## Problem Statement

You're given the following real `layout-shift` PerformanceObserver entries captured from a product listing page (viewport 1280x900, so viewport area = 1,152,000 px²):

```js
[
  { value: 0.02, hadRecentInput: false, sources: ["product-grid > .product-card:nth-child(3)"] },
  { value: 0.18, hadRecentInput: false, sources: ["#promo-banner"] },
  { value: 0.05, hadRecentInput: true,  sources: [".filter-panel"] }, // user clicked "Filter" just before
  { value: 0.09, hadRecentInput: false, sources: ["img.product-thumbnail"] },
]
```

Compute the page's CLS score from this data, identify the primary contributor, and propose the fix.

## Constraints

- Correctly apply the `hadRecentInput` exclusion rule per the CLS spec.
- Identify the single largest fixable contributor, not just sum everything.
- Propose a fix specific to the actual element/pattern causing the largest shift.

## Solution

**Step 1 — apply the exclusion rule.** Per the CLS spec (see `theory/04-core-web-vitals-lcp-inp-cls.md`), shifts within 500ms of user interaction are excluded — `hadRecentInput: true` on the `.filter-panel` entry means it's the user's own click causing an expected change, and its `0.05` is **excluded** from the CLS sum.

**Step 2 — sum the remaining (unexpected) shifts.**

```
CLS = 0.02 (product-card) + 0.18 (promo-banner) + 0.09 (product-thumbnail)
    = 0.29
```

**Step 3 — classify against thresholds.** `0.29 > 0.25` → this page is in the **"Poor"** bucket (threshold: Good ≤ 0.1, Poor > 0.25).

**Step 4 — identify the primary contributor.** `#promo-banner` at `0.18` accounts for `0.18 / 0.29 ≈ 62%` of the total score — by a wide margin the dominant contributor, and the one to fix first for the highest-leverage improvement. Fixing it alone would bring CLS to `0.02 + 0.09 = 0.11` — still "Needs Improvement" but a dramatic improvement, and worth doing before addressing the smaller remaining contributors.

**Step 5 — diagnose why `#promo-banner` causes a 0.18 shift.** A shift of this magnitude (recall from `output-based/03-cls-calculation-worked-example.md` that even a 150px shift on a large element scored ~0.10) suggests either a large element (wide impact fraction) or a significant vertical movement (large distance fraction), or both — consistent with a promo banner that has **no reserved space** and gets injected into the page after some async condition resolves (a promo eligibility check, an A/B test assignment, or a slow-loading creative), pushing the product grid down once it appears.

**Fix for `#promo-banner`:**

```css
/* BEFORE: no reserved space — banner insertion pushes everything below it down */
.promo-banner-slot {
  /* no height until content is injected */
}

/* AFTER: reserve the banner's known/typical height up front */
.promo-banner-slot {
  min-height: 90px; /* matches the banner's actual rendered height */
}
```
Or, if the banner's presence itself is conditional (some users see it, some don't, decided async), render a same-height placeholder/skeleton immediately and swap its *content* in place once the async decision resolves, rather than inserting a new element with its own height into the flow — this guarantees zero shift regardless of whether the banner ultimately appears or not, since the space was already accounted for either way.

**Remaining smaller contributors** (`.product-card`, `img.product-thumbnail`) are both consistent with images lacking explicit `width`/`height`/`aspect-ratio` — the standard fix (reserve space via explicit dimensions or `aspect-ratio`) applies to both, and should be handled as a systemic fix (audit all `<img>` usage in the product grid/card components) rather than patched per-instance, since the same root cause is very likely to recur across every product card on the page, not just the one instance sampled in this data.

## Expected outcome

Fixing all three unexpected-shift sources should bring CLS toward `~0.0`, comfortably within the "Good" (≤ 0.1) threshold — well below even the promo-banner-only partial fix's `0.11`.
