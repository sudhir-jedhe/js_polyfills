# Problem: Design a Code-Splitting Strategy for a Large Multi-Section App

## Problem Statement

Given an application with the following sections and their approximate current bundle contribution (all currently shipped in one bundle):

| Section | Bundle size | Visit frequency |
|---|---|---|
| Dashboard (landing page after login) | 180KB | Every session |
| Settings | 90KB | ~5% of sessions |
| Admin panel (only visible to admin role, ~2% of users) | 340KB | Rare, admin-only |
| Rich text editor (used inside a "compose" modal) | 410KB | ~15% of sessions, and only after opening the modal |
| Charting library (used in a "reports" tab within Dashboard) | 290KB | ~30% of Dashboard visits click into "reports" |
| Core app shell (router, auth, layout) | 120KB | Every session, always needed first |

Total current bundle: 1,430KB. Design a code-splitting strategy, specify what goes in the initial bundle vs. what's split into separate chunks, and estimate the new initial bundle size.

## Constraints

- The initial bundle must contain everything needed to reach a usable Dashboard, and nothing more than that.
- Splitting decisions must be justified by the visit-frequency/necessity data given, not applied uniformly.
- State explicitly which loading trigger (on-demand, on-hover, on-viewport, idle-prefetch) is used for each split chunk, and why.

## Solution

**Initial bundle (must-have for a usable Dashboard on every session):**

```
Core app shell:  120KB  (always needed first — router, auth, layout)
Dashboard:       180KB  (the landing page itself — every session needs it)
-----------------------
Initial bundle:  300KB
```

This is the only content justified for the initial bundle by the "every session" visit frequency — everything else is either role-gated (admin), low-frequency (settings, 5%), or conditionally-triggered-within-a-session (rich text editor, charting).

**Split 1 — Admin panel (340KB), on-demand, route-based:**
```jsx
const AdminPanel = lazy(() => import("./routes/AdminPanel"));
```
Justification: only ~2% of users are admins at all, and even for those users it's not needed on initial Dashboard load — the highest-leverage split by far, since 340KB is the single largest chunk and is irrelevant to 98% of users on every session.

**Split 2 — Settings (90KB), on-demand, route-based:**
```jsx
const Settings = lazy(() => import("./routes/Settings"));
```
Justification: only ~5% of sessions visit it; no reason to pay this cost on every Dashboard load for the 95% who don't.

**Split 3 — Rich text editor (410KB), on-demand, interaction-triggered (not route-based, since it lives inside a modal, not a route):**
```jsx
const RichTextEditor = lazy(() => import("./components/RichTextEditor"));

function ComposeModal({ isOpen }) {
  return isOpen ? (
    <Suspense fallback={<EditorSkeleton />}>
      <RichTextEditor />
    </Suspense>
  ) : null;
}
```
Justification: 410KB is the second-largest chunk; even though 15% of sessions eventually use it, it's specifically gated behind opening the compose modal — loading it only at that trigger point (not preemptively) avoids the cost for the 85% of sessions that never open the modal, and even for the 15% that do, avoids paying it during initial Dashboard load when it isn't needed yet.

**Split 4 — Charting library (290KB), on-viewport or on-demand within the Reports tab, NOT prefetched by default:**
```jsx
const ReportsChart = lazy(() => import("./components/ReportsChart"));

function DashboardTabs({ activeTab }) {
  return activeTab === "reports" ? (
    <Suspense fallback={<ChartSkeleton />}>
      <ReportsChart />
    </Suspense>
  ) : null;
}
```
Justification: 30% of Dashboard visits click into "reports" is meaningfully more frequent than settings/admin, which makes this a good **on-hover prefetch** candidate rather than pure on-demand — prefetching when the user hovers/focuses the "Reports" tab gives a head start on the 290KB download before they actually click, trading a small amount of wasted bandwidth (for the 70% who hover but don't click, if any) for meaningfully faster perceived tab-switch for the 30% who do click through.

## Resulting bundle breakdown

| Chunk | Size | Load trigger |
|---|---|---|
| Initial (shell + Dashboard) | 300KB | Always, on page load |
| Admin panel | 340KB | On-demand, route navigation (2% of users ever) |
| Settings | 90KB | On-demand, route navigation (5% of sessions) |
| Rich text editor | 410KB | On-demand, modal open (15% of sessions) |
| Charting library | 290KB | On-hover prefetch + on-demand fallback (30% of Dashboard visits) |

**Initial bundle reduced from 1,430KB to 300KB — a ~79% reduction** in what every session must download before reaching a usable Dashboard, with the remaining 1,130KB split into four chunks that are each loaded only when their specific, data-justified trigger condition is actually met. Combine with vendor-chunk splitting (separating rarely-changing third-party dependencies from the frequently-changing application code within each of these chunks) for better browser-cache reuse across deploys, per `theory/06-code-splitting-lazy-loading.md`.
