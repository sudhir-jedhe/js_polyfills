# Scenario: A Large Portion of Users Are on Slow Networks and Low-End Devices

**Scenario:** Analytics reveal that ~35% of a web app's users are on 3G-equivalent connections or low-end Android devices (common in several of the app's key growth markets). The current JS bundle is 2.4MB (uncompressed), shipped as a single file. These users report the app feels "broken" for the first several seconds after navigating to it, and bounce rate from that segment is far higher than from users on fast connections/devices. How do you approach reducing the bundle's real-world impact for this segment specifically?

**Diagnosis:** A single 2.4MB bundle means every user — regardless of what they actually use in a given session — pays the full download, parse, and execute cost before the app becomes interactive. On a slow connection, download time alone can be many seconds; on a low-end device, JS *parsing and execution* (not just download) is also meaningfully slower than on a fast device, compounding the delay. The "feels broken" complaint is consistent with a long gap between first paint (if anything renders before the bundle finishes) and the app actually becoming interactive/responsive — likely a poor INP or a long Time to Interactive even if LCP looks acceptable.

**Fix, layered by leverage:**

1. **Route-based code splitting first** (see `theory/06-code-splitting-lazy-loading.md`) — audit which parts of the 2.4MB are route-specific (an admin panel, a rarely-visited settings page, a reporting dashboard) versus genuinely needed on first load, and split accordingly. This is almost always the highest-leverage fix, since it directly reduces the bytes that *must* be downloaded before the initial route is usable, without removing any functionality.

2. **Audit for tree-shaking gaps** — check whether large dependencies are being imported in ways that defeat tree shaking (barrel-file imports pulling in unused code, as covered in `06-frontend-architecture-folder-structure/output-based/05-barrel-file-import-cost-tracing.md`; a CommonJS-only dependency that can't be shaken at all; a missing `sideEffects: false`). Tools like `webpack-bundle-analyzer` or `source-map-explorer` make this concrete — visualize exactly what's contributing bytes to the bundle, rather than guessing.

3. **Check compression is actually configured correctly** — confirm the server/CDN is serving Brotli (preferred) or at minimum Gzip for JS assets, not uncompressed; this is a common and easy-to-miss gap that costs real bytes over the wire for zero benefit, orthogonal to the tree-shaking/minification work.

4. **Consider whether any large dependencies have a smaller alternative** for what's actually used — a common real-world pattern is pulling in a large date-manipulation library for a handful of format calls that a much smaller utility (or even native `Intl.DateTimeFormat`) could cover.

5. **Prioritize what loads first — critical path vs. deferred.** Even after splitting, ensure the *initial* chunk contains only what's needed for first meaningful paint and interactivity; anything else (analytics initialization, a chat widget, non-critical third-party scripts) should load after, via `async`/deferred/idle-time strategies, so it doesn't compete with critical-path bytes on a constrained connection.

6. **Test against representative conditions, not just fast office wifi** — use Chrome DevTools' network throttling (Slow 3G/Fast 3G presets) and CPU throttling (4x-6x slowdown, approximating low-end device CPU) during development and in CI performance budgets, since a bundle that "feels fine" on a developer's fast machine and connection can be catastrophic for the actual affected user segment — this is specifically why the problem wasn't caught earlier.

7. **Set and enforce a bundle size budget in CI** (e.g., via `bundlesize` or a Lighthouse CI budget config) so this doesn't silently regress again after the fix — a one-time cleanup without an ongoing guardrail tends to erode back toward the same problem as new dependencies get added over time.

**Why this ordering:** route-based splitting and tree-shaking fixes address the actual bytes shipped, which matters most for download-time-bound (slow network) users; compression is a comparatively cheap, high-value, orthogonal win; and CPU-bound concerns (low-end device parse/execute time) are helped by simply shipping less JS overall — all of the above compound rather than being independent alternatives to pick just one of.
