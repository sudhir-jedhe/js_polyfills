# Scenario: A "Simple" Drag-to-Reorder List Is Janky

**Scenario:** A drag-to-reorder list component (imperative DOM manipulation, no framework, for maximum control during drag) feels extremely janky — dropping frames visibly during drag, especially with more than ~30 items in the list. Profiling in Chrome DevTools Performance panel shows a huge number of "Layout" (purple) blocks, each small individually, but so many of them that they dominate every frame's time budget during the drag interaction. The relevant code:

```js
function onDragMove(draggedEl, mouseY) {
  const items = document.querySelectorAll(".list-item");
  items.forEach((item) => {
    const rect = item.getBoundingClientRect(); // READ
    if (shouldSwapPosition(rect, mouseY)) {
      item.style.transform = `translateY(${computeOffset(rect, mouseY)}px)`; // WRITE
    }
  });
}
```

**Diagnosis:** This is layout thrashing, precisely as described in `theory/02-reflow-vs-repaint.md`'s layout thrashing section — the loop reads `getBoundingClientRect()` (a layout-dependent read) for one item, then writes a style for that same item, then moves to the next item and reads `getBoundingClientRect()` **again**, which forces the browser to synchronously flush the layout change from the *previous* iteration's write before it can return an accurate value. With 30+ items and this pattern running on every `mousemove` event during drag (potentially dozens of times per second), each frame is paying for `N` forced synchronous layout recalculations instead of one, and this is compounding with itself across the whole interaction.

**Fix — batch all reads before any writes, exactly per the general pattern:**

```js
function onDragMove(draggedEl, mouseY) {
  const items = document.querySelectorAll(".list-item");

  // Phase 1: ALL reads first — one layout flush total (or zero, if layout was already clean)
  const rects = Array.from(items, (item) => item.getBoundingClientRect());

  // Phase 2: ALL writes — queued, no read in between forces anything synchronous
  items.forEach((item, i) => {
    if (shouldSwapPosition(rects[i], mouseY)) {
      item.style.transform = `translateY(${computeOffset(rects[i], mouseY)}px)`;
    }
  });
}
```

**Second issue worth catching in the same pass: `transform` is already the right property choice.** The code was already using `transform: translateY(...)` rather than, say, `top`, which is correct — `transform` is composite-only (see `theory/02-reflow-vs-repaint.md`), so the *writes* in this loop were never the expensive part; only the *interleaved reads forcing synchronous layout* were. This is worth stating explicitly in a diagnosis, since a shallower read of the profiler output might have wrongly concluded "the transform writes are the problem" and gone down the wrong optimization path (e.g., trying to further optimize the transform math) instead of the actual fix (batching the reads).

**Further optimization once thrashing is fixed:** if profiling still shows the per-frame read cost non-trivial with many items, throttle `onDragMove` to run at most once per animation frame via `requestAnimationFrame` rather than on every raw `mousemove` event (mouse events can fire far more often than the display's refresh rate, so processing every single one is wasted work beyond what can ever be visually rendered anyway):

```js
let rafScheduled = false;
let latestMouseY = 0;

function handleMouseMove(e) {
  latestMouseY = e.clientY;
  if (!rafScheduled) {
    rafScheduled = true;
    requestAnimationFrame(() => {
      onDragMove(draggedEl, latestMouseY);
      rafScheduled = false;
    });
  }
}
```

**Takeaway:** the profiler's "many small Layout blocks" signature is close to a diagnostic fingerprint for interleaved read/write layout thrashing specifically — the fix (batch reads, then writes) is nearly always the same regardless of the specific component, and it's worth verifying the *writes* are already using cheap, composite-only properties before assuming they're part of the problem too.
