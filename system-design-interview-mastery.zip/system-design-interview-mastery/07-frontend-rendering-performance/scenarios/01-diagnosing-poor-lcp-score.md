# Scenario: Diagnosing and Fixing a Poor LCP Score

**Scenario:** A product page's LCP (measured via field data / CrUX) sits at 4.8s — solidly in "Poor" territory. The LCP element is identified (via Chrome DevTools Performance panel / web-vitals debug logging) as the main product hero image. Lighthouse trace shows: server TTFB of 600ms, a render-blocking stylesheet taking 900ms to download, and the hero image itself not starting its download until 3.1s into the page load, finishing at 4.6s. How do you diagnose and fix this?

**Diagnosis, working through the timeline:**

The hero image doesn't start downloading until 3.1s — that's the actual root cause of the poor LCP, not the image's own download time (1.5s, from 3.1s to 4.6s) in isolation. Investigating *why* the image starts so late reveals the real problem: it's a standard `<img>` tag, and the browser's preload scanner doesn't discover it until HTML parsing reaches that point in the DOM — but HTML parsing was delayed by the 900ms render-blocking stylesheet and (commonly, in this kind of app) an unmarked blocking `<script>` earlier in `<head>`, plus the image's actual `src` was being set by client-side JS after a data fetch, rather than being present in the initial HTML at all — meaning the browser couldn't even discover the image URL early, let alone start downloading it early.

**Fix, addressing each layer of delay:**

1. **Reduce TTFB (600ms → target well under 200ms):** cache the product page response (CDN edge caching, or server-side response caching for a product page that doesn't change per-request), since every millisecond of TTFB delay pushes back everything downstream, including the LCP element's discovery.

2. **Get the hero image URL into the initial HTML, not client-fetched.** If the image URL depends on a client-side data fetch, move that fetch to the server (SSR) so the `<img src="...">` is present in the HTML the browser receives — this alone can eliminate seconds of delay, since the browser's preload scanner can then discover the image URL the moment it parses that part of the HTML, without waiting for JS to fetch data and mutate the DOM first.

3. **Add `<link rel="preload" as="image" href="hero.jpg" fetchpriority="high">`** in `<head>`, which tells the browser to start downloading the hero image immediately, in parallel with everything else, rather than waiting for the parser to reach the `<img>` tag naturally — this is specifically valuable for exactly this "LCP element is an image discovered late" pattern.

4. **Reduce the render-blocking stylesheet's impact:** split CSS so only styles needed for above-the-fold content (including whatever styles affect the hero image's container) are render-blocking; defer non-critical CSS (below-the-fold styles, rarely-used component styles) via a `media` attribute trick or loading it asynchronously after first paint.

5. **Ensure no unmarked blocking `<script>` sits before the hero image's markup in `<head>`** — mark analytics/non-critical scripts `async`, so they don't hold up HTML parsing from reaching (and the preload scanner from discovering) the image.

6. **Set explicit `width`/`height` (or `aspect-ratio`) on the hero image** — while this specifically targets CLS rather than LCP, it's worth doing in the same pass since layout-shift-inducing images are frequently found alongside LCP problems in the same component.

**Expected outcome:** moving the image URL into server-rendered HTML plus preloading it should let the image start downloading within a few hundred milliseconds of TTFB rather than at 3.1s — combined with a faster TTFB and unblocked parsing, LCP should move from ~4.8s toward the 2.5s "Good" threshold, with the image's own download time (network-bound, not much further reducible without a smaller/better-compressed image) now the dominant remaining cost rather than the multi-second discovery delay that was the actual root cause.
