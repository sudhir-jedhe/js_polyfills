Diagrams and reference images for frontend rendering & performance (e.g. critical rendering path diagrams, Core Web Vitals threshold charts) will be added here.
