# Reflow vs. Repaint (Precise Distinction)

This is one of the most commonly hand-waved topics in frontend interviews — "reflow is expensive, repaint is less expensive" is the shallow version. The precise version requires knowing exactly what geometric/visual information each step recomputes, and exactly which CSS properties trigger which.

## Reflow (layout)

**Reflow** (also called layout, or relayout when it happens after the initial layout) is the browser recalculating the **geometry** of elements — position and size — for some or all of the render tree. Because layout is a tree-structured computation (a child's size can depend on a parent's size, and a parent's size can depend on a child's content size, e.g. an auto-height container), a reflow of one element frequently **cascades** to needing to recompute the layout of ancestors, descendants, and even siblings that are positioned relative to it. This cascading is exactly why reflow is the most expensive of the three "back half" operations (layout, paint, composite) — a single triggering change can force geometry recalculation across a large portion of the tree, not just the one changed element.

**What triggers reflow:** any change to a property that affects an element's box-model geometry or the geometry of anything that depends on it:
- `width`, `height`, `min-/max-width/height`
- `margin`, `padding`, `border` (border-width specifically — `border-color` alone does not)
- `top`, `left`, `right`, `bottom` (when `position` is not `static`)
- `font-size`, `font-family` (changes text metrics → changes layout)
- Adding/removing DOM nodes, changing `display` (except purely composite-safe values)
- Reading certain layout-dependent properties in JS (`offsetWidth`, `offsetHeight`, `getBoundingClientRect()`, `getComputedStyle()`) — see the layout thrashing note below

## Repaint

**Repaint** is the browser recomputing the **visual appearance** (pixels) of an element **without any change to its geometry** — the element's size and position stay exactly the same, but something about how it looks changes.

**What triggers repaint (without reflow):**
- `color`, `background-color`, `background-image`
- `border-color` (as opposed to `border-width`, which triggers reflow)
- `box-shadow`, `outline`
- `visibility` (changes whether it's painted, but — critically — `visibility: hidden` still occupies layout space, so toggling it triggers repaint, not reflow, unlike `display: none`)

Every reflow is **always followed by a repaint** (new geometry necessarily needs new pixels drawn) — but a repaint can happen **without** a preceding reflow, when only visual appearance changed and geometry didn't. This asymmetry — "reflow implies repaint, but repaint doesn't imply reflow" — is the core relationship to state precisely.

## The cheapest tier: composite-only

Some properties can be changed with **neither reflow nor repaint** — only the compositing step re-runs, which can happen entirely on the GPU:
- `transform` (translate, scale, rotate)
- `opacity`

These are cheap specifically because the browser can pre-paint the element onto its own compositor layer once, then let the GPU handle moving/scaling/fading that already-painted layer on subsequent frames — no CPU-bound geometry recalculation (reflow) or pixel-filling (repaint) needed at all. This is precisely why animating `transform: translateX()` is dramatically cheaper than animating `left`, even though they can produce a visually identical movement — `left` is a layout-affecting property (triggers reflow every frame of the animation), while `transform` is not.

## Full comparison table

| Tier | Triggered by | Cost | Example properties |
|---|---|---|---|
| Reflow (layout) → repaint → composite | Geometry-affecting changes | Highest — can cascade to ancestors/descendants/siblings | `width`, `height`, `margin`, `top` (positioned), `font-size`, DOM insertion/removal |
| Repaint → composite (no reflow) | Visual-only changes, geometry unchanged | Medium | `color`, `background-color`, `border-color`, `box-shadow`, `visibility` |
| Composite only (no reflow, no repaint) | GPU-compositable transform changes | Lowest | `transform`, `opacity` |

## Layout thrashing (a related, critical concept)

Reading a layout-dependent property (`offsetHeight`, `getBoundingClientRect()`) **forces the browser to synchronously flush any pending layout recalculation** before it can return an accurate value — it cannot answer from a stale/queued layout state. If JS code writes a style (queuing a reflow), then immediately reads a layout property, then writes again, then reads again, in a loop, it forces a **synchronous, uncached layout recalculation on every single iteration** instead of letting the browser batch pending layout changes into a single recalculation before the next paint. This "layout thrashing" pattern is one of the most common real-world causes of janky UI, and the fix is always the same: batch all reads first, then all writes (`for (el of elements) { reads.push(el.offsetHeight) }` then a separate loop that writes), so only one layout flush is needed instead of one per element.
