# Virtualization (Windowing) for Long Lists

Rendering a list of 10,000 items by mounting 10,000 DOM nodes is a common and severe performance problem — virtualization is the standard fix, and understanding the exact mechanism (not just "it only renders visible items") is what separates a surface-level answer from a strong one.

## The problem, precisely

A DOM node isn't just "a chunk of memory" — each one participates in layout calculations, has an entry in the render tree, and (depending on styling) can trigger repaint on various updates. 10,000 mounted list-item nodes means every layout pass considers all 10,000, even though at any given scroll position, a user can only *see* perhaps 15-30 of them. The cost is paid continuously (memory footprint, initial mount time, any reflow touching the list) for rendering work that produces zero visible benefit for the ~9,970 offscreen items.

## The mechanism: render only what's in (or near) the viewport

Virtualization keeps a **fixed, small number of actual DOM nodes** mounted — just enough to cover the visible viewport plus a small buffer — and as the user scrolls, **reuses and repositions** those same DOM nodes to display different data, rather than mounting new nodes for every item that scrolls into view.

```
Full list: 10,000 items, each 50px tall → total scrollable height = 500,000px
Viewport: 800px tall → at most ~16 items visible at once

Virtualized approach:
1. Render an outer container with height = 500,000px (so the scrollbar behaves correctly,
   as if all 10,000 items were really there)
2. Render only ~20 actual item nodes (16 visible + a few buffer items above/below)
3. On scroll, compute which data indices should now be visible (based on scrollTop / itemHeight)
4. Reposition the ~20 existing DOM nodes (via `transform: translateY(...)`) to their new
   scroll-relative positions, and swap their content to the newly-visible data — WITHOUT
   mounting/unmounting new DOM nodes for each swap
```

The outer container's height is set to the *total* height the full un-virtualized list would occupy, which is what makes the scrollbar size/position behave correctly even though only ~20 real nodes exist — the browser thinks it's scrolling through a 500,000px-tall element, but only ~20 of those "positions" have real content mounted at any moment.

## Fixed-height vs. variable-height virtualization

- **Fixed-height items** (every row is exactly 50px): trivial to compute which indices are visible — `startIndex = Math.floor(scrollTop / itemHeight)`. This is the simple, common case (`react-window`'s `FixedSizeList`).
- **Variable-height items** (rows have different, possibly unknown-until-rendered heights): requires either measuring each item's actual height after it renders and maintaining a running offset cache, or accepting an estimated height that gets corrected once the real height is measured — meaningfully more complex, and can cause visible scrollbar "jumps" as estimates are corrected against measured reality. Libraries like `react-window`'s `VariableSizeList` or `react-virtual`/`TanStack Virtual` handle this with a measurement + cache strategy.

## Windowing vs. pagination — a related but distinct technique

Pagination avoids rendering all 10,000 items by only ever loading/rendering one page's worth (e.g., 50 items) at a time, requiring explicit navigation (next/previous page) to see more. Virtualization instead presents the *illusion* of one continuously scrollable list of all 10,000 items, while only ever having a small number of real DOM nodes mounted at once — better UX for "infinite scroll"-style browsing, at the cost of more implementation complexity (scroll position tracking, node recycling) than pagination's simpler "swap the whole visible set on button click."

## When virtualization is (and isn't) worth the complexity

Worth it: lists that can realistically grow into the hundreds or thousands of items — data tables, chat histories, social feeds, search results without pagination. Not worth it: short, bounded lists (a dropdown with 20 options, a nav menu) where the DOM node count is trivially small regardless — virtualization adds real implementation complexity (careful handling of scroll position restoration, accessibility for screen readers navigating a "virtual" list, focus management) that isn't justified when the underlying problem (too many DOM nodes) doesn't actually exist at that list size.

## Complexity

| Approach | DOM nodes mounted | Memory | Scroll performance |
|---|---|---|---|
| Render all items | `O(n)` | `O(n)` | Degrades as `n` grows — large reflow/paint surface |
| Virtualized | `O(viewport size)`, constant regardless of `n` | `O(viewport size)` for DOM, `O(n)` for the underlying data still held in memory/state | Stays flat/fast regardless of `n` |
