# Core Web Vitals: LCP, INP, CLS

Core Web Vitals are Google's standardized, field-measurable metrics for real-world user experience quality. Precision matters a lot here — getting the exact definition, the exact "good" threshold, and exactly what affects each metric right is the difference between a hand-wavy answer and a strong one.

## Largest Contentful Paint (LCP) — loading performance

**Definition:** the render time of the **largest** image or text block visible within the viewport, measured from navigation start. "Largest" is determined by the element's visible size in the viewport (not the DOM subtree size) — commonly a hero image, a large heading, or a big block of body text, whichever renders and occupies the most viewport-relative pixels.

**Thresholds:** Good ≤ **2.5s**, Poor > **4.0s**, with "needs improvement" in between.

**What affects LCP:**
- Slow server response time (Time to First Byte) — the LCP element can't even begin rendering until the browser has enough to build the DOM around it
- Render-blocking CSS/JS delaying when the LCP element's containing markup and styles are ready
- Slow-loading resources the LCP element itself depends on (a large hero image not preloaded, a web font blocking text render via `font-display: block`)
- Client-side rendering that delays the LCP element behind a JS bundle download + execute + render cycle, rather than the element being present in the initial HTML

**Common LCP element instability:** the "largest" element can change mid-page-load — a lazy-loaded ad or a late-arriving image can end up larger than what was initially the largest element, which is why LCP measurement continues considering candidates until the page's first user interaction or a set cutoff.

## Interaction to Next Paint (INP) — responsiveness (successor to First Input Delay)

**Definition:** measures the latency of **all** user interactions (clicks, taps, key presses) throughout the page's entire lifecycle, from input to the next frame the browser paints reflecting that interaction's visual result — reporting (roughly) the **worst** interaction latency observed (technically the highest percentile among interactions, excluding a small number of outliers on pages with very many interactions), not just the first one.

**Thresholds:** Good ≤ **200ms**, Poor > **500ms**.

**Why INP replaced First Input Delay (FID) as the official Core Web Vital (March 2024):** FID only measured the delay before the **first** interaction's event handler even started running — it said nothing about how long the handler took to execute, and nothing about any interaction after the first one. A page could have an excellent FID (fast first click response) while being janky and unresponsive for every subsequent interaction — FID was structurally blind to that. INP measures full input-to-paint latency (not just handler start delay) across the *entire* session, giving a much more complete responsiveness picture.

**What affects INP:**
- Long JavaScript tasks blocking the main thread (anything over ~50ms is a "long task" that can delay input processing)
- Expensive event handlers doing synchronous work (heavy computation, forced synchronous layout/layout thrashing) before yielding back to let the browser paint
- Large component re-renders triggered by an interaction (e.g., a click causing a huge React tree to re-render synchronously)

## Cumulative Layout Shift (CLS) — visual stability

**Definition:** a unitless score summing the impact of every **unexpected** layout shift during the page's lifecycle. Each individual shift's score is `impact fraction × distance fraction`:
- **Impact fraction:** the proportion of the viewport affected by the shifting element(s), comparing the union of the element's visible area before and after the shift, divided by total viewport area.
- **Distance fraction:** the distance the element moved (horizontally or vertically, whichever is greater), divided by the viewport's largest dimension (width or height, whichever is greater).

**Thresholds:** Good ≤ **0.1**, Poor > **0.25**.

**Critically — shifts are only counted if unexpected.** A layout shift within 500ms of a user interaction is **not** counted toward CLS (the assumption being the user caused it and expects visual change) — this is why deliberately excluding user-initiated changes matters for accurately attributing CLS to genuinely jarring, unprompted shifts (an ad loading late and pushing content down, a web font swap changing text metrics, an image without reserved dimensions loading in).

**What affects CLS:**
- Images/embeds/ads without explicit `width`/`height` (or `aspect-ratio`) reserving their layout space before the resource loads
- Web fonts causing a FOUT/FOIT (flash of unstyled/invisible text) with different metrics than the fallback font, shifting surrounding content when the real font swaps in
- Content dynamically injected above existing content (a banner inserted at the top of the page after initial render) without reserved space
- Animations that use layout-triggering properties (`top`, `margin`) instead of `transform`, which visually reads as continuous movement but is technically composed of many small discrete layout shifts if implemented via layout properties rather than compositor-only ones

## Summary table

| Metric | Measures | Good threshold | Primary levers |
|---|---|---|---|
| LCP | Loading — time to render the largest visible content element | ≤ 2.5s | TTFB, render-blocking resources, resource loading priority for the LCP element |
| INP | Responsiveness — worst-case input-to-paint latency across the whole session | ≤ 200ms | Long main-thread tasks, expensive event handlers, large synchronous re-renders |
| CLS | Visual stability — cumulative unexpected layout shift | ≤ 0.1 | Reserved space for async content, font-loading strategy, avoiding late-injected content |
