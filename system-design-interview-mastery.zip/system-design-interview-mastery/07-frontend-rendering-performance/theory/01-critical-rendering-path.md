# Critical Rendering Path

The critical rendering path (CRP) is the exact sequence of steps a browser takes to convert HTML, CSS, and JS into pixels on screen. Understanding each step precisely — not just naming them in order — is what interviewers are actually probing for, since most of frontend performance optimization is about intervening at a specific step in this pipeline.

## The six steps, in order

### 1. HTML parsing → DOM construction

The browser parses HTML bytes into tokens, tokens into nodes, and nodes into the **DOM (Document Object Model)** tree — an in-memory, object representation of the document's structure. Parsing is largely incremental and streaming: the browser can start building the DOM before the full HTML document has finished downloading.

### 2. CSS parsing → CSSOM construction

In parallel with (or interleaved with) HTML parsing, the browser parses CSS (from `<style>` tags, `<link>` stylesheets, and eventually any dynamically injected CSS) into the **CSSOM (CSS Object Model)** — a tree representing every matched style rule, including inherited and cascaded values. Unlike DOM construction, CSSOM construction is **not incremental in a usable sense** — the browser cannot know a rule won't later be overridden by a rule further down the stylesheet, so **render-blocking CSS must be fully downloaded and parsed before the CSSOM can be considered complete enough to use** for rendering.

### 3. JavaScript execution (interleaved)

A `<script>` tag encountered during HTML parsing **blocks the parser** by default (unless marked `async` or `defer`) — the parser pauses, the script downloads (if external) and executes, and only then does HTML parsing resume. This is because script execution can call `document.write()` or otherwise mutate the DOM/CSSOM in ways that must be accounted for before parsing continues. A script also cannot safely execute until the CSSOM is ready if it might query computed styles, which is why browsers often delay script execution until CSSOM construction completes even for scripts not directly blocking the parser.

### 4. Render tree construction

The browser combines the DOM and CSSOM into the **render tree**: a tree of only the nodes that will actually be visually rendered, each annotated with its computed style. Nodes with `display: none` are **excluded entirely** from the render tree (they generate no render tree node at all) — this is different from `visibility: hidden`, which **does** generate a render tree node (it takes up layout space, just isn't painted). `<head>` contents and other non-rendered elements are likewise excluded.

### 5. Layout (a.k.a. reflow)

The browser computes the exact **geometry** — position and size in pixels — of every node in the render tree, given the viewport dimensions. This is where box model calculations (width, height, margin, padding, position) actually resolve to concrete pixel values. See `02-reflow-vs-repaint.md` for the precise distinction between this step and paint.

### 6. Paint, then composite

**Paint** fills in the actual pixels for each render tree node — text, colors, images, borders, shadows — typically onto multiple separate **layers**. **Composite** is the final step: the browser combines those separately-painted layers into the final image shown on screen, in the correct stacking order, handling things like transforms and opacity on the GPU without needing to re-paint. Compositing is the cheapest of the three "back half" operations (layout, paint, composite) specifically because it can often be done entirely on the GPU without touching the CPU-bound layout/paint work at all — which is exactly why `transform` and `opacity` animations are so much cheaper than animating `width` or `top`.

## The full sequence, visually

```
HTML bytes → [parse] → DOM  ─┐
                              ├→ [combine] → Render Tree → [Layout] → [Paint] → [Composite] → pixels on screen
CSS bytes → [parse] → CSSOM ─┘
                (JS execution interleaved, can block HTML parsing and mutate DOM/CSSOM)
```

## Why this matters for optimization

Every major frontend performance technique is an intervention at a specific point in this pipeline: `<link rel="preload">` speeds up getting bytes to the parser sooner; `async`/`defer` avoid JS blocking HTML parsing; minimizing render-blocking CSS shortens time-to-first-CSSOM; reducing DOM depth/complexity shortens layout time; preferring `transform`/`opacity` for animation avoids triggering layout or paint at all, landing the change directly in the cheap composite-only step. Being able to say precisely *which step* a given technique affects — not just "it makes things faster" — is the level of precision expected in a rendering-performance deep dive.
