# Code Splitting and Lazy Loading Strategies

Shipping one giant JS bundle means every user pays the download/parse/execute cost for code they may never use on a given visit (an admin panel a regular user never opens, a modal's heavy rich-text editor most page views never trigger). Code splitting breaks the bundle into smaller chunks loaded on demand; lazy loading is the runtime strategy of *when* to actually request those chunks.

## Route-based code splitting

The most common and highest-leverage form: each route/page gets its own chunk, loaded only when the user navigates to it.

```jsx
import { lazy, Suspense } from "react";

const Dashboard = lazy(() => import("./routes/Dashboard"));
const Settings = lazy(() => import("./routes/Settings"));
const Reports = lazy(() => import("./routes/Reports")); // rarely visited — good splitting candidate

function App() {
  return (
    <Suspense fallback={<PageSkeleton />}>
      <Routes>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/settings" element={<Settings />} />
        <Route path="/reports" element={<Reports />} />
      </Routes>
    </Suspense>
  );
}
```
A user who only ever visits `/dashboard` never downloads `Settings.js` or `Reports.js` at all — those chunks simply aren't requested until (if ever) that route is navigated to.

## Component-based code splitting

Splitting at a finer grain than routes — useful for heavy components that only render conditionally within a page that's otherwise lightweight (a rich text editor, a charting library, a modal that's rarely opened):

```jsx
const RichTextEditor = lazy(() => import("./RichTextEditor")); // pulls in a large editor library

function CommentForm({ showEditor }) {
  return (
    <div>
      {showEditor ? (
        <Suspense fallback={<TextareaFallback />}>
          <RichTextEditor />
        </Suspense>
      ) : (
        <SimpleTextarea />
      )}
    </div>
  );
}
```

## Lazy loading strategies — *when* to actually trigger the load

Splitting creates the chunk boundary; a lazy loading strategy decides when to fetch it:

- **On-demand (interaction-triggered):** load only when the user actually needs it — e.g., `RichTextEditor` above loads exactly when `showEditor` becomes true. Simplest, but the user waits for the download at the exact moment they need it (a visible loading state is often unavoidable).
- **On-hover / on-intent:** start loading a route's chunk when the user hovers a link (or focuses it via keyboard) — a strong signal they're likely about to navigate there, buying a head start on the download before the click actually happens. Next.js's `<Link>` and similar router-level prefetching do this by default for viewport-visible links.
- **On-viewport (intersection-based):** for below-the-fold content, defer loading a component's chunk (and its data) until it's about to scroll into view, using `IntersectionObserver` — commonly paired with lazy-loaded images (`loading="lazy"`) but applicable to component chunks too.
- **Idle-time prefetch:** use `requestIdleCallback` (or a router's built-in prefetch-on-idle behavior) to quietly fetch likely-next-needed chunks during otherwise-unused main-thread idle time, so they're already cached by the time the user navigates — trades a small amount of unnecessary bandwidth (chunks prefetched but never used) for a much faster perceived navigation when the guess is right.

## Vendor/dependency splitting

Separately from route/component splitting, bundlers can split third-party dependencies into their own chunk(s), separate from application code:

```js
// webpack config (conceptual)
optimization: {
  splitChunks: {
    cacheGroups: {
      vendor: { test: /[\\/]node_modules[\\/]/, name: "vendor", chunks: "all" },
    },
  },
}
```
The benefit is caching-related, not just size-related: application code changes far more frequently than third-party dependencies, so splitting them into separate chunks means a deploy that only changed application code doesn't invalidate the (much larger, rarely-changing) vendor chunk's browser cache — users only need to re-download the small app chunk, not the whole bundle, on most deploys.

## The tradeoff to state explicitly

Code splitting trades a larger number of smaller network requests (each with its own latency overhead, though HTTP/2 multiplexing mitigates this significantly) for a smaller *initial* payload — the right granularity depends on realistic usage patterns: splitting too aggressively (many tiny chunks) can add request overhead and waterfall delays that outweigh the benefit, while splitting too little defeats the purpose by keeping rarely-used code in the initial bundle anyway. Route-based splitting is close to always a net win with minimal downside; finer-grained component splitting should be reserved for genuinely heavy, conditionally-rendered pieces, not applied uniformly to every component.
