# Bundle Size Optimization: Tree Shaking, Minification, and Compression

Three genuinely distinct techniques that are frequently conflated in casual conversation — precisely distinguishing them (what each does, at what stage, and why one enables another) is exactly the kind of specificity that separates a strong answer from a hand-wavy one.

## Tree shaking — removing code that's provably never used

Tree shaking is a **build-time, static-analysis** process that removes exports which are never imported/used anywhere in the dependency graph, before the bundle is ever assembled. It relies fundamentally on **ES module (ESM) static import/export syntax** (`import`/`export`), because ESM imports are statically analyzable — the bundler can determine, without running any code, exactly what's imported from where. CommonJS (`require`/`module.exports`) is dynamic and can't be reliably tree-shaken in the general case, because `require()` calls and `module.exports` assignments can happen conditionally or be computed at runtime, which static analysis can't fully resolve ahead of time.

```js
// mathUtils.js — exports several functions
export function add(a, b) { return a + b; }
export function subtract(a, b) { return a - b; }
export function multiply(a, b) { return a * b; } // never imported anywhere

// app.js
import { add, subtract } from "./mathUtils";
// tree shaking removes `multiply` entirely from the final bundle — it's provably unreachable
```

**Why the `sideEffects` field matters:** a bundler can only safely remove an unused export if it can prove doing so has no observable side effect — a module that runs code at the top level (registers a global, injects CSS, mutates a shared object) can't be safely dropped even if none of its named exports are used, because *importing it at all* was doing something. Setting `"sideEffects": false` in `package.json` explicitly tells the bundler "nothing in this package has top-level side effects, it's safe to drop any unused parts" — without it, bundlers conservatively keep code they can't prove is side-effect-free (see `06-frontend-architecture-folder-structure/output-based/05-barrel-file-import-cost-tracing.md` for a concrete case where this goes wrong).

## Minification — shrinking code without changing behavior

Minification is a separate, later step: transforming code to be **functionally identical but smaller in byte size** — renaming variables to shorter names, removing whitespace/comments, collapsing expressions where safe (e.g., `if (x) { return true } else { return false }` → `return !!x`). It operates on whatever code survived tree shaking; it doesn't remove unused code itself, it just makes the code that remains smaller.

```js
// before minification
function calculateTotalPrice(itemPrice, quantity, taxRate) {
  const subtotal = itemPrice * quantity;
  return subtotal + (subtotal * taxRate);
}

// after minification (conceptually — real minifiers produce denser output)
function a(b,c,d){const e=b*c;return e+e*d}
```

## Compression — reducing bytes over the wire, not the code itself

Compression (Gzip, or the more modern and generally more effective Brotli) is applied by the **server at transfer time** (or precompiled into static assets ahead of time) to the already-minified bundle, encoding repeated patterns more compactly for network transfer — the browser decompresses it back to the exact minified code upon receipt. Compression operates on **bytes**, with zero knowledge of JavaScript semantics — it doesn't know or care what a "variable" or "function" is, purely finding and encoding repetition in the byte stream, which is why compression works on any file type (HTML, CSS, JSON, images to a lesser extent) equally, not just JS.

## The precise ordering and why it matters

```
Source code
  → [Tree shaking] removes provably-unused code           (build time, ESM-dependent)
  → [Minification] shrinks the remaining code's byte size  (build time, semantic-aware)
  → [Compression]  encodes repeated byte patterns compactly (transfer time, semantics-blind)
  → bytes sent over the network → browser decompresses → parses/executes the minified JS
```

Each step operates on the *output* of the previous one, and skipping an earlier step doesn't make a later one redundant: minifying code that wasn't tree-shaken still ships the dead code, just in smaller form; compressing code that wasn't minified still transfers fewer bytes than uncompressed, but starts from a larger baseline than compressing already-minified code would. All three are complementary, not substitutes for each other — a common misconception is that "compression handles everything," which is wrong because compression can't know a `multiply` function is unreachable dead code; it can only encode whatever bytes it's given more compactly, dead code included.

## Brotli vs. Gzip (brief)

Brotli generally achieves better compression ratios than Gzip for text-based web assets (JS, CSS, HTML), particularly because it ships with a built-in static dictionary pre-trained on common web content patterns, but has slightly higher compression *time* cost at maximum settings — for static assets (precompressed at build time, not per-request), that cost is irrelevant since it's paid once at build time, not per request, making Brotli close to a strictly-better default for static asset serving on modern browsers (which all support it).
