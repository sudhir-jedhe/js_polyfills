# Virtual DOM vs. Real DOM

A frequently mis-explained topic — "virtual DOM is faster than the real DOM" is imprecise to the point of being wrong in some cases. The accurate framing is about **minimizing real DOM mutations**, not about the virtual DOM itself being inherently faster than direct DOM manipulation.

## What the virtual DOM actually is

The virtual DOM (VDOM) is a lightweight, in-memory JavaScript object representation of what the UI *should* look like — a plain object tree, not connected to the browser's actual rendering pipeline at all. Frameworks like React re-render components by producing a **new** virtual DOM tree on every state change, then run a **diffing algorithm (reconciliation)** comparing the new tree against the previous one to compute the minimal set of actual DOM mutations needed, and only then apply exactly those mutations to the real DOM.

## Why this exists: the real problem it solves

Directly manipulating the real DOM is expensive **specifically because every mutation can potentially trigger reflow/repaint** (see `02-reflow-vs-repaint.md`) — and naive, imperative UI code that doesn't carefully batch or minimize DOM writes tends to cause many more read/write operations on the real DOM than are strictly necessary, especially as an application's UI logic grows complex (many interacting pieces of state, each naively updating the DOM independently). The virtual DOM's actual value is that diffing happens against cheap, disconnected JS objects — comparing two plain object trees is orders of magnitude cheaper than touching the real DOM — so the *expensive* real-DOM mutations can be computed as a minimal, batched set **before** anything expensive actually happens.

## Where the virtual DOM genuinely helps

- **Complex, deeply interdependent UI updates** where many pieces of state affect overlapping parts of the tree — manually tracking the minimal DOM diff by hand across many interacting components is error-prone and often ends up over-mutating; the VDOM's diffing automates finding that minimal set correctly.
- **Batching updates across a render cycle** — multiple state changes within one event handler/tick can be coalesced into a single real-DOM update pass rather than each triggering its own separate mutation, avoiding redundant intermediate layout/paint work.
- **Declarative programming model as the primary value**, with performance as a secondary (and situational) benefit — describing UI as "what it should look like given this state" rather than manually writing imperative DOM-mutation code is a substantial developer-experience and correctness win independent of raw performance, and is arguably the VDOM's larger real contribution.

## Where the virtual DOM does *not* help (and can be slower)

- **A small, targeted, well-known update** — if you know exactly which single text node needs to change, `element.textContent = newValue` is unambiguously faster than re-rendering a component tree, diffing two virtual trees, and then applying the resulting single mutation — the diffing step itself is pure overhead in that case, not free.
- **Highly performance-critical, high-frequency updates** (e.g., updating an animation position 60 times a second, or a real-time chart with thousands of data points changing every frame) — many performance-sensitive libraries (D3 for complex visualizations, or React itself for animation-heavy work) intentionally **bypass the VDOM/reconciler** for these hot paths, mutating specific DOM nodes or canvas/WebGL surfaces directly, because the diffing overhead becomes the bottleneck rather than the DOM mutation itself.
- **Compile-time frameworks that skip the VDOM entirely** (Svelte, SolidJS) demonstrate the VDOM is a specific *strategy* for minimizing DOM mutations, not the only one — these frameworks instead compile component code into fine-grained, surgical DOM update instructions ahead of time, achieving the same "minimal DOM mutation" goal without a runtime diffing step at all, and often outperform VDOM-based frameworks specifically because they eliminate the diffing overhead entirely rather than just minimizing what it produces.

## The precise correct statement

"The virtual DOM is faster than the real DOM" is not a coherent claim — the virtual DOM is a JS object, not a rendering mechanism, so there's no direct performance comparison to make. The precise claim is: **diffing two virtual DOM trees to compute a minimal real-DOM mutation set is, for sufficiently complex/interdependent UI updates, cheaper than the alternative of naive, unminimized direct DOM manipulation** — but for simple, well-understood, or extremely hot-path updates, direct DOM manipulation (or a compile-time fine-grained-reactivity approach) can outperform the VDOM specifically because it skips the diffing overhead altogether.

## Comparison

| | Virtual DOM (React) | Fine-grained reactivity (SolidJS, Svelte) | Direct DOM manipulation |
|---|---|---|---|
| Update mechanism | Re-render → diff two trees → apply minimal patch | Compile-time-generated surgical updates, no diffing at runtime | Manual, imperative |
| Overhead per update | Diffing cost + DOM mutation cost | Just the DOM mutation cost (no diffing) | Just the DOM mutation cost, but requires manual minimal-mutation logic |
| Developer ergonomics | Declarative, don't manually track what changed | Declarative, don't manually track what changed | Imperative, must manually determine and apply minimal changes |
| Best fit | Complex, interdependent UI at typical interaction frequency | Same use case, often faster due to no diff step | Extremely hot paths, or trivially simple/known-exact updates |
