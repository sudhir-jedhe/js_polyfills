# Interview Q&A — Core Web Vitals

**Q: Define LCP precisely, including the "Good" threshold.**
LCP is the render time of the largest image or text block visible within the viewport, measured from navigation start. The "Good" threshold is ≤ 2.5 seconds. It specifically measures the largest element *by rendered viewport-relative size*, not by DOM subtree size or importance — a large hero image or heading typically qualifies, and the candidate can change as the page continues loading (e.g., a late-arriving image replacing an initially-larger text block as the largest element).

**Q: What replaced First Input Delay (FID), and precisely why?**
Interaction to Next Paint (INP) replaced FID as the official Core Web Vital in March 2024. FID only measured the delay before the *first* interaction's event handler started running — it said nothing about how long that handler took to execute, and nothing about responsiveness for any interaction after the first. INP measures the full input-to-paint latency (not just handler-start delay) across the entire page session, capturing the worst-case (roughly the highest percentile) interaction latency a user actually experienced — a much more complete responsiveness signal than FID's narrow, first-interaction-only scope.

**Q: What are the two components of an individual CLS shift's score, and how are they calculated?**
Impact fraction — the union of the shifting element's visible area before and after the shift, divided by total viewport area. Distance fraction — the distance the element moved (whichever of horizontal/vertical is greater), divided by the viewport's largest dimension (width or height, whichever is greater). The shift's score is the product of the two, and CLS is the sum of all such scores for unexpected shifts across the page's lifecycle.

**Q: Why are layout shifts within 500ms of a user interaction excluded from CLS?**
Because the assumption is the user caused the shift intentionally (e.g., tapping "load more" content, expanding an accordion) and expects the resulting visual change — counting user-initiated, expected shifts toward a metric meant to measure *unexpected*, jarring visual instability would incorrectly penalize normal, desired interactive behavior. Only shifts the user didn't cause or wouldn't expect (a late-loading ad, a font swap, a banner injected above existing content) count.

**Q: Name three concrete causes of poor CLS and the fix for each.**
(1) Images/embeds without explicit dimensions — fix: set `width`/`height` or `aspect-ratio` so space is reserved before the resource loads. (2) Web font swaps changing text metrics — fix: use `font-display: optional` or match fallback font metrics closely, or preload the font so it's more likely ready before first text paint. (3) Content dynamically injected above existing content (a late-loading banner/ad) — fix: reserve space for the injected content ahead of time via a placeholder container sized to the expected content.

**Q: What's a "long task" and why does it specifically hurt INP rather than, say, LCP?**
A long task is any JS execution block over roughly 50ms that occupies the main thread without yielding. It hurts INP because while the main thread is busy running a long task, it cannot process a user's input event or paint the result of an interaction — the input sits queued until the long task finishes, directly adding to that interaction's input-to-paint latency. It doesn't directly affect LCP (a loading metric) unless the long task happens to be blocking the specific work needed to render the LCP element itself, which is a different (though related) failure mode.

**Q: A page has excellent LCP and CLS but poor INP — what class of problem does that point to?**
Since loading (LCP) and visual stability (CLS) are both fine, the problem is isolated to responsiveness after the page has loaded — almost certainly long-running JavaScript tasks or expensive synchronous work inside event handlers (heavy computation, large re-renders, layout thrashing) blocking the main thread during user interaction, rather than anything related to initial resource loading or unexpected layout movement.
