# Interview Q&A — Critical Rendering Path

**Q: List the steps of the critical rendering path in order.**
HTML parsing → DOM construction (in parallel: CSS parsing → CSSOM construction) → JavaScript execution interleaved with parsing → render tree construction (combining DOM + CSSOM, excluding non-rendered nodes) → layout (computing geometry) → paint (filling in pixels, often across multiple layers) → composite (combining layers into the final displayed image).

**Q: Why can't the CSSOM be used incrementally the way the DOM can be?**
Because the browser cannot know that a CSS rule won't be overridden by a rule that appears later in the same or a subsequently-loaded stylesheet — a rule parsed early might be contradicted by one parsed later, so the CSSOM can only be considered reliable for rendering once the full render-blocking stylesheet chain has been downloaded and parsed. The DOM doesn't have this problem in the same way because HTML parsing is fundamentally sequential/appendable in a way CSS's cascade and override semantics aren't.

**Q: Why does an unmarked `<script>` tag block HTML parsing?**
Because the script could call `document.write()` or otherwise synchronously mutate the DOM in ways the parser must account for before continuing — the browser can't safely skip ahead and parse subsequent HTML without risking the script having changed what that HTML should even resolve to. Additionally, the script's own execution is commonly delayed until CSSOM construction completes, in case it queries computed styles, compounding the block.

**Q: What's the difference between `display: none` and `visibility: hidden` in terms of the render tree?**
`display: none` excludes the element from the render tree entirely — it generates no render tree node at all, occupies no layout space, and its removal/addition triggers reflow for surrounding elements. `visibility: hidden` still generates a render tree node and still occupies its layout space — the element just isn't painted. This means toggling `display` triggers reflow, while toggling `visibility` triggers only repaint (no geometry change).

**Q: Why are `transform` and `opacity` cheaper to animate than `width` or `top`?**
Because they can be handled entirely at the compositing step — the browser paints the element onto its own layer once, and the GPU can then translate, scale, rotate, or fade that already-painted layer on every animation frame without any CPU-bound layout recalculation or repaint. `width` and `top` (for a positioned element) are geometry-affecting properties, so animating them forces a full reflow → repaint → composite sequence on every single frame of the animation, which is dramatically more expensive.

**Q: What is `async` vs. `defer` and how does each affect the critical rendering path differently?**
Both let the script's *download* happen without blocking the HTML parser (unlike an unmarked script tag). `async` scripts execute as soon as they finish downloading, whenever that happens — potentially interrupting HTML parsing at an arbitrary point if the download finishes before parsing completes, and with no guaranteed order relative to other `async` scripts. `defer` scripts are guaranteed to execute only after HTML parsing fully completes, in the order they appear in the document, right before `DOMContentLoaded` fires — making `defer` the safer choice when script order or full-DOM availability matters, and `async` more appropriate for independent scripts (like analytics) that don't need the DOM or a specific execution order.
