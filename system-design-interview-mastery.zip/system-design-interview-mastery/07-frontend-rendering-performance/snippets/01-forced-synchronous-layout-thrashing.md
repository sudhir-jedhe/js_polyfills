# Snippet: Layout Thrashing and the Fix

Demonstrates the exact anti-pattern that forces synchronous, uncached layout recalculation on every loop iteration, and the batched read/write fix.

```js
// BAD: layout thrashing — interleaved reads and writes force a synchronous
// layout recalculation on EVERY iteration of the loop
function resizeAllBoxesThrashing(boxes) {
  boxes.forEach((box) => {
    const currentWidth = box.offsetWidth;       // READ — forces layout flush if a write is pending
    box.style.width = currentWidth + 10 + "px";  // WRITE — invalidates layout, queues a new one
    // next iteration's .offsetWidth READ forces the just-queued layout to run synchronously,
    // instead of letting the browser batch it before the next paint
  });
}
```

```js
// GOOD: batch all reads first, then all writes — only ONE layout flush total
function resizeAllBoxesBatched(boxes) {
  // Phase 1: all reads (layout is only computed once, on the FIRST read here)
  const widths = boxes.map((box) => box.offsetWidth);

  // Phase 2: all writes (queued, but nothing reads layout again until the next frame,
  // so the browser is free to batch these into a single recalculation before paint)
  boxes.forEach((box, i) => {
    box.style.width = widths[i] + 10 + "px";
  });
}
```

```js
// Measuring the difference (conceptual — actual numbers depend on element count/complexity)
console.time("thrashing");
resizeAllBoxesThrashing(document.querySelectorAll(".box")); // 500 elements
console.timeEnd("thrashing"); // e.g. ~180ms — one forced synchronous layout per element

console.time("batched");
resizeAllBoxesBatched(document.querySelectorAll(".box"));
console.timeEnd("batched"); // e.g. ~8ms — one layout flush total
```

The rule that generalizes this fix: **never interleave a layout-dependent read (`offsetWidth`, `offsetHeight`, `getBoundingClientRect()`, `getComputedStyle()`) with a style write inside a loop.** Libraries like FastDOM automate the read/write batching pattern shown above by scheduling all reads and all writes into separate queues automatically.
