# Snippet: Measuring Core Web Vitals in the Field

Real code using the `web-vitals` library and raw Performance Observer APIs to measure LCP, INP, and CLS as defined in `theory/04-core-web-vitals-lcp-inp-cls.md`.

```js
// using the official web-vitals library (recommended — handles edge cases correctly)
import { onLCP, onINP, onCLS } from "web-vitals";

function sendToAnalytics({ name, value, id, rating }) {
  // rating is "good" | "needs-improvement" | "poor", computed against the official thresholds
  navigator.sendBeacon(
    "/analytics/vitals",
    JSON.stringify({ name, value, id, rating, page: location.pathname })
  );
}

onLCP(sendToAnalytics);
onINP(sendToAnalytics);
onCLS(sendToAnalytics);
```

```js
// raw PerformanceObserver for LCP — shows what web-vitals does under the hood
new PerformanceObserver((entryList) => {
  const entries = entryList.getEntries();
  const lastEntry = entries[entries.length - 1]; // the LAST candidate is the current LCP element
  console.log("LCP candidate:", lastEntry.startTime, lastEntry.element);
  // "largest" candidates can change as the page loads — e.g. a late-loading hero image
  // can replace an initially-larger text block as the LCP element
}).observe({ type: "largest-contentful-paint", buffered: true });
```

```js
// raw PerformanceObserver for CLS — shows the impact-fraction × distance-fraction calculation
let clsValue = 0;
new PerformanceObserver((entryList) => {
  for (const entry of entryList.getEntries()) {
    // hadRecentInput excludes shifts within 500ms of user interaction, per spec —
    // these are NOT counted toward CLS since the user likely caused them intentionally
    if (!entry.hadRecentInput) {
      clsValue += entry.value; // entry.value IS the pre-computed impact × distance fraction
      console.log("Unexpected layout shift:", entry.value, "sources:", entry.sources);
    }
  }
}).observe({ type: "layout-shift", buffered: true });
```

```js
// raw PerformanceObserver for long tasks — the main contributor to poor INP
new PerformanceObserver((entryList) => {
  for (const entry of entryList.getEntries()) {
    if (entry.duration > 50) {
      // any task blocking the main thread >50ms risks delaying input processing,
      // directly hurting INP for any interaction queued behind it
      console.warn(`Long task: ${entry.duration.toFixed(1)}ms`, entry);
    }
  }
}).observe({ type: "longtask", buffered: true });
```

Field data (real users, via `web-vitals` + an analytics endpoint) is what Google's Core Web Vitals reporting (Search Console, CrUX) is based on — lab data (Lighthouse, synthetic testing) is useful for catching regressions in CI, but only field measurement reflects what actual users on actual devices/networks experience, which is why both are typically run in a real performance program rather than relying on lab data alone.
