# Snippet: Dynamic Imports for Route and Interaction-Based Splitting

Shows the three lazy-loading trigger strategies from `theory/06-code-splitting-lazy-loading.md` as concrete code: on-demand, on-hover prefetch, and idle-time prefetch.

```jsx
// --- 1. Route-based, on-demand (chunk requested only on navigation) ---
import { lazy, Suspense } from "react";

const Reports = lazy(() => import("./routes/Reports"));

function App() {
  return (
    <Suspense fallback={<div>Loading…</div>}>
      <Route path="/reports" element={<Reports />} />
    </Suspense>
  );
}
```

```jsx
// --- 2. On-hover prefetch: start the download before the click happens ---
function NavLink({ to, children }) {
  const prefetch = () => {
    // triggers the dynamic import's network request without rendering the component yet —
    // by the time the user actually clicks, the chunk is likely already cached
    import(`./routes/${to}.js`);
  };

  return (
    <a href={`/${to}`} onMouseEnter={prefetch} onFocus={prefetch}>
      {children}
    </a>
  );
}
```

```js
// --- 3. Idle-time prefetch: quietly fetch a likely-next chunk when the main thread is free ---
function prefetchOnIdle(importFn) {
  if ("requestIdleCallback" in window) {
    requestIdleCallback(() => importFn());
  } else {
    setTimeout(() => importFn(), 200); // fallback for browsers without requestIdleCallback
  }
}

// call after the current page has finished its own critical rendering work
prefetchOnIdle(() => import("./routes/Settings.js"));
```

```js
// --- Vendor chunk splitting (webpack config) ---
// application code changes every deploy; vendor code rarely does — separate chunks
// means most deploys only invalidate the browser cache for the small app chunk
module.exports = {
  optimization: {
    splitChunks: {
      cacheGroups: {
        vendor: {
          test: /[\\/]node_modules[\\/]/,
          name: "vendor",
          chunks: "all",
        },
      },
    },
  },
};
```

Network tab verification: after adding route-based splitting, the initial page load's JS payload for `/dashboard` should no longer include `Reports.js`'s bytes at all — that chunk only appears as a separate network request the moment `/reports` is actually visited (or prefetched via hover/idle).
