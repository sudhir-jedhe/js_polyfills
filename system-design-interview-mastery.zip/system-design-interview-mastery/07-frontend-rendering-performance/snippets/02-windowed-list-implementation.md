# Snippet: Minimal Fixed-Height Windowed List

A from-scratch implementation of the virtualization mechanism described in `theory/05-virtualization-windowing-long-lists.md` — no library, to make the actual mechanics explicit.

```jsx
import { useState, useRef, useMemo } from "react";

function VirtualizedList({ items, itemHeight, viewportHeight, renderItem }) {
  const [scrollTop, setScrollTop] = useState(0);
  const containerRef = useRef(null);

  const totalHeight = items.length * itemHeight;

  // how many items fit in the viewport, plus a small buffer above/below for smooth scrolling
  const bufferCount = 3;
  const visibleCount = Math.ceil(viewportHeight / itemHeight);

  const startIndex = Math.max(0, Math.floor(scrollTop / itemHeight) - bufferCount);
  const endIndex = Math.min(items.length, startIndex + visibleCount + bufferCount * 2);

  const visibleItems = useMemo(
    () => items.slice(startIndex, endIndex),
    [items, startIndex, endIndex]
  );

  return (
    <div
      ref={containerRef}
      style={{ height: viewportHeight, overflowY: "auto", position: "relative" }}
      onScroll={(e) => setScrollTop(e.currentTarget.scrollTop)}
    >
      {/* full-height spacer so the scrollbar behaves as if all items were really mounted */}
      <div style={{ height: totalHeight, position: "relative" }}>
        {visibleItems.map((item, i) => {
          const actualIndex = startIndex + i;
          return (
            <div
              key={actualIndex}
              style={{
                position: "absolute",
                top: actualIndex * itemHeight, // reposition via top offset within the spacer
                height: itemHeight,
                width: "100%",
              }}
            >
              {renderItem(item, actualIndex)}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// --- usage: 10,000 items, only ~20-25 actually mounted at any time ---
const items = Array.from({ length: 10000 }, (_, i) => ({ id: i, label: `Row ${i}` }));

function App() {
  return (
    <VirtualizedList
      items={items}
      itemHeight={50}
      viewportHeight={600}
      renderItem={(item) => <div style={{ padding: 12 }}>{item.label}</div>}
    />
  );
}
```

Even with 10,000 items in `items`, `visibleItems.length` stays roughly constant (`visibleCount + 2*bufferCount`, around 18-24 items for a 600px viewport with 50px rows) — the DOM node count doesn't grow with the underlying data size. Production-grade libraries (`react-window`, `@tanstack/react-virtual`) add variable-height support, horizontal virtualization, and more robust scroll-position/measurement handling on top of this same core mechanism.
