# Snippet: Tree Shaking — ESM vs. CommonJS, and the `sideEffects` Field

Demonstrates exactly why ESM syntax is required for reliable tree shaking, and how `sideEffects: false` unlocks it for a package that otherwise wouldn't be safely shakeable.

```js
// utils.esm.js — ESM: statically analyzable, tree-shakeable
export function formatDate(d) { /* ... */ }
export function formatCurrency(n) { /* ... */ }
export function debounce(fn, ms) { /* ... */ } // unused below — will be dropped
```

```js
// app.js
import { formatDate, formatCurrency } from "./utils.esm.js";
// bundler statically sees exactly which named exports are used — `debounce` is
// provably unreachable and gets removed from the final bundle entirely
```

```js
// utils.cjs.js — CommonJS: NOT reliably tree-shakeable
function formatDate(d) { /* ... */ }
function formatCurrency(n) { /* ... */ }
function debounce(fn, ms) { /* ... */ }

module.exports = { formatDate, formatCurrency, debounce };
// `require()` and `module.exports` are just regular JS values assigned at runtime —
// a bundler can't statically prove which properties of the exported object are
// actually used without much more limited, fragile static analysis, so most bundlers
// conservatively keep the WHOLE module, including `debounce`, even if it's never called
```

```js
// require() can even be conditional — this is exactly why it's not statically analyzable
if (someRuntimeCondition) {
  module.exports = require("./utils-a");
} else {
  module.exports = require("./utils-b");
}
// a bundler running at build time has no way to know which branch executes at runtime
```

```json
// package.json — unlocking tree shaking for a package with top-level side effects
{
  "name": "@company/ui-kit",
  "sideEffects": false
}
```

```json
// package.json — a package that DOES have real side effects (e.g. injects global CSS),
// listing exactly which files aren't safe to drop even if "unused" — everything else
// is still treated as safely shakeable
{
  "name": "@company/ui-kit",
  "sideEffects": ["./src/globalStyles.css", "./src/polyfills.js"]
}
```

```js
// src/globalStyles.css injection — this is a genuine side effect: importing the module
// does something (injects a <style> tag) even though nothing "uses" an exported value
import "./globalStyles.css"; // must NOT be tree-shaken away, hence listed in sideEffects
```

Without the `sideEffects` field, a bundler seeing `import "./globalStyles.css"` with no destructured import has no way to know whether that import is safe to drop (no side effect) or load-bearing (a real side effect) — the field is exactly the escape hatch that lets the bundler tell the difference and tree-shake aggressively everywhere it's safe to.
