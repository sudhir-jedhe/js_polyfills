# Output: Worked CLS Score Calculation

```
Viewport: 1000px wide x 800px tall (area = 800,000 px²)

A banner ad loads late and inserts itself above an article's text block, pushing
the text block down. Before the shift, the text block occupied the region
y=[200, 600] (400px tall, full 1000px wide) = 400,000 px² of viewport area.
After the shift, it occupies y=[350, 750] (also 400px tall, same width),
having moved down by 150px. This shift happens 2 seconds after page load, with
no user interaction in the preceding 500ms.
```

**Question:** Calculate this individual layout shift's contribution to CLS.

**Answer:**

**Impact fraction** = (union of the element's visible area before and after the shift) / (viewport area).

The union of `y=[200,600]` and `y=[350,750]` (both full 1000px wide) spans `y=[200,750]`, which is `750 - 200 = 550px` tall → union area = `550 * 1000 = 550,000 px²`.

`impact fraction = 550,000 / 800,000 = 0.6875`

**Distance fraction** = (distance moved) / (viewport's largest dimension). The element moved 150px vertically. Viewport's largest dimension is `max(1000, 800) = 1000`.

`distance fraction = 150 / 1000 = 0.15`

**This shift's score** = `impact fraction × distance fraction = 0.6875 × 0.15 = 0.103125`

**Is it counted toward CLS?** Yes — the shift happened with `hadRecentInput = false` (no user interaction in the preceding 500ms, per the spec's exclusion window), so it counts as an *unexpected* shift and contributes fully to the page's cumulative score.

**Verdict against the threshold:** if this were the *only* shift on the page, the cumulative CLS score would be `0.103`, which crosses the "Good" threshold of `≤ 0.1` (barely) into "Needs Improvement" — a single, seemingly modest layout shift (150px, on a page with other content) is enough to push a page out of the "Good" bucket on its own.

**The fix:** reserve space for the banner ad *before* it loads — e.g., a container with an explicit `min-height` matching the ad's expected size, or `aspect-ratio` if the ad's dimensions are known ahead of time — so when the ad's content arrives, it fills already-reserved space rather than pushing existing content down. This converts the "unexpected" shift into no shift at all, since nothing downstream needs to move.
