# Output: Classify Each Style Change as Reflow, Repaint-Only, or Composite-Only

```js
el.style.width = "300px";
el.style.backgroundColor = "blue";
el.style.transform = "translateX(50px)";
el.style.borderColor = "red";
el.style.borderWidth = "4px";
el.style.opacity = "0.5";
el.style.visibility = "hidden";
el.style.display = "none";
el.style.top = "20px";        // (assume el has position: absolute)
el.style.fontSize = "18px";
```

**Question:** For each line, classify it as triggering (a) reflow (→ repaint → composite), (b) repaint only (→ composite), or (c) composite only.

**Answer:**

| Line | Classification | Why |
|---|---|---|
| `width = "300px"` | **Reflow** | Changes box-model geometry directly |
| `backgroundColor = "blue"` | **Repaint only** | Visual-only change, no geometry affected |
| `transform = "translateX(50px)"` | **Composite only** | GPU-compositable, element's layout box/geometry is unaffected — it visually moves without a layout recalculation |
| `borderColor = "red"` | **Repaint only** | Color-only change; contrast with `borderWidth` below |
| `borderWidth = "4px"` | **Reflow** | Border *width* changes the element's box-model dimensions, unlike `borderColor` |
| `opacity = "0.5"` | **Composite only** | Along with `transform`, one of the two canonical GPU-compositable properties |
| `visibility = "hidden"` | **Repaint only** | The element still occupies its layout space (unlike `display: none`) — only its paint/visibility changes |
| `display = "none"` | **Reflow** | Removes the element from the render tree entirely — every sibling/ancestor whose layout depended on its presence must be recalculated |
| `top = "20px"` (position: absolute) | **Reflow** | For a positioned element, `top`/`left`/`right`/`bottom` directly determine its geometry |
| `fontSize = "18px"` | **Reflow** | Changes text metrics, which changes the geometry of the element (and potentially its container, if sized by content) |

**The key contrasts worth internalizing from this table:** `borderColor` (repaint) vs. `borderWidth` (reflow) — same CSS property family, completely different cost tier, because only one of them changes geometry. And `visibility: hidden` (repaint — space still reserved) vs. `display: none` (reflow — space is reclaimed, forcing everything around it to recompute) — both "hide" the element visually, but with a materially different layout consequence, which is a very common trick-question pairing in interviews.
