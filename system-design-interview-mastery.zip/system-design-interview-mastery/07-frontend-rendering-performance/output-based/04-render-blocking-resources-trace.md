# Output: Tracing Render-Blocking Behavior Through a Page Load

```html
<head>
  <link rel="stylesheet" href="styles.css">          <!-- 400ms to download -->
  <script src="analytics.js"></script>                <!-- 300ms to download, no async/defer -->
  <script src="app.js" defer></script>                <!-- 200ms to download -->
</head>
<body>
  <h1>Welcome</h1>
  <script>
    console.log("inline script runs here");
  </script>
  <p>Some content</p>
</body>
```

**Question:** In what order do these resources block HTML parsing and/or rendering, and at what approximate point can the browser first paint any content?

**Answer, traced step by step:**

1. HTML parsing begins, reaches `<head>`.
2. `styles.css` starts downloading. This is a render-blocking resource — the browser continues parsing HTML (building the DOM can continue even while CSS downloads) but **cannot render/paint anything** until the CSSOM is complete, because computing final styles requires the full stylesheet (a later rule could override an earlier one).
3. `analytics.js` (no `async`/`defer`) is encountered next. Because it has neither attribute, it **blocks HTML parsing entirely** — the parser must pause, wait for `analytics.js` to download (300ms) AND execute, before continuing to parse the rest of the document. Critically, this script's execution is *also* implicitly blocked on the CSSOM being ready first (in case the script queries computed styles), so if `styles.css` (400ms) is still downloading when the parser reaches `analytics.js`, the script's execution additionally waits for CSSOM completion — meaning the effective block here is `max(400ms CSS, 300ms JS download) ` before `analytics.js` can execute and parsing can resume.
4. `app.js` has `defer` — its download can happen in parallel with HTML parsing (non-blocking), and its **execution is deferred** until after HTML parsing completes entirely (but before `DOMContentLoaded` fires). It does not block the parser at all.
5. Parsing resumes into `<body>`, builds the DOM node for `<h1>`.
6. The inline `<script>` executes **immediately when the parser reaches it** (inline scripts always block parsing synchronously, same as an unmarked external script) — but by this point, CSSOM is already complete (from step 2/3), so no additional CSSOM wait is needed here.
7. Parsing continues, builds the `<p>` node.
8. HTML parsing completes → `app.js` (deferred) now executes, in the order it appeared relative to other deferred scripts.
9. Only once render tree construction can proceed (DOM is complete enough + CSSOM is complete) does layout, paint, and composite actually happen — first paint cannot occur before `styles.css` finishes downloading and parsing, **regardless of how much of the DOM is ready**, because the browser needs the complete CSSOM to compute final styles correctly.

**First paint timing, approximately:** bounded below by `max(400ms for styles.css, time for analytics.js's blocking download+execute)` — in this trace, roughly 400-700ms depending on exact overlap, **not** immediately after the `<h1>` DOM node exists, precisely because CSS is render-blocking and `analytics.js` additionally delays when the parser even reaches `<body>` at all.

**Optimization takeaways directly from this trace:** marking `analytics.js` as `async` (it doesn't need to run before other scripts or manipulate the DOM during parsing) would let it download without blocking the parser at all; moving non-critical CSS out of the render-blocking path (e.g., via `media` attribute tricks or loading it after first paint) would let first paint happen sooner, bounded only by whatever *is* left render-blocking.
