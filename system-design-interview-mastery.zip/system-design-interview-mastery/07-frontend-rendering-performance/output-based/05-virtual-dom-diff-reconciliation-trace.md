# Output: Tracing a Virtual DOM Diff and the Resulting Real DOM Mutations

```jsx
// Previous render's virtual DOM tree
<ul>
  <li key="a">Apple</li>
  <li key="b">Banana</li>
  <li key="c">Cherry</li>
</ul>

// New render's virtual DOM tree, after state change
<ul>
  <li key="a">Apple</li>
  <li key="d">Date</li>       {/* new item inserted */}
  <li key="b">Banana</li>
  <li key="c">Cherry (ripe)</li> {/* text content changed */}
</ul>
```

**Question:** Walk through what the reconciler's diff produces, and what actual real-DOM mutations get applied — assuming keys are used correctly.

**Answer:**

Because each `<li>` has a stable `key`, the reconciler can match old and new tree nodes by key rather than by position, which is exactly what makes the diff minimal and correct:

- `key="a"` (Apple): present in both trees, same content → **no mutation**.
- `key="d"` (Date): present only in the new tree → **one DOM insertion** — a new `<li>` node created and inserted at the correct position (before the `key="b"` node).
- `key="b"` (Banana): present in both trees, same content, but its **position shifted** (was index 1, now index 2) → depending on the reconciler's specific strategy, this is typically handled as "no content mutation needed, existing DOM node is simply left in its new relative position by virtue of the insertion before it" rather than an explicit move operation for every shifted sibling.
- `key="c"` (Cherry → Cherry (ripe)): present in both trees, but text content differs → **one DOM text-content mutation** on the existing `<li>` node — importantly, the existing DOM node is **reused**, not destroyed and recreated, because the key matched.

**Total real DOM operations: 1 insertion + 1 text update** — despite the *virtual* tree comparison conceptually touching all 4 list items, only 2 of them require an actual real-DOM mutation; the other 2 (`a` and the repositioned `b`) needed zero real DOM writes.

**Now the counterfactual — what happens WITHOUT keys (using array index as the implicit key):**

Without explicit keys, React matches old and new children by **position** instead of identity. Old index 1 was "Banana," new index 1 is "Date" — React would see this as "the element at position 1 changed content" and mutate the *existing* DOM node that used to represent Banana into now representing Date (a text-content mutation), then continue similarly misattributing content down the list — potentially causing more mutations than necessary, and in cases involving component state (not just text), causing **stale state to attach to the wrong logical item** (e.g., an input's focus or a checkbox's checked state ending up on the wrong row after an insertion), because the DOM node identity no longer lines up with the same logical list item across renders.

**Takeaway:** this trace demonstrates the actual mechanism behind the general advice "always use stable keys, never array index, for lists that can reorder/insert/delete" — it's not a style preference, it's what allows the diffing algorithm to correctly minimize real DOM mutations and correctly preserve per-item state across renders.
