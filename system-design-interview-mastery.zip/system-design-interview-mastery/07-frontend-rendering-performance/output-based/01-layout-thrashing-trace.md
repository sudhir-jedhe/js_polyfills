# Output: Tracing Layout Recalculations in a Read/Write Loop

```js
const boxes = document.querySelectorAll(".box"); // 4 elements

boxes.forEach((box) => {
  box.style.width = "100px";        // write 1
  console.log(box.offsetWidth);     // read 1
});
```

**Question:** How many synchronous layout recalculations does this code force, and why?

**Answer: 4 forced synchronous layout recalculations — one per iteration, not one total.**

Trace through why: on iteration 1, `box.style.width = "100px"` invalidates the current layout and queues a new one (the browser doesn't recompute immediately — it would prefer to batch this with other pending changes before the next paint). But the very next line, `box.offsetWidth`, is a layout-dependent **read** — the browser cannot answer it from a stale/queued layout, so it's forced to synchronously flush the pending layout recalculation right then, before returning a value, rather than waiting for its normal batched timing. This happens again on iteration 2 (another write, then another forced read), and again on iterations 3 and 4 — **4 separate forced synchronous layout passes**, each one triggered by the read immediately following a write.

**Contrast — if the loop only wrote, with no interleaved read:**

```js
boxes.forEach((box) => {
  box.style.width = "100px"; // write only
});
console.log("done writing"); // no layout-dependent read here
```
This forces **zero** synchronous recalculations during the loop — all 4 writes queue up, and the browser batches them into a single layout pass whenever it's actually needed (the next paint, or the next layout-dependent read, whichever comes first) — the browser gets to choose the efficient timing because nothing in the loop forces it to answer early.

**The fix, applying the batching principle from `snippets/01-forced-synchronous-layout-thrashing.md`:**

```js
const widths = Array.from(boxes, (box) => box.offsetWidth); // all reads first — ONE layout flush
boxes.forEach((box, i) => { box.style.width = "100px"; });    // all writes after — batched, no forced flush
```
This forces at most **1** synchronous layout flush total (on the very first read, if layout was already dirty from something earlier) instead of 4 — a 4x reduction in this small example, growing linearly worse with element count in the original interleaved version.
