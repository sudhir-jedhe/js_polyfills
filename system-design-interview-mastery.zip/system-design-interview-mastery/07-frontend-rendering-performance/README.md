# Frontend Rendering & Performance

Everything a browser does between receiving bytes over the network and putting pixels on screen — and everything that can go wrong along the way — is what this topic covers. It's one of the most precision-tested areas in frontend interviews specifically because the vocabulary is widely known ("reflow," "virtual DOM," "Core Web Vitals") while the exact mechanisms behind that vocabulary are frequently hand-waved: knowing that `transform` is "cheaper" than animating `top` is table stakes, but explaining *why* — that it skips layout and paint entirely, landing only in the GPU-compositable step — is what separates a strong answer. This topic builds that precision: the critical rendering path step by step, the exact reflow-vs-repaint boundary property by property, when the virtual DOM actually helps (and when it doesn't), the precise definitions and thresholds behind LCP/INP/CLS, and the mechanics of virtualization, code splitting, and bundle optimization.

## Folder structure

- **`theory/`** — the critical rendering path in depth, reflow vs. repaint (precise, property-by-property), virtual DOM vs. real DOM, Core Web Vitals (LCP/INP/CLS) with exact definitions and thresholds, virtualization/windowing for long lists, code splitting and lazy loading strategies, and bundle size optimization (tree shaking, minification, compression as three distinct stages).
- **`snippets/`** — 5 runnable examples: forced synchronous layout thrashing (and the batched-read/write fix), a from-scratch windowed list implementation, dynamic-import code splitting with multiple lazy-loading triggers, ESM vs. CommonJS tree shaking with the `sideEffects` field, and Core Web Vitals field measurement code.
- **`output-based/`** — 5 "given this exact setup, what happens?" questions: tracing forced layout recalculations in a read/write loop, classifying style changes as reflow/repaint/composite-only, a fully worked CLS score calculation, tracing render-blocking resource behavior through a page load, and tracing a virtual DOM diff into its resulting real DOM mutations.
- **`scenarios/`** — 5 real-world situations: diagnosing a poor LCP score end to end, fixing layout thrashing in a drag-to-reorder component, virtualizing a 15,000-row table that freezes the tab, reducing bundle size for users on slow networks/low-end devices, and fixing a CLS regression caused by a late-loading ad network.
- **`interview-qa/`** — 3 themed files: the critical rendering path, Core Web Vitals, and performance optimization techniques.
- **`problems/`** — 3 hands-on challenges: implement a virtualized list component, diagnose and fix a CLS regression from real metrics data, and design a code-splitting strategy for a large multi-section app.
- **`assets/`** — placeholder for diagrams/images (see `assets/README.md`).

## What's covered

- The critical rendering path step by step — HTML parsing → DOM, CSS parsing → CSSOM, JS execution and its parser-blocking behavior, render tree construction, layout, paint, and composite — and precisely which optimization technique intervenes at which step
- Reflow vs. repaint: the exact property-by-property boundary (`border-color` vs. `border-width`, `visibility` vs. `display`), why reflow always implies repaint but not vice versa, and layout thrashing as a concrete, traceable failure mode
- Virtual DOM vs. real DOM: what the VDOM actually is, why diffing it can minimize real DOM mutations, and — just as importantly — where direct DOM manipulation or compile-time fine-grained reactivity (Svelte, SolidJS) outperforms it
- Core Web Vitals — LCP, INP (and why it replaced FID), and CLS — with precise definitions, exact "Good" thresholds, and the specific factors that move each metric
- Virtualization/windowing mechanics for long lists, including the fixed-height vs. variable-height distinction and why the scrollbar still behaves correctly with only a handful of real DOM nodes mounted
- Code splitting and lazy-loading trigger strategies (on-demand, on-hover prefetch, on-viewport, idle-time prefetch) and vendor-chunk splitting for cache efficiency
- Bundle size optimization as three genuinely distinct stages — tree shaking (build-time, ESM-dependent, static analysis), minification (byte-size shrinking), and compression (transfer-time, semantics-blind) — and why none of the three substitutes for the others
